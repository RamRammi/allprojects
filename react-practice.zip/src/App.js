
import './App.css';
import InputField from './components/input-api/input-api';
import MovieTicketBooking from './components/movieBooking/movieBooking';
import TableApi from './components/tableApicall/TableApicall';

function App() {
  return (
    <div className="App">    
    {/* <p>Hello</p> */}
<InputField/>
{/* <TableApi/> */}

<MovieTicketBooking/>

    </div>
  );
}

export default App;
