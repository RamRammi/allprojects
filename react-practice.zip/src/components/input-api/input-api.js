import React, { useEffect, useState }  from 'react';
// import axios from "axios"
import axios from "axios";

const InputField = () => {

const [data , setData] = useState([])

const apicall = async (e) => {    

    try {
    const apidata = await axios.get("https://dummyjson.com/products/search?q=" + e.target.value)
    console.log(apidata.data.products)
   await setData(apidata.data.products)
}
catch (error){


}
}

useEffect(() =>{
    apicall()
}, [])


return(
    <>
    <input onChange={(e)=> apicall(e)}/>
    <select>
   { data && data.length > 0 ? data.map(item => {
        return (
      <option> {item.title}</option>
        )
    }): null
}
 </select>
    </>
)
}
export default InputField;
    // const [data,setData]= useState([])
    // useEffect(() =>{
    //     apiData()
    // }, [])

    // const apiData = async () => {

    //     try {
    //         const response = await axios.get("https://jsonplaceholder.typicode.com/todos")
    //         console.log(response)
    //       await setData(response.data)
    //     } catch (error) {
            

    //     }

    // }

//     useEffect(() =>{
//         apiData()
//     }, [])

//     const apiData = async (e) => {

//         try {
//             const response = await axios.get("https://dummyjson.com/products/search?q=" + e.target.value)
//             console.log(response.data.products)
//           await setData(response.data.products)
          
//         } catch (error) {
            

//         }

//     }


//     return ( 
// <>

// {/* <input type="text" /> */}
// <input onChange={(e)=> apiData(e)}/>
// <select>
//     { data && data.length > 0 ? data.map(item => {
//         return (
//       <option> {item.title}</option>

//         )
//     }): null
// }


// </select>

// </>

//      );
// }

