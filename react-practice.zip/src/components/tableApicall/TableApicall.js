import axios from 'axios';
import React, { useEffect, useState }  from 'react'
import "./TableApiCall.css";
const TableApi  = () => {
 const[tabledata, setTabledata]= useState([]);
 useEffect(()=>{
    tablepi()
},[])
    const tablepi = async () => {
        console.log(tabledata)
        try{
            console.log(tabledata)
            const tableapidata = await axios.get("https://jsonplaceholder.typicode.com/todos")
            console.log(tableapidata.data)
            await setTabledata(tableapidata.data)
        }catch (error){

        }
        console.log(tabledata)
    }
 

    return ( 
        <>
     <div className="tableFixHead">
      <table>
        <thead>
          <tr>
            <th>Col 1</th>
            <th>Col 2</th>
            <th>Col 3</th>
            <th>Col 4</th>
          </tr>
        </thead>
        <tbody>
          
         {tabledata && tabledata.length > 0 ? tabledata.map(item =>{
            console.log(item)
            return (

                <tr>

                <td>{item.title}</td>
                <td>2.5</td>
                <td>1.1</td>
                <td>2.1</td>
              </tr>
            )
}) : null
         }
         
          
        </tbody>
      </table>
    </div>
            
            </>
     );
}
 
export default TableApi ;