import React, { Component } from 'react'
const  MovieTicketBooking= () => {
    return ( 
    <>
    <section className=''>

    </section>
    </>
     );
}
 
export default MovieTicketBooking ;