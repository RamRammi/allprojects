import React from 'react';
import Head from 'next/head'
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';

import Button from '@material-ui/core/Button';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';

import TensionData from './Data/tensiondata.json';
import ProductsList from './Data/productResultList.json';
import QuestionsList from './Data/QuestionsList.json';

import Tension from './Components/tension';
import ProductQuestion from './Components/ProductQuestion';
import FooterComponent from './Components/Footer';


class App extends React.Component {

  render() {
    return (
      <div>
        <Head>
          <meta charset='utf-8' />
          <meta http-equiv='X-UA-Compatible' content='IE=edge' />
          <meta name='viewport' content='width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no' />
          <meta name='description' content='Description' />
          <meta name='keywords' content='Keywords' />
          <title>PGP Advisor</title>
          <link rel="manifest" href="/manifest.json" />
          {/* <link rel='icon' type='image/png' sizes='192x192' href='../public/icons/Hsm-icon-192x192.png' /> */}
          <link rel='icon' type='image/png' sizes='512x512' href='../public/icons/Icon_Bird_512x512.png' />
          <meta name="theme-color" content="#317EFB" />
        </Head>

        <ProductQuestion />
        <Tension></Tension>
        <FooterComponent/>
      </div>
    )
  }
}
export default App;
