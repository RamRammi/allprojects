import React, { useState } from 'react';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import Button from '@material-ui/core/Button';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';

import TensionData from '../Data/tensiondata.json';
import QuestionsList from '../Data/QuestionsList.json';



function Tension() {

    const [tensionData, setTensionData] = useState(0);
    const [product, setProduct] = useState(0);
    const [rtbData, setrtbData] = useState(0);

    const handleChangetensData = (event) => {
        let tensionDataVal = event.target.value;
        let tensionData = [...TensionData];
        tensionData = tensionDataVal;
        setTensionData(tensionData);
    }

    const handleSubmit = () => {
        let arr = tensionData;
        var result = Object.values(arr);
        var product = result[1];
        var rtbData = result[2];
        console.log("heroProduct::", product)
        console.log("rtb::", rtbData);
        setProduct(product)
        setrtbData(rtbData)
    }


    let tensionDataList = TensionData.map((v, i) =>
        <MenuItem value={v}>{v.keyTension}</MenuItem>
    );
    return (
        <div style={{ margin: 'auto', textAlign: 'center' }}>
            <FormControl>
                <InputLabel id="demo-simple-select-label" style={{ width: '350px' }}>Key Tension</InputLabel>
                <Select
                    style={{ width: '300px' }}
                    labelId="demo-simple-select-label"
                    id="demo-simple-select"
                    onChange={handleChangetensData}
                >
                    {tensionDataList}
                </Select>
            </FormControl>
            <br /><br />
            <Button variant="contained" onClick={handleSubmit}>
                Submit
            </Button>

            <TableContainer component={Paper}>
                <Table size="small" aria-label="a dense table">
                    <TableHead>
                        <TableRow>
                            <TableCell style={{ fontWeight: "bold" }}>Product Recommendation</TableCell>
                            <TableCell align="center" style={{ fontWeight: "bold" }}>rtbData</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        <TableRow >
                            <TableCell align="right">{product}</TableCell>
                            <TableCell align="right">{rtbData}</TableCell>
                        </TableRow>
                    </TableBody>
                </Table>
            </TableContainer>
        </div>
    )
}
export default Tension;
