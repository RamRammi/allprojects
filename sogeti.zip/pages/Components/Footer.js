import React from 'react';
import Link from '@material-ui/core/Link';
import Button from '@material-ui/core/Button';
import { makeStyles } from '@material-ui/core/styles';
import BottomNavigation from '@material-ui/core/BottomNavigation';
import FacebookIcon from '@material-ui/icons/Facebook';
import PlayArrowIcon from '@material-ui/icons/PlayArrow';


const useStyles = makeStyles({
    navBar: {
        background: '#003e7d',
        boxSizing: 'border-box', margin: '283px 0px 0px 0px',
        padding: '16px 10px 0px 0px', borderRadius: ' 100% / 30% 30% 0 0', height: '450px', position: 'relative',
        zIndex: '1',
        boxShadow: '0 0 10px 5px #01a0e0'
    },
    mainNavBar: {
        marginLeft: '45px', marginTop: '30px'
    },
    contactLine: {
        display: 'inline-flex', margin: '96px 250px 0px 0px'
    },
    aboutLine: {
        color: 'white', marginLeft: '2px'
    },
    contactUsLine: {
        color: 'white', marginLeft: '15px'
    },
    iStudioLine: {
        display: 'inline-flex', width: '600px', marginTop: '20px'
    },

    mainLine: {
        fontSize: '25px',
        textAlign: 'center',
        color: '#003e7d',
        border: '1px solid white',
        cursor: 'pointer'
    },
    iStudioMainLine: {
        color: 'white', fontSize: '20px', fontFamily: 'inherit',
        fontSize: '100%', textTransform: 'none', boxSizing: 'border-box',
        border: '2px solid rgba(245, 0, 87, 0.04)', fontWeight: '500',
    },
    digitalLine: {
        color: 'white', fontSize: '18px', margin: '-16px 5px 1px 16px',
        width: '500px'
    },
    additionalLine: {
        marginTop: '25px', display: 'inline-flex'
    },
    additionalInformationLine: {
        color: 'white', fontSize: '18px'
    },
    copyRights: {
        color: 'white', fontSize: '18px', float: 'right', marginLeft: '230px'
    },
    adChoice: {
        marginTop: '15px', display: 'inline-flex'
    },
    playIcon: {
        marginTop: '16px', cursor: 'pointer', color: '#01a0e0'
    }
});
function FooterComponent() {
    const classes = useStyles();
    return (
        <div>
            <BottomNavigation className={classes.navBar}>
                <div className={classes.mainNavBar}>
                    <div className={classes.contactLine}>
                        <div className={classes.aboutLine} >About Us</div>
                        <div className={classes.contactUsLine} >Contact Us</div>
                        <div className={classes.contactUsLine} >Privacy</div>
                        <div className={classes.contactUsLine} >CA Privacy</div>
                        <div className={classes.contactUsLine} >Terms & Conditions</div>
                        <div className={classes.contactUsLine} >Do Not Sell My Personal Information</div>
                        <div className={classes.contactUsLine} >Sitemap</div>
                    </div>
                    <div>
                        <div>
                        </div>
                    </div>
                    <div className={classes.iStudioLine}>
                        <div className={classes.mainLine}>
                            <span className={classes.iStudioMainLine}>iSTUDIO</span>
                        </div>
                        <div className={classes.digitalLine}>

                            <span>Your digital warehouse for images, documents, videos, training and other PGPro resources.<Link href="#" style={{ color: '#01a0e0' }}>
                                Get Started
      </Link></span>
                        </div>

                    </div>
                    <div className={classes.additionalLine}>
                        <div className={classes.additionalInformationLine}>
                            For additional information call 1-800-332-7787 Call center hours 24/7, 365 days a year.
         </div>
                        <div className={classes.copyRights}>
                            &copy; 2020 P&G. All Rights Reserved.
         </div>
                    </div>
                    <div className={classes.adChoice}>
                        <div className={classes.additionalInformationLine}>
                            AdChoices
         </div>
                        <div><Link className={classes.playIcon}><PlayArrowIcon /></Link></div>
                    </div>
                </div>
            </BottomNavigation>
        </div>

    )
}
export default (FooterComponent);