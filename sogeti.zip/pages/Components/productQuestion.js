import React, { useState } from 'react';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';

import Button from '@material-ui/core/Button';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import { withStyles } from '@material-ui/core/styles';

import TensionData from '../Data/tensiondata.json';
import ProductsList from '../Data/productResultList.json';
import QuestionsList from '../Data/QuestionsList.json';

const styles = theme => ({
  table: {
    minWidth: 650,
  }
})

function ProductQuestion() {
  const [businessType, setBusinessType] = useState(0);
  const [businessSize, setBusinessSize] = useState(0);
  const [primaryArea, setPrimaryArea] = useState(0);
  const [totalBusinessSizesList, setTotalBusinessSizesList] = useState([]);
  const [totalPrimaryAreasList, setTotalPrimaryAreasList] = useState([]);
  const [productsResultList, setProductsResultList] = useState([]);

  const handleChange = (event) => {
    let businessSizesList = [];
    let primaryAreasList = [];
    let newQuestionsList = QuestionsList
    let businessType = event.target.value
    let mainBusinessSizeList = QuestionsList.filter(v => {
      if (v.BusinessType === businessType) {
        businessSizesList.push(...v.BusinessSize)
        primaryAreasList.push(...v.PrimaryArea);

        const totalBusinessSizesList = [...businessSizesList];
        setTotalBusinessSizesList(totalBusinessSizesList);
        console.log('totalBusinessSizesList', totalBusinessSizesList)

        const totalPrimaryAreasList = primaryAreasList;
        setTotalPrimaryAreasList(totalPrimaryAreasList);

        const BusinessType = businessType;
        setBusinessType(BusinessType)
      }
    })

  };

  const handleBusinessSizeChange = (event) => {
    let businessSize = event.target.value;
    setBusinessSize(businessSize);
  }
  const handlePrimaryAreaChange = (event) => {
    const primaryArea = event.target.value;
    setPrimaryArea(primaryArea);
  }
  const handleSubmitForm = (event) => {
    event.preventDefault();
    let _productsResultList = ProductsList.filter(x => x["BusinessType"] == businessType && x["BusinessSize"] == businessSize && x["PrimaryArea"] == primaryArea)
    let data = ProductsList.ma
    const productsResultList = _productsResultList;
    setProductsResultList(productsResultList);
    console.log('productsResultList', productsResultList)
  }

  let businessList = QuestionsList.map(v =>
    <MenuItem value={v.BusinessType}>{v.BusinessType}</MenuItem>
  );


  let newBusinessSizesList = totalBusinessSizesList.map((v, i) =>
    <MenuItem value={v}>{v}</MenuItem>
  );

  let newPrimaryAreasList = totalPrimaryAreasList.map((v, i) =>
    <MenuItem value={v}>{v}</MenuItem>
  );

  return (
    <div>
      <form onSubmit={handleSubmitForm}>
        <FormControl>
          <InputLabel id="demo-simple-select-label" style={{ width: '150px' }}>Business Type</InputLabel>
          <Select
            style={{ width: '150px' }}
            labelId="demo-simple-select-label"
            id="demo-simple-select"
            onChange={handleChange}
          >
            {businessList}
          </Select>
        </FormControl>
        <FormControl style={{ marginLeft: '20px' }}>
          <InputLabel id="demo-simple-select-label" style={{ width: '150px' }}>Business Size</InputLabel>
          <Select
            style={{ width: '150px' }}
            labelId="demo-simple-select-label"
            id="demo-simple-select"
            onChange={handleBusinessSizeChange}
          >
            {newBusinessSizesList}
          </Select>
        </FormControl>
        <FormControl style={{ marginLeft: '20px' }}>
          <InputLabel id="demo-simple-select-label" style={{ width: '350px' }}>Primary Area</InputLabel>
          <Select
            style={{ width: '300px' }}
            labelId="demo-simple-select-label"
            id="demo-simple-select"
            onChange={handlePrimaryAreaChange}
          >
            {newPrimaryAreasList}
          </Select>
        </FormControl>
        <FormControl style={{ marginTop: '10px' }}>
          <Button variant="contained" type="submit"  >
            Submit
      </Button>
        </FormControl>
      </form>

      <TableContainer component={Paper}>
        <Table size="small" aria-label="a dense table">
          <TableHead>
            <TableRow>
              <TableCell style={{ fontWeight: "bold" }}>Product Recommendation</TableCell>
              <TableCell align="center" style={{ fontWeight: "bold" }}>Size</TableCell>
              <TableCell align="center" style={{ fontWeight: "bold" }}>Description</TableCell>

            </TableRow>
          </TableHead>
          <TableBody>
            {productsResultList.map((row) => (
              <TableRow key={row.ProductRecomendation}>
                <TableCell component="th" scope="row">
                  {row.ProductRecomendation}
                </TableCell>
                <TableCell align="right">{row.Size}</TableCell>
                <TableCell align="right">{row.Description}</TableCell>

              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

    </div>
  )
}
export default ProductQuestion;
