import React from 'react';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import QuestionsList from './Data/QuestionsList.json';
import Button from '@material-ui/core/Button';
import TensionData from './Data/tensiondata.json';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';


class DataTension extends React.Component {
    constructor() {
        super();
        this.state = {
            tensionData: [],
            S1: [],
            S2: [],
        }
    }
    handleChangetensData = (event) => {
        let tensionDataVal = event.target.value;
        this.setState({ tensionData: tensionDataVal })
    }
    handleSubmit = () => {
        let arr = this.state.tensionData;
        var result = Object.values(arr);
        var res1 = result[1];
        var res2 = result[2];
        console.log("heroProduct::", result[1])
        console.log("rtb::", result[2]);
        this.setState({ S1: res1 })
        this.setState({ S2: res2 })
    }

    render() {
        const { productsResultList } = this.state

        let tensionDataList = TensionData.map((v, i) =>
            <MenuItem value={v}>{v.keyTension}</MenuItem>
        );
        return (
            <div style={{ margin: 'auto', textAlign: 'center' }}>
                <FormControl>
                    <InputLabel id="demo-simple-select-label" style={{ width: '350px' }}>Key Tension</InputLabel>
                    <Select
                        style={{ width: '300px' }}
                        labelId="demo-simple-select-label"
                        id="demo-simple-select"
                        onChange={this.handleChangetensData}
                    >
                        {tensionDataList}
                    </Select>
                </FormControl>
                <br /><br />
                <Button variant="contained" onClick={this.handleSubmit}>
                    Submit
                </Button>
                <TableContainer component={Paper}>
                    <Table size="small" aria-label="a dense table">
                        <TableHead>
                            <TableRow>
                                <TableCell style={{ fontWeight: "bold" }}>Product Recommendation</TableCell>
                                <TableCell align="center" style={{ fontWeight: "bold" }}>Description</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            <TableRow >
                                <TableCell align="right">{this.state.S1}</TableCell>
                                <TableCell align="right">{this.state.S2}</TableCell>

                            </TableRow>
                        </TableBody>
                    </Table>
                </TableContainer>
            </div>
        )
    }
}
export default DataTension;
