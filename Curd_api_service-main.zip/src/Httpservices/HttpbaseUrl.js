


import axios from "axios";

const HttpservicesApi = axios.create({
  baseURL: "https://670f3f563e71518616570bdb.mockapi.io/react-curd",
});

export default HttpservicesApi;