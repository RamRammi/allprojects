import HttpservicesApi from "./HttpbaseUrl";

export const Apidata = async(post) => {
            // console.log(post)
        const result = await HttpservicesApi.post("/user",post);
        return result;
}
export const Apiuserdata = async() => {
    const result = await HttpservicesApi.get("/user")
        return result
}

export const Apiuserdelet = async(id) => {
  const result = await HttpservicesApi.delete("/user/"+id)
  return result
}
export const Apiuseredit = async(id) => {
    const result = await HttpservicesApi.get("/user/"+id)
    return result
  }

  export const Apiuserupdate = async(id,post) => {
    const result = await HttpservicesApi.put("/user/"+id,post)
    return result
  }


export default {
    Apidata,
    Apiuserdata,
    Apiuserdelet,
    Apiuseredit,
    Apiuserupdate
}