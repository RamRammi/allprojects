import React, { useEffect, useState } from 'react'
// import Apidata from '../Httpservices/DataService'
import DataService, { Apiuserdelet } from '../Httpservices/DataService'


const Userdata = () => {
  const [id,setId] = useState("")
  const [name,setName] = useState("")
  const [age,setAge] = useState("")
  const [email,setEmail] = useState("")
  const [mobile,setMobile] = useState("")
  const [data,setData] = useState([]);
// get api
  useEffect(() =>{
    getdata()
  }, [])



 const getdata = async() =>{
  try {
    const dat = await DataService.Apiuserdata();
    setData(dat.data)
    console("dat", dat)
     
  } catch (error) {
    console.log(error)
  }
 } 

 // post api
 const submitHandler = async() =>{
   const postobj = {
    name:name,age:age,email:email,mobile:mobile
   }
  //  console.log(postobj)
     await DataService.Apidata(postobj)
     await getdata()
     await clearfileds()
     
 }
 const clearfileds = () =>{

  setName("")
  setAge("")
  setEmail("")
  setMobile("")
 }


 // delete
 const handleDelet = async(S) => {
      console.log(S)
      await DataService.Apiuserdelet(S)
      // getdata() //refresh
      const newdata = data.filter(list => list.id !== S)
      setData(newdata)
 }

 // edit
 
 const handleEdit = async(F) =>{
       console.log(F)
       const res = await DataService.Apiuseredit(F)
       console.log(res.data)
       setName(res.data.name)
       setAge(res.data.age)
       setEmail(res.data.email)
       setMobile(res.data.mobile)
       setId(res.data.id)
 }
 //update
 const updateHandler = async() => {
  const postobj = {
    name:name,age:age,email:email,mobile:mobile
   }
  //  console.log(postobj)
     await DataService.Apiuserupdate(id,postobj)
     await getdata()
     await clearfileds()
     setId("")
 }

console.log(id)
  return (

    <div>
    <h1>User Details</h1>
    Name  : <input value={name} onChange={(e) => setName(e.target.value)}/> <br></br>
    Age   : <input value={age} onChange={(e) => setAge(e.target.value)}/> <br></br>
    Email : <input value={email} onChange={(e) => setEmail(e.target.value)}/> <br></br>
    Mobile: <input value={mobile} onChange={(e) => setMobile(e.target.value)}/> <br></br>
    { id ? <button onClick={() => updateHandler()}>Update</button> : <button onClick={() => submitHandler()}>submit</button>}
    
  
  
    <table style={{width:"100%",tableLayout:"fixed"}}>
   { data && data.length > 0 ?
    data.map((k) => {
        return(

       
              <tr >
                <td style={{border:"1px solid #000"}}>{k.id}</td>
                <td style={{border:"1px solid #000"}}>{k.name}</td>
                <td style={{border:"1px solid #000"}}>{k.age}</td>
                <td style={{border:"1px solid #000"}}>{k.email}</td>
                <td style={{border:"1px solid #000"}}>{k.mobile}</td>
                <td style={{border:"1px solid #000"}}><button onClick={() => handleDelet(k.id)}>delete</button></td>
                <td style={{border:"1px solid #000"}}><button onClick={() => handleEdit(k.id)}>edit</button></td>
              </tr>


       
           )

     }) : null
  
   }
   </table>
</div>

  )
}

export default Userdata