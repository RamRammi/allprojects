
import './App.css';
import Userdata from './datadisplay/Userdata';

function App() {
return (
    <div className="App">
    <Userdata/>
    </div>
  );
}

export default App;
