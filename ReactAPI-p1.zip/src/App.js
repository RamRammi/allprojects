import logo from './logo.svg';
import './App.css';
// import AccordionFun from './components/accordion/accordion';
import UserTable from './components/table';

function App() {
  return (
    <div className="App">
     <UserTable/>
     {/* <AccordionFun/> */}
    </div>
  );
}

export default App;
