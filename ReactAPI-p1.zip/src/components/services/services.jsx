import { baseURL } from "./baseUrl";
import axios from 'axios';

export const Usertabledata = async(endpoint) =>{
   try {
    const url = `${baseURL}/${endpoint}`
    const result = await axios.get(url)
    return result
    
   } catch (error) {
    console.log(`error from  Usertabledata`)
   }

}

export default {
    Usertabledata
}