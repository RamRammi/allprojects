import React from "react";
import { useEffect } from "react";
import { useState } from "react";
import services from "./services/services";

const UserTable = () =>{
    const [data,setData] = useState([])
    const [search,setSearch] = useState('')


    useEffect (()=>{
        getdata()
    },[])
    const getdata = async() =>{
        const result = await services.Usertabledata('/getUser')
        console.log()
            setData(result.data.users)
    }
    return(
        <>
        <p>Table data search</p>
        <p><input type='text' value={search} onChange = {(e) => setSearch(e.target.value)}/> 
        <span><button>search</button></span>
        </p>
        <table>
             <thead>
                <th>name :</th>
                <th>email :</th>
                <th>mobile :</th>
              

             </thead>
            <tbody>
          {
            data.filter((item) =>{
                return search === '' ? item : item.name?.toLowerCase().includes(search) ;
            }).map((item)=>{
                return(
                <tr >
                <td>{item.name}</td>
                <td> {item.email}</td>
                <td>{item.mobile}</td>
                

            </tr>
            )})
          } 
            </tbody>
           
        </table>
        </>
    )
}

export default UserTable