import React, { useState } from 'react';
import './index.css'; 

const AccordionFun = () => {
  const [areAllAccordionsOpen, setAreAllAccordionsOpen] = useState(false);
  const [accordionsState, setAccordionsState] = useState([false, false, false]);

 
  const openAllAccordions = () => {
    setAreAllAccordionsOpen(true);
    setAccordionsState([true, true, true]);
  };

  const closeAllAccordions = () => {
    setAreAllAccordionsOpen(false);
    setAccordionsState([false, false, false]);
  };
  const toggleAccordion = (index) => {
    const newAccordionsState = [...accordionsState];
    newAccordionsState[index] = !newAccordionsState[index];
    setAccordionsState(newAccordionsState);

    setAreAllAccordionsOpen(newAccordionsState.every(state => state));
  };

  return (
    <div>
      <button onClick={openAllAccordions}>Open All Accordions</button>
      <button onClick={closeAllAccordions}>Close All Accordions</button>

      <div className="accordion">
        <AccordionItem
          isOpen={accordionsState[0]}
          title="Accordion 1"
          onClick={() => toggleAccordion(0)}
        >
          Content of Accordion 1
        </AccordionItem>
        <AccordionItem
          isOpen={accordionsState[1]}
          title="Accordion 2"
          onClick={() => toggleAccordion(1)}
        >
          Content of Accordion 2
        </AccordionItem>
        <AccordionItem
          isOpen={accordionsState[2]}
          title="Accordion 3"
          onClick={() => toggleAccordion(2)}
        >
          Content of Accordion 3
        </AccordionItem>
      </div>
    </div>
  );
};

const AccordionItem = ({ isOpen, title, onClick, children }) => {
  return (
    <div className="accordion-item">
      <div className="accordion-header" onClick={onClick}>
        {title}
      </div>
      {isOpen && <div className="accordion-content">{children}</div>}
    </div>
  );
};



export default AccordionFun;
