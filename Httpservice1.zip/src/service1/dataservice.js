import Httpaxios from "./Httpservice";


export const getapidata = async() => {
    const data = await Httpaxios.get('/cude_project');
    return data;
}

export default {
    getapidata
} 