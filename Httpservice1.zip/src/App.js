
import './App.css';
import Datadisplay from './pages/datadisplay'
import Datadisplay1 from './pages1/Datadisplay1';
function App() {
  return (
    <div className="App">
      
     
       
    {/* <Datadisplay/> */}
    <Datadisplay1/>
    </div>
  );
}

export default App;
