import React from 'react'
import { useEffect } from 'react'
import { useState } from 'react'
import dataservice from '../service/dataservice'

const Datadisplay = () => {
    const [data,setData] = useState([])

    useEffect(()=> {
        dataget()
    }, [])

    const dataget = async() =>{
        const Ddata = await dataservice.getdata();
    console.log(Ddata,"testt")
    setData(Ddata)
}
  return (
    <div>
      <span>hello</span>
      {/* { data && data.length } */}
    </div>
  )
}

export default Datadisplay;
