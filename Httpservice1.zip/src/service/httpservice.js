import axios from 'axios'

const axiosService = axios.create({
    baseURL : 'https://633245c8a54a0e83d24e58d8.mockapi.io'
})

export default axiosService

