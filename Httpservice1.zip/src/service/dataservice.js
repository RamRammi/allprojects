import axiosService from "./httpservice";


export const getdata = async() => {
  const dataa = await axiosService.get('/cude_project') 
    return dataa;
}

export default {
    getdata
}