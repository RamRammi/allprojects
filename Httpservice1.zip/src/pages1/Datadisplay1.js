

import React, { useEffect, useState } from 'react'
import dataservice from '../service1/dataservice'

const Datadisplay1 = () => {
    const [data,setData] = useState([])

    useEffect ( () =>{
        getdata()
    },[])

    const getdata = async() => {
        const det = await dataservice.getapidata();
        console.log(det,"hello")
        setData(det.data)

    }
  return (
    <div>
       { data && data.length > 0 ?
       data.map((k) => {
        return(
            <h2>{k.id}</h2>
        )
       }) : null
    }
    </div>
  )
}

export default Datadisplay1
