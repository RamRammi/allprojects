import React from "react";
class Loginpage extends React.Component{
    constructor(props){
        super(props);
        this.state={
            userName : '',
            password : ''
        };
    }
changeUserName = (event)=>{ 
   this.setState({userName:event.target.value},()=>{console.log(this.state.userName)});
   
}
changePassword =(event)=>{
   console.log(this.state.password);
   this.setState({password:event.target.value},()=>{console.log(this.state.password)});
  // console.log(this.state.password);
}
    render(){
        return<div className="container" style={{ width:500,margin: '0 auto'}}> 
            <div className="row" style={{color:'red', textAlign:'center'}}><lable>Login page</lable>  </div>
            <div  style={{display:'flex', justifyContent:'space-between', width:300}}>
                <div><lable>First Name :</lable></div>
               <div> <input type='text'  /*placeholder="First Name"  value={this.state.userName}*/ onChange={this.changeUserName}></input></div>
           </div>
           <div style={{display:'flex', justifyContent:'space-between', width:300}}>
            <div><label>Last Name  :</label></div>
            <div><input type='text' placeholder="Last Name" onChange={this.changePassword}></input></div>
            </div>
            <div style={{display:'flex', justifyContent:'space-between', width:300}}>
           <div> <label>Email  : </label></div>
           <div><input type='Email' placeholder="Email"></input> </div>
           </div>
           {this.state.userName}
        </div>
    }
}
export default Loginpage;