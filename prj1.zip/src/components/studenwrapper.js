import React from "react";

class Studentwrapper extends React.Component{
    // constructor(props){
    //     super(props);
    // };
    render(){
        return <div><p>
 {this.props.name}
  {this.props.rollno}         </p> 
       </div>
    }
}

// function Studentwrapper(props){
//  return <div>
// {`
// student name: ${props.name} 
// student rollno : ${props.rollno} 
//  `}           
//  </div>
//     }
export default Studentwrapper;