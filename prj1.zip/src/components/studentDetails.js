import React from "react";
import Studentwrapper from "./studenwrapper";
class StudentDetils extends React.Component{
  
    render(){
       var students = [{name:'rameshh',rollno:'1'},{name:"devi",rollno:"2"}];
         return <>
{
    students.map((student)=><Studentwrapper name={student.name} rollno={student.rollno} />)
}
<button type></button>
         </>
     }
 }
// function Test(){
// return <p style={{color:'red',fontSize:'25px'}}>This is Testing </p>
// }

export default StudentDetils;  