import React from "react";
import StudentDeatails2 from "./studentdeatils2";
function StudentDetails(props){
    return <div>
{props.name}
{props.rollNumber}
{props.section}

<StudentDeatails2 name2={props.name} rollNumber2={props.rollNumber} section2={props.section}/>
    </div>
}
export default StudentDetails;