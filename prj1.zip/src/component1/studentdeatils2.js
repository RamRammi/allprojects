import React from "react";
class StudentDeatails2 extends React.Component{
    constructor(props){
        super(props);
    }
    render(){
        return <div>
<p> this is {this.props.name2}, my rollNumber is {this.props.rollNuber2} , i'm from {this.props.section2} </p>
        </div>
    }
}
export default StudentDeatails2;