import React from "react";
import StudentDetails from "./studentdetails";
class StudentData extends React.Component{
    constructor(props){
        super(props);
        this.state={
            students:[{name :'ramesh',rollNumber:'1'},{name :'ram',rollNumber:'2'},{name :'ram1',rollNumber:'3'}]};  
    }

    addStudent=()=>{
        var studentAd = this.state.students;
        studentAd.push({name:'kumar',rollNumber:'4'})
        this.setState({students:studentAd});
    }
    render(){
        return<div>
{
    this.state.students.map((student)=><StudentDetails name={student.name} rollNumber={student.rollNumber} section={student.rollNumber%2 === 0 ? 'A' : 'B'}/>)
}
<button onClick={this.addStudent}>Add Student</button>
        </div>
    }
}
export default StudentData;