import React from "react";

const Hoc = (Component) => {
    return (
        class extends React.Component{
            state = {
                auth:true,
                name:'ramesh'
            }
            render(){
                return <div>
                   {this.state.auth ? <Component namee={this.state.name}/> : <h1>Please login</h1> } 
                </div>
            }
        }
    )
}
export default Hoc;