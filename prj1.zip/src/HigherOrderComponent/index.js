import React from "react";
import Hoc from "./HocComponent";
 const App = (props) => {
    
return<>
<h1>{props.namee}</h1>

</>
 }
 export default Hoc(App);