import logo from './logo.svg';
import './App.css';
import DataDisplay from './pages/datadisplay';

function App() {
  return (
    <div className="App">
     
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <DataDisplay />
    </div>
  );
}

export default App;
