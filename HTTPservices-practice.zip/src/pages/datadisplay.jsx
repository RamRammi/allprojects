import React, { Component, useState } from 'react';
import { useEffect } from 'react';
import dataservice from '../services/dataservice';




const DataDisplay = () => {
    const [data,setData] = useState([]);
    useEffect(() => {
        dataget();
    },[])
    const dataget = async() => {
        try {
            const dat = await dataservice.getdata();
            console.log(dat.data,'dat');
            setData(dat.data)
        } catch (error) {
            console.log(error);
        }
       
    }
    return ( 
        <>
            <div>
                {data && data.length > 0 ? 
                    data.map((k) => {
                        return(
                            <h2>{k.firstName}</h2>
                        )
                    }) :null
                }
            </div>
        </>
     );
}
 
export default DataDisplay;