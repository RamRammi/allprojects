import axiosInstance from "./httpservice";


export const getdata = async() => {
    const data = await axiosInstance.get('/cude_project');
    return data;
}

// export const postData = async(post) => {
//     const data = await axiosInstance.get('/cude_project',post);
//     return data;
// }
// export const updateData = async(post) => {
//     const data = await axiosInstance.get('/cude_project',post);
//     return data;
// }
// export const deleteData = async(id) => {
//     const data = await axiosInstance.get(`/cude_project/${id}`);
//     return data;
// }


export default {
    getdata
}   