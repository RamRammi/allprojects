import React, { useState } from 'react';

const FunctForm = () => {

    const [inputFiled, setInputFiled] = useState( [ { name : '', email : '', city : '', statee :''}]);
    const { name , email, city, statee} = inputFiled;


    const updateForm = (event) =>{
     setInputFiled({[event.target.name] : event.target.value})
    }

    const submitForm = (event) => {
        event.preventDefault();
        alert("sucess");

    }


    

    return(
        <>
       <form onSubmit={submitForm}>
        Name :  <input type="text" name="name" value={name} onChange={updateForm}/><br/>
        Email :  <input type="email" name="email" value={email} onChange={updateForm}/><br/>
        State :  <input type="text" name="city" value={city} onChange={updateForm}/><br/>
        city :  <input type="text" name="statee" value={statee} onChange={updateForm}/><br/>
        <button value='submit'>Submit</button>
       

       </form>
       <p>{name}</p>
       <h1>{email}</h1>
       <h1>{city}</h1>
       <h1>{statee}</h1>
        </>
    )
} 


export default FunctForm