import React, { useEffect, useState } from 'react'
import axios from 'axios';


const EmpData = () => {
 const [data,setData] = useState([]);

 useEffect (() =>{
    EmpMainData()
 },[])

 const EmpMainData = async() =>{
    const getApidata = await axios.get("https://633245c8a54a0e83d24e58d8.mockapi.io/cude_project")  ;
    const res = await getApidata.data
    console.log(res,"ress")
    setData(res)
 }

    return ( 
    <>
      <p>hello</p>
  {
      data.map((itemnn,indexx) => {
         return ( 

            <p key={indexx}> {itemnn.firstName} </p>
          )
      }
      )
   }

      </>
    )
  

}
export default EmpData