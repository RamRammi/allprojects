

import './App.css';
import EmpData from './component/EmpData/createnew';
import FunctForm from './component/usestate/functionalform';


function App() {
  return (
    <div>
      {/* <EmpData/> */}
     <FunctForm/>
    </div>
  );
}

export default App;
