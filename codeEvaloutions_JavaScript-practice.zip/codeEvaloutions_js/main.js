// console.log("hello i'm form main.js")

// let age =24
// console.log(age)

// const salary = 80000
// console.log(salary)

// var z

// console.log(z)

// var a= [1,2,3,4,5,6,7,8];
// var b = [ "ram", "ram1", "ram2" , "ram3" ]
// var c= [true,false];


// // for (var i=0 ; i<= a.length-1; i++)
// // {
// //     if(a[i]=== 5)
// // document.writeln(a[i]);
// // elseif()
// // document.writeln(a[i]);
// // }

// // var Adata = a.map(e => e)

// // document.writeln(Adata)

// // push

// // var arr1 = [1,2,4,5,6,7,8,9]
// // document.write(arr1)
// //  arr1.push(3)

// //  document.writeln(arr1)

//  // sort 

//  var sortArr = [1, 9, 91, 2, 3, 4, 5, 6, 7]

//  var yyy = sortArr.map(e => e)
// //  document.writeIn(yyy)
//  document.writeln(yyy  + "<br>")


//     // var a = sortArr.reverse()
//     //   document.writeln(a)

//     // document.writeIn(a)


//     concatarr = a.concat(b,c)
// document.writeln(concatarr)


const target = { a: 1, b: 2, c:"chandu" };

const source = JSON.stringify(target);
 
console.log(JSON.stringify(target))

console.log(JSON.parse(source))