import { html, css, LitElement } from 'lit';

export class MyForm extends LitElement {
  static styles = css`
    form {
      display: flex;
      flex-direction: column;
      max-width: 400px;
      margin: 20px auto;
    }
    label {
      margin-bottom: 8px;
    }
    input {
      padding: 8px;
      margin-bottom: 12px;
    }
    button {
      padding: 10px;
      background-color: blue;
      color: white;
      border: none;
      cursor: pointer;
    }
    button:hover {
      background-color: darkblue;
    }
    .error {
      color: red;
      font-size: 0.9em;
    }
  `;

  constructor() {
    super();
    this.name = '';
    this.email = '';
    this.errors = { name: '', email: '' };
  }

  validateName() {
    if (this.name.trim() === '') {
      this.errors.name = 'Name is required';
    } else {
      this.errors.name = '';
    }
  }

  validateEmail() {
    const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    if (this.email.trim() === '') {
      this.errors.email = 'Email is required';
    } else if (!emailPattern.test(this.email)) {
      this.errors.email = 'Please enter a valid email address';
    } else {
      this.errors.email = '';
    }
  }

  handleSubmit(e) {
    e.preventDefault();
    this.validateName();
    this.validateEmail();

    if (this.errors.name === '' && this.errors.email === '') {
      console.log('Form submitted with:', { name: this.name, email: this.email });
      // Reset form fields after submission if needed
      this.name = '';
      this.email = '';
      this.requestUpdate();
    } else {
      console.log('Form has errors, not submitting.');
    }
  }

  render() {
    return html`
      <form @submit=${this.handleSubmit}>
        <label for="name">Name</label>
        <input
          type="text"
          id="name"
          .value=${this.name}
          @input=${(e) => { this.name = e.target.value; this.validateName(); }}
          required
        />
        ${this.errors.name ? html`<span class="error">${this.errors.name}</span>` : ''}

        <label for="email">Email</label>
        <input
          type="email"
          id="email"
          .value=${this.email}
          @input=${(e) => { this.email = e.target.value; this.validateEmail(); }}
          required
        />
        ${this.errors.email ? html`<span class="error">${this.errors.email}</span>` : ''}

        <button type="submit">Submit</button>
      </form>
    `;
  }
}

window.customElements.define('my-form', MyForm);
