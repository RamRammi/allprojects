import {html, css, LitElement} from 'lit';
import { customElement, property } from 'lit/decorators.js';
import './SayHello1.js' ;
import './MyForm.js';
// @customElement('say-hello')
export class SayHello extends LitElement
{
 
  

  

  

render()


{
    return  html`
    <p>Hello Worlddd123 </p>
   <say-hello1></say-hello1>
     <my-form> </my-form>
    `
}
}
window.customElements.define('say-hello', SayHello);
