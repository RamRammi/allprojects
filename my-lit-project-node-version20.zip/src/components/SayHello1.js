import {html, css, LitElement} from 'lit';

export class SayHello1 extends LitElement
{
render(){
    return html`
    
    <p>hello1</p>
    `
}

}
window.customElements.define('say-hello1',SayHello1)