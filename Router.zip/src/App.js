
import './App.css';
import { Route, Routes } from 'react-router-dom';
import Home from './RouterComponent/Home'
import View from './RouterComponent/View'
import New from './RouterComponent/New'
import Edit from './RouterComponent/edit'
function App() {
  return (
    <div className="App">
      <Routes>
    <Route path='/' element={<Home />} />
    <Route path='/View' element={<View />} />
    <Route path='/New' element={<New/>} />
    <Route path='/Edit' element={<Edit/>} />
   </Routes>
    </div>
  );
}

export default App;
