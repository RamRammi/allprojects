// racf
import React from 'react'
import { Link } from 'react-router-dom'

const Navbar = () => {
  return (
    <div>
      <ul className='navul'>
        <Link to={'/'}><li>Home</li></Link>
        <Link to={'/View'}> <li>View</li></Link>
        <Link to={'/New'}>  <li>New</li></Link>
        <Link to={'/'}><li>About</li></Link>
        <Link to={'/'}> <li>Contact</li></Link>
        <Link to={'/'}><li>Services</li></Link>
       <Link to={'/New'}> <button className='addnewbutton addnewbutton_mar'> Add New</button></Link>
      </ul>

      
    </div>
  )
}

export default Navbar
