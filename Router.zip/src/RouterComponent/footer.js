import React from 'react'
import { useNavigate } from 'react-router-dom'

const Footer = () => {
    const navigate = useNavigate()
    const gotoback = () =>{
        navigate('/')
    }
  return (
    <div>
    <footer className='bgfooter'>

    <button onClick={()=>gotoback()} className='backbutton backbutton-mar'>Back</button>
   </footer>
    </div>
  )
}

export default Footer
