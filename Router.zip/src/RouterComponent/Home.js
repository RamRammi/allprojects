//racf
import React, { useEffect, useState } from 'react'
import axios from 'axios'
import "./Home.css"
import Navbar from './Navbar'
import Footer from './footer'
import { useNavigate } from 'react-router-dom'

const Home = () => {
    const [getdata, setGetdata] = useState([])
    let navigate = useNavigate()
    const baseUrl = "https://633245c8a54a0e83d24e58d8.mockapi.io/cude_project"
    useEffect(() =>{
        getApidata()
    },[])
    const getApidata = async () => {
        try {
            const Apidata = await axios.get(baseUrl)
            // console.log(Apidata.data,"ggg")
            const res = await Apidata.data
            setGetdata(res)
        } catch (error) {
            
        }


    }
    const edit = (data) =>{
      navigate('/Edit',{state:{editdata:data}})
    }
  return (     
    <div>
        <Navbar/>
        <table>
        <tr className='trbgcolor'>
            <th>S.No</th>
            <th>FirstName</th>
            <th>LastNamr</th>
            <th>Phome</th>
            <th>Email</th>
            <th>Action</th>
        </tr>
   {
    getdata.map((item)=>{
        return(
            <tr>
            
                <td><input type="radio"/>{item.id}</td>
                <td>{item.firstName}</td>
                <td>{item.lastName}</td>
                <td>{item.email}</td>
                <td>{item.phone}</td>
                <td>
                    <button className='tdbutton'>Delete</button>
                    <button className='tdbutton'>View</button>
                    <button onClick={()=>edit(item)} className='tdbutton'>edit</button>
                </td>
        
                </tr>
        )
    })
   }
   </table>
 <Footer/>
    </div>
  )
}

export default Home
