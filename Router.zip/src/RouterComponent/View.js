import React from 'react'
// import { useNavigate } from 'react-router-dom'
import { Link } from 'react-router-dom'
import Footer from './footer'
import Navbar from './Navbar'

const  View = () => {
//   let navigate = useNavigate()

//   const gotoHome =()=>{
//     navigate('/')

//   }
  return (
    <div>
     <Navbar/>
      <Link to='/'>Home</Link> 
      <Link to= '/View'>View</Link>
      {/* <button onClick={()=>gotoHome()}>Back</button> */}
      <Footer/>
         </div>
  )
}

export default View
