//racf
import React from 'react'
import Navbar from './Navbar'
import { useState } from 'react'
import axios from 'axios'
import Footer from './footer'
import { useNavigate, useLocation } from 'react-router-dom'

const Edit = () => {
    const location = useLocation()
    console.log(location,"lll")
    const [firstName,setFirstName] = useState(location.state.editdata.firstName)
    const [lastName,setLastname] = useState(location.state.editdata.lastName)
    const [phone,setPhone] = useState('')
    const [email,setEmail] = useState('')
    const navigate = useNavigate()
    const submitHandler = () =>{
        axios.post("https://633245c8a54a0e83d24e58d8.mockapi.io/cude_project",{
            firstName,lastName,phone,email  })
            setFirstName("")
            setLastname("")
            setPhone("")
            setEmail("")
            alert('suess')
           
            navigate('/')



    }

  return (
    <div className='createnew-m'>
      <Navbar/>
      <div className='createnew_div'>
       <div className='createnew-h4'> <h4>Edit Page</h4></div>
        <div className='input-m'>  <input placeholder='FirstName' value={firstName} onChange={(e)=>{setFirstName(e.target.value)}}/></div>
        <div className='input-m'>  <input  placeholder='LasttName' value={lastName} onChange={(e)=>{setLastname(e.target.value)}}/></div>
        <div className='input-m'>   <input  placeholder='Phone' value={phone} onChange={(e)=>{setPhone(e.target.value)}}/></div>
        <div className='input-m'>    <input  placeholder='Email' value={email} onChange={(e)=>{setEmail(e.target.value)}}/></div>
      <button className='submitbutton' onClick={()=>submitHandler()}>Submit </button>

      </div>
    
      <Footer/>
    </div>
  )
}

export default Edit
