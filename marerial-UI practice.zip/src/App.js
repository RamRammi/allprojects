
import Home from "./components/home/home.js";
import SearchAppBar from "./components/header/header.js";

import ResponsiveGrid from "./components/grid/grid.js";

function App() {
  return (
    
    <div className="App">
      <SearchAppBar/>
      <Home/>
      <ResponsiveGrid/>

  
      
    </div>
  );
}

export default App;
