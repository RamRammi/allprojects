import React from 'react'
import { Button } from "@mui/material";
import { Add,Delete,Settings } from "@mui/icons-material";
const Home = () => {
  return (
    <div>
      <p>this is home page</p>
      <Button variant="text" >Text</Button>
    <Button color="secondary" startIcon={<Settings/>}  variant="contained">Settings</Button>

     <Button endIcon={<Add/>}  variant="outlined">Add a new item</Button>
     <Button color="secondary" disabled startIcon={<Delete/>}  variant="contained">Delete</Button>
    </div>
  )
}

export default Home
