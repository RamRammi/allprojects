
import './App.css';
import AppState from './useStatee/useStateLearn';
import CounterApp from './counter/counter';
// import Radiotab from './radiotab/radiotab';
import Namechangeusstate1 from './useStatee/namechangee1';
import Formusestate from './useStatee/formusestate'
import Name from './useStatee/Validation'
import Passwordvalidation from './useStatee/Password';

function App() {
  return (
    <div className="App">
     <AppState/>
     <CounterApp/>
     {/* <Radiotab/> */}
     <Namechangeusstate1/>
     <Formusestate/>
     <Name/>
     <Passwordvalidation/>
     
    </div>
  );
}

export default App;
