import React, { useState } from 'react'

const AppState = () => {
  const [name,setName] = useState("Ramesh")

  const nameHandler = () =>{
    setName("Kumar")
  }
  return (
    <div>
    {name}

    <button onClick={ () => nameHandler()}>Name change</button>
    </div>
  )
}

export default AppState
