import React, { useState } from 'react'

const Validation = () => {
    const [username, setUsername] = useState('')
    const [error, setError] = useState('')

    const updateuser= (e) => {
        setUsername(e.target.value)
    }
    const Validation = (e) => {
        if(username === '' || username === null)
         {
            setError(" blank ")
        }
        // else
        // {
        //     setError( " good")
        // }
    }
      return (
    <div>
   <label>username</label>
   <input 
   type='text' 
   name='username' 
   value={username} onChange={updateuser} /><span>{error}</span>
   <button onClick={Validation}>click</button>
    </div>
  )
}

export default Validation
