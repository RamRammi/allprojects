import React, { useState } from 'react'

const Namechangeusstate1 = () => {

  const [name,updateName] = useState("ram")

  const handleNamechange = (e) =>{
    updateName(e.target.value)
  };
  return (
    <div>
   <input type="text" onChange={handleNamechange}/> 
   {name}
    </div>
  )
}

export default Namechangeusstate1
