import React, { useState } from 'react'

const Formusestate = () => {


    const [inputfiled, setInputFiled] = useState({name:"", email:"",city:"", state:""})
    
    const handlechange = (event) =>{
        setInputFiled({[event.target.name] : event.target.value})
    }
    const submitform = (event) => {
        event.preventDefault();
    }
  return (
    <div>
      <form onSubmit={submitform}>
      name<input type='text'  placeholder='Name'name="name" value= {inputfiled.name} onChange={handlechange}/>
      email<input type='text' placeholder='Email' name='email'  value= {inputfiled.email} onChange={handlechange}/>
     city <input type='text' placeholder                                                                                                                                                                         ='City' name='city' value= {inputfiled.city} onChange={handlechange}/>
     state <input type='text' placeholder='State' name='state'  value= {inputfiled.state} onChange={handlechange}/>
     <button>submit</button>
     </form>      
    </div>
  )
}

export default Formusestate
