import React, { useState } from 'react'

const Passwordvalidation = () => {
    const [password, setPassword] = useState('')
    const [error, setError] = useState('')

    const upadtepassword = (e) =>{
        setPassword(e.target.value)
    }
    const updatecpassword = (e) =>{
        setPassword(e.target.value)
    }
    const pvalidation = () =>{
        if(password === "" || password === null)
        {
            setError('password should not blank and Empty')
        }
        else if(password.length > 4) {
            setError('password should be more than 4 letters')
        }
    }
  return (
    
    <div>
        <lable for ='password'>Password</lable>
      <input
            type="password"
            name =' password'
            value={password} onChange={upadtepassword}/><span> {error}</span><br/>

         <lable for ='password'>CPassword</lable>
      <input
            type="password"
            name =' Cpassword'
            value={password} onChange={updatecpassword}/>

    <button onClick={pvalidation}>Validate</button>

    </div>
  )
}

export default Passwordvalidation
