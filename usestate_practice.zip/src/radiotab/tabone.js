import React from 'react'

const Tabone = () => {
  return (
    <div>
        <p>1</p>
      
    </div>
  )
}

export default Tabone
