import React from 'react'

const Tabsecond = () => {
  return (
    <div>
      <p>2</p>
    </div>
  )
}

export default Tabsecond
