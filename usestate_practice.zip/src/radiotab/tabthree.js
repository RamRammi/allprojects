import React from 'react'

const Tabthree = () => {
  return (
    <div>
      <p>3</p>
    </div>
  )
}

export default Tabthree
