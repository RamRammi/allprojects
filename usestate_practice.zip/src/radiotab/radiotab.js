import React from 'react'
import Tabone from './tabone'
import Tabsecond from './tabsecond'
import Tabthree from './tabthree'

const Radiotab = () => {
  const [selectedradio,setSelectedradio] = ("tabone")
  const handlethree = (e) => {
    setSelectedradio(e.target.value);
  }

  return (
    <div>
        <div className='radios'>
      <input id='tabonee' type="radio"  />
      <input id='tabsecond' type="radio"/>
      <input id='tabthree' type="radio" checked ={selectedradio === "tabthree"}
      onChange={handlethree} />
      </div>

      <div className='tabscointainer'>
        <Tabone/>
        <Tabsecond/>
        <Tabthree/>
        <p className='Colors'>hello suma</p>

      </div>

    </div>
  )
}

export default Radiotab
