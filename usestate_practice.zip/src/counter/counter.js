import React, { useState } from 'react'

const CounterApp = () => {

    const [counter, setCounter] = useState(0)
    const Increment = () => {
        setCounter(counter + 1)
    }

    const decrement = () => {
        setCounter(counter - 1)
    }
console.log(counter,"hhh")
    
  return (
    <div>
      <p>{counter}</p>
      <button onClick={() => Increment()}>+</button>
      <button onClick={() => decrement()}>-</button>
    </div>
  )
}

export default CounterApp
