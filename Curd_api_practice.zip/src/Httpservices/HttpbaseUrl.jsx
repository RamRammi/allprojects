import axios from "axios";

const HttpbaseUrl = axios.create({
     baseURL : "https://670f3f563e71518616570bdb.mockapi.io/react-curd"
})

export default  HttpbaseUrl