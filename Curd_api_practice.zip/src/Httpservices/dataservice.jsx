import HttpbaseUrl from "./HttpbaseUrl";

export const postApiUser = async(post) =>{
  const result = await HttpbaseUrl.post("/user",post)
  return result 
}

export const getApiUser = async() =>{
    const result = await HttpbaseUrl.get("/user")
    return result
}

export const deletAPiuser = async(id) => {
    const result = await HttpbaseUrl.delete("/user/"+id)
    return result
}
export const editapiuser = async(id) => {
    const result = await HttpbaseUrl.get("/user/"+id)
    return result
}
export default {
    postApiUser,
    getApiUser,
    deletAPiuser,
    editapiuser
}