
import './App.css';
import Userdata from './components/userdata';

function App() {
  return (
    <div className="App">
  <Userdata/>
    </div>
  );
}

export default App;
