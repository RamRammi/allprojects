import React, { useEffect, useState } from 'react'
import dataservice from '../Httpservices/dataservice'
const Userdata = () => {
    const [name,setName] = useState("")
    const [age,setAge] = useState("")
    const [email,setEmail] = useState("")
    const [mobile,setMobile] = useState("")
    const [data,setData] = useState([])
    const [id,setId] = useState("")

    //post data 

    const submitHandler = async() =>{

        const postobj = {name:name,
                          age:age, email: email , mobile : mobile      
                          }
        await dataservice.postApiUser(postobj)      
        setName("")     
        setAge("")
        setEmail("")
        setMobile("")

    }
    //get user data
  useEffect(()=> {
     getdata()
  },[])

  const getdata = async() => {
    try {
        const det = await dataservice.getApiUser()
        console.log(det)
        setData(det.data)
        
    } catch (error) {
        
    }
   
  }

  //delet user

  const handleDelet = async(F) =>{
      await dataservice.deletAPiuser(F)
      const newdata = data.filter(list => list.id !== F)
      setData(newdata)

  }

  //edit 

  const handleEdit = async(S) =>{
    const res = await dataservice.deletAPiuser(S)
    setName(res.data.name)
    setAge(res.data.age)
    setEmail(res.data.email)
    setMobile(res.data.mobile)





  }


  return (
    <div>
      <h1>User Deatils</h1>
      Name :<input value={name} onChange = {(e) => setName(e.target.value)}/><br></br>
      Age :<input value={age} onChange = {(e) => setAge(e.target.value)}/><br></br>
      Email :<input value={email} onChange = {(e) => setEmail(e.target.value)}/><br></br>
      Mobile :<input value={mobile} onChange = {(e) => setMobile(e.target.value)}/><br></br>
      <button onClick={() => submitHandler()}>submit</button>


<table style={{width : "100%",tableLayout : "fixed"}}>
    <tr>
        <th>Name</th>
        <th>Age</th>
        <th>Emaik</th>

        <th>Mobile</th>

    </tr>
{  data && data.length > 0 ? 
   data.map((k) =>  {

    return(
    <tr>
        <td>{k.id}</td>
        <td>{k.name}</td>
        <td>{k.age}</td>
        <td>{k.email}</td>
        <td>{k.mobile}</td>
        <td><button onClick={() => handleDelet(k.id) }>Delet</button></td>
        <td><button onClick={() => handleEdit(k.id)}>Edit</button></td>
    </tr>
    ) })   : null }
</table>
    </div>
  )
}

export default Userdata
