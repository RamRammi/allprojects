import React from 'react'
import { useNavigate } from 'react-router-dom'
//import { Link } from 'react-router-dom'

function View() {
  let navigate = useNavigate()

  const gotoHome =()=>{
    navigate('/')

  }
  return (
    <div>
      view
      {/* <Link to='/'>Home</Link>  */}
      <button onClick={()=>gotoHome()}>Back</button>
         </div>
  )
}

export default View
