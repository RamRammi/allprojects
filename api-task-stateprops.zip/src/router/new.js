import React from 'react'

function new() {
  return (
    <div>
      new
    </div>
  )
}

export default new
