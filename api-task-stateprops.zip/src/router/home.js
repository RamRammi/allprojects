import React from 'react'

function home() {
  return (
    <div>
      Home
    </div>
  )
}

export default home
