import React from 'react'

function edit() {
  return (
    <div>
      edit
    </div>
  )
}

export default edit
