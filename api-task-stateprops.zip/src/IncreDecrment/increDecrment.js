import React, { useState } from 'react'

const IncreDecrment = () => {

    const [count,setCount] = useState(1)

    function Incre (){

        setCount(prevCount => prevCount + 1)
    }
    function Decre (){

        setCount(prevCount => prevCount - 1)
    }
    return ( 
        <>
        <button onClick={Decre}>-</button>
        <button onClick={Incre}>+</button>
        <span> {count}</span>
        </>
     );


}
 
export default IncreDecrment;