//racf 
import React, { useState } from 'react'
import Propsp from './propsp';

const Statename = () => {
    const [name,setname] = useState("ramesh");

  return (
    <div>
      {name}    
      <Propsp names={name}/>  
    </div>
  )
}

export default Statename



