//racf 
import React from 'react'

const Propsp = (props) => {
    

  return (
    <div>
    Hello  {props.names}      
    </div>
  )
}

export default Propsp



