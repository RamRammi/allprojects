import React, { useState } from 'react';

const MyTable = () => {
  const [selectedRow, setSelectedRow] = useState(null);

  const handleRadioChange = (rowIndex) => {
    setSelectedRow(rowIndex);
  };

  return (
    <table>
      <thead>
        <tr>
          <th>Select</th>
          <th>Edit</th>
        </tr>
      </thead>
      <tbody>
        {data.map((row, index) => (
          <tr key={index}>
            <td>
              <input
                type="radio"
                checked={selectedRow === index}
                onChange={() => handleRadioChange(index)}
              />
            </td>
            <td>{selectedRow === index ? <input type="text" /> : row.editableContent}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default MyTable;
