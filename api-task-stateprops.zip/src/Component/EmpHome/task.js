// import { Component } from 'react';
// export default class TodoList extends Component {
//     constructor(props){
//         super(props);
//         this.state = {list:[],item:{value:'',isStriked:''}}

//         this.addItem = this.addItem.bind(this)

//          this.handleChange = this.handleChange.bind(this);

//           this.handleStrike = this.handleStrike.bind(this);

//           this.handleremaining = this.handleremaining.bind(this);

//     }




//     addItem(e){

//         this.setState({item:{value:e.target.value,isStriked:false}})

//     }

//     handleChange(e){

//         e.preventDefault();

//         const list = [...this.state.list];

//         list.push(this.state.item)

//       this.setState({list:list,item:{value:'',isStriked:''}});

      

//     }

//     handleStrike(item){

         

//         let list = [...this.state.list];

       

//         list.map((x) => {

//           return x.value === item.value?x.isStriked=!x.isStriked: x;

//       })

//         this.setState({list:list})

       

//     }

//    handleremaining(){

//     return  this.state.list.filter(x=>x.isStriked!==true).length

    

   

//    }

   

//     render() {

//         return (

//             <>

//                 <div>

//                    <input type="text" value = {this.state.item.value} onChange={this.addItem}/>

//                    <button type="submit" onClick = {this.handleChange}>Add</button><br/>

//                    <span className="task-counter">{this.handleremaining()}  remaining out of {this.state.list.length} tasks</span>

//                    <ul>{this.state.list.map(item=><li onClick={this.handleStrike.bind(this,item)} className={item.isStriked &&`is-done`}>{item.value}</li>)}</ul>

//                 </div>

//                 <style>{`

//                     .is-done {

//                         text-decoration: line-through;

//                     }

//                 `}</style>

//             </>

//         );

//     }

// }







 //  ****************  task done with some issue


// import cx from 'classnames';
// import { Component } from 'react';

// export default class TodoList extends Component {
//     constructor(props){
//         super(props);
//         this.state = {todos: [], newId :0,task: 0,remaingTask:0};
//         this.handlesubmit = this.handlesubmit.bind(this);
//         this.handletodoClick = this.handletodoClick.bind(this);

//     }

//     handlesubmit(e){
//         e.preventDefault();
//         const newtodo = {
//             id : this.state.newId, 
//             lable : e.target[0].value,
//             done : false,
//         };
    
//         if (!newtodo.lable) return;
//         this.setState((state) => ({
//             todos:[...state.todos, newtodo],
//             newId : state.newId + 1 ,
//             task : state.task + 1,
            
//         }));
//         e.target[0].value = "";
//     }
//         handletodoClick (index) {
//             const updatedtodos =JSON.parse(JSON.stringify(this.state.todos));
//             updatedtodos[index].done = !updatedtodos[index].done;
//             this.setState((state) => ({
//                 ...state,
//                 todos :updatedtodos,


//             })) 
                   

//     }
//     render() {  


//         return (
//             <>
//                 <div>
                   
//                     <form  onSubmit = {this.handlesubmit}>
//                     <input type ="text" name="todo"/>
//                     <input type= "submit" value="add"/>
                   

//                     </form>
//                      <h3>{this.state.task} remaining out of {this.state.task} tasks</h3>

//                     {
//                         this.state.todos.map((todo,idx) => (
//                             <div

//                             key={todo.id}
//                             onClick = {()=> this.handletodoClick(idx)}
//                             className={cx({done:todo.done})}
//                             >
                            
//                             {todo.lable}

//                             </div>
//                         ))
//                     }
                  
//                 </div>
//                 <style>{`
//                     .done {
//                         text-decoration: line-through;
//                     }
//                 `}</style>
//             </>
//         );
//     }
// }


// *************** using  Functional component 


// import React, { useState } from 'react';

// const TodoList = () => {
//   const [items, setItems] = useState([]);
//   const [newItem, setNewItem] = useState('');

//   const handleInputChange = (event) => {
//     setNewItem(event.target.value);
//   };

//   const handleAddItem = () => {
//     if (newItem.trim() !== '') {
//       setItems([...items, newItem]);
//       setNewItem('');
//     }
//   };

//   const handleToggleItem = (index) => {
//     const updatedItems = [...items];
//     updatedItems[index] = updatedItems[index].startsWith('~~')
//       ? updatedItems[index].substring(2)
//       : `~~${updatedItems[index]}`;

//     setItems(updatedItems);
//   };

//   return (
//     <div>
//       <input type="text" value={newItem} onChange={handleInputChange} />
//       <button onClick={handleAddItem}>Add</button>
//       <ul>
//         {items.map((item, index) => (
//           <li
//             key={index}
//             style={{
//               textDecoration: item.startsWith('~~') ? 'line-through' : 'none',
//             }}
//             onClick={() => handleToggleItem(index)}
//           >
//             {item.startsWith('~~') ? item.substring(2) : item}
//           </li>
//         ))}
//       </ul>
//     </div>
//   );
// };

// export default TodoList;




import React, { useState } from 'react';

const TodoList = () => {
  const [items, setItems] = useState([]);
  const [newItem, setNewItem] = useState('');

  const handleInputChange = (event) => {
    setNewItem(event.target.value);
  };

  const handleAddItem = () => {
    if (newItem.trim() !== '') {
      setItems([...items, { text: newItem, isCompleted: false }]);
      setNewItem('');
    }
  };

  const handleToggleItem = (index) => {
    const updatedItems = [...items];
    updatedItems[index].isCompleted = !updatedItems[index].isCompleted;
    setItems(updatedItems);
  };

  const countTotalItems = () => {
    return items.length;
  };

  const countCompletedItems = () => {
    return items.filter((item) => item.isCompleted).length;
  };

  return (
    <div>
      <input type="text" value={newItem} onChange={handleInputChange} />
      <button onClick={handleAddItem}>Add</button>
      <ul>
        {items.map((item, index) => (
          <li
            key={index}
            style={{
              textDecoration: item.isCompleted ? 'line-through' : 'none',
            }}
            onClick={() => handleToggleItem(index)}
          >
            {item.text}
          </li>
        ))}
      </ul>
      <p>Total Items: {countTotalItems()}</p>
      <p>Completed Items: {countCompletedItems()}</p>
    </div>
  );
};

export default TodoList;

