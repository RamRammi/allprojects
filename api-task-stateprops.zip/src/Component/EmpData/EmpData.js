// CURD rfce

import React, { useEffect, useState } from 'react'
import axios from 'axios'
import "./Emp.css"

function EmpData() {
    const[data, setData] = useState([])
    useEffect(()=>{
        // getData()
        mainData()
    },[])

   
    // const getData = ()=>{
    //    axios.get('https://633245c8a54a0e83d24e58d8.mockapi.io/cude_project')
    //   .then(res => setData(res.data))
    //   console.log(data, 'data')
    // }

    const mainData = async() =>{
        const getData = await axios.get('https://633245c8a54a0e83d24e58d8.mockapi.io/cude_project')
        const responce = await getData.data
        setData(responce)
        console.log(responce, 'responce dat')
    }
  return(
    <>
    <p>Emp Data</p>
    <table className='table'>
    <tr>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Email</th>
        <th>Phone</th>
    </tr>


    {
        data.map((item,inx) =>{
            return(
                <tr>
                <td>{item.firstName}</td>
                <td>{item.lastName}</td>
                <td>{item.email}</td>
                <td>{item.phone}</td>
                </tr>
            )
        })
    }
            </table> 
    </>
  )
}

export default EmpData


// // CURD rfce racf

// import React, { useEffect, useState } from 'react'
// import axios from 'axios'

// function EmpData() {
//     const[data, setData] = useState([])
//     useEffect(()=>{
//         // getData()
//         mainData()
//     },[])

   
//     // const getData = ()=>{
//     //    axios.get('https://633245c8a54a0e83d24e58d8.mockapi.io/cude_project')
//     //   .then(res => setData(res.data))
//     //   console.log(data, 'data')
//     // }

//     const mainData = async() =>{
//         const getData = await axios.get('https://633245c8a54a0e83d24e58d8.mockapi.io/cude_project')
//         const responce = await getData.data
//         setData(responce)
//         console.log(responce, 'responce dat')
//     }
//   return(
//     <>
//     <div className='container'>
//     <p>Emp Data</p>
//     <table className='table table-bordered'>
//     <tr>
//         <th>SL NO</th>
//         <th>ID</th>
//         <th>First Name</th>
//         <th>Last Name</th>
//         <th>Email</th>
//     </tr>


//     {
//         data.map((item,inx) =>{
//             return(
                
//                 <tr key={inx}>
//                     <td>{inx+1}</td>
//                     <td>{item.id}</td>
//                     <td>{item.firstName}</td>
//                     <td>{item.lastName}</td>
//                     <td>{item.email}</td>

//                 </tr>
//             )
//         })
//     }
//             </table> 
//             </div>
//     </>
//   )
// }

// export default EmpData
