// import React, { useEffect, useState } from 'react'
// import axios from 'axios'


 
// const ApiIntegration = () => {
//     const [apidata,setApiData] = useState([])
//     const baseURL = "https://633245c8a54a0e83d24e58d8.mockapi.io/cude_project"

//     useEffect(() => {
//         getApi()
//         }, [])
        
//         const getApi = async() => {
//         try {

//         const getdata = await axios.get(baseURL)
//         const res = await getdata.data
//         console.log(getdata,"resss")
//         setApiData(res)
        
//        } catch (error) {
        
//        }
//         }
  
//     return(
//         <div>

//        {
//         apidata.map((i)=>{
//             return (
//                 <div>
//                     {i.firstName}
//                     </div>
//             )
//         })
//        }
//         </div>

//     )
// }

// export default ApiIntegration

// import React, { useEffect, useState } from 'react'
// import axios from "axios"
// const ApiIntegration = () => {

//     const [Apidata,setApidata] = useState([])
//     const baseURL = "https://633245c8a54a0e83d24e58d8.mockapi.io/cude_project"
//     useEffect(()=>{
//         getApi()
//     },[])

//     const getApi = async() => {
       
//         try {
//             const res = await axios.get(baseURL)
//             const apii = await res.data
//           //  console.log(apii,"reee")

//             setApidata(apii)
//         } catch (error) {
            
//         }
//     }
//     return(
//        <>
//        {console.log('Apidata', Apidata)}
//        <div>test</div>
//        {
//         Apidata.map((i)=>{
//             return (
//                 <div>
//                     {i.firstName}
//                     </div>
//             )
//         } )
//        }
//        </>
//     )
// }
// export default ApiIntegration

// import axios from 'axios'
// import React, { useEffect, useState } from 'react'

// const ApiIntegration = () => {
    
// const [apidata,setApidata] = useState([])

// useEffect(() =>{
//     getApi()
// },[])

// const getApi=  async() => {
//  try {
//     const ApiInt = await axios.get("https://633245c8a54a0e83d24e58d8.mockapi.io/cude_project")
//     console.log(ApiInt,"ttt")
//     const res = await ApiInt.data
//     setApidata(res)

//  } catch (error) {
    
//  }

// }
// return(
//     <div>

// {
//     apidata.map((i) =>{
//         return(
//             <div>
//                 {i.firstName}
//                 </div>
//         )
//     })
// }
//     </div>
// )

// }

// export default ApiIntegration

import axios from 'axios'
import React, { useEffect, useState } from 'react'

const ApiIntegration =() =>{
    const [data, setData] = useState([])
    const baseUrl= "https://633245c8a54a0e83d24e58d8.mockapi.io/cude_project"

    useEffect(()=>{
        getapi ()
    }, [])
    const getapi = async() =>{
        try {
            const ApiData = await axios.get(baseUrl)
            // console.log(ApiData.data,"ress")
            const res = await ApiData.data
            setData(res)
        } catch (error) {
            
        }
       
    }
    return(
        <div>

            <table>
                <tr style="border: 1px solid">
                    <th>id </th>
                    <th>FirstName </th>
                    <th>LastName</th>
                    <th>Phone</th>
                    </tr>
            </table>
            {
                data.map((item)=>{
                    return(
                        <>
                      <tr>  <td>{item.firstName}</td>
                       <td>{item.lastName}</td>
                       <td>{item.phone}</td>
                        <td>{item.email}</td></tr>
                        </>
                    )
                })
            }
        </div>
    )
}
export default ApiIntegration
