
import {useState} from 'react'

 const Task2 = (props) => {
const clickchild = () => {
   props.onClick('mahesh')
}
 return(
    <div>
        
    {props.dat}
    <button onClick={() => clickchild()}>Click ME</button>
        </div>
 )
 }
export default Task2


