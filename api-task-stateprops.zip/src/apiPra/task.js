
import {useState} from 'react'
import Task2 from './task2'

 const Task = () => {
    const [data,setdata] = useState("ramesh")
 const getdata = () => {
 
    setdata("rakesh")
 }
const getchild = (item) => {
    setdata(item)
}
 return(
    <div>
        
    <Task2  onClick={() => getchild()} dat={data} />
       <button  className=''  onClick={() => getdata()}>Click</button>
        </div>
 )
 }
export default Task


