// import axios from 'axios'
// import React, { useState } from 'react'

// const Postapi = () => {
//     const [firstName,setFirstName] = useState("")
//     const [surename, setSurename] = useState("")
//     const [phone, setPhone] = useState("")
//     const [email,setEmail] = useState("")

//     const submithandler = () => {
//         axios.post('https://633245c8a54a0e83d24e58d8.mockapi.io/cude_project',{
//             firstName,surename,phone,email
//         })

//         setFirstName('')
//         setSurename('')
//         setPhone('')
//         setEmail('')

//     }

//     return(
//         <div>
//             <input value={firstName}  onChange={(e)=>setFirstName(e.target.value)}/>
//             <input value={surename} onChange={(e)=>setSurename(e.target.value)}/>
//             <input value={phone} onChange={(e)=>setPhone(e.target.value)}/>
//             <input value={email} onChange={(e)=>setEmail(e.target.value)}/>
//             <button  onClick={()=> submithandler() }> Submit</button>
//         </div>
//     )
// } 
// export default Postapi


import axios from 'axios'
import React, { useState } from 'react'

const Postapi = () =>{
    const [firstName, setFirstname] = useState("")
    const [surename, setSurename] = useState("")
    const [Phone, setPhone] = useState("")
    const [email, setEmail] = useState("")

    const submitHandler = () => {
        axios.post("https://633245c8a54a0e83d24e58d8.mockapi.io/cude_project", {
            firstName,surename,Phone,email
        })
        setFirstname("")
        setSurename("")
        setPhone("")
        setEmail("")
    }

    return(
        <div>
       FirstName : <input onChange={(e)=>setFirstname(e.target.value)}/><br></br>
      SurName : <input onChange={(e)=>setSurename(e.target.value)}/><br></br>
       Phone : <input onChange={(e)=>setPhone(e.target.value)}/><br></br>
     Email :  <input onChange={(e)=>setEmail(e.target.value)}/><br></br>
       <button onClick={()=>submitHandler()}>submit</button>

        </div>
    )
}
export default Postapi