
import './App.css';
import EmpData from './Component/EmpData/EmpData';
// import IncreDecrment from './IncreDecrment/increDecrment';
import 'bootstrap/dist/css/bootstrap.min.css';
// import TodoList from './Component/EmpHome/task';
// import Statename from './Component/ReactPractice/statep';
// import ApiIntegration from './apiPra/apiIntegration';
import Task from './apiPra/task';
// import Postapi from './apiPra/postapiIntegration';
// import { Route, Routes } from 'react-router-dom';
// import Home from './router/home'
// import View from './router/view'

function App() {
  return (
    // <div className="App">
    //  <IncreDecrment/>
    // </div>
    <>
    {/* <EmpData /> */}
    {/* <TodoList/>  */}
   {/* <Statename/> */}
   {/* <ApiIntegration/> */}
   <Task/>
   {/* <Postapi/> */}
   {/* <Routes>
    <Route path='/' element={<Home />} />
    <Route path='/view' element={<View />} />
   </Routes> */}
    </>
  );
}

export default App;
