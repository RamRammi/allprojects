// this is for signin script

let userElement = document.getElementById("uservalue");
console.log(userElement,"sss")
let userstatusvalu = document.getElementById("statuscheck");

function signin(){
 let getuservalue = document.getElementById("uservalue").value;
 let verifyinput = "Hi" + getuservalue + "verifing you account"
userstatusvalu.textContent = verifyinput
      

}



// this script random number game

let userInput = document.getElementById("userinput")
console.log(userInput)
let gameresultvalue = document.getElementById("gameresult")
let randomnumber = Math.ceil(Math.random() * 100)
console.log(randomnumber)

function checkGuess(){
        let randomvaluee = (userInput.value)
        console.log(randomvaluee)

        if (randomvaluee > randomnumber) {
                gameresultvalue.textContent="this is higher "
        }
        else if (randomvaluee < randomnumber)
        {
            gameresultvalue.textContent="this is small "
        }
   
        else (randomvaluee === randomnumber)
        {
            gameresultvalue.textContent="correctl "
        }
   
}