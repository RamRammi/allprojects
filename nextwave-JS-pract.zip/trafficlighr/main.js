// #008000 green 
// #FF0000 red
// #FFFF00 yellow
function stopBtn(){
   

    document.getElementById("stop-signal").style.backgroundColor = "#ffc0cb"
    document.getElementById("go-signal").style.backgroundColor = "#ccc"
    document.getElementById("ready-signal").style.backgroundColor = "#ccc"

    
    document.getElementById("stopcolor-light").style.backgroundColor = "#ffc0cb"
    document.getElementById("gocolor-light").style.backgroundColor = "#ccc"
    document.getElementById("readycolor-light").style.backgroundColor = "#ccc"
    


}
function goBtn(){

    
    document.getElementById("stop-signal").style.backgroundColor = "#ccc"
    document.getElementById("go-signal").style.backgroundColor = "#008000"
    document.getElementById("ready-signal").style.backgroundColor = "#ccc"
   
    document.getElementById("stopcolor-light").style.backgroundColor = "#ccc"
    document.getElementById("gocolor-light").style.backgroundColor = "#008000"
    document.getElementById("readycolor-light").style.backgroundColor = "#ccc"



}function readyBtn(){
   
    
    document.getElementById("stop-signal").style.backgroundColor = "#ccc"
    document.getElementById("go-signal").style.backgroundColor = "#ccc"
    document.getElementById("ready-signal").style.backgroundColor = "#FFFF00"

    document.getElementById("stopcolor-light").style.backgroundColor = "#ccc"
    document.getElementById("gocolor-light").style.backgroundColor = "#ccc"
    document.getElementById("readycolor-light").style.backgroundColor = "#FFFF00"



}