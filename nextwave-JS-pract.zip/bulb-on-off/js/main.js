
function switchOn() {
    document.getElementById("ONOFF-img").src="./img/On.png"
    document.getElementById("switch-statu").textContent="Switch On"
    document.getElementById("On-bg").style.backgroundColor="#808080"
    document.getElementById("Off-bg").style.backgroundColor="#FF0000"
}


function switchOff() {

    document.getElementById("ONOFF-img").src="./img/Off.png"
    document.getElementById("switch-statu").textContent="Switch Off"
    document.getElementById("Off-bg").style.backgroundColor="#808080"
    document.getElementById("On-bg").style.backgroundColor="#008000"

}