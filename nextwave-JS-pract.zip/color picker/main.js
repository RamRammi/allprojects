let colorpick = document.getElementById("color-status")

function color1() {
 document.getElementById("colorpickercontainer").style.backgroundColor = "#FF0000"
    colorpick.textContent ="this is red"
}
function color2() {
    document.getElementById("colorpickercontainer").style.backgroundColor = "#FFFF00"
    colorpick.textContent ="this is yellow"
       
   }
   function color3() {
    document.getElementById("colorpickercontainer").style.backgroundColor = "#008000"
    colorpick.textContent ="this is greeen"
       
   }
   function color4() {
    document.getElementById("colorpickercontainer").style.backgroundColor = "#7F00FF"
    colorpick.textContent ="this is violet"
       
   }