
var presentvalue = document.getElementById("currentvalue")
function incBtn(){
    let previousevalue = presentvalue.textContent
    console.log(textContent,"PV")
    let updatedvalue = parseInt(previousevalue) + 1 
    presentvalue.textContent = updatedvalue

}

function decBtn(){

    let previousevalue = presentvalue.textContent
    let updatedvalue = parseInt(previousevalue) - 1 
    presentvalue.textContent = updatedvalue

}

function reSet (){
    let updatedvalue = 0;
    presentvalue.textContent = updatedvalue
  
}