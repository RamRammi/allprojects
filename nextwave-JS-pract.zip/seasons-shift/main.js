
function allSeasons() {
    document.getElementById("slect-img").src = "./img/all-seasons.png"
}
function springButton(){

    document.getElementById("slect-img").src ="./img/spring.png"
}
function summerButton(){

    document.getElementById("slect-img").src ="./img/summer.png"
}

function authumButton(){

    document.getElementById("slect-img").src ="./img/authum.png"
}

function winterButton(){

    document.getElementById("slect-img").src ="./img/winter.png"
}



