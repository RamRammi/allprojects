let ppImage =     document.getElementById("puppyImg")
function likeImg(){

   if(ppImage.src = "./img/puppy1.png"){
     ppImage.src="./img/puppy2.png"
    document.getElementById("likebutton").style.backgroundColor= "#0000FF"
    document.getElementById("iconcar").style.color= "#0000FF"
}
else if(ppImage.src = "./img/puppy2.png"){
    ppImage.src="./img/puppy1.png"
}
}

function reset() {
    ppImage.src="./img/puppy1.png"
      document.getElementById("likebutton").style.backgroundColor= "#FFF"
    document.getElementById("iconcar").style.color= "black"
}