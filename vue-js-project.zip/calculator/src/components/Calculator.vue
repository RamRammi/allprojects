<template>
  <div class="hello">
    <h1 class="title">{{ msg }}</h1>
<div class="col-md-4 center ">
  <table class="table table-bordered table-bg">
 
  <tbody>
    <tr class="output">
       <td colspan="4">{{output || 0}}</td>
    </tr>
    <tr>
   <td v-on:click="clearField">c</td>
      <td v-on:click="setNagativeOrPositive">+/-</td>
      <td v-on:click="calculatePercentage">%</td>
      <td class="last-coloum"
      @click="processOutput('divide')"><i class="fa-solid fa-divide"></i></td>
    </tr>
    <tr>
      <td v-on:click="getNumber('7')">7</td>
      <td v-on:click="getNumber('8')">8</td>
      <td v-on:click="getNumber('9')">9</td>
       <td class="last-coloum" 
       @click="processOutput('multiply')">X</td>
    </tr>
     <tr>
      <td v-on:click="getNumber('4')">4</td>
      <td v-on:click="getNumber('5')">5</td>
      <td v-on:click="getNumber('6')">6</td>
       <td class="last-coloum"
       @click="processOutput('substract')">-</td>
    </tr> <tr>
      <td v-on:click="getNumber('1')">1</td>
      <td v-on:click="getNumber('2')">2</td>
      <td v-on:click="getNumber('3')">3</td>
       <td class="last-coloum" @click="processOutput('add')">+</td>
    </tr>
     <tr>
   
      <td colspan="2" v-on:click="getNumber('0')">0</td>
      <td v-on:click="getDot()">.</td>
       <td class="last-coloum" @click="updateOutput">=</td>
    </tr> 
  </tbody>
</table>
</div>
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  props: {
    msg: String
  },
  data(){
    return{
      output:'',
      previousValue : null ,
      operationFired: false,

    }
  },
  methods:{
    clearField(){
       this.output=""
    },
     setNagativeOrPositive(){
      this.output = this.output[0] === '-' ? this.output.slice(1) : `-${this.output}`;
     },
     calculatePercentage(){
      this.output = parseFloat(this.output)/100;
     },
     getNumber(number){
      if(this.operationFired){
        this.output = '';
        this.operationFired = false;
      }
      this.output =`${this.output}${number}`;
     } ,
     getDot(){
      if(this.output.indexOf('.') === -1){
        this.output =this.output+'.';
      }
     },
     processOutput(string){

if(string =='add'){
   this.operation =(a,b)=>{
       return parseFloat (a) + parseFloat(b) ;
}
  }else if (string =='substract'){
  this.operation =(a,b)=>{
       return parseFloat (a) - parseFloat(b) ;
}
  }
  else if (string =='divide'){
  this.operation =(a,b)=>{
       return parseFloat (a) / parseFloat(b) ;
}}
 else if (string =='multiply'){
  this.operation =(a,b)=>{
       return parseFloat (a) * parseFloat(b) ;
}}
      this.previousValue = this.output;
      this.operationFired = true;
      },
      updateOutput(){
        this.output = `${this.operation(this.previousValue, this.output)}`
      }

  
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
.otput{
  background-color: rgb(48, 0, 63);
  color: #fff;
}
.last-coloum{
  background-color: rgb(218, 118, 36);
  color: #fff;
}.last-coloum:active{
  background-color: rgb(0, 0, 0);
  color: #fff;
}
.hello{
  background-image: url(../assets/Bg.png);
    height: 700px;
}.center{ margin: 0 auto;
}
td{
  color: rgb(255, 255, 255);
}body{
  margin: 0px;
}
.table-bg{
  background-color: rgb(88, 88, 88);
}.title{
  padding: 60px 0;
}
</style>
