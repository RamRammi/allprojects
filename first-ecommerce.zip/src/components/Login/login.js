import React from 'react'

const Login = () => {
    return ( 
      <section className='login-page'>
        <div className='login-main'>
           <div className='login-head'>            {/* <img src={public.env.process_url} */}           

            <p>hello</p>            
           </div>
           <div className='login-body'>
           <div className='login-input'>
           <input placeholder='Email'/>
           </div>
           <div className='login-input'>           
           <input placeholder='Passsword'/>
           </div>
           <div className='login-forgot-rember'>
            <div className='login-rember'><input type="checkbox"/> REMEMBER ME</div>
            <div className='login-forgot'> FORGOT PASSWORD</div>
           </div>
          <div className='login-button'>
            <button>Login</button>
          </div>
       
          <div className='login-button-below'>
          <div className='signup-now'><p>Not a member ? <span className='signup-span'>Sign up now</span></p></div>
            <div className='login-with'>or login with</div>
            <div>
            <a href="#" class="icon-button twitter"><i class="icon-twitter"></i><span></span></a>
<a href="#" class="icon-button facebook"><i class="icon-facebook"></i><span></span></a>
<a href="#" class="icon-button google-plus"><i class="icon-google-plus"></i><span></span></a>
<a href="#" class="icon-button youtube"><i class="fa fa-youtube"></i><span></span></a>
<a href="#" class="icon-button pinterest"><i class="fa fa-pinterest"></i><span></span></a>
                </div>
            </div>
          </div>
          
        </div>
      </section>
     );
}
 
export default Login;