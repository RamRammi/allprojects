import axios from "axios";
import { baseURL } from "./baseurl";

const getapidata = async(endpointe) =>{
   
    try {
        const url = `${baseURL}/${endpointe}`
        const  result = await axios.get(url)
        return result


    } catch (error) {
        
    }
}

export default{
    getapidata
}