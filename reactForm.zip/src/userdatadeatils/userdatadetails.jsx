import React, { useState } from 'react'
import service_api from './services/service_api'

const Userdatadetails = () => {
    const[userdata,setUserData] = useState([])

    const getdata = async() =>{
        const result = await service_api.getapidata
    }
  return (
    <div>
      <p>hello</p>
    </div>
  )
}

export default Userdatadetails
