import React from 'react'

function UserForm({feilds,setFeilds,handelAdd,handelUpdate}) {

    const handelInputChange =(e)=>{
  setFeilds({
    ...feilds,[e.target.name]:e.target.value
})

    }
  return (
    <>
    
    <div className='main'>
      <div className='header'>
        <span className='heading'>User</span>
      </div>
      <div className='user-Data'>
        <div className='formGroup'>
            <label>Name</label>
            <input name='userName' value={feilds.userName} onChange={handelInputChange} />
        </div>
        <div className='formGroup'>
            <label>Email</label>
            <input name='userEmail' value={feilds.userEmail} onChange={handelInputChange} />
        </div>
        <div className='formGroup'>
            <label>Phone</label>
            <input name='userPhone' value={feilds.userPhone} onChange={handelInputChange} />
        </div>
        <div className='formGroup'>
            {
            feilds.id ? 
             <button className='button' onClick={handelUpdate}>Update</button> 
            :
            <button className='button' onClick={handelAdd}>Save</button>
  }
        </div>
      </div>
      </div>
      
    </>
  )
}

export default UserForm
