import React, { useState } from 'react'
import UserForm from './UserForm'

function User() {
  const[popup,setPopup]=useState(false)
  const[feilds,setFeilds]=useState({})
  const[data,setData]=useState([])


const handelUpdate =()=>{

}
  const handelAdd =()=>{
const obj ={
  ...feilds,
  id:Math.random()
}
console.log(obj,'hhh')
setData([...data, obj])
setPopup(false)
setFeilds({})
  }
  const handelEdit =(row)=>{
setFeilds(row)
setPopup(true)
  }
  const handelNew =()=>{
    setPopup(true)
    // setFeilds({})
  }
  const handelDelete = (id)=>{
    const updatedData = data.filter(item => item.id !== id);
    setData(updatedData)
  }
  return (
    <>
    <div className='main'>
      <div className='header'>
        <span className='heading'>User</span>
        <span className='button' onClick={handelNew}>New</span>
      </div>
      <div className='user-Data'>
        <table>
          <thead>
            <tr>
              <th>S No</th>
              <th>Name</th>
              <th>Email</th>
              <th>Phone</th>
              <th>Action</th>
              </tr>
          </thead>
          <tbody>
           {
            data.map((list, inx)=>{
              return(
                <tr key={list.id}>
                  <td>{inx + 1}</td>
                  <td>{list.userName}</td>
                  <td>{list.userEmail}</td>
                  <td>{list.userPhone}</td>
                  <td>
                  <span className='link' style={{paddingRight:"5px"}} onClick={()=>handelEdit(list)}>Edit</span>
                    <span className='link' onClick={()=>handelDelete(list.id)}>Delete</span>
                  </td>
                </tr>
              )
            })
           }
          </tbody>
        </table>
      </div>
    </div>
    { popup === true ? 
    <div id="popup" class="popup">
    <div class="popup-content">
        <span class="close"  onClick={()=>setPopup(false)}>&times;</span>
       <UserForm  feilds ={feilds} setFeilds={setFeilds} handelAdd={handelAdd} handelUpdate={handelUpdate}/>
    </div>
</div>
:null
}
    </>
  )
}

export default User
