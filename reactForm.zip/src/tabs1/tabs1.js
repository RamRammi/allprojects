import React, { useState } from 'react'

const Tabs1 = () => {
    const [radio,setRadio] = useState('men')
    const [disabled,setDisabled] = useState(true)

    const handlegender = (e) =>{
        setRadio(e.target.value)
    if(e.target.checked){
        setDisabled(false)
    }
    else{
        setDisabled(true)
    }
    }
  return (
    <div >
        
      <p>please select your gender</p>
      <p className='containertab1'>
        <input 
        type='radio'
        name='men'
        value='men'
        onChange={handlegender}
        checked={radio === 'men'}
        /><span>men</span>
      </p>
      <p className='containertab1'>
        <input
        type='radio'
        name='women'
        value='women'
        onChange= {handlegender}
        checked={radio === 'women'}
        /><span>women</span>
        
      </p>
      <input type='checkbox' name='one' disabled={disabled}/>
      <p className='containertab1'>
        <input 
        type='radio'
        name='kids'
        value='kids'
        onChange={handlegender}
        checked = {radio === 'kids'}
        />
        <span>kid</span>
      </p>
  
    </div>
  )
}

export default Tabs1
