import React from 'react'
import { useState } from 'react'

const Tab2 = () => {
    const[username,setusername] = useState('')
    const[usermail ,setusermail] = useState('')
   
const [disabledcheck, setdisablecheck] = useState(true)
    const[submitdisabled,setSubmitdisabled] = useState(true)

    const handleusername = (e) =>{
        setusername(e.target.value)
        validation()
    }
    const handleusermail = (e) =>{
        setusermail(e.target.value)
        validation()
    }
    const validation = () =>{
        if((username === '') || (usermail === '')){
            setSubmitdisabled(true)
        }else{
            setSubmitdisabled(false)
        }
        
    }
    const handlegender =(e) =>{
        const res = e.target.checked
        if (res){
            setdisablecheck(false)
            submitdisabled(true)
        }else{
            setdisablecheck(true)
            submitdisabled(false)

        }
    }
  return (
    <div>
      <p>
        <span>Name :</span>
        <span><input
        type='text'
        name = 'name'
        value={username}
        onChange={handleusername}
        />
        </span>
      </p>
      <p>
        <span>email :</span>
        <span><input
        type='mail'
        name = 'name'
        value={usermail}
        onChange={handleusermail}
        />
        </span>
      </p>
      <p>
        <span>select age :</span>
       <select>
       <option  >0</option>
        <option>1</option>
        <option>2</option>
        <option>3</option>
<b/>       </select>    
      </p>
      <p>
      <span className='gender-check'><input type='radio' onChange={handlegender}/>select Gender </span>
      <span className='gender-check'><input disabled = {disabledcheck} type="checkbox"/>men</span>
      <span className='gender-check'><input disabled = {disabledcheck} type="checkbox"/>women</span>
      <span className='gender-check'><input disabled = {disabledcheck} type="checkbox"/>kid</span>
      <span className='gender-check'><input disabled = {disabledcheck} type="checkbox"/>other</span>
     

      </p>
      <button disabled = {submitdisabled}>submit</button>
    </div>
  )
}

export default Tab2
