import React, {useState} from 'react'

const Inputradios = () => {
    const [radio,setRadio] = useState('radio1')

    const haneleradio =(e) =>{
        setRadio(e.target.value)
    }
    
  return (
    <div>
      <p>Radio Input</p>
        <div>
            <p className='rad1'>
                <input type="radio"
                value='radio1'
                checked = {radio === "radio1"}
                onChange = {haneleradio}
                />
                <p >
                   <p> First Input1 :  <input type='text' /></p>
                   <p> Second Input1 :  <input type='text' /></p>
                   <p> Third Input1 :  <input type='text' /></p>

                </p>
            </p>
            <p className='rad2'>
                <input type="radio"
                value='radio2'
                checked = {radio === 'radio2'}
                onChange = {haneleradio}

                />
                
                <p>
                   <p > First Input2 :  <input type='text' disabled={radio !== "radio2"} /></p>
                   <p> Second Input2 :  <input type='text' disabled={radio !== "radio2"} /></p>
                   <p> Third Input2 :  <input type='text'  disabled={radio !== "radio2"}/></p>

                </p>
            </p>
            <p className='rad3'>
                <input type="radio"
                 value='radio3'
                 checked={radio === 'radio3'}
                onChange = {haneleradio}

                 />
                <p>
                   <p> First Input3 :  <input type='checkbox' disabled={radio !== 'radio3'} /></p>
                   <p> Second Input3 :  <input type='checkbox' disabled={radio !== 'radio3'} /></p>
                   <p> Third Input3 :  <input type='checkbox' disabled={radio !== 'radio3'} /></p>

                </p>
            </p>
        </div>
    </div>
  )
}

export default Inputradios
