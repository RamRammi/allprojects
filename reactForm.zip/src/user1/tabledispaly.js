import React, { useState } from 'react'

import Tableinput from './tableinput'

const Tabledispaly = () => {
    const [popup,setPopup] = useState(false)
    const [fileds,setFeilds] = useState({})
    const [data, setData] = useState([])
    const handlesave = () =>{
        setData([...data,fileds])

    }
    const openpopup = () =>{
        setPopup(true)
    }
  return (
    <section className='container'>
        <div className='main'>
            <div className='main-heading'>User Data</div>
            <div className='main-btns'>
                <span className='user-table'>User Table</span>
                <span className='new-table' onClick={openpopup}>New</span>
            </div>
            <div >
                <table className='main-table'>
                    <thead>
                        <tr>
                            <th>s.no</th>
                            <th>name</th>
                            <th>email</th>
                            <th>address</th>
                        </tr>
                    </thead>
                    <tbody>
                        { data.map((list, inx)=>{
                            return(
                                  <tr key={list} >
                                  <td>1</td>
                                  <td>{list.username}</td>
                                  <td>{list.email}</td>
                                  <td>{list.address}</td>
                              </tr>
                            )
                        })}
                  
                    </tbody>
                </table>
            </div>
        </div>

      {  popup === true ?
       <div id="popup" class="popup">
         <div class="popup-content">

        <span class="close"  onClick={()=>setPopup(false)}>&times;</span>
        <Tableinput  fileds={fileds} setFeilds={setFeilds} handlesave={handlesave} />

        </div>
        </div>
       : null  }
      
    </section>
  )
}

export default Tabledispaly
