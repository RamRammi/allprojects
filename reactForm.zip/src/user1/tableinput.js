import React from 'react'

const Tableinput = ({fileds,setFeilds,handlesave}) => {

    const handlefileds = (e) =>{
      setFeilds({
           ...fileds,[e.target.name]: e.target.value
         } )
    }

  return (
    <div>
        <label>username</label>
        <input type='text' name='username'  onChange={handlefileds}  value={fileds.username}/>
        <input type='text' name='email' onChange={handlefileds}  value={fileds.email}/>

        <input type='text' name='phone' onChange={handlefileds}  value={fileds.phone}/>
        <input type='text' name='address' onChange={handlefileds}  value={fileds.address}/>


        <button onClick={handlesave}>save</button>
      
    </div>
  )
}

export default Tableinput
