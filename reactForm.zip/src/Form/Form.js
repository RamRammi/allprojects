import React, { useState } from 'react'
import './form.css'
const Form = () => {
  const [username, setUsername] = useState("")
  const [email, setemail] = useState("")
  const [password, setpassword] = useState("")


  const userhandler = (e) => {
    setUsername(e.target.value)
  }
  const emailhandler = (e) => {
    setemail(e.target.value)
  }
  const passhandler = (e) => {
    setpassword(e.target.value)
  }

  return (
    <div >
     <form className='bg-css' >
        <label  htmlFor='username'>username :</label>
        <input type="text"
            name='username'
            value={username} onChange = {userhandler} 
            /> <span> {username}</span><br/>
        <label htmlFor='email'>email    :</label>
        <input type='text'
         name = 'email'
         value={email} onChange = {emailhandler}
        /> { email}<br/>
        <label  htmlFor='password'>Password  :</label>
        <input type="text"
        name ='password'
        value ={password} onChange = {passhandler}/> {password}
          <button type='submit'> submit</button>
        </form>
    </div>
  )
}

export default Form
