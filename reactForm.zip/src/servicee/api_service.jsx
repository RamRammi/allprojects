import axios from "axios"
import { UserURL } from "./urls"

//this function used for getting data by url
 const getApidata = async(endpoint) =>{
        try {
            const url = `${UserURL}/${endpoint}`
            const result = await axios.get(url)
            return result
            
        } catch (error) {
            console.log(`getApidata ${endpoint} error`)
        }
    } 

// this function used for post data by url  

const postApiData = (endpoint,postObj) =>{
    try {
        const url = `${UserURL}/${endpoint}`
        const result = axios.post(url,postObj)
        return result
    } catch (error) {
        console.log(`postApiData ${endpoint} error`)
        return 'getting somting error'
    }
}



export default {
    getApidata,
    postApiData
}