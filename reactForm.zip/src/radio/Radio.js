import React, { useState } from 'react'

const Radio = () => {
    const [radio, setRadio] = useState("men")
    const [mendata, setMendata] = useState()
    const [womendata, setWomendata] = useState()
    const [kiddata, setKiddata] = useState()



    const handleRadio = (e) =>{
      setRadio(e.target.value)
    }
    console.log(radio)
  return (
    <div>
      <p>       
        <input
        type='radio'
        value='men'
        onChange={handleRadio}
        checked = {radio === 'men'}
        />  <label> men</label>
      
      </p>
      <p>       
        <input
        type='radio'
        value='women'
        onChange={handleRadio}
        checked = {radio === 'women'}
        />  <label> women</label>
      
      </p>
      <p>       
        <input
        type='radio'
        value='kid'
        onChange={handleRadio}
        checked = {radio === 'kid'}
        />  <label> kid</label>
      
      </p>

{
    radio === 'men' ?
    <> we are mens
    <input
    type='text'
    value={mendata}
    onChange={(e) => setMendata(e.target.value)} 
    />
        </>

    : radio === 'women' ?
    <>we are womens
    <input
    type='text'
    value={womendata}
    onChange={(e) => setWomendata(e.target.value)} 
    />
    </>
    

    : <>we are kids
     <input
    type='text'
    value={kiddata}
    onChange={(e) => setKiddata(e.target.value)} 
    />
    </>
}

    </div>
  )
}

export default Radio
