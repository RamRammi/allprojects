import React from 'react'
import { useEffect } from 'react'
import { useState } from 'react'
import api_service from '../servicee/api_service'
const Userdata = () => {
    const [data,setData] = useState([])
 const [name,setName] = useState('') 
 const [email,setEmail] = useState('')
 const [mobile,setMobile] = useState('')
    const getdata = async() =>{
        const result =await api_service.getApidata('/getUser')
        setData(result.data.users)

    }
    const handleClick = () =>{
        const obj = {
            name : name,
            email : email,      
            mobile : mobile
        }
        api_service.postApiData('/createUser',obj)
    }
    const NameChange = (e) =>{
        setName(e.target.value)
    } 
    const emailChange = (e) =>{
        setEmail(e.target.value)
    }
    const mobileChange = (e) =>{
        setMobile(e.target.value)
    }



    useEffect(() =>{
        getdata()
    },[])
  return (
    <div>
      <p>hello</p>
      <input type='text'
      value={name}
      onChange={NameChange}
      />
      <input type='text'
      value={email}
      onChange={emailChange}
      />

<input type='text'
      value={mobile}
      onChange={mobileChange}
      />
      <button onClick={handleClick}>save</button>
      
    </div>
  )
}

export default Userdata
