
import Httpserviceapi from "./Httpservice";

export const DisplayService = async() => {
    const getdisplay = await  Httpserviceapi.get('/getUser');
    return getdisplay
}

export default {
    DisplayService
}