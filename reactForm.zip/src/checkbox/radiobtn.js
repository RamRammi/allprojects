import React, { useState, useEffect } from "react";


const Radiocheck = () => {
  const [radio, setRadio] = useState("radio1");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [radio3, setRadio3] = useState([false, false, false, false, false]);

  const handelRadio = (e) => {
    setRadio(e.target.value);
  };

  const handleCheckbox = (index) => {
    const updatedRadio3 = [...radio3];
    updatedRadio3[index] = !updatedRadio3[index];
    setRadio3(updatedRadio3);
  };

  const isSaveButtonDisabled = () => {
    if (
      (radio === "radio2" && fromDate && toDate) ||
      (radio === "radio3" && fromDate && toDate && radio3.includes(true))
    ) {
      return false;
    }
    return true;
  };
  console.log(radio,'111')

  return (
    <>
      <div className="w-full">
        <input
          type="radio"
          value="radio1"
          name="radio"
          onChange={handelRadio}
          checked={radio === "radio1"}
        />{" "}
        Radio 1
      </div>
      <div className="w-full">
        <input
          type="radio"
          value="radio2"
          name="radio"
          onChange={handelRadio}
          checked={radio === "radio2"}
        />{" "}
        Radio 2
        <div className="w-full">
          <label>From date</label>
          <input
            type="date"
            value={fromDate}
            onChange={(e) => setFromDate(e.target.value)}
            disabled={radio !== "radio2"}
          />
          <label>To date</label>
          <input
            type="date"
            value={toDate}
            onChange={(e) => setToDate(e.target.value)}
            disabled={radio !== "radio2"}
          />
        </div>
      </div>
      <div className="w-full">
        <input
          type="radio"
          value="radio3"
          name="radio"
          onChange={handelRadio}
          checked={radio === "radio3"}
        />{" "}
        Radio 3
        <div className="w-full">
          <input
            type="checkbox"
            checked={radio3[0]}
            onChange={() => handleCheckbox(0)}
            disabled={radio !== "radio3"}
          />
          <label>Check 1</label>
          <input
            type="checkbox"
            checked={radio3[1]}
            onChange={() => handleCheckbox(1)}
            disabled={radio !== "radio3"}
          />
          <label>Check 2</label>
          <input
            type="checkbox"
            checked={radio3[2]}
            onChange={() => handleCheckbox(2)}
            disabled={radio !== "radio3"}
          />
          <label>Check 3</label>
          <input
            type="checkbox"
            checked={radio3[3]}
            onChange={() => handleCheckbox(3)}
            disabled={radio !== "radio3"}
          />
          <label>Check 4</label>
          <input
            type="checkbox"
            checked={radio3[4]}
            onChange={() => handleCheckbox(4)}
            disabled={radio !== "radio3"}
          />
          <label>Check 5</label>
        </div>
      </div>
      <button disabled={isSaveButtonDisabled()}>Save</button>
      <div className="w-full mt-4">
        <input
          type="radio"
          value="user"
          name="radio"
          onChange={handelRadio}
          checked={radio === "user"}
        />
        user
      </div>
      {radio === "user" && (
        <div className="w-full">
          {/* <User /> */}
          <p>user check</p>
        </div>
      )}
    </>
  );
};

export default Radiocheck;
