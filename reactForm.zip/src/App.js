
import './App.css';

import Radiocheck from './checkbox/radiobtn';
import Inputradios from './radiochecked/inputradios';
// import Userdata from './userdata/userdata';
// import Userdatadetails from './userdatadeatils/userdatadetails';
// import Radio from './radio/Radio';
// import Gendertabs from './tabs/radiotabs/gendertabs';
// import Tabledispalyy from './userapi/tabledispalyy';
// import User from './user/User';
// import BasicTable from './user2/user2';

// import Userdetails from './userR/userdetails';
// import Calcultaor from './calculator/calculaor';
// import Form from './Form/Form';



function App() {
  return (
    <div className="App">
     
      {/* <Form/> */}
      {/* <Calcultaor/> */}
      {/* <User/> */}
      {/* <BasicTable/> */}
      
     {/* <Userdetails/> */}
     {/* <Tabledispalyy/> */}
     {/* <Radiocheck/> */}

     
      {/* <Radio/> */}
      {/* <Gendertabs/> */}
      {/* <Tabs1/> */}
      {/* <Tab2/> */}
    <Inputradios/>
    {/* <Userdata/> */}
    {/* <Userdatadetails/> */}
    </div>
  );
}

export default App;
