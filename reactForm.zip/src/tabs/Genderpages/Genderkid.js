import React from 'react'

const Genderkid = () => {
  return (
    <div>
      <p>
        <div>Kid details</div>
        <div className='kid-details'>
            <input type='text' name='kidname' value='kidname'/>
            <input type='text' name='kidage' value='kidage'/>  
        </div>
      </p>
    </div>
  )
}

export default Genderkid
