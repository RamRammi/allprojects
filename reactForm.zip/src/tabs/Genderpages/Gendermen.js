import React, { useEffect, useState } from 'react'

const Gendermen = () => {
    const [menname,setMenname] = useState('')
    const [menemail,setEmail] = useState('')
    const [menphone,setPhone] = useState('')
    const [menaddress,setAddress] = useState('')
    const [btndisable,setBtndisabled] =useState(true)

    const handlemenname = (e) => {
        setMenname(e.target.value)
    }
    const handlemenage = (e) => {
        setEmail(e.target.value)
    }
    const handlemenphone = (e) => {
        setPhone(e.target.value)
    }
    const handlemenaddress = (e) => {
        setAddress(e.target.value)
    }
    const handleserch = () => {
        
    }

    useEffect(()=>{
        if(menname !== '' && menemail !== '' && menphone !=='' ){
            setBtndisabled(false)
        }
    },[menname,menemail,menphone])
  return (
    <div>
        <p>
        <div>men details</div>
        <div className='men-details'>
          Name :  <input type='text' name='menname' value={menname} onChange={handlemenname}/>
          Email :  <input type='text' name='menemail' value={menemail} onChange={handlemenage}/>
           Phone : <input type='text' name='menphone' value={menphone} onChange={handlemenphone}/>
           Address: <input type='text' name='menaddress' value={menaddress} onChange={handlemenaddress}/>
          <button onClick={handleserch} 
        //   disabled={
        //     menname !=="" &&
        //     menemail !=="" &&
        //     menphone !=="" ? false : true
        //   }
        disabled={btndisable}
          >serach</button>
            
        </div>
        </p>
      
    </div>
  )
}

export default Gendermen

