import React, { useState } from 'react'

const Genderwomen = () => {
    const [womenname,setWomenname] = useState()
    const [womenage,setWomenage] = useState()
    // const [radiooneval,setRadiooneval] = useState()
    const [enableCheck,setEnableCheck] = useState(true)
    const handelradiooneval  = (e)=>{
       const res = e.target.checked
       if(res){
        setEnableCheck(false)
       }
       else{
        setEnableCheck(true)
       }
    }

  return (
    <div className='kid-details'>
       <p>
        <div>women details</div>
        <div >
            <input type='text' name='womenname' value={womenname}/>
            <p className='radioone'>
            <input type='radio' name='radioone'  onChange={handelradiooneval}/><span>checkone</span>  <br/>
            <input type='checkbox' disabled={enableCheck}/><span>one</span><br/>
            <input type='checkbox' disabled={enableCheck}/><span>two</span><br/>
            <input type='checkbox' disabled={enableCheck}/><span>three</span><br/>
            <input type='checkbox' disabled={enableCheck}/><span>four</span><br/>
            <input type='checkbox' disabled={enableCheck}/><span>five</span><br/>

            </p>
        </div>
      </p>
    </div>
  )
}

export default Genderwomen
