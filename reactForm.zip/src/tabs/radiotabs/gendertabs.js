import React, { useState } from 'react'
import Genderkid from '../Genderpages/Genderkid'
import Gendermen from '../Genderpages/Gendermen'
import Genderwomen from '../Genderpages/Genderwomen'
import './style.css'
const Gendertabs = () => {
    const [radio, setRadio] = useState('men')

    const handleRadio = (e) =>{
        setRadio(e.target.value)
    }
  return (
    <div>
        <p className='input-main'>
      <input type='radio'
      value='men'
      onChange={handleRadio}
      checked={radio === "men"}
      
      />men
      <input type='radio'
      value='women'
      onChange={handleRadio}
      checked={radio === "women"}
      />women    
      <input type='radio'
      
      value='kid'
      onChange={handleRadio}
      checked={radio === "kid"}
      />kid
      </p>
{
    radio === 'men' ?
    <><Gendermen/></> : 
    radio === 'women' ?
    <><Genderwomen/></> :
    <><Genderkid/>    </> 
}
    </div>
  )
}

export default Gendertabs
