import axios from 'axios'

const Httpserviceapi = axios.create({
    baseURL : "https://user-1-7sfp.onrender.com/auth"
})

export default Httpserviceapi;