import Httpserviceapi from "./httpservice";


export const dataget = async() =>{
    const dataa = await Httpserviceapi.get('/getUser');
    return dataa;
}

export default {
    dataget
}