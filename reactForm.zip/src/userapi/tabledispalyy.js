import React, { useEffect, useState } from "react";
import dispalydata from "./services/dispalydata";

const Tabledispalyy = () =>{
    const [data, setData]= useState([])
    
    useEffect( () => {
    getdata()
    }, [])
    const getdata = async() =>{
        try{
        const tabledata = await dispalydata.dataget()
        console.log(tabledata,"ggg")
        const res = tabledata.data.users
        setData(res)
        } catch(error){
            console.log(error);
        }
    }
    return(
        <>
        <div className="container">
           <div> Student Data</div> 
           <span>New</span>
            <div>
            <table  className="main-table">
                <thead>
                    <tr>
                        <th>s.no</th>
                        <th>Name</th>
                        <th>phone</th>
                        <th>email</th>
                        <th>Action</th>
                    </tr>   
                </thead>
                <tbody>
                 { data.map((list,inx)=>{
                   return(
                   <tr key={list}>
                  <td>{inx+1}</td>
                    <td>{list.name}</td>
                    <td>{list.mobile}</td>
                    <td>{list.email}</td>
                    <td>
                        <span className="act-btn">edit</span>
                        <span className="act-btn">delet</span>
                    </td>

                   </tr>
                   )
                 })  
                 }
                </tbody>
            </table>

            </div>
        </div>
        </>
    )
}

export default Tabledispalyy ;











// import axios from "axios";
// import React, { useEffect, useState } from "react";
// import Httpserviceapi from "./services/httpservice";

// const Tabledispalyy = () =>{
//     const [data, setData]= useState([])
    
//     useEffect( () => {
//     getdata()
//     }, [])
//     const getdata = async() =>{
//         try{
//         const tabledata = await axios.get('https://user-1-7sfp.onrender.com/auth/getUser')
//         const res = tabledata.data.users
//                 console.log(res,"ggg")
//         setData(res)
//         } catch(error){
//             console.log(error);
//         }
//     }
//     return(
//         <>
//         <div>
//             <p>hello</p>
//             {data.map((list,inx)=>{
//                 return(
//                     <p>{
//                     list.name
//                     }</p>
//                 )

//             })}
//         </div>
//         </>
//     )
// }

// export default Tabledispalyy ;