const Employe = [
    {
        id:"0",
        name : "ramesh",
        Age : "28"
    },  {
        id:"1",
        name : "ramesh1",
        Age : "28"
    },  {
        id:"2",
        name : "ramesh2",
        Age : "29"
    },  {
        id:"3",
        name : "ramesh3",
        Age : "30"
    },  {
        id:"4",
        name : "ramesh4",
        Age : "31"
    }
] 
export default Employe