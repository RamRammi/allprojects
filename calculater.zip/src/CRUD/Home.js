import React, { useEffect, useState } from 'react'
import Employe from "./Employess"
import "./Home.css"
import axios from 'axios'

const Crud =() =>{
 const [data,setData] = useState([]);
 const baseUrl ='https://jsonplaceholder.typicode.com/todos'
 useEffect(()=>{
    getData()
 },[])

    const handleEdit =() =>{

    }

//     const getData = async()=>{
//        const  gdata = await axios.get(baseUrl)
//       const res = await gdata.data
//       console.log(res)
//       setData(res)
// }
const getData = async()=>{
    try {
        const  gdata = await axios.get(baseUrl)
        const res = await gdata.data
        console.log(res)
        setData(res)
    } catch (error) {
        
    }

}

    const handleDelete =(del) =>{
            const det = data.filter((c) => {
                return c.id !== del.id
            })
            setData(det)
    }
    return(
        <div>hello CRUD

                    <tr className='border'>
                            <th className='border'>
                                ID
                            </th>
                            <th className='border'>
                                Name
                            </th>
                            <th className='border'>
                                Age
                            </th>
                            <th className='border'>
                                Action
                            </th>
                        </tr>

            {
                
                data.map((item) => {    
                    return (
                        <>
                       
                        <tr>
                        <td className='border'>
                        {item.id} 
                        </td>
                        <td className='border'>
                        {item.title} 
                        </td>                        
                        <td className='border'>
                        <button onClick={()=> handleEdit(item)}>Edit </button>
                        <button onClick={() => handleDelete(item)}>Delet</button>
                        {/* <button>Create</button> */}
                       

                        </td>
                        </tr>
                        </>
                    )
                })
            }
        </div>

    )
} 
export default Crud;