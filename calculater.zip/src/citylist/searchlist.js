import React from "react"

const SearchFilter = () =>{
    return(
        <>
        <input type="text"/>
        <div>
        <iframe width="1300" height="667" frameborder="0" scrolling="no" src="https://capgemini.sharepoint.com/sites/HGICookbook/_layouts/15/Doc.aspx?sourcedoc=%7B06e549b1-2663-4428-9215-48e4e21c1e70%7D&action=embedview&Item=Table1&wdHideGridlines=True&wdDownloadButton=True&wdInConfigurator=True&wdInConfigurator=True&edesNext=false&resen=true&ed1JS=false%22"></iframe>
        </div>
        </>
    )
}
export default SearchFilter