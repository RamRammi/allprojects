import logo from './logo.svg';
import './App.css';
import Calculator from './calculator/calculator';
import Crud from './CRUD/Home';
import SearchImage from './ImagesSearch/imagesSearch';
import SearchFilter from './citylist/searchlist';

function App() {
  return (
    <div className="App">
      {/* <Calculator/> */}
      {/* <Crud/> */}
      <SearchImage/>
      {/* <SearchFilter/> */}
      
        </div>
  );
}

export default App;
