import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import * as Api from "./comman/api";
import * as Constant from "./comman/constant";
import keycloak from "./keycloak";
import Cookies from "js-cookie";
import {
  setProjectId,
  setClientId,
  setUserId,
  setUserData,
  setJwt,
  setProjectName,
  setUserRole,
  setUrlClientId,
  setUrlProjectId,
  setUrlUserId,
} from "./redux/actions/questionnaireAction";
import { Box } from "@mui/material";
import ConsultantApp from "./ConsultantApp";
import { connect } from "react-redux";
import ClientApp from "./ClientApp";
const USER_MODAL = {
  projectID: "",
  clientID: "",
  userID: "",
};
function App() {
  const [userData, seUserData] = useState();
  const [userDetails, setUseDetails] = useState(USER_MODAL);
  const [errorMsg, setErrorMsg] = useState("");
  const { projectID, clientID, userID } = userDetails;
  const urlProjectId = useSelector(
    (state) => state.questionnaireReducer.urlProjectId
  );
  const urlClientId = useSelector(
    (state) => state.questionnaireReducer.urlClientId
  );
  const urlUserId = useSelector(
    (state) => state.questionnaireReducer.urlUserId
  );
  const location = useLocation();
  const dispatch = useDispatch();
  useEffect(() => {
    const query = new URLSearchParams(location.search);
    const projectID = query.get("projectId");
    const clientID = query.get("clientId");
    const userID = query.get("userId");
    if (projectID !== null && clientID !== null && userID !== null) {
      setUseDetails({
        projectID: encodeURIComponent(projectID),
        clientID: encodeURIComponent(clientID),
        userID: encodeURIComponent(userID),
      });
      dispatch(setUrlProjectId(projectID));
      dispatch(setUrlClientId(clientID));
      dispatch(setUrlUserId(userID));
    } else {
      setUseDetails({
        projectID: encodeURIComponent(urlProjectId),
        clientID: encodeURIComponent(urlClientId),
        userID: encodeURIComponent(urlUserId),
      });
    }
  }, [location]);
  // Calling getUserDetail API with Redux store Data
  useEffect(() => {
    let timer;
    keycloak.onAuthSuccess = () => {
      const { token, tokenParsed } = keycloak;
      Cookies.set("jwt", token);
      localStorage.setItem("jwt", token);
      Cookies.set("tokenParsed", tokenParsed);
      dispatch(setJwt(token));
      timer = setTimeout(() => {
        Api.fetchLoginDetails(
          `${Constant.LOGIN_URL}UserId=${userDetails.userID}&ClientId=${userDetails.clientID}&ProjectId=${userDetails.projectID}`
          //   https://dan-apps-dev-be01.azurewebsites.net/User/GetUserDetailById?userId=2a228ada-7a0d-11ed-b239-1d7c1802c5d4&clientId=456889f1-7ad9-11ed-b239-1d7c1802c5d4&projectId=5aae90ef-7ada-11ed-b239-1d7c1802c5d4
        )
          .then((data) => {
            if (!data.statusCode) {
              seUserData(data);
              dispatch(setUserData(data));
              dispatch(setProjectName(data.projectName));
              //Store data into redux state
              dispatch(setProjectId(data.projectId));
              dispatch(setClientId(data.clientId));
              dispatch(setUserId(data.id));
            } else {
              seUserData({});
              dispatch(setUserData({}));
              dispatch(setProjectName(""));
              setErrorMsg(data.errorMsg);
              dispatch(setProjectId(""));
              dispatch(setClientId(""));
              dispatch(setUserId(""));
            }
          })
          .catch((error) => {
            console.log(error);
            throw error;
          });
      }, 100);
      //  }
      return () => clearTimeout(timer);
    };
  }, [userDetails]);
  // This patch code is commented because we are getting same role and stream multiple times from the Platefrom API.
  // because of that one screen was display multiple times
  // const renderDashboard = () => {
  //   const userInfo =
  //     userData && userData.userRoleMappings ? (
  //       userData.userRoleMappings.map((role) => {
  //         let roleNameList;
  //         if (role && role.stream.toUpperCase() === "SHAPE") {
  //           roleNameList = <ConsultantApp />;
  //         }
  //         return roleNameList;
  //       })
  //     ) : (
  //       <Box sx={{ textAlign: "center", marginTop: "30px" }}>  //         You do not have shape stream , please contact to adminstartor..
  //       </Box>  //     );
  //   return userInfo;
  // };
  // This patch code is added because we are getting same role and stream multiple times from the Platefrom API
  const renderDashboard = () => {
    const streamFound = userData.userRoleMappings.filter(
      (el) => el.stream.toUpperCase() === "SHAPE"
    );
    dispatch(setUserRole(streamFound));
    const userInfo = streamFound.length ? (
      streamFound[0].roleName === "CONSULTANT" ||
      streamFound[0].roleName === "SHAPEADMIN" ? (
        <ConsultantApp />
      ) : (
        <ClientApp />
      )
    ) : (
      <Box sx={{ textAlign: "center", marginTop: "30px" }}>
        You do not have shape stream , please contact to adminstartor..
      </Box>
    );
    return userInfo;
  };
  return (
    <div>
      {userData && userData.userRoleMappings ? (
        renderDashboard()
      ) : (
        <Box sx={{ textAlign: "center", marginTop: "30px" }}>{errorMsg}</Box>
      )}
    </div>
  );
}
export default connect()(App);
