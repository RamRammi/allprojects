import * as React from "react";
// import { styled } from '@mui/material/styles';
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import IconButton from "@mui/material/IconButton";
// import Typography from '@mui/material/Typography';
// import InputBase from '@mui/material/InputBase';
import Badge from "@mui/material/Badge";
import MenuItem from "@mui/material/MenuItem";
import Menu from "@mui/material/Menu";
// import MenuIcon from '@mui/icons-material/Menu';
import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
// import SearchIcon from '@mui/icons-material/Search';
import AccountCircle from "@mui/icons-material/AccountCircle";
import MailIcon from "@mui/icons-material/Mail";
import { useNavigate } from "react-router-dom";
// import NotificationsIcon from "@mui/icons-material/Notifications";
import MoreIcon from "@mui/icons-material/MoreVert";
import "./Navbar.css";
import CG_Logo from "../../Images/CG_Logo.png";
import { Typography, Divider } from "@mui/material";
import KeyboardDoubleArrowRightIcon from "@mui/icons-material/KeyboardDoubleArrowRight";
import SettingsIcon from "@mui/icons-material/Settings";
import Notification from "../PopUp/Notification/Notification";
import GridViewIcon from "@mui/icons-material/GridView";
import { Link } from "react-router-dom";
import AccountCircleIcon from "@mui/icons-material/AccountCircle";
import HomeOutlinedIcon from "@mui/icons-material/HomeOutlined";
import { useLocation } from "react-router-dom";
//import { useKeycloak } from '@react-keycloak/web';
import keycloak from "../../keycloak";
import Cookies from "js-cookie";
//import { useKeycloak } from '@react-keycloak/web';
//import keycloak from "./keycloak";
//import Cookies from 'js-cookie';
import { useSelector, useDispatch } from "react-redux";
import {
  setProjectId,
  setClientId,
  setUserId,
  setUserData,
  setJwt,
} from "../../redux/actions/questionnaireAction";
// const Search = styled('div')(({ theme }) => ({
//   position: 'relative',
//   borderRadius: theme.shape.borderRadius,
//   backgroundColor: alpha(theme.palette.common.white, 0.15),
//   '&:hover': {
//     backgroundColor: alpha(theme.palette.common.white, 0.25),.
//   },
//   marginRight: theme.spacing(2),
//   marginLeft: 0,
//   width: '100%',
//   [theme.breakpoints.up('sm')]: {
//     marginLeft: theme.spacing(3),
//     width: 'auto',
//   },
// }));

// const SearchIconWrapper = styled('div')(({ theme }) => ({
//   padding: theme.spacing(0, 2),
//   height: '100%',
//   position: 'absolute',
//   pointerEvents: 'none',
//   display: 'flex',
//   alignItems: 'center',
//   justifyContent: 'center',
// }));

// const StyledInputBase = styled(InputBase)(({ theme }) => ({
//   color: 'inherit',
//   '& .MuiInputBase-input': {
//     padding: theme.spacing(1, 1, 1, 0),
//     // vertical padding + font size from searchIcon
//     paddingLeft: `calc(1em + ${theme.spacing(4)})`,
//     transition: theme.transitions.create('width'),
//     width: '100%',
//     [theme.breakpoints.up('md')]: {
//       width: '20ch',
//     },
//   },
// }));

export default function PrimarySearchAppBar(props) {
  const { NODE_ENV, REACT_APP_DAN_FE_URL } = process.env;
  const isDev = NODE_ENV === "development";
  const isUat = NODE_ENV === "uat";

  const location = useLocation();
  const dispatch = useDispatch();
  const [anchorEl, setAnchorEl] = React.useState(null);
  const [mobileMoreAnchorEl, setMobileMoreAnchorEl] = React.useState(null);
  const navigate = useNavigate();
  const isMenuOpen = Boolean(anchorEl);
  const isMobileMenuOpen = Boolean(mobileMoreAnchorEl);
  const projectName = useSelector(
    (state) => state.questionnaireReducer.projectName
  );
  const programName = useSelector(
    (state) => state.questionnaireReducer.programName
  );
  const handleProfileMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMobileMenuClose = () => {
    setMobileMoreAnchorEl(null);
  };

  const handleMenuClose = () => {
    if (window.location.origin.includes("8443")) {
      window.open(
        window.location.origin.replace(":8443", "") + "/changeclient",
        "_top"
      );
    } else {
      window.open(
        window.location.origin.replace(
          "https://shape-apps-dev-fe01.azurewebsites.net",
          "https://dan-apps-dev-fe02.azurewebsites.net"
        ) + "/changeclient",
        "_top"
      );
    }

    setAnchorEl(null);
    handleMobileMenuClose();
  };
  const handleHomeChange = () => {
    console.log("homeclick");
    if (window.location.origin.includes("8443")) {
      window.open(
        window.location.origin.replace(":8443", "") + "/consultant",
        "_top"
      );
    } else {
      window.open(
        window.location.origin.replace(
          "https://shape-apps-dev-fe01.azurewebsites.net",
          "https://dan-apps-dev-fe02.azurewebsites.net"
        ) + "/consultant",
        "_top"
      );
    }
  };

  const handleMenuSignOut = () => {
    Cookies.remove("jwt");
    Cookies.remove("tokenParsed");
    //localStorage.clear();
    //window.open(window.location.origin.replace(":8443", "") + "/", "_top");
    setAnchorEl(null);
    keycloak.logout({ redirectUri: REACT_APP_DAN_FE_URL });
    handleMobileMenuClose();
  };

  const handleMobileMenuOpen = (event) => {
    setMobileMoreAnchorEl(event.currentTarget);
  };

  const handleLogout = () => {
    dispatch(setProjectId(""));
    dispatch(setClientId(""));
    dispatch(setUserId(""));
    dispatch(setUserData(""));
    dispatch(setJwt(""));
    localStorage.setItem("jwt", "");
    handleMenuClose();
  };

  const menuId = "primary-search-account-menu";
  const renderMenu = (
    <Menu
      className="header-dropDown"
      anchorEl={anchorEl}
      anchorOrigin={{
        vertical: "top",
        horizontal: "right",
      }}
      id={menuId}
      keepMounted
      transformOrigin={{
        vertical: "top",
        horizontal: "right",
      }}
      open={isMenuOpen}
      onClose={handleMenuClose}
    >
      <MenuItem onClick={handleMenuClose}>Change Client/Project</MenuItem>
      <MenuItem onClick={handleMenuSignOut}>Sign out</MenuItem>
    </Menu>
  );

  const mobileMenuId = "primary-search-account-menu-mobile";
  const renderMobileMenu = (
    <Menu
      anchorEl={mobileMoreAnchorEl}
      anchorOrigin={{
        vertical: "top",
        horizontal: "right",
      }}
      id={mobileMenuId}
      keepMounted
      transformOrigin={{
        vertical: "top",
        horizontal: "right",
      }}
      open={isMobileMenuOpen}
      onClose={handleMobileMenuClose}
    >
      <MenuItem>
        <IconButton size="small" aria-label="show 4 new mails" color="inherit">
          <Badge badgeContent={4} color="error">
            <MailIcon />
          </Badge>
        </IconButton>
        <p>Messages</p>
      </MenuItem>
      <MenuItem>
        <IconButton
          size="small"
          aria-label="show 17 new notifications"
          color="inherit"
        >
          <Badge badgeContent={17} color="error">
            <Notification />
          </Badge>
        </IconButton>
        <p>Notifications</p>
      </MenuItem>
      <MenuItem onClick={handleProfileMenuOpen}>
        <IconButton
          size="small"
          aria-label="account of current user"
          aria-controls="primary-search-account-menu"
          aria-haspopup="true"
          color="inherit"
        >
          <AccountCircle />
        </IconButton>
        <p>Profile</p>
      </MenuItem>
    </Menu>
  );

  return (
    <Box className="menu_css" sx={{ flexGrow: 1 }}>
      <AppBar
        position="static"
        style={{ backgroundColor: "#0070AD", height: "40px" }}
      >
        <Toolbar className="Nav_tool">
          <IconButton
            size="small"
            edge="start"
            color="inherit"
            aria-label="open drawer"
            sx={{ mr: 2 }}
          >
            {/* <MenuIcon /> */}
            <ArrowBackIosIcon />
          </IconButton>

          {/* <Typography
            variant="h6"
            noWrap
            component="div"
            sx={{ display: { xs: 'none', sm: 'block' } }}
          >
            MUI
          </Typography> */}
          <div className="CG_Logo">
            <img src={CG_Logo} alt="img" />
          </div>
          <Typography className="ShapeProgram">
            <p
              onClick={() => {
                navigate("/shape-program");
              }}
              style={{ cursor: "pointer" }}
            >
              Strategy Navigator
            </p>
          </Typography>
          {props.pageName === "home" ? "" : <KeyboardDoubleArrowRightIcon />}
          <Typography className="ShapeProgram">
            <p
              onClick={() => {
                location.pathname.includes("/process-hierarchies")
                  ? navigate("/process-hierarchies")
                  : navigate("/") ||
                    location.pathname.includes("/client/project")
                  ? navigate("/client/project")
                  : navigate("/") ||
                    location.pathname.includes("/valueDriveTrees")
                  ? navigate("/valueDriveTrees")
                  : navigate("/") || location.pathname.includes("/painpoints")
                  ? navigate("/painpoints")
                  : navigate("/");
                // || location.pathname.includes('/ValueDriveTrees/master-value-driver/') ? navigate("/ValueDriveTrees") : navigate("/")

                // || location.pathname.includes('/client/project') ? navigate("/client/project") : navigate("/")
              }}
              style={{ cursor: "pointer" }}
            >
              {props.pageName === "home"
                ? ""
                : // : "Project"}
                  programName}
            </p>
          </Typography>
          {/* {props.pageName === "home"?"":<KeyboardDoubleArrowRightIcon />} */}
          {/* <Typography className="ShapeProgram">
            <p
              onClick={() => {
                navigate("/process-hierarchies");
              }}
              style={{ cursor: "pointer" }}
            >
              {location.pathname.includes("/process-hierarchies") &&
                "Process Hierarchy"}
            </p>
          </Typography> */}
          <Typography className="ShapeProgram">
            <p
              onClick={() => {
                navigate("/process-hierarchies");
              }}
              style={{ cursor: "pointer" }}
            >
              {/* {location.pathname.includes("/process-hierarchies") &&
                "Process Hierarchy"} */}
              {location.pathname.includes("/process-hierarchies")}
            </p>
          </Typography>

          {/* <Search>
            <SearchIconWrapper>
              <SearchIcon />
            </SearchIconWrapper>
            <StyledInputBase
              placeholder="Search…" 
              inputProps={{ 'aria-label': 'search' }}
            />
          </Search> */}
          <Box sx={{ flexGrow: 1 }} />
          <Box sx={{ display: { xs: "none", md: "flex" } }}>
            <Typography
              noWrap
              sx={{
                font: "normal normal medium 18px/21px Ubuntu",
                letterSpacing: "0px",
                mx: "10px",
                opacity: 1,
                fontSize: "1.2rem",
                marginTop: "5px",
              }}
            >
              {projectName}
            </Typography>
            <Divider
              orientation="vertical"
              flexItem
              variant="middle"
              sx={{
                backgroundColor: "#FFFFFF33",
                borderWidth: "1px",
                mx: "10px",
                marginTop: "11px",
                marginBottom: "12px",
              }}
            />
            {/* <IconButton color="inherit" size="large" edge="end" aria-label="home" aria-haspopup="true" onClick={() => navigate("/shape-program")}>
            
            */}
            <IconButton
              color="inherit"
              size="large"
              edge="end"
              aria-label="home"
              aria-haspopup="true"
              onClick={handleHomeChange}
            >
              <HomeOutlinedIcon />
            </IconButton>
            <Divider
              orientation="vertical"
              flexItem
              variant="middle"
              sx={{
                backgroundColor: "#FFFFFF33",
                borderWidth: "1px",
                mx: "10px",
                marginTop: "11px",
                marginBottom: "12px",
              }}
            />
            <IconButton
              size="small"
              aria-label="show 17 new notifications"
              color="inherit"
            >
              <Badge color="error">
                <Notification usertype={props.usertype} />
              </Badge>
            </IconButton>
            <Divider
              orientation="vertical"
              flexItem
              variant="middle"
              sx={{
                backgroundColor: "#FFFFFF33",
                borderWidth: "1px",
                mx: "10px",
                marginTop: "11px",
                marginBottom: "12px",
              }}
            />
            <IconButton
              color="secondary"
              aria-label="notification-item"
              aria-controls="notification"
              aria-haspopup="true"
            >
              {/* <img src="img/Settings_Icon.svg" alt="change project" /> */}
              {/* <img src="" alt="change project" /> */}
              <img src="../../../img/Settings_Icon.svg" alt="change project" />
            </IconButton>
            <Divider
              orientation="vertical"
              flexItem
              variant="middle"
              sx={{
                backgroundColor: "#FFFFFF33",
                borderWidth: "1px",
                mx: "10px",
                marginTop: "11px",
                marginBottom: "12px",
              }}
            />
            <IconButton
              size="small"
              edge="end"
              aria-label="account of current user"
              aria-controls={menuId}
              aria-haspopup="true"
              onClick={handleProfileMenuOpen}
              color="inherit"
            >
              <AccountCircle />
            </IconButton>
          </Box>

          <Box sx={{ display: { xs: "flex", md: "none" } }}>
            <IconButton
              size="small"
              aria-label="show more"
              aria-controls={mobileMenuId}
              aria-haspopup="true"
              onClick={handleMobileMenuOpen}
              color="inherit"
            >
              <MoreIcon />
            </IconButton>
          </Box>
        </Toolbar>
      </AppBar>
      {renderMobileMenu}
      {renderMenu}
    </Box>
  );
}
