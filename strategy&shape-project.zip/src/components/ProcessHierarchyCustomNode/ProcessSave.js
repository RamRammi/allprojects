import React, { useState, useEffect } from "react"
import Button from "@mui/material/Button"
import Box from "@mui/material/Box"
import Typography from "@mui/material/Typography"
import Modal from "@mui/material/Modal"
import SuccssMsg from "../../components/AlertBox/SuccessMsg"
import WarningMsg from "../../components/AlertBox/WarningMsg"
import { useNavigate, useLocation, Link } from "react-router-dom"
import CircularProgress from "@mui/material/CircularProgress"
import * as Constant from "../../comman/constant"
import { BASE_URL, BASE_DAN_BE_URL } from "../../comman/constant"
import { useSelector } from "react-redux"
import * as Api from "../../comman/api"

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 250,
  textAlign: "center",
  bgcolor: "background.paper",
  border: "2px solid #000",
  boxShadow: 24,
  p: 4,
}

export const ProcessSave = (props) => {
  const location = useLocation()
  const [open, setOpen] = React.useState(false)
  const [saveTree, setSaveTree] = useState()
  const [spin, setSpin] = useState(false)
  const [showAlertBox, setShowAlertBox] = useState(false)
  const [successMessage, setSuccessMessage] = useState("")
  const [showWarningBox, setShowWarningBox] = useState(false)
  const [warningMessage, setWarningMessage] = useState("")

  let navigate = useNavigate()
  const projectId = useSelector((state) => state.questionnaireReducer.projectId)
  const clientId = useSelector((state) => state.questionnaireReducer.clientId)
  const userId = useSelector((state) => state.questionnaireReducer.userId)
  const email = useSelector((state) => state.questionnaireReducer.userData.email)

  const saveSelectedNode = async () => {
    let data = JSON.stringify({ objPhSaveList: props.newSelectedResult, objPlatformUserDetails: { projectId: projectId, clientId: clientId, userId: userId, email: email } })
    let URL = BASE_DAN_BE_URL + Constant.PROCESS_HIERARCHY_SAVE
    Api.saveClientPH(URL, data)
      .then((result) => {
        if (result.statusCode === 200) {
          setSaveTree(result)
          setShowAlertBox(true)
          setSuccessMessage("Successfully Saved")
          if (props.saveModal) {
            setOpen(false)
          }
          setInterval(() => {
            window.location.reload(true)
          }, 600)
          console.log(result.message)
        } else {
          setShowWarningBox(true)
          setWarningMessage("Something went wrong")
          if (props.saveModal) {
            setOpen(false)
          }
          setSpin(false)
        }
      })
      .catch((err) => console.log(err))
  }

  // const isOwnerStatus = props.newSelectedResult.find((val) => {
  //   if (val.isOwner) {
  //     return val.isOwner
  //   }
  // })

  const handleSubmit = (event) => {
    event.preventDefault()
    saveSelectedNode()
    setSpin(true)
  }

  const handleBack = () => {
    if (props.saveModal) {
      setOpen(true)
    } else {
      navigate(-1)
    }
  }
  const handleBackClose = () => setOpen(false)
  //console.log(variable)
  return (
    <div className="rightCol-inner footerbtn">
      {spin && <div className="loader">{!saveTree && <CircularProgress />}</div>}
      {/* <div className={isOwnerStatus === undefined ? "noneedit" : ""}> */}
      {props.showBtn ? (
        <>
          {!spin ? (
            <Button onClick={handleSubmit} style={{ float: "right", marginTop: "0" }} variant="contained">
              {saveTree ? "Saved" : "save"}
            </Button>
          ) : (
            <CircularProgress size="22px" style={{ float: "right", marginTop: "4px", marginLeft: "4px" }} />
          )}
        </>
      ) : (
        props.clientValue != "Client preview" &&
        props.masterValue != "Master preview" && (
          <Button onClick={props.handleEdit} style={{ float: "right", marginTop: "0" }} variant="outlined">
            Edit
          </Button>
        )
      )}
      {/* </div> */}
      <Button onClick={handleBack} style={{ float: "right", marginTop: "0" }} variant="outlined">
        Back
      </Button>

      <Modal open={open} onClose={handleBackClose} aria-labelledby="modal-modal-title" aria-describedby="modal-modal-description">
        <Box sx={style}>
          <Typography id="modal-modal-title" variant="h6" component="h2">
            Save Changes?
          </Typography>
          {!spin ? (
            <>
              <Button onClick={handleSubmit} style={{ borderRadius: "30px", marginTop: "10px" }} variant="contained">
                {saveTree ? "Saved" : "save"}
              </Button>
              <Button onClick={() => navigate(-1)} style={{ borderRadius: "30px", marginLeft: "10px", marginTop: "10px" }} variant="outlined">
                No
              </Button>
            </>
          ) : (
            <CircularProgress style={{ marginTop: "10px" }} size="22px" />
          )}
        </Box>
      </Modal>
      <SuccssMsg showAlertBox={showAlertBox} setShowAlertBox={setShowAlertBox} message={successMessage} />
      <WarningMsg showWarningBox={showWarningBox} setShowWarningBox={setShowWarningBox} message={warningMessage} />
    </div>
  )
}
