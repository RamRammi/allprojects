const NodeColor = {
  Level1: "#0070AD",
  Level2: "#0F999C",
  Level3: "#CB2980",
  Level4: "#6D64CC",
  Level5: "#FF7E83",
}

export default NodeColor
