import React, { useState, useEffect } from "react"
import IconButton from "@mui/material/IconButton"
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp"
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown"
import TextField from "@mui/material/TextField"
import CheckIcon from "@mui/icons-material/Check"
import CloseIcon from "@mui/icons-material/Close"
import AddCircleOutlineIcon from "@mui/icons-material/AddCircleOutline"
import Checkbox from "@mui/material/Checkbox"
import EditIcon from "@mui/icons-material/Edit"
import { useDragOver } from "@minoru/react-dnd-treeview"
import styles from "./customnode.css"

export const CustomNode = (props) => {
  const [hover, setHover] = useState(false)
  const { id } = props.node
  const [visibleInput, setVisibleInput] = useState(false)
  const [labelText, setLabelText] = useState(props.node.text)
  const [object, setObject] = useState([])
  useEffect(() => {
    setObject(props.node)
  }, [object])

  const storeObj = () => {
    localStorage.setItem("single-node", JSON.stringify(object))
  }

  const handleSelect = (e) => {
    props.onSelect(props.node)

    props.node.isNew = props.addNewNode
    props.node.isUpdated = false
    const boolStatus = props.isNewtrue ? true : false
    props.node.isNew = boolStatus
    if (e.target.checked) {
      props.node.isChecked = true

      if (props.addNewNode) {
        //props.node.isUpdated = false
        props.node.isNew = props.addNewNode
      } else {
        //props.node.isUpdated = false
        props.node.isNew = boolStatus
      }
    } else {
      props.node.isChecked = false
      if (props.addNewNode) {
        //props.node.isUpdated = false
        props.node.isNew = true
      } else {
        props.node.isNew = boolStatus
        //props.node.isUpdated = true
      }
      //props.node.isNew = boolStatus
    }
    // props.node.Layer = Number(e.target.parentElement.parentElement.parentElement.parentElement.className.slice(-1)) + 1
  }

  props.node.isUpdated = true

  //props.node.isChecked = props.isSelected
  //props.node.isNew = boolStatus
  // props.node.isUpdated = !props.isSelected
  props.node.Layer = props.depth + 1

  // const selectionCheck = () => {
  //   if (props.node.isChecked === false && props.node.isNew === false && props.node.isUpdated === false) {
  //     return false
  //   } else {
  //     return true
  //   }
  // }

  const handleToggle = (e) => {
    e.stopPropagation()
    props.onToggle(props.node.id)
  }
  const handleShowInput = () => {
    setVisibleInput(true)
  }

  const handleCancel = () => {
    setLabelText(props.node.text)
    setVisibleInput(false)
  }

  const handleChangeText = (e) => {
    setLabelText(e.target.value)
    props.node.isUpdated = true
    // if (props.addNewNode) {
    //   props.node.isUpdated = false
    // }
  }

  const handleSubmit = () => {
    setVisibleInput(false)
    props.onTextChange(id, labelText)
  }

  const dragOverProps = useDragOver(id, props.isOpen, props.onToggle)

  return (
    <div className={`tree-subitem-${props.depth} ${props.node.isChecked}`} onClick={storeObj} {...dragOverProps}>
      <div className={styles.labelGridItem}>
        {visibleInput ? (
          <div className="edit-node">
            <TextField className="single-edit-node" value={labelText} onChange={handleChangeText} />
            <IconButton className="edit-button" onClick={handleSubmit} disabled={labelText === ""}>
              <CheckIcon className="edit-icon" />
            </IconButton>
            <IconButton className="edit-button" onClick={handleCancel}>
              <CloseIcon className="edit-icon" />
            </IconButton>
          </div>
        ) : (
          <div className={`normal-node ${props.node.isChecked}`}>
            <span
              style={{
                borderLeftColor: props.node.color,
                borderLeftStyle: "solid",
                borderLeftWidth: "6px",
              }}
              className="node-text"
              onClick={props.showBtn ? handleShowInput : undefined}
            >
              {props.node.sequenceNumber + " "}
              {props.node.text}
            </span>
            {props.node.droppable && props.hasChild ? (
              <span className="node-navIcon" onClick={handleToggle}>
                {props.isOpen ? <KeyboardArrowUpIcon className="edit-icon" /> : <KeyboardArrowDownIcon className="edit-icon" />}
              </span>
            ) : (
              ""
            )}
            {props.showBtn ? (
              <>
                {props.depth != 4 && <AddCircleOutlineIcon onClick={props.handleOpenDialog} className="add-node" />}
                <Checkbox className="check-node" color="primary" size="small" checked={props.node.isChecked ? true : false} onClick={handleSelect} />
              </>
            ) : (
              ""
            )}
          </div>
        )}
      </div>
    </div>
  )
}
