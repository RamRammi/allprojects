import React, { useState, useEffect } from "react"
import { Link } from "react-router-dom"

import "./processsteps.css"
import Accordion from "@mui/material/Accordion"
import AccordionDetails from "@mui/material/AccordionDetails"
import AccordionSummary from "@mui/material/AccordionSummary"
import ExpandMoreIcon from "@mui/icons-material/ExpandMore"

const ProcessSteps = (props) => {
  const [expanded, setExpanded] = useState(props.expandAll || props.isCheckedId === true ? true : false)
  const [panelids, setpanelids] = useState([])

  useEffect(() => {
    getcs()
  }, [props.expandAll, props.searchStr, props.isCheckedId])

  const getcs = () => {
    let ids = []
    //let clientIds = []
    if (props.expandAll === true) {
      props.processData.map((k) => {
        ids.push(k.id)
      })
      setpanelids(ids)
    } else if (props.isCheckedId != "") {
      // clientIds.push(props.isCheckedId)
      setpanelids(props.isCheckedId)
      //setpanelids(ids)
    } else {
      setpanelids([])
    }
  }
  const getHighlightedText = (text, higlight) => {
    // Split text on higlight term, include term itself into parts, ignore case
    if (higlight !== "") {
      var parts = text.split(new RegExp(`(${higlight})`, "gi"))
      return (
        <div style={{ display: "block" }}>
          {parts.map((part, index) => (
            <span style={{ backgroundColor: part.toLowerCase() === higlight.toLowerCase() ? "#e8bb49" : "white" }}>{part}</span>
          ))}
        </div>
      )
    } else {
      return text
    }
  }
  const handleChange = (panel) => async (event, newExpanded) => {
    setExpanded(newExpanded ? panel : false)

    if (panelids.includes(panel)) {
      let arr = panelids
      const ryu = arr.filter((item) => item !== panel)
      await setpanelids(ryu)
    } else {
      let arr = panelids
      arr.push(panel)
      await setpanelids(arr)
    }
    // if (panelids.includes(panel)) {
    //   let arr = panelids
    //   const ryu = arr.filter((item) => item !== panel)
    // }
  }
  return (
    <div>
      {props.processData.map((panel) => (
        <Accordion disableGutters={true} square={true} expanded={expanded === panel.id || panelids.includes(panel.id)} onChange={handleChange(panel.id)}>
          <AccordionSummary expandIcon={<ExpandMoreIcon width="medium" style={{ fill: "#0070ad", transform: "scale(1.3)" }} />} aria-controls={panel.description} id={panel.id}>
            <Link to={`/process-hierarchies/process/${panel.id}`}>
              <p>{panel.description}</p>
            </Link>
          </AccordionSummary>
          <AccordionDetails className="wrapper">
            <div className="processblocks">
              <span className="processsteps borderlevel-one">{getHighlightedText(panel.description.split(" ")[0] ?? "", props.searchStr)}</span>
            </div>
            {panel.masterl2List.map((level) => {
              return (
                <div key={level.id} className="processblocks">
                  <span className="processsteps borderlevel-two">{getHighlightedText(level.description, props.searchStr)}</span>
                </div>
              )
            })}
            <div className="processblocks">
              <span className="processsteps borderlevel-one">
                {getHighlightedText(
                  panel.description
                    .replace(/[\s-]+$/, "")
                    .split(/[\s-]/)
                    .pop() ?? "",
                  props.searchStr
                )}
              </span>
            </div>
          </AccordionDetails>
        </Accordion>
      ))}
    </div>
  )
}

export default ProcessSteps
