import React, { useState, useEffect } from "react"
import { Link } from "react-router-dom"
import "./processsteps.css"
import Button from "@mui/material/Button"
import Box from "@mui/material/Box"
import Typography from "@mui/material/Typography"
import Modal from "@mui/material/Modal"
import Accordion from "@mui/material/Accordion"
import CircularProgress from "@mui/material/CircularProgress"
import AccordionDetails from "@mui/material/AccordionDetails"
import AccordionSummary from "@mui/material/AccordionSummary"
import ExpandMoreIcon from "@mui/icons-material/ExpandMore"
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline"
import OpenInNewIcon from "@mui/icons-material/OpenInNew"

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 250,
  textAlign: "center",
  bgcolor: "background.paper",
  border: "2px solid #000",
  boxShadow: 24,
  p: 4,
}

const ProcessStepsClient = (props) => {
  const [expanded, setExpanded] = useState(props.expandAll || props.isCheckedId === true ? true : false)
  const [panelids, setpanelids] = useState([])
  const [open, setOpen] = useState(false)

  useEffect(() => {
    getcs()
  }, [props.expandAll, props.searchStr, props.isCheckedId])

  const getcs = () => {
    let ids = []
    //let clientIds = []
    if (props.expandAll === true) {
      props.processDataClient.map((k) => {
        ids.push(k.id)
      })
      setpanelids(ids)
    } else if (props.isCheckedId != "") {
      // clientIds.push(props.isCheckedId)
      setpanelids(props.isCheckedId)
      //setpanelids(ids)
    } else {
      setpanelids([])
    }
  }

  const getHighlightedText = (text, higlight) => {
    // Split text on higlight term, include term itself into parts, ignore case
    if (higlight !== "") {
      var parts = text.split(new RegExp(`(${higlight})`, "gi"))
      return (
        <div style={{ display: "block" }}>
          {parts.map((part, index) => (
            <span style={{ backgroundColor: part.toLowerCase() === higlight.toLowerCase() ? "#e8bb49" : "white" }}>{part}</span>
          ))}
        </div>
      )
    } else {
      return text
    }
  }

  const handleChange = (panel) => async (event, newExpanded) => {
    setExpanded(newExpanded ? panel : false)

    if (panelids.includes(panel)) {
      let arr = panelids
      const ryu = arr.filter((item) => item !== panel)
      await setpanelids(ryu)
    } else {
      let arr = panelids
      arr.push(panel)
      await setpanelids(arr)
    }
  }
  const [deleteProcessId, setDeleteProcessId] = useState()
  //console.log(props.processDataClient)
  const handleOpen = () => setOpen(true)
  const handleClose = () => setOpen(false)

  return (
    <>
      {props.processDataClient != "" ? (
        props.processDataClient.map((panel) => {
          return (
            <>
              <Accordion key={panel.id} disableGutters={true} square={true} expanded={expanded === panel.id || panelids.includes(panel.id)} onChange={handleChange(panel.id)}>
                <AccordionSummary className="accordion-box-display" expandIcon={panel.link ? "" : <ExpandMoreIcon width="medium" style={{ fill: "#0070ad", transform: "scale(1.3)" }} />} aria-controls={panel.description} id={panel.id}>
                  <a
                    onClick={() => {
                      handleOpen()
                      setDeleteProcessId(panel.id)
                    }}
                    title="Delete"
                    style={{ float: "right", marginRight: "5px" }}
                  >
                    <DeleteOutlineIcon />
                  </a>
                  {panel.link ? (
                    <Link to={panel.link} className="link-icon" target="_blank">
                      <p style={{ float: "left", marginRight: "8px" }}>
                        {getHighlightedText(panel.description, props.searchStr)} <OpenInNewIcon />
                      </p>

                      <em style={{ fontSize: "10px", textDecoration: "underline", float: "right", marginTop: "3px", marginRight: "10px" }}>{panel.createdBy ? getHighlightedText(panel.createdBy, props.searchStr) : ""}</em>
                    </Link>
                  ) : (
                    <Link to={`/process-hierarchies/client-process/${panel.id}`}>
                      <p style={{ float: "left", marginRight: "8px" }}>{getHighlightedText(panel.description, props.searchStr)}</p>
                      <em style={{ fontSize: "10px", textDecoration: "underline", float: "right", marginTop: "3px", marginRight: "10px" }}>{panel.createdBy ? getHighlightedText(panel.createdBy, props.searchStr) : ""}</em>
                    </Link>
                  )}
                </AccordionSummary>
                {panel.link ? (
                  ""
                ) : (
                  <AccordionDetails className="wrapper">
                    <div className="processblocks">
                      <span className="processsteps borderlevel-one">{getHighlightedText(panel.description.split(" ")[0] ?? "", props.searchStr)}</span>
                    </div>

                    {panel.clientL2BPHs.map((level) => {
                      return (
                        <div key={level.id} className="processblocks">
                          <span className="processsteps borderlevel-two">
                            {/* {level.description}test2 */}
                            {getHighlightedText(level.description, props.searchStr)}
                          </span>
                        </div>
                      )
                    })}

                    <div className="processblocks">
                      <span className="processsteps borderlevel-one">
                        {/* {panel.description.split(" ")[2]}test3 */}
                        {getHighlightedText(
                          panel.description
                            .replace(/[\s-]+$/, "")
                            .split(/[\s-]/)
                            .pop() ?? "",
                          props.searchStr
                        )}
                      </span>
                    </div>
                  </AccordionDetails>
                )}
              </Accordion>
            </>
          )
        })
      ) : (
        <div style={{ marginTop: "15px" }}>
          <em>No Records Found</em>
        </div>
      )}
      <Modal open={open} onClose={handleClose} aria-labelledby="modal-modal-title" aria-describedby="modal-modal-description">
        <Box sx={style}>
          <Typography id="modal-modal-title" variant="h6" component="h2">
            Are you sure?
          </Typography>
          <Button
            onClick={() => {
              props.handleDelete(deleteProcessId)
              handleClose()
            }}
            style={{ borderRadius: "30px", marginTop: "10px" }}
            variant="contained"
          >
            Yes
          </Button>
          <Button onClick={handleClose} style={{ borderRadius: "30px", marginLeft: "10px", marginTop: "10px" }} variant="outlined">
            No
          </Button>
        </Box>
      </Modal>
    </>
  )
}

export default ProcessStepsClient
