import React, { useState } from "react"
import Modal from "@mui/material/Modal"
import Box from "@mui/material/Box"
import Table from "@mui/material/Table"
import TableBody from "@mui/material/TableBody"
import TableCell from "@mui/material/TableCell"
import TableContainer from "@mui/material/TableContainer"
import TableHead from "@mui/material/TableHead"
import TableRow from "@mui/material/TableRow"
import Checkbox from "@mui/material/Checkbox"
import Button from "@mui/material/Button"

const boxStyle = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: "40%",
  bgcolor: "background.paper",
  boxShadow: 24,
  p: 2,
  "@media(max-height: 890px)": {
    top: "0",
    transform: "translate(-50%, 0%)",
  },
}

const ProcessModal = (props) => {
  const handleImport = (e) => {}
  return (
    <Modal open={props.opens} onClose={props.handleClose} sx={{ overflowY: "scroll" }} disableScrollLock={false} aria-labelledby="modal-modal-title" aria-describedby="modal-modal-description">
      <Box sx={boxStyle}>
        <h4 style={{ marginTop: "5px" }}>Process Hierarchies</h4>
        <TableContainer>
          <Table sx={{ minWidth: 100 }} aria-label="simple table">
            <TableHead>
              <TableRow>
                <TableCell></TableCell>
                <TableCell align="left">S.no</TableCell>
                <TableCell align="left">End to End Processes</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {props.checkList.map((row, index) => (
                <TableRow key={row.id} sx={{ "&:last-child td, &:last-child th": { border: 0 } }}>
                  <TableCell width="10%" size="small" padding="checkbox" component="th" scope="row">
                    <Checkbox defaultChecked />
                  </TableCell>
                  <TableCell width="20%" align="left">
                    {index + 1}
                  </TableCell>
                  <TableCell width="70%" style={{ color: "#0070AD" }} align="left">
                    {row.description}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
        <div className="processBtn">
          <Button onClick={() => props.handleClose()} variant="outlined">
            Cancel
          </Button>
          <Button onClick={() => handleImport()} variant="contained">
            Import
          </Button>
        </div>
      </Box>
    </Modal>
  )
}
export default ProcessModal
