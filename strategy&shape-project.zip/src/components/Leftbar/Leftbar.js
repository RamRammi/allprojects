import React from "react";

import { NavLink } from "react-router-dom";

import ContentCopyIcon from "@mui/icons-material/ContentCopy";

import GridViewIcon from "@mui/icons-material/GridView";

import DescriptionIcon from "@mui/icons-material/Description";
import questionnaire from "../.././";
import { Typography } from "@mui/material";

import "./Leftbar.css";
import { useSelector } from "react-redux";

const Leftbar = () => {
  const programName = useSelector(
    (state) => state.questionnaireReducer.programName
  );
  return (
    <React.Fragment>
      <div className="Leftbar_bg">
        {programName === "Ambition & Levers" ? (
          <div>
            {/* <div className="Leftbar_pad">
            <p className="Leftbar_central">
              <NavLink to="/" onClick={(event) => event.preventDefault()}>
                {" "}
                <ContentCopyIcon className="leftbar_css" />
                <p>Project Doc Repository</p>
              </NavLink>
            </p>
          </div> */}

            <NavLink to="/">
              <div className="Leftbar_pad">
                <p className="Leftbar_central">
                  {/* <GridViewIcon className="leftbar_css" /> */}
                  <img
                    className="leftbar_css"
                    src="../img/questionaire-icon.svg"
                    width="15"
                    height="15"
                    alt="Questionnaire"
                  />

                  <p>Questionnaire</p>
                </p>
              </div>
            </NavLink>

            <NavLink to="/process-hierarchies">
              <div className="Leftbar_pad">
                <p className="Leftbar_central">
                  {/* <DescriptionIcon className="leftbar_css" /> */}
                  <img
                    className="leftbar_css"
                    src="../img/process-icon.svg"
                    width="15"
                    height="15"
                    alt="Questionnaire"
                  />
                  Process Hierachies
                </p>
              </div>
            </NavLink>

            <NavLink to="/valueDriveTrees">
              <div className="Leftbar_pad">
                <p className="Leftbar_central">
                  {/* <DescriptionIcon className="leftbar_css" /> */}
                  <img
                    className="leftbar_css"
                    src="../img/value-icon.svg"
                    width="15"
                    height="15"
                    alt="Value Driver Tree"
                  />
                  Value Driver Tree
                </p>
              </div>
            </NavLink>

            <NavLink
              to="/TaskSummary"
              onClick={(event) => event.preventDefault()}
            >
              <div className="Leftbar_pad">
                <p className="Leftbar_central">
                  <img
                    className="leftbar_css"
                    src="../img/questionaire-icon.svg"
                    width="15"
                    height="15"
                    alt="Questionnaire"
                  />
                  Summary
                </p>
              </div>
            </NavLink>

            <NavLink to="/client/project">
              <div className="Leftbar_pad">
                <p className="Leftbar_central">
                  <img
                    className="leftbar_css"
                    src="../img/questionaire-icon.svg"
                    width="15"
                    height="15"
                    alt="Questionnaire"
                  />
                  Client
                </p>
              </div>
            </NavLink>
          </div>
        ) : (
          ""
        )}
        {programName === "Maturity" ? (
          <div>
            <NavLink to="/" onClick={(event) => event.preventDefault()}>
              <div className="Leftbar_pad">
                <p className="Leftbar_central">
                  {/* <GridViewIcon className="leftbar_css" /> */}
                  <img
                    className="leftbar_css"
                    src="../../img/kpi.svg"
                    width="15"
                    height="15"
                    alt="KPIs"
                  />

                  <p>KPI's</p>
                </p>
              </div>
            </NavLink>

            <NavLink to="/painpoints">
              <div className="Leftbar_pad">
                <p className="Leftbar_central">
                  {/* <DescriptionIcon className="leftbar_css" /> */}
                  <img
                    className="leftbar_css"
                    src="../../img/pain-point.svg"
                    width="15"
                    height="15"
                    alt="pain-point-icon"
                  />
                  Pain Points & Improvement Opportunities
                </p>
              </div>
            </NavLink>

            <NavLink to="/" onClick={(event) => event.preventDefault()}>
              <div className="Leftbar_pad">
                <p className="Leftbar_central">
                  {/* <DescriptionIcon className="leftbar_css" /> */}
                  <img
                    className="leftbar_css"
                    src="../../img/maturity-matrix.svg"
                    width="15"
                    height="15"
                    alt="maturity-matrix-icon"
                  />
                  Maturity Matrix
                </p>
              </div>
            </NavLink>
            <NavLink to="/" onClick={(event) => event.preventDefault()}>
              <div className="Leftbar_pad">
                <p className="Leftbar_central">
                  {/* <GridViewIcon className="leftbar_css" /> */}
                  <img
                    className="leftbar_css"
                    src="../../img/skills.svg"
                    width="15"
                    height="15"
                    alt="skills-icon"
                  />

                  <p>Skills</p>
                </p>
              </div>
            </NavLink>
          </div>
        ) : (
          ""
        )}
      </div>
    </React.Fragment>
  );
};

export default Leftbar;
