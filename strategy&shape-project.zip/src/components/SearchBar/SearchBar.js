import * as React from "react";
import { styled, alpha } from "@mui/material/styles";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import "./SearchBar.css";
import Button from "@mui/material/Button";
import InputBase from "@mui/material/InputBase";
import { Link, useNavigate } from "react-router-dom";
import SearchIcon from "@mui/icons-material/Search";
import { useSelector, useDispatch } from "react-redux";
import {
  setLeadershipId,
  setMasterFilterQuestion,
  setMasterQuestionSearch,
  setLeadershipCateName,
  setLeadershipCate,
  setRoleList,
  setSelectedRoles,
  setMasterSearchApply,
  setSelectedMasterQuestion,
  setGeneralQuestion,
  setLeaderShipQuestion,
  setRoleQuestion,
  setTemplateId,
  setPId,
  setSavedQuestions,
  setQuestionnaireState,
  setAddNewQuestionsFlag,
  setTemplateName,
  setTemplateStatus,
  setMasterQuestionnaireEvent,
  setEditQuestionList,
  setQuestionnaireEvent,
} from "../../redux/actions/questionnaireAction";

const Search = styled("div")(({ theme }) => ({
  position: "relative",
  borderRadius: theme.shape.borderRadius,
  backgroundColor: alpha(theme.palette.common.white, 0.15),
  "&:hover": {
    backgroundColor: alpha(theme.palette.common.white, 0.25),
  },
  marginRight: theme.spacing(2),
  marginLeft: 0,

  [theme.breakpoints.up("sm")]: {
    marginLeft: theme.spacing(3),
    width: "auto",
  },
}));

const SearchIconWrapper = styled("div")(({ theme }) => ({
  padding: theme.spacing(0, 2),
  height: "100%",
  position: "absolute",
  pointerEvents: "none",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
}));

const StyledInputBase = styled(InputBase)(({ theme }) => ({
  color: "inherit",
  "& .MuiInputBase-input": {
    padding: theme.spacing(1, 1, 1, 0),
    // vertical padding + font size from searchIcon
    paddingLeft: `calc(1em + ${theme.spacing(4)})`,
    transition: theme.transitions.create("width"),

    [theme.breakpoints.up("md")]: {},
  },
}));

export default function SearchBar(props) {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const addQuestionnaire = () => {
    dispatch(setLeadershipCate([]));
    dispatch(setLeadershipCateName([]));
    dispatch(setLeadershipId(0));
    dispatch(setSelectedRoles([]));
    dispatch(setRoleList([]));
    dispatch(setMasterQuestionSearch(""));
    dispatch(setMasterSearchApply(false));
    dispatch(
      setMasterFilterQuestion({
        general: [],
        leadershipType: [],
        roleSpecific: [],
      })
    );
    dispatch(setSelectedMasterQuestion([]));
    dispatch(setGeneralQuestion([]));
    dispatch(setLeaderShipQuestion([]));
    dispatch(setRoleQuestion([]));
    dispatch(setTemplateId(0));
    dispatch(setPId(0));
    dispatch(setSavedQuestions([]));
    dispatch(setQuestionnaireState("add"));
    dispatch(setTemplateName("Untitled"));
    dispatch(setTemplateStatus(""));
    dispatch(setQuestionnaireEvent(""));
    dispatch(setMasterQuestionnaireEvent("add"));
    dispatch(setEditQuestionList([]));
    navigate("/Questionnaire");
  };

  return (
    <React.Fragment>
      <div className="search-button-border">
        <Box className="search_button_M" sx={{ flexGrow: 1 }}>
          <AppBar className="search_button_s" position="static">
            <Search className="search_button">
              <SearchIconWrapper className="searchIconWrapper_css">
                <SearchIcon className="searchicon_css" />
              </SearchIconWrapper>
              <StyledInputBase
                className="search_inputbase"
                placeholder="Search…"
                inputProps={{ "aria-label": "search" }}
                defaultValue={props.searchStr ? props.searchStr : ""}
                onChange={(event) => props.searchText(event)}
              />
            </Search>
            <Box sx={{ flexGrow: 1 }} />
          </AppBar>
        </Box>

        {/* {props.pageName === "project" ? (
          <Button
            className="Project_search_css"
            variant="contained"
            style={{ backgroundColor: "#0070AD", color: "#fff" }}
          >
            Upload
          </Button>
        ) : (
          ""
        )} */}
        {props.pageName === "project" ? (
          <Button className="Project_search_css1" onClick={addQuestionnaire}>
            Create New Questionnaries
          </Button>
        ) : (
          ""
        )}
        {/* {props.pageName === "addQuestionnaire" ? (
          <Button
            className="Questionnaire_search_css"
            variant="contained"
            style={{ backgroundColor: "#0070AD", color: "#fff" }}
          >
            Upload
          </Button>
        ) : (
          ""
        )} */}
        {props.pageName === "addQuestionnaire" ? (
          <Button
            className="Questionnaire_search_css1"
            variant="outlined"
            onClick={() => dispatch(setAddNewQuestionsFlag(1))}
            // disabled={!props.isOwner}
          >
            Add Question
          </Button>
        ) : (
          ""
        )}
      </div>
    </React.Fragment>
  );
}
