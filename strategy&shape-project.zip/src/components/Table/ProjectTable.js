import * as React from "react";
import PropTypes from "prop-types";
import "./ProjectTable.css";
import Box from "@mui/material/Box";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import TableSortLabel from "@mui/material/TableSortLabel";
import Toolbar from "@mui/material/Toolbar";
import Typography from "@mui/material/Typography";
import Paper from "@mui/material/Paper";
import IconButton from "@mui/material/IconButton";
import Tooltip from "@mui/material/Tooltip";
import FormControlLabel from "@mui/material/FormControlLabel";
import Switch from "@mui/material/Switch";
import DeleteIcon from "@mui/icons-material/Delete";
import FilterListIcon from "@mui/icons-material/FilterList";
import { visuallyHidden } from "@mui/utils";
import { Pagination } from "@mui/material";
import { PausePresentationTwoTone } from "@mui/icons-material";
import FileMoreVerIcon from "../Icons/FileMoreVerIcon";
import ContentCopyIcon from "@mui/icons-material/ContentCopy";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import { useNavigate } from "react-router-dom";
import FileDownloadIcon from "../../components/Icons/FileDownloadIcon";
import SearchBar from "../SearchBar/SearchBar";
import * as Api from "../../comman/api";
import * as Constant from "../../comman/constant";
import { useSelector, useDispatch } from "react-redux";
import {
  setLeadershipId,
  setMasterFilterQuestion,
  setMasterQuestionSearch,
  setLeadershipCateName,
  setLeadershipCate,
  setRoleList,
  setSelectedRoles,
  setMasterSearchApply,
  setSelectedMasterQuestion,
  setGeneralQuestion,
  setLeaderShipQuestion,
  setRoleQuestion,
  setTemplateId,
  setPId,
  setQuestionnaireState,
  setAddNewQuestionsFlag,
  setTemplateStatus,
  setQuestionnaireEvent,
} from "../../redux/actions/questionnaireAction";

function descendingComparator(a, b, orderBy) {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
}

function getComparator(order, orderBy) {
  return order === "desc"
    ? (a, b) => descendingComparator(a, b, orderBy)
    : (a, b) => -descendingComparator(a, b, orderBy);
}

// This method is created for cross-browser compatibility, if you don't
// need to support IE11, you can use Array.prototype.sort() directly
function stableSort(array, comparator) {
  const stabilizedThis = array.map((el, index) => [el, index]);
  stabilizedThis.sort((a, b) => {
    const order = comparator(a[0], b[0]);
    if (order !== 0) {
      return order;
    }
    return a[1] - b[1];
  });
  return stabilizedThis.map((el) => el[0]);
}

const headCells = [
  {
    id: "name",
    numeric: false,
    disablePadding: true,
    label: "S.no",
  },
  {
    id: "calories",
    numeric: true,
    disablePadding: false,
    label: "Project Templates",
  },
  {
    id: "fat",
    numeric: true,
    disablePadding: false,
    label: "Date",
  },
  {
    id: "email",
    numeric: true,
    disablePadding: true,
    label: "Owner",
  },
  {
    id: "action",
    numeric: true,
    disablePadding: false,
    label: "Actions",
  },
];

function EnhancedTableHead(props) {
  const {
    onSelectAllClick,
    order,
    orderBy,
    numSelected,
    rowCount,
    onRequestSort,
  } = props;
  const createSortHandler = (property) => (event) => {
    onRequestSort(event, property);
  };

  return (
    <TableHead>
      <TableRow>
        {headCells.map((headCell) => (
          <TableCell
            key={headCell.id}
            align={headCell.numeric ? "left" : "left"}
            padding={headCell.disablePadding ? "none" : "normal"}
            sortDirection={orderBy === headCell.id ? order : false}
          >
            {/* <TableSortLabel
              active={orderBy === headCell.id}
              direction={orderBy === headCell.id ? order : "asc"}
              onClick={createSortHandler(headCell.id)}
            > */}
            {headCell.label}
            {orderBy === headCell.id ? (
              <Box component3="span" sx={visuallyHidden}>
                {order === "desc" ? "sorted descending" : "sorted ascending"}
              </Box>
            ) : null}
            {/* </TableSortLabel> */}
          </TableCell>
        ))}
      </TableRow>
    </TableHead>
  );
}

EnhancedTableHead.propTypes = {
  numSelected: PropTypes.number.isRequired,
  onRequestSort: PropTypes.func.isRequired,
  onSelectAllClick: PropTypes.func.isRequired,
  order: PropTypes.oneOf(["asc", "desc"]).isRequired,
  orderBy: PropTypes.string.isRequired,
  rowCount: PropTypes.number.isRequired,
};

export default function ProjectTable(props) {
  const [order, setOrder] = React.useState("asc");
  const [orderBy, setOrderBy] = React.useState("calories");
  const [selected, setSelected] = React.useState([]);
  const [page, setPage] = React.useState(0);
  const [dense, setDense] = React.useState(false);
  const [rowsPerPage, setRowsPerPage] = React.useState(5);
  const [pageCount, setPagepageCount] = React.useState(0);
  const [tableData, setTableData] = React.useState([]);
  const [rows, setRows] = React.useState([]);
  const [searchStr, setSearchStr] = React.useState("");
  const [showAlertBox, setShowAlertBox] = React.useState("");
  const [successMessage, setSuccessMessage] = React.useState("");
  const projectId = useSelector(
    (state) => state.questionnaireReducer.projectId
  );
  const clientId = useSelector((state) => state.questionnaireReducer.clientId);
  const userId = useSelector((state) => state.questionnaireReducer.userId);
  const email = useSelector(
    (state) => state.questionnaireReducer.userData.email
  );
  const navigate = useNavigate();
  const dispatch = useDispatch();
  React.useEffect(() => {
    getSearchData();
  }, [searchStr]);

  // React.useEffect(() => {
  //   getProjectTable();
  // }, [props.filterField]);

  React.useEffect(() => {
    setPage(0);
    if (tableData.length > 0) {
      let pageCounts = Math.ceil(tableData.length / rowsPerPage);
      setPagepageCount(pageCounts);
    }
  }, [rowsPerPage, tableData]);

  const getProjectTable = () => {
    setTableData(props.filterField);
    setRows(props.filterField);
  };
  const dateFormat = (d) => {
    let date = new Date(d);
    return (
      date.getDate() + "/" + (date.getMonth() + 1) + "/" + date.getFullYear()
    );
  };

  const searchText = (event) => {
    setSearchStr(event.target.value);
  };
  const getSearchData = () => {
    let data = {
      projectId: projectId,
      clientId: clientId,
      userId: userId,
      search: searchStr,
      createdByEmail: email,
    };
    let URL = Constant.GET_PROJECT_DOCUMENT_LIST;
    Api.getProjectDocumentList(URL, data).then((res) => {
      setTableData(res);
    });
  };

  const handleRequestSort = (event, property) => {
    const isAsc = orderBy === property && order === "asc";
    setOrder(isAsc ? "desc" : "asc");
    setOrderBy(property);
  };

  const handleSelectAllClick = (event) => {
    if (event.target.checked) {
      const newSelected = rows.map((n) => n.name);
      setSelected(newSelected);
      return;
    }
    setSelected([]);
  };

  const handleClick = (event, name) => {
    const selectedIndex = selected.indexOf(name);
    let newSelected = [];

    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selected, name);
    } else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selected.slice(1));
    } else if (selectedIndex === selected.length - 1) {
      newSelected = newSelected.concat(selected.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        selected.slice(0, selectedIndex),
        selected.slice(selectedIndex + 1)
      );
    }

    setSelected(newSelected);
  };

  // const handleChangePage = (event, newPage) => {
  //   setPage(newPage);
  // };
  const handleChangePage = (event, newPage) => {
    setPage(newPage - 1);
  };

  const handleChangeRowsPerPage = (newValue) => {
    setRowsPerPage(newValue);
    setPage(0);
  };

  const handleChangeDense = (event) => {
    setDense(event.target.checked);
  };

  const getHighlightedText = (text, higlight) => {
    // Split text on higlight term, include term itself into parts, ignore case
    if (higlight !== "") {
      var parts = text.split(new RegExp(`(${higlight})`, "gi"));
      return (
        <div style={{ display: "block" }}>
          {parts.map((part, index) => (
            <span
              style={{
                backgroundColor:
                  part.toLowerCase() === higlight.toLowerCase()
                    ? "#e8bb49"
                    : "white",
              }}
            >
              {part}
            </span>
          ))}
        </div>
      );
    } else {
      return text;
    }
  };

  const viewQuestionnaire = (
    pId,
    templateId,
    status,
    questionId,
    cQuestionId
  ) => {
    dispatch(setTemplateId(templateId));
    dispatch(setPId(pId));
    dispatch(setTemplateStatus(status));
    // dispatch(setUserType("consultant"));
    if (status === "Saved") {
      dispatch(setLeadershipCate([]));
      dispatch(setLeadershipCateName([]));
      dispatch(setLeadershipId(0));
      dispatch(setSelectedRoles([]));
      dispatch(setRoleList([]));
      dispatch(setMasterQuestionSearch(""));
      dispatch(setMasterSearchApply(false));
      dispatch(
        setMasterFilterQuestion({
          general: [],
          leadershipType: [],
          roleSpecific: [],
        })
      );
      dispatch(setSelectedMasterQuestion([]));
      dispatch(setGeneralQuestion([]));
      dispatch(setLeaderShipQuestion([]));
      dispatch(setRoleQuestion([]));
      dispatch(setQuestionnaireState("add"));
      dispatch(setAddNewQuestionsFlag(0));
      dispatch(setQuestionnaireEvent("editQuestionnaire"));
      navigate("/AddQuestionnaire");
    } else {
      navigate("/Respond");
    }
  };

  const isSelected = (name) => selected.indexOf(name) !== -1;

  // Avoid a layout jump when reaching the last page with empty rows.
  const emptyRows =
    page > 0 ? Math.max(0, (1 + page) * rowsPerPage - rows.length) : 0;

  return (
    <Box sx={{ width: "100%" }}>
      <Paper sx={{ width: "100%", mb: 2 }}>
        {/* <EnhancedTableToolbar numSelected={selected.length} /> */}
        <SearchBar searchText={searchText} pageName="project" />
        <TableContainer>
          <Table sx={{ minWidth: 750 }} aria-labelledby="tableTitle">
            <EnhancedTableHead
              numSelected={selected.length}
              order={order}
              orderBy={orderBy}
              onSelectAllClick={handleSelectAllClick}
              onRequestSort={handleRequestSort}
              rowCount={tableData.length}
            />
            <TableBody>
              {/* if you don't need to support IE11, you can replace the `stableSort` call with:
                 rows.slice().sort(getComparator(order, orderBy)) */}
              {stableSort(tableData, getComparator(order, orderBy))
                .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                .map((row, index) => {
                  const isItemSelected = isSelected(row.name);
                  const labelId = `enhanced-table-checkbox-${index}`;

                  return (
                    <TableRow
                      hover
                      onClick={(event) => handleClick(event, row.name)}
                      role="checkbox"
                      aria-checked={isItemSelected}
                      tabIndex={-1}
                      key={row.name}
                      selected={isItemSelected}
                    >
                      <TableCell
                        component="th"
                        id={labelId}
                        scope="row"
                        padding="none"
                      >
                        {index + 1}
                      </TableCell>
                      <TableCell
                        style={{ color: "#0070AD" }}
                        onClick={() =>
                          viewQuestionnaire(
                            row.pId,
                            row.templateId,
                            row.status,
                            row.questionId,
                            row.cQuestionId
                          )
                        }
                      >
                        {/* {row.name} */}
                        <p>{getHighlightedText(row.name, searchStr)}</p>
                      </TableCell>
                      <TableCell className="date-formator">
                        {dateFormat(row.createdDate)}
                      </TableCell>
                      <TableCell align="right">{row.createdByEmail}</TableCell>
                      {/* <TableCell className="date-formator">{dateFormat(row.createdDate)}</TableCell> */}
                      {/* <TableCell> {"--"} </TableCell> */}
                      <TableCell>
                        {/* <ContentCopyIcon /> */}
                        {/* <MoreVertIcon /> */}
                        <FileDownloadIcon
                          name={row.name}
                          showAlertBox={showAlertBox}
                          setShowAlertBox={setShowAlertBox}
                          setSuccessMessage={setSuccessMessage}
                          getSearchData={getSearchData}
                          successMessage={successMessage}
                          templateId={row.templateId}
                          pId={row.pId}
                          status={row.status}
                          pageName="project"
                          // isOwner={row.isOwner}
                        />
                      </TableCell>
                    </TableRow>
                  );
                })}
              {emptyRows > 0 && (
                <TableRow
                  style={{
                    height: (dense ? 33 : 53) * emptyRows,
                  }}
                >
                  <TableCell colSpan={6} />
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
        {tableData.length ? (
          ""
        ) : (
          <div
            style={{
              marginTop: "20px",
              display: "flex",
              justifyContent: "center",
            }}
          >
            <div
              style={{
                color: "#707070DE",
                textAlign: "center",
                alignItems: "center",
                marginLeft: "20px",
                textAlign: "center",
                width: "520px",
                padding: "64px 20px",
                fontSize: "16px",
              }}
            >
              <em>No Record Found</em>
            </div>
          </div>
        )}
        {tableData.length ? (
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              margin: "20px",
              paddingBottom: "20px",
            }}
          >
            <Typography
              style={{
                display: "inline-block",
                font: "ubuntu",
                color: "#707070DE",
              }}
            >
              Page {page + 1} of {pageCount}
            </Typography>
            <div
              className="Pagination"
              //nikhitha
              // style={{ marginLeft: "39%", display: "inline-block" }}
            >
              <Pagination
                count={pageCount}
                defaultPage={1}
                boundaryCount={2}
                onChange={handleChangePage}
              />
            </div>
            <Typography
              style={{
                //nikhitha
                // marginLeft: "35%",
                // display: "inline-block",
                color: "#707070DE",
              }}
            >
              Show{" "}
              <button
                style={{
                  border: "none",
                  font: "ubuntu",
                  backgroundColor: "white",
                  marginRight: "5px",
                  fontSize: "16px",
                  color: "#0070AD",
                }}
                onClick={() => handleChangeRowsPerPage(5)}
              >
                5
              </button>
              <button
                style={{
                  border: "none",
                  font: "ubuntu",
                  backgroundColor: "white",
                  marginRight: "5px",
                  fontSize: "16px",
                  color: "#0070AD",
                }}
                onClick={() => handleChangeRowsPerPage(10)}
              >
                10
              </button>
              <button
                style={{
                  border: "none",
                  font: "ubuntu",
                  backgroundColor: "white",
                  fontSize: "16px",
                  color: "#0070AD",
                }}
                onClick={() => handleChangeRowsPerPage(tableData.length)}
              >
                All
              </button>
            </Typography>
          </div>
        ) : (
          ""
        )}
      </Paper>
    </Box>
  );
}
