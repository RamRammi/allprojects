import * as React from "react";
import PropTypes from "prop-types";
import { alpha } from "@mui/material/styles";
import Box from "@mui/material/Box";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import TableSortLabel from "@mui/material/TableSortLabel";
import Toolbar from "@mui/material/Toolbar";
import Typography from "@mui/material/Typography";
import Paper from "@mui/material/Paper";
import IconButton from "@mui/material/IconButton";
import Tooltip from "@mui/material/Tooltip";
import FormControl from "@mui/material/FormControl";
import DeleteIcon from "@mui/icons-material/Delete";
import { visuallyHidden } from "@mui/utils";
import EditOutlinedIcon from "@mui/icons-material/EditOutlined";
import DeleteOutlineOutlinedIcon from "@mui/icons-material/DeleteOutlineOutlined";
import * as Constant from "../../comman/constant";
import Checkbox from "@mui/material/Checkbox";
import rearrangeImg from "../../Images/arrange.png";
//import attachmentImg from "../../Images/attachment.png";
import "./AddQuestionnaireTable.css";
import deleteImg from "../../Images/deleteImg.png";
import Button from "@mui/material/Button";
import TextField from "@material-ui/core/TextField";
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import { useTheme } from "@mui/material/styles";
import { Transform } from "@mui/icons-material";
import CloseIcon from "@mui/icons-material/Close";
import { Link, useNavigate } from "react-router-dom";
import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd";
import { useSelector, useDispatch } from "react-redux";
import {
  setSavedQuestions,
  setAddNewQuestionsFlag,
} from "../../redux/actions/questionnaireAction";
function descendingComparator(a, b, orderBy) {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
}

function getComparator(order, orderBy) {
  return order === "desc"
    ? (a, b) => descendingComparator(a, b, orderBy)
    : (a, b) => -descendingComparator(a, b, orderBy);
}

// This method is created for cross-browser compatibility, if you don't
// need to support IE11, you can use Array.prototype.sort() directly
function stableSort(array, comparator) {
  const stabilizedThis = array?.map((el, index) => [el, index]);
  stabilizedThis.sort((a, b) => {
    const order = comparator(a[0], b[0]);
    if (order !== 0) {
      return order;
    }
    return a[1] - b[1];
  });
  return stabilizedThis?.map((el) => el[0]);
}

const headQuestionnaire = [
  {
    id: "priority",
    numeric: false,
    disablePadding: false,
    label: "Priority",
    sort: true,
  },
  {
    id: "question",
    numeric: false,
    disablePadding: false,
    label: "Question",
    sort: false,
  },
  {
    id: "question-type",
    numeric: false,
    disablePadding: false,
    label: "Question Type",
    sort: false,
  },
  {
    id: "action",
    numeric: false,
    disablePadding: false,
    label: "Actions",
    sort: false,
  },
];

function EnhancedTableHead(props) {
  const {
    onSelectAllClick,
    order,
    orderBy,
    numSelected,
    rowCount,
    onRequestSort,
  } = props;
  const createSortHandler = (property) => (event) => {
    onRequestSort(event, property);
  };

  return (
    <TableHead>
      <TableRow>
        {/* <TableCell padding="checkbox"> */}
        {/* <Checkbox
            color="primary"
            indeterminate={numSelected > 0 && numSelected < rowCount}
            checked={rowCount > 0 && numSelected === rowCount}
            onChange={onSelectAllClick}
            inputProps={{
              "aria-label": "select all desserts",
            }}
          /> */}
        {/* </TableCell> */}
        {headQuestionnaire.map((headCell) => (
          <TableCell
            key={headCell.id}
            align={headCell.numeric ? "right" : "left"}
            padding={headCell.disablePadding ? "none" : "normal"}
            sortDirection={orderBy === headCell.id ? order : false}
          >
            {headCell.sort ? (
              <TableSortLabel
                active={orderBy === headCell.id}
                direction={orderBy === headCell.id ? order : "asc"}
                onClick={createSortHandler(headCell.id)}
              >
                {headCell.label}
                {orderBy === headCell.id ? (
                  <Box component="span" sx={visuallyHidden}>
                    {order === "desc"
                      ? "sorted descending"
                      : "sorted ascending"}
                  </Box>
                ) : null}
              </TableSortLabel>
            ) : (
              headCell.label
            )}
          </TableCell>
        ))}
      </TableRow>
    </TableHead>
  );
}

EnhancedTableHead.propTypes = {
  numSelected: PropTypes.number.isRequired,
  onRequestSort: PropTypes.func.isRequired,
  onSelectAllClick: PropTypes.func.isRequired,
  order: PropTypes.oneOf(["asc", "desc"]).isRequired,
  orderBy: PropTypes.string.isRequired,
  rowCount: PropTypes.number.isRequired,
};

const EnhancedTableToolbar = (props) => {
  const { numSelected } = props;

  return (
    <Toolbar
      sx={{
        pl: { sm: 2 },
        pr: { xs: 1, sm: 1 },
        ...(numSelected > 0 && {
          bgcolor: (theme) =>
            alpha(
              theme.palette.primary.main,
              theme.palette.action.activatedOpacity
            ),
        }),
      }}
    >
      {numSelected > 0 ? (
        <Typography
          sx={{ flex: "1 1 100%" }}
          color="inherit"
          variant="subtitle1"
          component="div"
        >
          {numSelected} selected
        </Typography>
      ) : (
        <Typography
          sx={{ flex: "1 1 100%" }}
          variant="h6"
          id="tableTitle"
          component="div"
        ></Typography>
      )}

      {numSelected > 0 ? (
        <Tooltip title="Delete">
          <IconButton>
            <DeleteIcon />
          </IconButton>
        </Tooltip>
      ) : (
        <Tooltip title="Filter list">
          <IconButton>{/* <FilterListIcon /> */}</IconButton>
        </Tooltip>
      )}
    </Toolbar>
  );
};

EnhancedTableToolbar.propTypes = {
  numSelected: PropTypes.number.isRequired,
};

export default function AddQuestionnaireTable(props) {
  const [order, setOrder] = React.useState("asc");
  const [orderBy, setOrderBy] = React.useState("calories");
  const [selected, setSelected] = React.useState([]);
  const [page, setPage] = React.useState(0);
  const [dense, setDense] = React.useState(false);
  const [rowsPerPage, setRowsPerPage] = React.useState(100);
  // const [rows, setRows] = React.useState([]);
  const [tableData, setTableData] = React.useState([]);
  const [questionType, setQuestionType] = React.useState("textbox");
  const [questionDesc, setQuestionDesc] = React.useState("");
  const [categoryId, setCategoryId] = React.useState(0);
  // const [addQuestionFlag, setAddQuestionFlag] = React.useState(false);
  const [editQuestionFlag, setEditQuestionFlag] = React.useState(false);
  const [editQuestionId, setEditQuestionId] = React.useState(-1);
  const savedQuestions = useSelector(
    (state) => state.questionnaireReducer.savedQuestions
  );
  const addNewQuestionsFlag = useSelector(
    (state) => state.questionnaireReducer.addNewQuestionsFlag
  );
  const StateValriable = useSelector((state) => state.questionnaireReducer);

  const [MCQOptions, setMCQOptions] = React.useState([]);
  const [arr, setArr] = React.useState({});
  const dispatch = useDispatch();
  React.useEffect(() => {
    setTableData(savedQuestions);
    setMCQData(savedQuestions);
    props.setFinalQuestionList(savedQuestions);
  }, [savedQuestions]);

  React.useEffect(() => {
    if (addNewQuestionsFlag === 1) {
      setQuestionType("textbox");
      setEditQuestionFlag(false);
      setEditQuestionId(-1);
      setQuestionDesc("");
      setCategoryId(0);
    }
  }, [addNewQuestionsFlag]);

  React.useEffect(() => {
    getSearchData();
    setQuestionType("textbox");
  }, [props.searchStr]);

  const setMCQData = (list) => {
    let newArr = [];
    list.map((value, index) => {
      if (value.type === "Multiple Choice Questions") {
        newArr[index] = value.multipleChoiceQuestionOptionList;
      }
    });
    setMCQOptions(newArr);
  };

  //Get Data after the search using serch box
  const getSearchData = () => {
    let searchData = [];
    let str = props.searchStr;
    searchData = savedQuestions.filter((value) => {
      return (
        value.questionDesc.toLowerCase().includes(str.toLowerCase()) ||
        value.type.toLowerCase().includes(str.toLowerCase())
      );
    });
    props.setRows(searchData);
    // setTableData(searchData);
    // dispatch(setSavedQuestions(searchData));
    // props.setFinalQuestionList(searchData);
  };

  const getHighlightedText = (text, higlight) => {
    // Split text on higlight term, include term itself into parts, ignore case
    if (higlight !== "") {
      var parts = text.split(new RegExp(`(${higlight})`, "gi"));
      return (
        <div style={{ display: "block" }}>
          {parts.map((part, index) => (
            <span
              style={{
                backgroundColor:
                  part.toLowerCase() === higlight.toLowerCase()
                    ? "#e8bb49"
                    : "white",
              }}
            >
              {part}
            </span>
          ))}
        </div>
      );
    } else {
      return text;
    }
  };

  const handleRequestSort = (event, property) => {
    const isAsc = orderBy === property && order === "asc";
    setOrder(isAsc ? "desc" : "asc");
    setOrderBy(property);
  };

  const handleSelectAllClick = (event) => {
    if (event.target.checked) {
      const newSelected = tableData?.map((n) => n.name);
      setSelected(newSelected);
      return;
    }
    setSelected([]);
  };

  const handleClick = (event, name) => {
    const selectedIndex = selected.indexOf(name);
    let newSelected = [];

    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selected, name);
    } else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selected.slice(1));
    } else if (selectedIndex === selected.length - 1) {
      newSelected = newSelected.concat(selected.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        selected.slice(0, selectedIndex),
        selected.slice(selectedIndex + 1)
      );
    }

    setSelected(newSelected);
  };

  const isSelected = (name) => selected.indexOf(name) !== -1;

  // Avoid a layout jump when reaching the last page with empty rows.
  const emptyRows =
    page > 0 ? Math.max(0, (1 + page) * rowsPerPage - tableData.length) : 0;

  const addNewQuestion = (questionIndex) => {
    let newArr = [...savedQuestions];
    if (questionDesc !== "") {
      newArr.push({
        questionDesc: questionDesc,
        type: questionType,
        roleId: 0,
        leaderShipCategoryId: 0,
        categoryId: categoryId,
        multipleChoiceQuestion:
          questionType === "Multiple Choice Questions"
            ? MCQOptions[questionIndex].join(",")
            : null,
        multipleChoiceQuestionOptionList:
          questionType === "Multiple Choice Questions"
            ? MCQOptions[questionIndex]
            : null,
      });
      resetQuestionData();
    }
    props.setRows(newArr);
    props.setFinalQuestionList(newArr);
    dispatch(setSavedQuestions(newArr));
    dispatch(setAddNewQuestionsFlag(0));
  };

  const deleteQuestion = (id) => {
    let newArr = [...savedQuestions];
    newArr.map((value, index) => {
      if (index === id) {
        newArr.splice(index, 1);
      }
    });
    props.setRows(newArr);
    props.setFinalQuestionList(newArr);
    dispatch(setSavedQuestions(newArr));
  };
  const editQuestion = (data, id) => {
    setEditQuestionId(id);
    setQuestionDesc(data.questionDesc);
    setQuestionType(data.type);
    setCategoryId(data.categoryId);
    setEditQuestionFlag(true);
    dispatch(setAddNewQuestionsFlag(0));
  };

  const updateQuestion = () => {
    let newArr = [...savedQuestions];
    newArr.map((value, index) => {
      if (index === editQuestionId) {
        newArr[index].questionDesc = questionDesc;
        newArr[index].type = questionType;
        newArr[index].multipleChoiceQuestion =
          questionType === "Multiple Choice Questions"
            ? MCQOptions[index].join(",")
            : null;
        newArr[index].multipleChoiceQuestionOptionList =
          questionType === "Multiple Choice Questions"
            ? MCQOptions[index]
            : null;
      }
    });
    props.setFinalQuestionList(newArr);
    props.setRows(newArr);
    dispatch(setSavedQuestions(newArr));
    resetQuestionData();
  };
  const handleseledit = async (event, index, editQuestionId) => {
    setQuestionType(event.target.value);
    if (event.target.value === "Multiple Choice Questions") {
      // const i = arr["question_" + editQuestionId]
      //   ? Object.keys(arr["question_" + editQuestionId]).length
      //   : 0;
      // addInput(i, editQuestionId);
      let newArr = [...MCQOptions];
      newArr[index] = [""];

      setMCQOptions(newArr);
    }
  };
  const handleselAdd = (event, index) => {
    setQuestionType(event.target.value);
    if (event.target.value === "Multiple Choice Questions") {
      let newArr = [...MCQOptions];
      newArr[index] = [""];

      setMCQOptions(newArr);
    }
  };
  const addInputAdd = (questionIndex, optionIndex) => {
    let newArr = [...MCQOptions];
    newArr[questionIndex] = [...newArr[questionIndex], ""];
    setMCQOptions(newArr);
  };

  const removeInputAdd = (questionIndex, optionIndex) => {
    let newArr = [...MCQOptions];
    newArr[questionIndex].splice(optionIndex, 1);
    setMCQOptions(newArr);
  };
  const addInput = (index, editQuestionId, value = "") => {
    if (typeof editQuestionId !== "undefined") {
      let obj = Object.keys(arr).includes("question_" + editQuestionId)
        ? arr["question_" + editQuestionId]
        : {};
      obj["answer_" + index] = value;
      setArr({ ...arr, ["question_" + editQuestionId]: obj });
    }
  };
  const handleChangeAdd = (e, optionIndex, questionIndex) => {
    // e.preventDefault();
    let newArr = [...MCQOptions];
    newArr[questionIndex][optionIndex] = e.target.value;
    setMCQOptions(newArr);
  };

  const resetQuestionData = () => {
    setEditQuestionFlag(false);
    setEditQuestionId(-1);
    // setAddQuestionFlag(false);
    //  props.addQuestion(false);
    dispatch(setAddNewQuestionsFlag(0));
    setQuestionDesc("");
    setQuestionType("");
    setCategoryId(0);
  };
  const reorder = (list, startIndex, endIndex) => {
    const result = Array.from(list);
    const [removed] = result.splice(startIndex, 1);
    result.splice(endIndex, 0, removed);

    return result;
  };

  const onDragEnd = (result) => {
    if (!result.destination) {
      return;
    }
    if (
      result.destination.droppableId === result.source.droppableId &&
      result.destination.index === result.source.index
    ) {
      return;
    }
    let movedItems = reorder(
      tableData,
      result.source.index,
      result.destination.index
    );
    setTableData(movedItems);
    // dispatch(setSavedQuestions(movedItems));
    props.setRows(movedItems);
  };
  const grid = 8;

  // const getItemStyle = (style,snapshot) => ({

  //   // // some basic styles to make the items look a bit nicer

  //   // userSelect: "none",

  //   // padding: grid * 2,

  //   // margin: `0 0 ${grid}px 0`,

  //   // // change background colour if dragging

  //   // background: isDragging ? "lightgreen" : "grey",

  //   // // styles we need to apply on draggables

  //   // ...draggableStyle
  //   if (!snapshot.isDropAnimating) {
  //     return style;
  //   }
  //   const { moveTo, curve, duration } = snapshot.dropAnimation;
  //   // move to the right spot
  //   const translate = `translate(${moveTo.x}px, ${moveTo.y}px)`;
  //   // add a bit of turn for fun
  //   const rotate = 'rotate(0.5turn)';

  //   // patching the existing style
  //   return {
  //     ...style,
  //     transform: `${translate} ${rotate}`,
  //     // slowing down the drop because we can
  //     transition: `all ${curve} ${duration + 1}s`,
  //   };

  // });
  // function getStyle(style, snapshot) {
  //   if (!snapshot.isDropAnimating) {
  //     return style;
  //   }
  //   const { moveTo, curve, duration } = snapshot.dropAnimation;
  //   // move to the right spot
  //   const translate = `translate(${moveTo.x}px, ${moveTo.y}px)`;
  //   // add a bit of turn for fun
  //   const rotate = 'rotate(0.5turn)';

  //   // patching the existing style
  //   return {
  //     ...style,
  //     transform: `${translate} ${rotate}`,
  //     // slowing down the drop because we can
  //     transition: `all ${curve} ${duration + 1}s`,
  //   };
  // }

  function getStyle(style, snapshot) {
    if (!snapshot.isDropAnimating) {
      return style;
    }
    return {
      ...style,
      // cannot be 0, but make it super tiny
      transitionDuration: `0.001s`,
    };
  }
  return (
    <>
      <Box sx={{ width: "98%", marginLeft: "18px" }}>
        <Paper sx={{ width: "100%", mb: 2, "box-shadow": "none" }}>
          {/* <EnhancedTableToolbar numSelected={selected.length} /> */}
          <DragDropContext onDragEnd={onDragEnd}>
            <TableContainer>
              <Table
                sx={{ minWidth: 750 }}
                aria-labelledby="tableTitle"
                size="medium"
              >
                <EnhancedTableHead
                  numSelected={selected.length}
                  order={order}
                  orderBy={orderBy}
                  onSelectAllClick={handleSelectAllClick}
                  onRequestSort={handleRequestSort}
                  rowCount={tableData.length}
                />
                <Droppable droppableId="tBody">
                  {(provided, snapshot) => (
                    <TableBody
                      ref={provided.innerRef}
                      {...provided.droppableProps}
                    >
                      {/* if you don't need to support IE11, you can replace the `stableSort` call with:
                 rows.slice().sort(getComparator(order, orderBy)) */}
                      {stableSort(props.rows, getComparator(order, orderBy))
                        .slice(
                          page * rowsPerPage,
                          page * rowsPerPage + rowsPerPage
                        )
                        ?.map((row, index) => {
                          const isItemSelected = isSelected(row.name);
                          const labelId = `enhanced-table-checkbox-${index}`;

                          return (
                            <>
                              {index !== editQuestionId ? (
                                <Draggable
                                  key={row.questionDesc}
                                  draggableId={"q-" + row.questionDesc}
                                  index={index}
                                >
                                  {(provided, snapshot) => (
                                    <TableRow
                                      ref={provided.innerRef}
                                      // {...provided.draggableProps}
                                      // {...provided.dragHandleProps}
                                      // isDragging={snapshot.isDragging && !snapshot.isDropAnimating}
                                      // style={getStyle(provided.draggableProps.style, snapshot)}
                                      {...provided.draggableProps}
                                      // {...provided.dragHandleProps}
                                      style={getStyle(
                                        provided.draggableProps.style,
                                        snapshot
                                      )}
                                      hover
                                      onClick={(event) =>
                                        handleClick(event, row.questionId)
                                      }
                                      role="checkbox"
                                      aria-checked={isItemSelected}
                                      tabIndex={-1}
                                      key={row.questionId}
                                      selected={isItemSelected}
                                    >
                                      <TableCell
                                        component="th"
                                        id={labelId}
                                        scope="row"
                                        padding="10px"
                                        style={{ width: 0 }}
                                        align="left"
                                      >
                                        <img
                                          {...provided.dragHandleProps}
                                          className="rearrange-img"
                                          src={rearrangeImg}
                                          alt="img"
                                        />
                                        {index + 1}
                                      </TableCell>
                                      <TableCell align="left">
                                        {/* {row.questionDesc} */}
                                        <p>
                                          {getHighlightedText(
                                            row.questionDesc,
                                            props.searchStr
                                          )}
                                        </p>
                                      </TableCell>
                                      <TableCell
                                        align="left"
                                        style={{ textTransform: "capitalize" }}
                                      >
                                        {row.type}
                                      </TableCell>
                                      <TableCell align="left">
                                        <EditOutlinedIcon
                                          style={{
                                            color: "#0070AD",
                                            // color: !props.isOwner
                                            //   ? "#BFBFBF"
                                            //   : "#0070AD",
                                            fontSize: "15px",
                                            // pointerEvents: !props.isOwner
                                            //   ? "none"
                                            //   : "block",
                                          }}
                                          onClick={() =>
                                            editQuestion(row, index)
                                          }
                                        />
                                        <DeleteOutlineOutlinedIcon
                                          style={{
                                            color: "#0070AD",
                                            // color: !props.isOwner
                                            //   ? "#BFBFBF"
                                            //   : "#0070AD",
                                            fontSize: "15px",
                                            // pointerEvents: !props.isOwner
                                            //   ? "none"
                                            //   : "block",
                                          }}
                                          onClick={() => deleteQuestion(index)}
                                        />
                                      </TableCell>
                                    </TableRow>
                                  )}
                                </Draggable>
                              ) : (
                                ""
                              )}

                              {addNewQuestionsFlag === 1 ? (
                                index + 1 === props.rows.length ? (
                                  <TableRow
                                    hover
                                    role="checkbox"
                                    aria-checked={isItemSelected}
                                    tabIndex={-1}
                                    key={row.length + 1}
                                    selected={isItemSelected}
                                  >
                                    <TableCell
                                      component="th"
                                      id={labelId}
                                      scope="row"
                                      padding="10px"
                                      style={{ width: 0 }}
                                      align="left"
                                    >
                                      {index + 2}
                                    </TableCell>
                                    <TableCell>
                                      <FormControl fullWidth sx={{ m: 1 }}>
                                        <TextField
                                          id="standard-basic"
                                          variant="standard"
                                          placeholder="Enter Question Description"
                                          inputProps={{ autoComplete: "off" }}
                                          onChange={(event) =>
                                            setQuestionDesc(
                                              event.target.value.replace(
                                                new RegExp(/[*~^`]/gm),
                                                ""
                                              )
                                            )
                                          }
                                          value={questionDesc}
                                          size="small"
                                        />
                                      </FormControl>
                                      <FormControl sx={{ m: 1 }}>
                                        <label className="select-label">
                                          Select Question Type
                                        </label>
                                        <Select
                                          value={questionType}
                                          onChange={(event) => {
                                            handleselAdd(event, index + 1);
                                          }}
                                          displayEmpty
                                          style={{
                                            // "margin-top": "12px",
                                            marginTop: "12px",
                                            minWidth: "140px",
                                          }}
                                          inputProps={{
                                            "aria-label": "Without label",
                                          }}
                                        >
                                          <MenuItem
                                            className="AddQuestTab_menuitem"
                                            value={"textbox"}
                                          >
                                            Textbox
                                          </MenuItem>
                                          <MenuItem
                                            className="AddQuestTab_menuitem"
                                            value={"Date"}
                                          >
                                            Date
                                          </MenuItem>
                                          <MenuItem
                                            className="AddQuestTab_menuitem"
                                            value={"Logical"}
                                          >
                                            Logical
                                          </MenuItem>
                                          <MenuItem
                                            className="AddQuestTab_menuitem"
                                            value={"Range of Values"}
                                          >
                                            Range of Values
                                          </MenuItem>
                                          <MenuItem
                                            className="AddQuestTab_menuitem"
                                            value={"Multiple Choice Questions"}
                                          >
                                            Multiple Choice Questions
                                          </MenuItem>
                                        </Select>
                                      </FormControl>

                                      {questionType ===
                                      "Multiple Choice Questions"
                                        ? MCQOptions[index + 1] &&
                                          MCQOptions[index + 1].map(
                                            (value, i) => {
                                              return (
                                                <div>
                                                  <input
                                                    className="IncDnc_Input"
                                                    placeholder="options"
                                                    onChange={(e) =>
                                                      handleChangeAdd(
                                                        e,
                                                        i,
                                                        index + 1
                                                      )
                                                    }
                                                    value={value}
                                                    id={i}
                                                    type={"text"}
                                                    size="20"
                                                  />
                                                  {i ===
                                                  MCQOptions[index + 1].length -
                                                    1 ? (
                                                    <span
                                                      style={{
                                                        cursor: "pointer",
                                                        fontSize: "18px",
                                                        marginLeft: "6px",
                                                      }}
                                                      className="increment"
                                                      onClick={() =>
                                                        addInputAdd(
                                                          index + 1,
                                                          i
                                                        )
                                                      }
                                                    >
                                                      +
                                                    </span>
                                                  ) : (
                                                    <span
                                                      style={{
                                                        cursor: "pointer",
                                                        fontSize: "18px",
                                                        marginLeft: "6px",
                                                      }}
                                                      onClick={() =>
                                                        removeInputAdd(
                                                          index + 1,
                                                          i
                                                        )
                                                      }
                                                      className="decrement"
                                                    >
                                                      <img
                                                        src="../img/Decredelete.png"
                                                        on
                                                        height="10px"
                                                        width="10px"
                                                        alt="Decredelete"
                                                      />
                                                    </span>
                                                  )}
                                                </div>
                                              );
                                            }
                                          )
                                        : ""}

                                      {/* </div> */}
                                    </TableCell>
                                    <TableCell
                                      align="left"
                                      style={{ textTransform: "capitalize" }}
                                    >
                                      {questionType}
                                    </TableCell>
                                    <TableCell
                                      style={{ padding: "60px 0px 0px 0px" }}
                                    >
                                      <CloseIcon
                                        style={{ marginLeft: "12px" }}
                                        onClick={() => resetQuestionData()}
                                      />
                                      <br />
                                      <FormControl sx={{ m: 1 }}>
                                        <Button
                                          // className="action-button-align"
                                          variant="contained"
                                          style={{
                                            margin: "10px 0px 10px 0px",
                                            padding: "5px 17px",
                                            backgroundColor: "#0070AD",
                                            color: "#fff",
                                            textTransform: "capitalize",
                                            "border-radius": "25px",
                                          }}
                                          onClick={() =>
                                            addNewQuestion(index + 1)
                                          }
                                        >
                                          Done
                                        </Button>
                                      </FormControl>
                                    </TableCell>
                                  </TableRow>
                                ) : (
                                  ""
                                )
                              ) : editQuestionFlag ? (
                                index === editQuestionId ? (
                                  <TableRow
                                    hover
                                    //  onClick={(event) => handleClick(event, row.name)}
                                    role="checkbox"
                                    aria-checked={isItemSelected}
                                    tabIndex={-1}
                                    key={index}
                                    selected={isItemSelected}
                                  >
                                    {/* <TableCell padding="checkbox">
                                <img src={rearrangeImg} alt="img" />
                              </TableCell> */}
                                    <TableCell
                                      component="th"
                                      id={labelId}
                                      scope="row"
                                      padding="10px"
                                      style={{ width: 0 }}
                                      align="left"
                                    >
                                      {index + 1}
                                    </TableCell>
                                    <TableCell>
                                      <FormControl fullWidth sx={{ m: 1 }}>
                                        <TextField
                                          id="standard-basic"
                                          variant="standard"
                                          placeholder="Enter Question Description"
                                          inputProps={{ autoComplete: "off" }}
                                          onChange={(event) =>
                                            setQuestionDesc(
                                              event.target.value.replace(
                                                new RegExp(/[*~^`]/gm),
                                                ""
                                              )
                                            )
                                          }
                                          size="small"
                                          value={questionDesc}
                                        ></TextField>
                                      </FormControl>
                                      <FormControl
                                        className="select_question_type"
                                        sx={{ m: 1 }}
                                      >
                                        <label className="select-label">
                                          Select Question Type
                                        </label>
                                        <Select
                                          className="AddQuestTab_Select"
                                          value={questionType}
                                          onChange={(event) =>
                                            handleseledit(
                                              event,
                                              index,
                                              editQuestionId
                                            )
                                          }
                                          displayEmpty
                                          inputProps={{
                                            "aria-label": "Without label",
                                          }}
                                          style={{
                                            // "margin-top": "12px",
                                            marginTop: "12px",
                                            minWidth: "140px",
                                          }}
                                        >
                                          <MenuItem
                                            className="AddQuestTab_menuitem"
                                            value={"textbox"}
                                          >
                                            Textbox
                                          </MenuItem>
                                          <MenuItem
                                            className="AddQuestTab_menuitem"
                                            value={"Date"}
                                          >
                                            Date
                                          </MenuItem>
                                          <MenuItem
                                            className="AddQuestTab_menuitem"
                                            value={"Logical"}
                                          >
                                            Logical
                                          </MenuItem>
                                          <MenuItem
                                            className="AddQuestTab_menuitem"
                                            value={"Range of Values"}
                                          >
                                            Range of Values
                                          </MenuItem>
                                          <MenuItem
                                            className="AddQuestTab_menuitem"
                                            value={"Multiple Choice Questions"}
                                          >
                                            Multiple Choice Questions
                                          </MenuItem>
                                        </Select>{" "}
                                      </FormControl>
                                      {/* <div>
                                        {questionType ===
                                        "Multiple Choice Questions"
                                          ? Object.values(
                                              arr["question_" + index]
                                            )?.map((value, i) => {
                                              return (
                                                <div>
                                                  <input
                                                    className="IncDnc_Input"
                                                    placeholder="options"
                                                    onChange={handleChange}
                                                    value={value}
                                                    id={i}
                                                    type={"text"}
                                                    size="20"
                                                  />
                                                  {i + 1 ===
                                                  Object.values(
                                                    arr["question_" + index]
                                                  ).length ? (
                                                    <span
                                                      style={{
                                                        cursor: "pointer",
                                                        fontSize: "18px",
                                                        marginLeft: "6px",
                                                      }}
                                                      onClick={() =>
                                                        addInput(
                                                          i + 1,
                                                          editQuestionId
                                                        )
                                                      }
                                                      className="increment"
                                                    >
                                                      +
                                                    </span>
                                                  ) : (
                                                    <></>
                                                  )}

                                                  {i + 1 !==
                                                  Object.values(
                                                    arr["question_" + index]
                                                  ).length ? (
                                                    <span
                                                      style={{
                                                        cursor: "pointer",
                                                        fontSize: "18px",
                                                        marginLeft: "6px",
                                                      }}
                                                      onClick={() =>
                                                        removeInput(i)
                                                      }
                                                      className="decrement"
                                                    >
                                                      <img
                                                        src="../img/Decredelete.png"
                                                        height="10px"
                                                        width="10px"
                                                        alt="Decredelete"
                                                      />
                                                    </span>
                                                  ) : null}
                                                </div>
                                              );
                                            })
                                          : null}
                                      </div> */}
                                      {questionType ===
                                      "Multiple Choice Questions"
                                        ? MCQOptions[index].map((value, i) => {
                                            return (
                                              <div>
                                                <input
                                                  className="IncDnc_Input"
                                                  placeholder="options"
                                                  onChange={(e) =>
                                                    handleChangeAdd(e, i, index)
                                                  }
                                                  value={value}
                                                  id={i}
                                                  type={"text"}
                                                  size="20"
                                                />
                                                {i ===
                                                MCQOptions[index].length - 1 ? (
                                                  <span
                                                    style={{
                                                      cursor: "pointer",
                                                      fontSize: "18px",
                                                      marginLeft: "6px",
                                                    }}
                                                    className="increment"
                                                    onClick={() =>
                                                      addInputAdd(index, i)
                                                    }
                                                  >
                                                    +
                                                  </span>
                                                ) : (
                                                  <span
                                                    style={{
                                                      cursor: "pointer",
                                                      fontSize: "18px",
                                                      marginLeft: "6px",
                                                    }}
                                                    onClick={() =>
                                                      removeInputAdd(index, i)
                                                    }
                                                    className="decrement"
                                                  >
                                                    <img
                                                      src="../img/Decredelete.png"
                                                      on
                                                      height="10px"
                                                      width="10px"
                                                      alt="Decredelete"
                                                    />
                                                  </span>
                                                )}
                                              </div>
                                            );
                                          })
                                        : ""}
                                    </TableCell>
                                    <TableCell
                                      align="left"
                                      style={{ textTransform: "capitalize" }}
                                    >
                                      {questionType}
                                    </TableCell>
                                    <TableCell>
                                      <CloseIcon
                                        onClick={() => resetQuestionData()}
                                      />
                                      <br />
                                      <Button
                                        //   className="action-button-align"
                                        variant="contained"
                                        style={{
                                          margin: "10px 0px 10px 0px",
                                          padding: "5px 17px",
                                          backgroundColor: "#0070AD",
                                          color: "#fff",
                                          textTransform: "capitalize",
                                          "border-radius": "25px",
                                        }}
                                        onClick={() => updateQuestion()}
                                      >
                                        Done
                                      </Button>
                                    </TableCell>
                                  </TableRow>
                                ) : (
                                  ""
                                )
                              ) : (
                                ""
                              )}
                            </>
                          );
                        })}
                      {emptyRows > 0 && (
                        <TableRow
                          style={{
                            height: (dense ? 33 : 53) * emptyRows,
                          }}
                        >
                          <TableCell colSpan={6} />
                        </TableRow>
                      )}
                      {provided.placeholder}
                    </TableBody>
                  )}
                </Droppable>
              </Table>
            </TableContainer>
          </DragDropContext>
        </Paper>
      </Box>
    </>
  );
}
