import * as React from "react";
import Box from "@mui/material/Box";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import Checkbox from "@mui/material/Checkbox";
import { useLocation } from "react-router-dom";
//import "./CenterRepositoryTable.css";
import "../QuestionnaireTable.css";
import { useSelector, useDispatch } from "react-redux";
import { setGeneralQuestion } from "../../../redux/actions/questionnaireAction";

export default function GeneralTable(props) {
  //const [selectedCateQuestion, setSelectedCateQuestion] = React.useState([]);
  const generalQ = useSelector(
    (state) => state.questionnaireReducer.generalQuestion
  );
  const selected = useSelector(
    (state) => state.questionnaireReducer.selectedMasterQuestion
  );

  const selectedGeneralQuestion = useSelector(
    (state) => state.questionnaireReducer.generalQuestion
  );
  const applyFilter = useSelector(
    (state) => state.questionnaireReducer.masterSearchApply
  );
  const eventName = useSelector(
    (state) => state.questionnaireReducer.masterQuestionnaireEvent
  );
  const editQuestionList = useSelector(
    (state) => state.questionnaireReducer.editQuestionList
  );

  const [tableData, setTableData] = React.useState([]);
  const dispatch = useDispatch();
  const location = useLocation();
  let sNoCount = 0;

  React.useEffect(() => {
    getQuestionTable();
  }, [props.filterField]);

  React.useEffect(() => {
    if (props.isGeneralSelect === true) {
      dispatch(setGeneralQuestion(props.filterField[0].rows));
    }
  }, [props.isGeneralSelect]);

  React.useEffect(() => {
    props.changeCateCheckbox("general");
  }, [generalQ]);
  React.useEffect(() => {
    if (eventName === "edit") {
      let addObj = [];

      editQuestionList.map((value1, index1) => {
        props.filterField[0].rows.map((value2, index) => {
          if (value1.questionDesc === value2.questionDesc) addObj.push(value2);
        });
      });
      dispatch(setGeneralQuestion(addObj));
    }
  }, []);

  const getQuestionTable = () => {
    if (props.filterField.length) {
      setTableData(props.filterField);
    } else {
      setTableData([]);
    }
  };

  const handleClick = (name) => {
    // const selectedIndex = generalQ.indexOf(name);
    let selectedIndex = generalQ.findIndex((data) => {
      return data.questionId === name.questionId;
    });
    let newSelected = [];

    if (selectedIndex === -1) {
      newSelected = newSelected.concat(generalQ, name);
    } else if (selectedIndex === 0) {
      newSelected = newSelected.concat(generalQ.slice(1));
    } else if (selectedIndex === selected.length - 1) {
      newSelected = newSelected.concat(generalQ.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        generalQ.slice(0, selectedIndex),
        generalQ.slice(selectedIndex + 1)
      );
    }
    dispatch(setGeneralQuestion(newSelected));
  };

  const isSelected = (question) => {
    // return generalQ.indexOf(question) !== -1;
    const found = generalQ.some((el) => el.questionId === question.questionId);
    return found;
  };

  return (
    <Box
      sx={{
        width: "98%",
        "margin-left": "18px",
      }}
    >
      {/* <Paper sx={{ width: "100%", mb: 2, "box-shadow": "none" }}> */}

      {tableData.map((value, index1) => {
        sNoCount =
          index1 > 0
            ? sNoCount + tableData[index1 - 1].rows.length
            : sNoCount + 0;
        return (
          <TableContainer
            style={{ overflowX: "hidden", marginTop: "10px" }}
            key={index1}
          >
            {value.roleName !== "" ? (
              <span className="questionlist-heading"> {value.roleName} </span>
            ) : (
              ""
            )}
            <Table
              sx={{ minWidth: 1380 }}
              // aria-labelledby="tableTitle"
              // size="medium"
            >
              <TableBody>
                {value.rows.map((row, index2) => {
                  const isItemSelected = isSelected(row);
                  const labelId = `enhanced-table-checkbox-${index2}`;

                  return (
                    <TableRow
                      hover
                      onClick={() => handleClick(row)}
                      role="checkbox"
                      aria-checked={isItemSelected}
                      tabIndex={-1}
                      key={row.questionId}
                      selected={isItemSelected}
                    >
                      <TableCell padding="checkbox">
                        <Checkbox
                          checked={isItemSelected}
                          inputProps={{
                            "aria-labelledby": labelId,
                          }}
                          color="primary"
                        />
                      </TableCell>
                      <TableCell align="left">
                        {index1 > 0
                          ? props.sNo + sNoCount + index2 + 1
                          : props.sNo + index2 + 1}
                      </TableCell>
                      <TableCell align="left">
                        {row.questionDesc}{" "}
                        {/* {row.attachment ? (
                            <img src={attachmentImg} alt="img" />
                          ) : (
                            ""
                          )} */}
                      </TableCell>
                      {/* <TableCell align="left">{row.type}</TableCell> */}
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </TableContainer>
        );
      })}
      {tableData.length ? (
        ""
      ) : (
        <div
          style={{
            marginTop: "20px",
            display: "flex",
            justifyContent: "center",
          }}
        >
          <div
            style={{
              color: "#707070DE",
              textAlign: "center",
              alignItems: "center",
              marginLeft: "20px",
              textAlign: "center",
              width: "520px",
              padding: "64px 20px",
              fontSize: "16px",
            }}
          >
            <em>No Record Found</em>
          </div>
        </div>
      )}
      {/* </Paper> */}
    </Box>
  );
}
