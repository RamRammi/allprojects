import React from "react";
import ContentCopyIcon from "@mui/icons-material/ContentCopy";

import ExpendPopup from "../PopUp/ExpendPopup/ExpendPopup";
const FileDownloadIcon = (props) => {
  return (
    <>
      <ContentCopyIcon className="icon-float" style={{ color: "#0070AD" }} />

      <ExpendPopup
        setSuccessMessage={props.setSuccessMessage}
        successMessage={props.successMessage}
        showAlertBox={props.showAlertBox}
        setShowAlertBox={props.setShowAlertBox}
        name={props.name}
        getSearchData={props.getSearchData}
        templateId={props.templateId}
        pId={props.pId}
        status={props.status}
        pageName={props.pageName}
        // isOwner={props.isOwner}
      />
    </>
  );
};
export default FileDownloadIcon;
