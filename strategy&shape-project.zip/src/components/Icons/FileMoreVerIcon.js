import React from "react";
import "./FileDownloadIcon.css";
import SaveAltIcon from "@mui/icons-material/SaveAlt";
import ContentCopyIcon from "@mui/icons-material/ContentCopy";
import Button from "@mui/material/Button";
import { Theme, useTheme } from "@mui/material/styles";
import { Typography } from "@mui/material";
import FormControl from "@mui/material/FormControl";
import OutlinedInput from "@mui/material/OutlinedInput";
import Dialog from "@mui/material/Dialog";
import MenuItem from "@mui/material/MenuItem";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import Box from "@mui/material/Box";
import DialogContentText from "@mui/material/DialogContentText";
import * as Api from "../../comman/api";
import * as Constant from "../../comman/constant";
import Select from "@mui/material/Select";
import DialogTitle from "@mui/material/DialogTitle";
import CommonModal from "../PopUp/ExpendPopup/modal";

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};

const documentType = ["pdf", "excel", "CSV"];

function getStyles(name, personName, theme) {
  return {
    fontWeight:
      personName.indexOf(name) === -1
        ? theme.typography.fontWeightRegular
        : theme.typography.fontWeightMedium,
  };
}

const FileMoreVerIcon = (props) => {
  const [open, setOpen] = React.useState(false);

  const handleClickOpen = () => {
    setOpen(true);
    //  props.setTemplateId(props.templateId)
  };

  const handleClose = async () => {
    await setOpen(false);
  };

  return (
    <div>
      <Button
        className="Button_BG"
        onClick={handleClickOpen}
        style={{ backgroundColor: "white", border: "none", color: "#0070AD" }}
      >
        <SaveAltIcon className="FileDownloadIcon_css" />
      </Button>
      <CommonModal
        pageName={props.pageName}
        templateId={props.templateId}
        status={props.status}
        open={open}
        synopis={props.synopis}
        templateName={props.templateName}
        onClose={() => handleClose()}
        type="download"
      />
    </div>
  );
};
export default FileMoreVerIcon;
