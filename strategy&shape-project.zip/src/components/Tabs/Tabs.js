import React from "react";
import PropTypes from "prop-types";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import { Button } from "@mui/material";
import "./Tabs.css";
import ProjectTable from "../Table/ProjectTable";
import SearchBar from "../SearchBar/SearchBar";
import TasksSummaryTable from "../../components/Table/TaskSummayTable";
import { Link, useNavigate } from "react-router-dom";
import * as Constant from "../../comman/constant";
import * as Api from "../../comman/api";
import { useSelector, useDispatch } from "react-redux";
import {
  setConsultantProjectActiveTab,
  setMasterSummarySearch,
} from "../../redux/actions/questionnaireAction";
const TabsList = (props) => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const value = useSelector(
    (state) => state.questionnaireReducer.consultantProjectActiveTab
  );
  const [documentType, setdocumentType] = React.useState(0);

  const handleChange = (event, newValue) => {
    dispatch(setConsultantProjectActiveTab(newValue));
  };

  const navigateMasterSummary = () => {
    dispatch(setMasterSummarySearch(""));
    navigate("/MasterSummary");
  };
  function TabPanel(props) {
    const { children, value, index, ...other } = props;

    return (
      <div
        role="tabpanel"
        hidden={value !== index}
        id={`simple-tabpanel-${index}`}
        aria-labelledby={`simple-tab-${index}`}
        {...other}
      >
        {value === index && (
          <Box className=" tabpanel_pad" sx={{ p: 3 }}>
            <Typography>{children}</Typography>
          </Box>
        )}
      </div>
    );
  }

  const navigateQuestionGallery = () => {
    navigate("/QuestionGallery");
  };

  TabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.number.isRequired,
    value: PropTypes.number.isRequired,
  };

  function a11yProps(index) {
    return {
      id: `simple-tab-${index}`,
      "aria-controls": `simple-tabpanel-${index}`,
    };
  }

  return (
    <div>
      <Box sx={{ width: "100%" }}>
        <Box
          className="tabs-div tabs_pad"
          // sx={{ borderBottom: 1, borderColor: "divider" }}
        >
          <Tabs
            value={value}
            onChange={handleChange}
            aria-label="basic tabs example"
          >
            <Tab
              className="tabs-label"
              label="Task and Summary"
              {...a11yProps(1)}
            />
            <Tab
              className="tabs-label"
              label="Project Templates"
              {...a11yProps(0)}
            />
          </Tabs>
        </Box>
        <TabPanel className="tab-panel" value={value} index={1}>
          <ProjectTable
            searchStr={props.searchStr}
            filterField={props.filterField}
          />
        </TabPanel>
        <TabPanel value={value} index={0}>
          <TasksSummaryTable
            documentType={documentType}
            navigateMasterSummary={navigateMasterSummary}
            navigateQuestionGallery={navigateQuestionGallery}

            // pageName = "taskSummaryTable"
          />
        </TabPanel>
      </Box>
    </div>
  );
};

export default TabsList;
