import React from "react";

import { Link } from "react-router-dom";

import ContentCopyIcon from "@mui/icons-material/ContentCopy";

import "./ClientLeftbar.css";

const ClientLeftbar = () => {
  return (
    <React.Fragment>
      <div className="Leftbar_bg">
        <div>
          {/* <div className="Leftbar_pad">
            <p className="Leftbar_central">
              <Link to="/client/project">
                {" "}
                <ContentCopyIcon className="leftbar_css" />
                <p>Project</p>
              </Link>
            </p>
          </div> */}
          <div className="Leftbar_pad">
            <p className="Leftbar_central">
              <Link to="/">
                {" "}
                <ContentCopyIcon className="leftbar_css" />
                <p>Consultant</p>
              </Link>
            </p>
          </div>
        </div>
      </div>
    </React.Fragment>
  );
};

export default ClientLeftbar;
