import * as React from "react";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import NotificationsIcon from "@mui/icons-material/Notifications";
import "./Notification.css";

import notificationicon_Respond from "../../../Images/notificationicon_Respond.png";
import Grid from "@mui/material/Grid";
import * as Api from "../../../comman/api";
import * as Constant from "../../../comman/constant";
import { useEffect } from "react";
import Paper from "@mui/material/Paper";
import Typography from "@mui/material/Typography";
import { useSelector } from "react-redux";

export default function Notification(props) {
  const [open, setOpen] = React.useState(false);
  const [notificationconsultant, setnotificationconsultant] = React.useState(
    []
  );
  const clientId = useSelector((state) => state.questionnaireReducer.clientId);
  const projectId = useSelector(
    (state) => state.questionnaireReducer.projectId
  );

  const handleClickOpen = () => {
    consultantNotification();
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };
  const consultantNotification = () => {
    let URL = "";
    if (props.usertype === "client") {
      URL =
        Constant.GET_CLIENT_NOTIFICATION +
        "?clientId=" +
        clientId +
        "&projectId=" +
        projectId;
    } else {
      URL =
        Constant.GET_CONSULTANT_NOTIFICATION +
        "?clientId=" +
        clientId +
        "&projectId=" +
        projectId;
    }
    Api.GetConsultantNotification(URL).then((res) => {
      setnotificationconsultant(res);
    });
  };

  return (
    <div className="Notification_main_di">
      <button className="Notifaction_css" onClick={handleClickOpen}>
        {/* <NotificationsIcon /> */}
        <img src="../../../img/Notification_Icon.svg" />
      </button>
      <Dialog
        className="notification_DialogM"
        open={open}
        onClose={handleClose}
      >
        <DialogTitle>
          {" "}
          <span className="Notification_spanM">Notifications</span>{" "}
          <Button className="Notif_span_button" onClick={handleClose}>
            Clear All
          </Button>
        </DialogTitle>

        <DialogContent className="Notification_DialogContent">
          <Paper
            className="Notification_paper"
            sx={{
              p: 2,
              margin: "auto",
              maxWidth: 500,
              flexGrow: 1,
              backgroundColor: (theme) =>
                theme.palette.mode === "dark" ? "#1A2027" : "#fff",
            }}
          >
            {notificationconsultant.map((obj) => {
              return (
                <Grid className="" container spacing={2}>
                  <Grid className="" item>
                    <span className="" sx={{ width: 10, height: 10 }}>
                      <img src={notificationicon_Respond} alt="img" />
                    </span>
                  </Grid>
                  <Grid className="" item xs={12} sm container>
                    <Grid item xs container direction="column" spacing={2}>
                      <Grid className="Notification_Grid1" item xs>
                        <Typography
                          className="Notification_typo1"
                          gutterBottom
                          variant="subtitle1"
                          component="div"
                        >
                          <div className="Notification_div">
                            {obj.clientName} A Has Response to{" "}
                            <span> ' {obj.taskName} '.</span>
                          </div>
                          <div
                            className="Notification_div2"
                            variant="body2"
                            color="text.secondary"
                          >
                            {obj.dateTime}
                          </div>
                        </Typography>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              );
            })}
          </Paper>
        </DialogContent>
      </Dialog>
    </div>
  );
}
