import * as React from "react";
import { useState } from "react";
import { Theme, useTheme } from "@mui/material/styles";
import OutlinedInput from "@mui/material/OutlinedInput";
import MenuItem from "@mui/material/MenuItem";
import { Typography } from "@mui/material";
import FormControl from "@mui/material/FormControl";
import Select, { SelectChangeEvent } from "@mui/material/Select";
import "./Export.css";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import Box from "@mui/material/Box";
import ContentCopyIcon from "@mui/icons-material/ContentCopy";
import { BugReportTwoTone } from "@mui/icons-material";
import * as Api from "../../../comman/api";
import * as Constant from "../../../comman/constant";

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};

const names = ["PDF", "Excel"];

function getStyles(name, personName, theme) {
  return {
    fontWeight:
      personName.indexOf(name) === -1
        ? theme.typography.fontWeightRegular
        : theme.typography.fontWeightMedium,
  };
}

export default function Export(props) {
  const theme = useTheme();
  const [personName, setPersonName] = React.useState(["PDF"]);
  const [exportSummary, setExportSummary] = useState();
  const [fileNames, setFileNames] = React.useState("");
  const [tempid, setTempId] = useState([]);
  const [open, setOpen] = React.useState(false);
  const handleClickOpen = () => {
    setOpen(true);
  };

  function handleFileName(e) {
    setFileNames(e.target.value.replace(
      new RegExp(/[*#$%!~^&`(){}<>?/\\:;""'|]/gm),
      ""
    ));
  };

  React.useEffect(() => {
    setTempId(props.tempIds);
  }, [props.tempIds]);

  // master summary export all fetch
  const exportAll = () => {
    let URL = "";
    URL =
      Constant.BASE_URL +
      Constant.EXPORT_MASTER_SUMMARY +
      "?fileName=" +
      fileNames +
      "&fileType=" +
      personName +
      "&templateId=" +
      props.tempIds.join(",");
    window.location.href = URL;
  };

  const handleClickClose = () => {
    setOpen(false);
  };
  const handleChange = (event) => {
    const {
      target: { value 
      
      },
    } = event;
    setPersonName(
      // On autofill we get a stringified value.
      typeof value === "string" ? value.split(",") : value
    );
  };

  return (
    <React.Fragment>
      <Button
        variant="contained"
        className="interview-synopsis-button"
        onClick={handleClickOpen}
      >
        Export All Synopsis
      </Button>
      <Dialog open={open} onClose={handleClickClose}>
        <DialogTitle className="ExportQuestion_width">Export As</DialogTitle>
        <DialogContent>
          <DialogContentText>
            <Box component="form" noValidate autoComplete="off">
              <Typography className="file-names">Specify a Filename</Typography>
              <FormControl sx={{ m: 1, width: 451, mt: 3, mr: 1 }}>
                <OutlinedInput
                  className="text-field"
                  onChange={handleFileName}
                  value={fileNames}
                  placeholder=""
                />
              </FormControl>
              <Typography className="file-names">
                Select the File type
              </Typography>
              <FormControl sx={{ m: 1, width: 451, mt: 3, mr: 1 }}>
                <Select
                  style={{ height: "40px" }}
                  displayEmpty
                  value={personName}
                  onChange={handleChange}
                  input={<OutlinedInput />}
                  renderValue={(selected) => {
                    if (selected.length === 0) {
                      return <em></em>;
                    }

                    return selected.join(", ");
                  }}
                  MenuProps={MenuProps}
                  inputProps={{ "aria-label": "Without label" }}
                >
                  <MenuItem disabled value="">
                    <em>PDF (*.pdf)</em>
                  </MenuItem>
                  {names.map((name) => (
                    <MenuItem
                      key={name}
                      value={name}
                      style={getStyles(name, personName, theme)}
                    >
                      {name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Box>
          </DialogContentText>
        </DialogContent>

        {/* <FormControl sx={{ m: 1, width: 451, mt: 3 }}>
          <Typography className="file-names">Choose a Location</Typography>
        </FormControl>
        <label>
          <input type="file" style={{ display: "none" }} />

          <div className="browser_css">
            Browse
            <span>
              <ContentCopyIcon className="browse_icon_css" />
            </span>
          </div>
        </label> */}
        <DialogActions className="ExportQuestionnaire_pad">
          <Button
            variant="outlined"
            style={{
              margin: "12px 0px 10px 0px",
              padding: "5px 17px",
              textTransform: "capitalize",
              "border-radius": "25px",
            }}
            onClick={handleClickClose}
          >
            Cancel
          </Button>
          <Button
            style={{
              margin: "12px 5px 10px 5px",
              padding: "5px 17px",
              backgroundColor: "#0070AD",
              color: "#fff",
              textTransform: "capitalize",
              "border-radius": "25px",
            }}
            variant="contained"
            // onClick={handleClickClose}
            onClick={exportAll}
          >
            Export
          </Button>
        </DialogActions>
      </Dialog>
    </React.Fragment>
  );
}
