import React from "react";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import EditOutlinedIcon from "@mui/icons-material/EditOutlined";
import FormControl from "@mui/material/FormControl";
import "../Icons/FileDownloadIcon.css";
import { setTemplateName } from "../../redux/actions/questionnaireAction";
import { useSelector, useDispatch } from "react-redux";
const RenameQuestionnaire = (props) => {
  const [name, setName] = React.useState("");
  const [nameErrorMessage, setNameErrorMessage] = React.useState("");
  const dispatch = useDispatch();

  const handleClickOpen = () => {
    props.setOpen(true);
  };

  const handleClose = () => {
    props.setOpen(false);
  };

  const handleDone = () => {
    if (name === "") {
      setNameErrorMessage("Please Select the Unique Project template name");
    } else {
      dispatch(setTemplateName(name));
      props.setRenameTemplate(1);
      //  props.saveQuestionnaire();
      handleClose();
    }
  };
  return (
    <span>
      {/* <EditOutlinedIcon onClick={handleClickOpen} /> */}
      <Dialog
        open={props.open}
        onClose={handleClose}
        maxWidth="xs"
        fullWidth={true}
      >
        <DialogTitle>
          {/* {props.questionnaireName === "Untitled" ||
          props.questionnaireName === "" ||
          props.questionnaireName === props.parentTemplateName
            ? "Save As"
            : "Rename"} */}
          Save As
        </DialogTitle>

        <DialogContent>
          <h4
            className="Filedownload_h4"
            style={{ fontFamily: "sans-serif", fontWeight: "500" }}
          >
            Document Name
          </h4>
          <FormControl fullWidth sx={{ m: 0 }}>
            <TextField
              id="outlined-basic"
              variant="outlined"
              placeholder=""
              size="small"
              onChange={(e) => {
                setName(e.target.value.replace(
                  new RegExp(/[*#$%!~^&`(){}<>?/\\:;""'|]/gm),
                  ""
                ));
                setNameErrorMessage("");
              }}
              value={name}
              inputProps={{ autoComplete: "off" }}
              defaultValue={
                props.questionnaireName === "Untitled"
                  ? ""
                  : props.questionnaireName
              }
            />
          </FormControl>
          <br />
          <span style={{ color: "red" }}>{nameErrorMessage}</span>
          <DialogActions className="rename_popup_button">
            <Button
              style={{
                margin: "12px 0px 0px 0px",
                padding: "5px 17px",
                textTransform: "capitalize",
                "border-radius": "25px",
              }}
              variant="outlined"
              onClick={handleClose}
            >
              Cancel
            </Button>
            <Button
              style={{
                margin: "12px 0px 0px 5px",
                padding: "5px 17px",
                backgroundColor: "#0070AD",
                color: "#fff",
                textTransform: "capitalize",
                "border-radius": "25px",
              }}
              variant="outlined"
              onClick={handleDone}
            >
              {/* {props.questionnaireName === "Untitled" ||
              props.questionnaireName === "" ||
              props.questionnaireName === props.parentTemplateName
                ? "Save"
                : "Done"} */}
              Save
            </Button>
          </DialogActions>
        </DialogContent>
      </Dialog>
    </span>
  );
};

export default RenameQuestionnaire;
