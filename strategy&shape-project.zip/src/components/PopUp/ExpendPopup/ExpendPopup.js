import * as React from "react";
import AppBar from "@mui/material/AppBar";
import { useState } from "react";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import Typography from "@mui/material/Typography";
import IconButton from "@mui/material/IconButton";
import MenuIcon from "@mui/icons-material/Menu";
import AccountCircle from "@mui/icons-material/AccountCircle";
import Switch from "@mui/material/Switch";
import FormControlLabel from "@mui/material/FormControlLabel";
import FormGroup from "@mui/material/FormGroup";
import MenuItem from "@mui/material/MenuItem";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import Menu from "@mui/material/Menu";
import "./ExpandPopup.css";
import CommonModal from "./modal";
import { useNavigate } from "react-router-dom";
import RenameQuestionnaire from "../RenameQuestionnaire";
import RenamePopUp from "./RenamePopUp";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import Button from "@mui/material/Button";
import { TextField } from "@mui/material";
import * as Api from "../../../comman/api";
import * as Constant from "../../../comman/constant";
import { useEffect } from "react";
import SuccssMsg from "../../AlertBox/SuccessMsg";
import WarningMsg from "../../AlertBox/WarningMsg";
import { useSelector, useDispatch } from "react-redux";
import {
  setTemplateId,
  setPId,
  setTemplateStatus,
  setQuestionnaireEvent,
} from "../../../redux/actions/questionnaireAction";

export default function ExpendPopup(props) {
  const [auth, setAuth] = React.useState(true);
  const [anchorEl, setAnchorEl] = React.useState(null);
  const [open, setOpen] = React.useState(false);
  const [openRename, setOpenRename] = useState(false);
  const [openSaveAs, setOpenSaveAs] = useState(false);
  const [documentName, setDocumentName] = useState("");
  const [newTemplateName, setNewTemplateName] = useState("");
  const [openDelete, setOpenDelete] = useState("");
  // const [showAlertBox, setShowAlertBox] = React.useState(false);
  const [error, setError] = useState("");
  const [warningMessage, setWarningMessage] = React.useState("");
  const [showWarningBox, setShowWarningBox] = React.useState(false);
  // const [successMessage, setSuccessMessage] = React.useState("Deleted Successfully");
  const projectId = useSelector(
    (state) => state.questionnaireReducer.projectId
  );
  const projectName = useSelector(
    (state) => state.questionnaireReducer.projectName
  );
  const clientName = useSelector(
    (state) => state.questionnaireReducer.userData.clientName
  );
  const email = useSelector(
    (state) => state.questionnaireReducer.userData.email
  );
  const clientId = useSelector((state) => state.questionnaireReducer.clientId);
  const userId = useSelector((state) => state.questionnaireReducer.userId);
  const dispatch = useDispatch();

  const handleDocumentChange = (e) => {
    setDocumentName(
      e.target.value.replace(new RegExp(/[*#$%!~^&`(){}<>?/\\:;""'|]/gm), "")
    );
  };
  //rename Document fetch
  function RenameDocument() {
    const data = {
      templateId: props.templateId,
      templateName: documentName,
      templateMessgae: "string",
      statusCode: 0,
    };

    Api.ProjectRename(Constant.PROJECT_RENAME, data).then((res) => {
      if (res.statusCode === 200) {
        props.getSearchData();
        handleRenameClose();
      } else {
        setError(res.message);
      }
    });
  }

  //Project Delete

  function deleteDocument() {
    let URL = "";
    URL = Constant.PROJECT_DELETE + "?templateId=" + props.templateId;

    Api.ProjectDelete(URL).then((res) => {
      if (res.statusCode === 200) {
        handleDeleteClose();
        props.getSearchData();
        openAlertBox();
        props.setSuccessMessage(res.message);
      } else if (res.statusCode === 400) {
        setWarningMessage(res.message);
        openWarningBox();
        handleDeleteClose();
      } else {
        setWarningMessage("Something went wrong");
        openWarningBox();
        handleDeleteClose();
      }
    });
  }
  // Save As Functionality
  const handleChangeSaveAs = (e) => {
    setError("");
    setNewTemplateName(
      e.target.value.replace(new RegExp(/[*#$%!~^&`(){}<>?/\\:;""'|]/gm), "")
    );
  };
  //rename Document fetch
  function saveAsTemplate() {
    if (newTemplateName !== "") {
      const data = {
        pId: props.pId,
        templateId: props.templateId,
        templateName: newTemplateName,
        clientId: clientId,

        projectId: projectId,

        createdBy: userId,

        clientName: clientName,

        projectName: projectName,
        createdByEmail: email,
      };
      Api.projectClone(Constant.SAVE_TEMPLATE_CLONE, data).then((res) => {
        if (res.code === 1) {
          props.getSearchData();
          handleSaveAsClose();
          openAlertBox();
          props.setSuccessMessage(res.message);
        } else {
          setError(res.message);
        }
      });
    } else {
      setError("Please Enter Template Name");
    }
  }

  const navigate = useNavigate();

  const handleChange = (event) => {
    setAuth(event.target.checked);
  };

  const handleMenu = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };
  const handleClickOpen = () => {
    handleClose();
    setOpen(true);
  };

  const handleClickRenameOpen = () => {
    handleClose();
    setOpenRename(true);
    setError("");
    documentName("");
  };

  const handleClickDeleteOpen = () => {
    handleClose();
    setOpenDelete(true);
  };

  const handleClickSaveAsOpen = () => {
    handleClose();
    setOpenSaveAs(true);
    setError("");
    setNewTemplateName("");
  };

  const openAlertBox = () => {
    props.setShowAlertBox(true);
  };

  const openWarningBox = () => {
    setShowWarningBox(true);
  };

  const viewQuestionnaire = (pId, templateId, status) => {
    dispatch(setTemplateId(templateId));
    dispatch(setPId(pId));
    dispatch(setTemplateStatus(status));
    dispatch(setQuestionnaireEvent("editQuestionnaire"));
    if (status === "Saved") {
      navigate("/AddQuestionnaire");
    } else {
      navigate("/Respond");
    }
  };
  const handlemodClose = async () => {
    await setOpen(false);
  };

  const handleRenameClose = async () => {
    await setOpenRename(false);
  };
  const handleDeleteClose = async () => {
    await setOpenDelete(false);
  };
  const handleSaveAsClose = async () => {
    await setOpenSaveAs(false);
  };
  return (
    <Box className="Expend_box" sx={{ flexGrow: 1 }}>
      <AppBar className="Expand_BG" position="static">
        <Toolbar className="name2">
          {auth && (
            <span>
              <IconButton
                className="name4"
                size="large"
                aria-label="account of current user"
                aria-controls="menu-appbar"
                aria-haspopup="true"
                onClick={handleMenu}
                color="inherit"
              >
                <MoreVertIcon style={{ color: "#0070AD" }} />
              </IconButton>
              <Menu
                className="ExpendPop_main"
                id="menu-appbar"
                anchorEl={anchorEl}
                anchorOrigin={{
                  vertical: "top",
                  horizontal: "right",
                }}
                keepMounted
                transformOrigin={{
                  vertical: "top",
                  horizontal: "right",
                }}
                open={Boolean(anchorEl)}
                onClose={handleClose}
              >
                <MenuItem
                  className="expend_popup_font"
                  onClick={() =>
                    viewQuestionnaire(props.pId, props.templateId, props.status)
                  }
                >
                  Open
                </MenuItem>
                <MenuItem
                  className="expend_popup_font"
                  onClick={handleClickOpen}
                >
                  Export
                </MenuItem>
                <MenuItem
                  className="expend_popup_font"
                  onClick={handleClickSaveAsOpen}
                >
                  Save As
                </MenuItem>
                <MenuItem
                  className="expend_popup_font"
                  onClick={handleClickRenameOpen}
                  //    disabled={!props.isOwner}
                >
                  Rename
                </MenuItem>
                <MenuItem
                  className="expend_popup_font"
                  onClick={handleClickDeleteOpen}
                  //   disabled={!props.isOwner}
                >
                  Delete
                </MenuItem>
              </Menu>
            </span>
          )}
        </Toolbar>
      </AppBar>

      <CommonModal
        open={open}
        onClose={() => handlemodClose()}
        type="export"
        templateId={props.templateId}
        pageName={props.pageName}
        status={props.status}
      />

      {/* Dialog Rename functionality    */}
      <Dialog
        className="rename-dialogue"
        open={openRename}
        onClose={handleRenameClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title" className="header-rename">
          {"Rename"}
        </DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            <p className="text-rename">Document Name</p>
            <TextField
              className="text-field-rename"
              onChange={handleDocumentChange}
              value={documentName}
            ></TextField>
            <p className="error-rename">{error}</p>
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button className="cancel-rename" onClick={handleRenameClose}>
            Cancel
          </Button>
          <Button
            className="save-rename"
            onClick={() => {
              RenameDocument();
            }}
            autoFocus
          >
            Done
          </Button>
        </DialogActions>
      </Dialog>

      {/* Dialog Delete functionality */}
      <Dialog
        className="rename-dialogue"
        open={openDelete}
        onClose={handleDeleteClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title" className="header-rename">
          {"Delete"}
        </DialogTitle>
        <DialogContent style={{ fontSize: "12px", fontFamily: "Ubuntu" }}>
          Do you really want to delete the Document {props.name}
        </DialogContent>
        <DialogActions>
          <Button className="cancel-rename" onClick={handleDeleteClose}>
            Cancel
          </Button>
          <Button
            className="save-rename"
            onClick={() => {
              deleteDocument();
            }}
            autoFocus
          >
            Done
          </Button>
        </DialogActions>
      </Dialog>

      {/* Dialog Save As functionality    */}
      <Dialog
        className="rename-dialogue"
        open={openSaveAs}
        onClose={handleSaveAsClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title" className="header-rename">
          {"Save As"}
        </DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            <p className="text-rename">Document Name</p>
            <TextField
              className="text-field-rename"
              onChange={handleChangeSaveAs}
              value={newTemplateName}
            ></TextField>
            <p className="error-rename">{error}</p>
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button className="cancel-rename" onClick={handleSaveAsClose}>
            Cancel
          </Button>
          <Button
            className="save-rename"
            onClick={() => {
              saveAsTemplate();
            }}
            autoFocus
          >
            Save
          </Button>
        </DialogActions>
      </Dialog>

      <SuccssMsg
        showAlertBox={props.showAlertBox}
        setShowAlertBox={props.setShowAlertBox}
        message={props.successMessage}
      />

      <WarningMsg
        showWarningBox={showWarningBox}
        setShowWarningBox={setShowWarningBox}
        message={warningMessage}
      />
    </Box>
  );
}
