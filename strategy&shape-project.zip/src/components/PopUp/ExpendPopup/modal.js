import React, { Component } from "react";
import { Theme, useTheme } from "@mui/material/styles";
import Dialog from "@mui/material/Dialog";
import Button from "@mui/material/Button";
import ContentCopyIcon from "@mui/icons-material/ContentCopy";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import { Typography } from "@mui/material";
import FormControl from "@mui/material/FormControl";
import DialogTitle from "@mui/material/DialogTitle";
import Select from "@mui/material/Select";
import Box from "@mui/material/Box";
import MenuItem from "@mui/material/MenuItem";
import OutlinedInput from "@mui/material/OutlinedInput";
import * as Api from "../../../comman/api";
import * as Constant from "../../../comman/constant";
import "./ExpandPopup.css";

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};

const documentType = ["pdf", "excel", "csv"];

function getStyles(name, personName, theme) {
  return {
    fontWeight:
      personName.indexOf(name) === -1
        ? theme.typography.fontWeightRegular
        : theme.typography.fontWeightMedium,
  };
}

const CommonModal = (props) => {
  const [documentName, setDocumentName] = React.useState(["pdf"]);
  const [downloadDocument, setDownloadDocument] = React.useState([]);
  const [fileName, setfileName] = React.useState("");

  const [location, setLocation] = React.useState("");
  const [tempid, setTempId] = React.useState(33);

  const theme = useTheme();
  const [personName, setPersonName] = React.useState([]);
  // const onClickselect =  () =>{

  //   setDocumentName(documentName)

  //  }
  const handleChangeFileName = (event) => {
    const {
      target: { value },
    } = event;
    setfileName(
      // On autofill we get a stringified value.
      typeof value === "string"
        ? value
            .replace(new RegExp(/[*#$%!~^&`(){}<>?/\\:;""'|]/gm), "")
            .split(",")
        : value.replace(new RegExp(/[*#$%!~^&`(){}<>?/\\:;""'|]/gm), "")
    );
  };
  const handleChangeLocation = (event) => {
    const {
      target: { value },
    } = event;
    setLocation(
      // On autofill we get a stringified value.
      typeof value === "string" ? value.split(",") : value
    );
  };
  function removeTags(str) {
    if (str === null || str === "") return "";
    else str = str.toString();

    // Regular expression to identify HTML tags in
    // the input string. Replacing the identified
    // HTML tag with a null string.
    return str.replace(/(<([^>]+)>)/gi, "");
  }

  function removeTags(str) {
    if (str === null || str === "") return "";
    else str = str.toString();

    // Regular expression to identify HTML tags in

    // the input string. Replacing the identified

    // HTML tag with a null string.

    return str.replace(/(<([^>]+)>)/gi, "");
  }

  const handleChange = (event) => {
    const {
      target: { value },
    } = event;
    setDocumentName(
      // On autofill we get a stringified value.
      typeof value === "string" ? value.split(",") : value
    );
  };
  const downloadFile = () => {
    let URL = "";
    if (props.pageName === "taskAssigned") {
      URL =
        Constant.BASE_URL +
        Constant.GET_Client_DownloadQuestionList +
        "?templateId=" +
        props.templateId +
        "&fileName=" +
        fileName[0] +
        "&fileType=" +
        documentName +
        "&status=" +
        props.status;
    }
    if (props.pageName === "Questionnaire") {
      let roleIdSection = "";
      props.selectedRoleList.map((value) => {
        roleIdSection = roleIdSection + "&roleId=" + value.roleId;
      });
      URL =
        Constant.BASE_URL +
        Constant.EXPORT_QUSETIONNAIRE_SET +
        "?fileName=" +
        fileName[0] +
        "&fileType=" +
        documentName +
        "&leaderShipCategoryId=" +
        props.leaderShipCategoryId +
        roleIdSection;
    }
    if (props.pageName === "Respond") {
      URL =
        Constant.BASE_URL +
        Constant.GET_CONSULTANT_EXPORTQUESTIONNAIRE +
        "?templateId=" +
        props.templateId +
        "&fileName=" +
        fileName[0] +
        "&fileType=" +
        documentName +
        "&status=" +
        props.status;
    }
    if (props.pageName === "ClientRespond") {
      URL =
        Constant.BASE_URL +
        Constant.GET_CLIENT_EXPORTQUESTIONNARIE +
        "?templateId=" +
        props.templateId +
        "&fileName=" +
        fileName[0] +
        "&fileType=" +
        documentName +
        "&status=" +
        props.status;
    }
    if (props.pageName === "project" || props.pageName === "AddQuestionnaire") {
      URL =
        Constant.BASE_URL +
        Constant.EXPORT_PROJECT_SET +
        "?templateId=" +
        props.templateId +
        "&fileName=" +
        fileName[0] +
        "&fileType=" +
        documentName +
        "&status=" +
        props.status;
    }

    if (props.pageName === "Interview Synopsis") {
      URL =
        Constant.BASE_URL +
        Constant.DOWNLOAD_LIST +
        "?templateName=" +
        props.templateName +
        "&synopsis=" +
        removeTags(props.synopis) +
        "&fileType=" +
        documentName +
        "&fileName=" +
        fileName[0];
    }
    if (props.pageName === "TaskSummay") {
      URL =
        Constant.BASE_URL +
        Constant.DOWNLOAD_TASK_SUMMARY_DOCUMENT +
        "?templateId=" +
        props.templateId +
        "&fileName=" +
        fileName[0] +
        "&fileType=" +
        documentName +
        "&status=" +
        props.status;
    }

    window.location.href = URL;
    console.log(URL);
  };

  const handlechildclose = () => {
    props.onClose();
  };
  return (
    <div>
      <Dialog open={props.open} onClose={() => handlechildclose()}>
        <DialogTitle>
          {props.type === "download" ? "Download" : "Export"}
        </DialogTitle>
        <DialogContent>
          <DialogContentText>
            <Box component="form" noValidate autoComplete="off">
              <Typography style={{ fontSize: "12px", fontWeight: "400" }}>
                <h3 style={{ margin: "1px 0px 3px 0px" }}>
                  Specify a Filename{" "}
                </h3>{" "}
              </Typography>
              <FormControl sx={{ m: 1, width: 451, mt: 3 }}>
                <OutlinedInput
                  placeholder=""
                  value={fileName}
                  onChange={handleChangeFileName}
                />
              </FormControl>
              <Typography style={{ fontSize: "12px", fontWeight: "400" }}>
                <h3 style={{ margin: "1px 0px 3px 0px" }}>
                  {" "}
                  Select the Filetype
                </h3>
              </Typography>
              <FormControl sx={{ m: 1, width: 451, mt: 3 }}>
                <Select
                  className="menuitem-block"
                  displayEmpty
                  value={documentName}
                  onChange={handleChange}
                  input={<OutlinedInput />}
                  renderValue={(selected) => {
                    if (selected.length === 0) {
                      // return <em>PDF (*.pdf)</em>;
                    }

                    return selected.join(", ");
                  }}
                  MenuProps={MenuProps}
                  inputProps={{ "aria-label": "Without label" }}
                >
                  <MenuItem className="menu-list-block" disabled value="">
                    {/* <em>PDF (*.pdf)</em> */}
                  </MenuItem>
                  {documentType.map((name) => (
                    <MenuItem
                      className="menu-list-block"
                      key={name}
                      value={name}
                      style={getStyles(name, documentName, theme)}
                    >
                      {name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Box>
          </DialogContentText>
        </DialogContent>

        {/* 
        <div>
          <label>
            <input
              type="file"
              style={{ display: "none" }}
              onChange={handleChangeLocation}
              directory=""
              webkitdirectory=""
            />
            <Typography>
              <h3 className="ChooswFile_css">Choose a Location</h3>
            </Typography>
            <div className="browser_css">
              Browse
              <span>
                <ContentCopyIcon className="browse_icon_css" />
              </span>
            </div>
          </label>
        </div> */}

        <DialogContent>
          {/* <h4  className='Filedownload_h4' style={{fontFamily:'sans-serif', fontWeight:"300"}}> Project</h4> */}
          {/* <MultipleInputSelect/> */}
          <DialogActions className="Download_button_margin">
            <Button
              style={{ padding: "0px 12px", textTransform: "capitalize" }}
              variant="outlined"
              onClick={() => handlechildclose()}
            >
              Cancel
            </Button>
            {props.type === "download" ? (
              <Button
                style={{
                  padding: "0px 12px",
                  backgroundColor: "#0070AD",
                  color: "#fff",
                  textTransform: "capitalize",
                }}
                variant="outlined"
                onClick={() => {
                  handlechildclose();
                  downloadFile();
                }}
              >
                Download
              </Button>
            ) : (
              <Button
                style={{
                  padding: "0px 12px",
                  backgroundColor: "#0070AD",
                  color: "#fff",
                  textTransform: "capitalize",
                }}
                variant="outlined"
                onClick={() => {
                  downloadFile();
                  handlechildclose();
                }}
              >
                Export
              </Button>
            )}
          </DialogActions>
        </DialogContent>
      </Dialog>
    </div>
  );
};
export default CommonModal;
