import * as React from "react";
import "./AlertBox.css";
import CheckIcon from "@mui/icons-material/Check";
import CloseIcon from "@mui/icons-material/Close";

export default function SuccssMsg(props) {
  const openAlertBox = () => {
    props.setShowAlertBox(true);
  };
  const closeAlertBox = () => {
    props.setShowAlertBox(false);
  };
  return (
    <div
      class="alertbox"
      style={{ display: props.showAlertBox ? "block" : "none" }}
    >
      <span
        class="closebtn"
        onclick="this.parentElement.style.display='none';"
      ></span>
      <CheckIcon className="checkicon" />
      <label>{props.message} </label>
      <CloseIcon className="closeicon" onClick={() => closeAlertBox()} />
    </div>
  );
}
