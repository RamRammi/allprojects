import * as React from "react";
import "./AlertBox.css";
// import CheckIcon from "@mui/icons-material/Check";
import ClearIcon from '@mui/icons-material/Clear';
import CloseIcon from "@mui/icons-material/Close";

export default function WarningMsg(props) {
  const openBox = () => {
    props.setShowWarningBox(true);
  };
  const closeBox = () => {
    props.setShowWarningBox(false);
  };
  return (
    <div
      class="warningbox"
      style={{ display: props.showWarningBox ? "block" : "none" }}
    >
      <span
        class="closebtn"
        onclick="this.parentElement.style.display='none';"
      ></span>
      <ClearIcon className="clearicon" />
      <label>{props.message }</label>
      <CloseIcon className="closeicon" onClick={() => closeBox()} />
    </div>
  );
}
