import * as React from "react";
import Box from "@mui/material/Box";
import InputLabel from "@mui/material/InputLabel";
import FormControl from "@mui/material/FormControl";
import NativeSelect from "@mui/material/NativeSelect";
import Stack from "@mui/material/Stack";
import Button from "@mui/material/Button";
import "./PlatformNav.css";
export default function PlatformNav() {
  return (
    <React.Fragment>
      <Box sx={{ minWidth: 120 }} className="onebutton">
        <FormControl>
          <InputLabel variant="standard" htmlFor="uncontrolled-native" />
          <NativeSelect
            defaultValue={30}
            inputProps={{
              name: "age",
              id: "uncontrolled-native",
            }}
          >
            <option value={10} style={{ backgroundColor: "#0070AD" }}>
              Startegy
            </option>
            <option value={20} style={{ backgroundColor: "#0070AD" }}>
              Twenty
            </option>
            <option value={30} style={{ backgroundColor: "#0070AD" }}>
              Startegy
            </option>
          </NativeSelect>
        </FormControl>
      </Box>
      <div className="threeButtons">
        <Stack spacing={2} direction="row">
          <Button variant="outlined">Planning</Button>
          <Button variant="outlined">Solutions</Button>
          <Button variant="outlined">Value Management</Button>
        </Stack>
      </div>
    </React.Fragment>
  );
}
