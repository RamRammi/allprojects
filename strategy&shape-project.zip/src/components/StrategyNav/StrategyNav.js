import * as React from "react";
import Button from "@mui/material/Button";
import Stack from "@mui/material/Stack";
import "./StrategyNav.css";

export default function StrategyNav() {
  return (
    <Stack className="TextButtons" direction="row" spacing={2}>
      <Button className="TextButton_button active" href="#text-buttons">
        Questionarie
      </Button>
      <Button className="TextButton_button" href="#text-buttons">
        Value Driver
      </Button>
      <Button className="TextButton_button" href="#text-buttons">
        KPIs
      </Button>
      <Button className="TextButton_button" href="#text-buttons">
        Process Hierarchies
      </Button>
      <Button className="TextButton_button" href="#text-buttons">
        Business Cases
      </Button>
      <Button className="TextButton_button" href="#text-buttons">
        TOMs
      </Button>
    </Stack>
  );
}
