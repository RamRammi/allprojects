import React, { useEffect, useRef } from "react";
import { makeStyles } from "@material-ui/core/styles";
import { withStyles } from "@material-ui/core/styles";
import MuiAccordion from "@material-ui/core/Accordion";
import MuiAccordionSummary from "@material-ui/core/AccordionSummary";
import MuiAccordionDetails from "@material-ui/core/AccordionDetails";
import Checkbox from "@material-ui/core/Checkbox";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Typography from "@material-ui/core/Typography";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import Button from "@mui/material/Button";
import { useNavigate } from "react-router-dom";
import GeneralTable from "../../components/Table/MasterQuestionTables/GeneralTable";
import LeaderShipTable from "../../components/Table/MasterQuestionTables/LeaderShipTable";
import RolesTable from "../../components/Table/MasterQuestionTables/RolesTable";
import { useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import {
  setSelectedMasterQuestion,
  setGeneralQuestion,
  setLeaderShipQuestion,
  setRoleQuestion,
  setQuestionnaireEvent,
  setTemplateName,
  setQuestionnaireState,
} from "../../redux/actions/questionnaireAction";

const Accordion = withStyles({
  root: {
    width: "100%",
    display: "inline-block",
    //border: "1px solid rgba(0, 0, 0, .125)",
    boxShadow: "none",
    "&:not(:last-child)": {
      borderBottom: 0,
    },
    "&:before": {
      display: "none",
    },
    "&$expanded": {
      margin: "auto",
    },
  },
  expanded: {},
})(MuiAccordion);

const AccordionSummary = withStyles({
  root: {
    backgroundColor: " #F6F6F6",
    borderBottom: "1px solid rgba(0, 0, 0, .125)",
    marginBottom: -1,
    minHeight: 56,
    "&$expanded": {
      minHeight: 56,
    },
  },
  content: {
    "&$expanded": {
      margin: "12px 0",
    },
  },
  expanded: {},
})(MuiAccordionSummary);

const AccordionDetails = withStyles((theme) => ({
  root: {
    padding: theme.spacing(2),
  },
}))(MuiAccordionDetails);
export default function QuestionList(props) {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const nodeRef = useRef(null);
  const [list, setList] = useState([]);
  // const [selected, setSelected] = React.useState([]);
  const selected = useSelector(
    (state) => state.questionnaireReducer.selectedMasterQuestion
  );
  const generalQ = useSelector(
    (state) => state.questionnaireReducer.generalQuestion
  );
  const leadershipQ = useSelector(
    (state) => state.questionnaireReducer.leadershipQuestion
  );
  const roleQ = useSelector((state) => state.questionnaireReducer.roleQuestion);
  const filterField = useSelector(
    (state) => state.questionnaireReducer.masterFilterQuestion
  );
  const [isGeneralSelect, setIsGeneralSelect] = React.useState(false);
  const [isLeadershipSelect, setIsLeadershipSelect] = React.useState(false);
  const [isRoleSelect, setIsRoleSelect] = React.useState(false);
  const [openGeneralSection, setOpenGeneralSection] = React.useState(false);
  const [openLeadershipTypeSection, setOpenLeadershipTypeSection] =
    React.useState(false);
  const [openRoleSpcificSection, setOpenRoleSpcificSection] =
    React.useState(false);

  React.useEffect(() => {
    if (props.openAccordion) {
      setOpenGeneralSection(true);
      setOpenLeadershipTypeSection(true);
      setOpenRoleSpcificSection(true);
    }
  }, [props.openAccordion]);

  const addQuestionnaire = () => {
    //   let newArray = [];
    //  newArray = newArray.concat(generalQ, leadershipQ, roleQ);
    dispatch(setQuestionnaireEvent("addQuestionnaire"));
    dispatch(setTemplateName(props.questionnaireName));
    dispatch(setQuestionnaireState("edit"));
    // dispatch(setSelectedMasterQuestion(newArray));
    navigate(
      "/AddQuestionnaire"
      // {
      // state: {
      //selectedQuestions: newArray,
      // leaderShipCategoryId: props.leaderShipCategoryId,
      //   eventName: "addQuestionnaire",
      // templateName: props.questionnaireName,
      // },
      // }
    );
  };
  const handleChangeCheckbox = (category) => {
    if (category === "general") {
      if (isGeneralSelect) {
        dispatch(setGeneralQuestion([]));
      }
      setIsGeneralSelect(!isGeneralSelect);
    }
    if (category === "leadershipType") {
      if (isLeadershipSelect) {
        dispatch(setLeaderShipQuestion([]));
      }
      setIsLeadershipSelect(!isLeadershipSelect);
    }
    if (category === "roleSpecific") {
      if (isRoleSelect) {
        dispatch(setRoleQuestion([]));
      }
      setIsRoleSelect(!isRoleSelect);
    }
  };

  const changeCateCheckbox = (name, length, selectedRows) => {
    if (name === "general") {
      if (filterField.general[0].rows.length === 0) {
        setIsGeneralSelect(false);
      } else if (filterField.general[0].rows.length === generalQ.length) {
        setIsGeneralSelect(true);
      } else {
        setIsGeneralSelect(false);
      }
      // dispatch(setGeneralQuestion(selectedRows));
    }
    if (name === "leadershipType") {
      if (filterField.leadershipType[0].rows.length === 0) {
        setIsLeadershipSelect(false);
      } else if (
        filterField.leadershipType[0].rows.length === leadershipQ.length
      ) {
        setIsLeadershipSelect(true);
      } else {
        setIsLeadershipSelect(false);
      }
    }
    if (name === "roleSpecific") {
      let roleObjLength = 0;
      filterField.roleSpecific.map((value, index) => {
        roleObjLength = roleObjLength + value.rows.length;
      });
      if (roleObjLength === 0) {
        setIsRoleSelect(false);
      } else if (roleObjLength === roleQ.length) {
        setIsRoleSelect(true);
      } else {
        setIsRoleSelect(false);
      }
    }
  };
  return (
    <div>
      <Accordion expanded={openGeneralSection}>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-label="Expand"
          aria-controls="additional-actions1-content"
          id="additional-actions1-header"
          onClick={() => setOpenGeneralSection(!openGeneralSection)}
        >
          <FormControlLabel
            aria-label="Acknowledge"
            onClick={(event) => event.stopPropagation()}
            onFocus={(event) => event.stopPropagation()}
            control={
              <Checkbox
                color="primary"
                //   setSelected={setSelected}
                isGeneralSelect={isGeneralSelect}
                // selected={selected}
                checked={isGeneralSelect}
                onChange={() => handleChangeCheckbox("general")}
                disabled={
                  filterField.general[0].rows.length === 0 ? true : false
                }
              />
            }
            label="General Questions"
          />
        </AccordionSummary>
        <AccordionDetails>
          <Typography color="textSecondary">
            <GeneralTable
              filterField={filterField.general}
              changeCateCheckbox={changeCateCheckbox}
              isGeneralSelect={isGeneralSelect}
              setIsGeneralSelect={setIsGeneralSelect}
              openGeneralSection={openGeneralSection}
              sNo={0}
            />
          </Typography>
        </AccordionDetails>
      </Accordion>
      <Accordion expanded={openLeadershipTypeSection}>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-label="Expand"
          aria-controls="additional-actions2-content"
          id="additional-actions2-header"
          onClick={() =>
            setOpenLeadershipTypeSection(!openLeadershipTypeSection)
          }
        >
          <FormControlLabel
            aria-label="Acknowledge"
            onClick={(event) => event.stopPropagation()}
            onFocus={(event) => event.stopPropagation()}
            control={
              <Checkbox
                color="primary"
                checked={isLeadershipSelect}
                onChange={() => handleChangeCheckbox("leadershipType")}
                disabled={
                  filterField.leadershipType[0].rows.length === 0 ? true : false
                }
              />
            }
            label="Leadership Type General Questions"
          />
        </AccordionSummary>
        <AccordionDetails>
          <Typography color="textSecondary">
            <LeaderShipTable
              filterField={filterField.leadershipType}
              changeCateCheckbox={changeCateCheckbox}
              isLeadershipSelect={isLeadershipSelect}
              setIsLeadershipSelect={setIsLeadershipSelect}
              sNo={filterField.general[0].rows.length}
            />
          </Typography>
        </AccordionDetails>
      </Accordion>
      <Accordion expanded={openRoleSpcificSection}>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-label="Expand"
          aria-controls="additional-actions3-content"
          id="additional-actions3-header"
          onClick={() => setOpenRoleSpcificSection(!openRoleSpcificSection)}
        >
          <FormControlLabel
            aria-label="Acknowledge"
            onClick={(event) => event.stopPropagation()}
            onFocus={(event) => event.stopPropagation()}
            control={
              <Checkbox
                color="primary"
                checked={isRoleSelect}
                onChange={() => handleChangeCheckbox("roleSpecific")}
                disabled={filterField.roleSpecific.length === 0 ? true : false}
              />
            }
            label="Role Specific Questions"
          />
        </AccordionSummary>
        <AccordionDetails>
          <Typography color="textSecondary">
            <RolesTable
              filterField={filterField.roleSpecific}
              isRoleSelect={isRoleSelect}
              setIsRoleSelect={setIsRoleSelect}
              changeCateCheckbox={changeCateCheckbox}
              sNo={
                filterField.general[0].rows.length +
                filterField.leadershipType[0].rows.length
              }
            />
          </Typography>
        </AccordionDetails>
      </Accordion>
      <div className="action-bottons">
        <Button
          style={{
            fontFamily: "Ubuntu",
            textTransform: "capitalize",
            fontSize: "12px",
            backgroundColor:
              generalQ.length > 0 || leadershipQ.length > 0 || roleQ.length > 0
                ? "#0070AD"
                : "#BFBFBF",
            color: "white",
            margin: "25px 50px 10px 10px",
            float: "right",
            // color: "white",
            borderRadius: "25px",
            padding: "7px 16px",
          }}
          disabled={
            generalQ.length > 0 || leadershipQ.length > 0 || roleQ.length > 0
              ? false
              : true
          }
          onClick={addQuestionnaire}
        >
          Next
        </Button>

        <Button
          style={{
            fontFamily: "Ubuntu",
            fontSize: "12px",
            textTransform: "capitalize",
            backgroundColor: "white",
            // color: "white",
            margin: "25px 30px 10px 10px",
            float: "right",
            color: "0070AD",
            borderRadius: "25px",
            padding: "7px 16px",
            border: "1px solid #0070AD",
          }}
          onClick={() => navigate("/")}
        >
          back
        </Button>
      </div>
    </div>
  );
}
