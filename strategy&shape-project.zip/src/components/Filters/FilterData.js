import * as React from "react";
import { useState, useEffect, useRef } from "react";
import { useTheme } from "@mui/material/styles";
import OutlinedInput from "@mui/material/OutlinedInput";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import "./FilterData.css";
import Button from "@mui/material/Button";
import * as Api from "../../comman/api";
import * as Constant from "../../comman/constant";
import { Typography } from "@mui/material";
import ListItemText from "@material-ui/core/ListItemText";
import Checkbox from "@material-ui/core/Checkbox";
import Input from "@material-ui/core/Input";
import { useLocation } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import {
  setLeadershipId,
  setLeadershipCateName,
  setLeadershipCate,
  setRoleList,
  setSelectedRoles,
  setMasterSearchApply,
  setMasterFilterQuestion,
  setGeneralQuestion,
  setLeaderShipQuestion,
  setRoleQuestion,
} from "../../redux/actions/questionnaireAction";
const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};

function getStyles(name, personName, theme) {
  return {
    fontWeight:
      personName.indexOf(name) === -1
        ? theme.typography.fontWeightRegular
        : theme.typography.fontWeightMedium,
    fontSize: "12px",
  };
}

export default function FilterData(props) {
  // const pageName = props.pageName;
  const theme = useTheme();
  const dispatch = useDispatch();
  const ref = useRef();
  const location = useLocation();
  //const [leadershipCate, setLeadershipCate] = React.useState([]);
  //const [leadershipCateName, setLeadershipCateName] = React.useState([]);
  // const [leadershipCateId, setLeadershipCateId] = React.useState(0);
  const leadershipCateName = useSelector(
    (state) => state.questionnaireReducer.leadershipCateName
  );
  const leadershipCate = useSelector(
    (state) => state.questionnaireReducer.leadershipCate
  );
  const leadershipId = useSelector(
    (state) => state.questionnaireReducer.leadershipId
  );
  const role = useSelector((state) => state.questionnaireReducer.selectedRoles);
  const roleName = useSelector((state) => state.questionnaireReducer.roleList);
  const applyFilter = useSelector(
    (state) => state.questionnaireReducer.masterSearchApply
  );
  const eventNameRedux = useSelector(
    (state) => state.questionnaireReducer.masterQuestionnaireEvent
  );
  const editQuestionList = useSelector(
    (state) => state.questionnaireReducer.editQuestionList
  );

  // const [role, setRole] = React.useState([]);
  // const [roleName, setRoleName] = React.useState([]);

  const [savedQuestionRoleId, setSavedQuestionRoleId] = React.useState([]);
  const [savedQuestionLeadershipId, setSavedQuestionLeadershipId] =
    React.useState(0);
  const [eventName, setEventName] = useState("add");
  const [eventEditStatus, setEventEditStatus] = useState(true);
  const [tables, setTables] = useState([]);
  const [open, setOpen] = React.useState(false);

  const handleClose = () => setOpen(false);

  const handleOpen = () => setOpen(true);

  React.useEffect(() => {
    setEventName(eventNameRedux);
    if (eventNameRedux === "edit") {
      let leaaderShipId = [];
      let savedQuestion = editQuestionList;
      savedQuestion.map((value, index) => {
        if (savedQuestionRoleId.indexOf(value.roleId) === -1)
          savedQuestionRoleId.push(value.roleId);
        if (leaaderShipId.indexOf(value.leaderShipCategoryId) === -1)
          leaaderShipId.push(value.leaderShipCategoryId);
      });
      let savedLeaderShipId = leaaderShipId.reverse().filter((Id) => Id !== 1);
      if (savedQuestionRoleId[savedQuestionRoleId.length - 1] !== 23) {
        Api.getLeaderShipIdByRoleId(
          Constant.GET_LEADERSHIP_CATEGORY_BY_ROLE_ID +
            "?roleId=" +
            //   savedQuestionRoleId[0]
            savedQuestionRoleId[savedQuestionRoleId.length - 1]
        ).then((res) => {
          setSavedQuestionLeadershipId(res[0].leaderShipCategoryId);
        });
      } else {
        setSavedQuestionLeadershipId(savedLeaderShipId[0]);
      }
    }
  }, []);
  useEffect(() => {
    getLeadershipCategoryList();
  }, []);
  useEffect(() => {
    getLeadershipCategoryList();
  }, [savedQuestionLeadershipId]);

  useEffect(() => {
    if (leadershipId > 0) getRoleList();
    else dispatch(setRoleList([]));
  }, [leadershipId]);

  useEffect(() => {
    if (applyFilter) handleApplyClick();
  }, [applyFilter]);

  useEffect(() => {
    if (!eventEditStatus) dispatch(setMasterSearchApply(false));
  }, [eventEditStatus]);

  useEffect(() => {
    if (eventName === "edit" && eventEditStatus) {
      setEventEditStatus(false);
      props.getSelectedFilters();
    }
  }, [role]);

  // useEffect(() => {
  //   props.setRoleList(role);
  // }, [role]);

  const handleApplyClick = () => {
    dispatch(setGeneralQuestion([]));
    dispatch(setLeaderShipQuestion([]));
    dispatch(setRoleQuestion([]));
    dispatch(setMasterSearchApply(true));
    props.getSelectedFilters(leadershipId, role);
  };

  //Get Leadership Category list
  const getLeadershipCategoryList = () => {
    Api.getLeadershipCategoryList(Constant.GET_LEADERSHIP_CATEGORY_LIST).then(
      (res) => {
        dispatch(setLeadershipCateName(res));
        if (eventName === "edit" && eventEditStatus) {
          res.map((value, index) => {
            if (value.id === savedQuestionLeadershipId) {
              dispatch(setLeadershipCate(value));
              dispatch(setLeadershipId(value.id));
            }
          });
        }
      }
    );
  };

  //Get Leadership Category list
  const getRoleList = (id) => {
    let url = Constant.GET_ROLE + "?leadershipId=" + leadershipId;
    Api.getRoleList(url).then((res) => {
      dispatch(setRoleList(res));
      if (eventName === "edit" && eventEditStatus) {
        let data = [];
        res.map((value, index) => {
          savedQuestionRoleId.map((id) => {
            if (value.roleId === id) {
              // handleChangeRole(value);
              data.push(value);
            }
          });
        });
        handleChangeRole(data);
      }
    });
  };

  const resetFilter = () => {};
  const setDropdownData = (data) => {
    let str = [];
    data.map((value) => {
      str.push(value.roleName);
    });
    if (str.length === 0) {
      return "Select Specific Role";
    } else {
      return str.join(",");
    }
  };

  const handleChangeLeadership = (value) => {
    dispatch(setMasterSearchApply(false));
    // props.setFilterField({
    //   general: [],
    //   leadershipType: [],
    //   roleSpecific: [],
    // });
    dispatch(
      setMasterFilterQuestion({
        general: [],
        leadershipType: [],
        roleSpecific: [],
      })
    );
    if (value === "") {
      dispatch(
        setLeadershipCate({
          id: 0,
          leaderShipName: "Select Leadership Category",
        })
      );
      dispatch(setLeadershipId(0));
      dispatch(setSelectedRoles([]));
    } else {
      dispatch(setSelectedRoles([]));
      dispatch(setLeadershipCate(value));
      dispatch(setLeadershipId(value.id));
    }
  };
  // On change Role
  const handleChangeRole = (value) => {
    if (value === "") {
      dispatch(setSelectedRoles([]));
    } else {
      dispatch(setSelectedRoles(value));
    }
  };
  return (
    <React.Fragment>
      <div className="Rightbar_input_drop_div">
        <FormControl sx={{ m: 1, maxWidth: 250, width: 250, mt: 3 }}>
          <Typography className="Rightbar_input_drop_typ">
            Leadership Category
          </Typography>
          <Select
            displayEmpty
            value={leadershipCate}
            onChange={(e) => {
              handleChangeLeadership(e.target.value);
            }}
            input={<OutlinedInput />}
            renderValue={(selected) => {
              if (selected.length === 0) {
                return "Select Leadership Category";
              }
              return selected.leaderShipName;
            }}
            MenuProps={MenuProps}
            inputProps={{ "aria-label": "Without label" }}
          >
            <MenuItem
              className="menu-List"
              value=""
              style={getStyles(0, leadershipCateName, theme)}
            >
              Select Leadership Category{" "}
            </MenuItem>
            {leadershipCateName.map((obj) => (
              <MenuItem
                className="menu-List-li"
                key={obj.id}
                value={obj}
                style={getStyles(obj.leaderShipName, leadershipCateName, theme)}
              >
                {obj.leaderShipName}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
        <FormControl sx={{ m: 1, maxWidth: 350, width: 350, mt: 3 }}>
          <Typography className="Rightbar_input_drop_typ">
            Specific Role
          </Typography>
          <Select
            displayEmpty
            multiple
            value={role}
            onChange={(e) => handleChangeRole(e.target.value)}
            input={<OutlinedInput />}
            renderValue={(selected) => {
              if (selected.length === 0) {
                return "Select Specific Role";
              }
              return setDropdownData(selected);
            }}
            open={open}
            onClose={handleClose}
            onOpen={handleOpen}
            MenuProps={MenuProps}
            inputProps={{ "aria-label": "Without label" }}
          >
            {roleName.map((data) => (
              <MenuItem
                className="item_checkbox"
                key={data.roleId}
                value={data}
                style={getStyles(data.roleName, roleName, theme)}
              >
                <Checkbox
                  checked={
                    role.map((e) => e.roleName).indexOf(data.roleName) > -1
                  }
                  color="primary"
                />
                <ListItemText
                  className="ListItem_checkbox"
                  primary={data.roleName}
                />
              </MenuItem>
            ))}
            <div className="dropdown-button-section">
              <Button
                className="apply-button"
                variant="contained"
                style={{ backgroundColor: "#0070AD", color: "#fff" }}
                onClick={() => {
                  dispatch(setGeneralQuestion([]));
                  dispatch(setLeaderShipQuestion([]));
                  dispatch(setRoleQuestion([]));
                  props.getSelectedFilters(leadershipId, role);
                  dispatch(setMasterSearchApply(true));
                  handleClose();
                }}
              >
                Apply
              </Button>
            </div>
          </Select>
        </FormControl>
      </div>
    </React.Fragment>
  );
}
