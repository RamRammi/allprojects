import React from "react";
import FormControl from "@mui/material/FormControl";
import { Typography } from "@mui/material";
import TextField from "@material-ui/core/TextField";
import { useContext } from "react";
import { ResponseContext } from "../../comman/context";
import { dateFormat } from "../../comman/utils";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { parseISO } from "date-fns";

const AddQuestionnaireDetailsFilter = (props) => {
  //   const { interviewee, setInterviewee } = useContext(ResponseContext);
  //   const { interviewer, setInterviewer } = useContext(ResponseContext);
  //   const { jobTitle, setJobTitle } = useContext(ResponseContext);
  //   const { date, setDate } = useContext(ResponseContext);
  //   const { isChanged, setIsChanged } = useContext(ResponseContext);
  const currentDate = new Date();

  const dateChange = (newDate) => {
    props.setDate(newDate.toISOString());
  };
  console.log(parseISO(props.date), "date from questionnaire");

  return (
    <div>
      <div className="filter-fields">
        <FormControl sx={{ m: 1, width: 200, mt: 3 }} className="filter-input">
          <Typography className="level">Interviewee</Typography>
          <TextField
            id="outlined-basic"
            value={props.interviewee}
            disabled={props.pageName === "preview" ? true : false}
            variant="outlined"
            placeholder=""
            inputProps={{ autoComplete: "off" }}
            size="small"
            onChange={(e) => {
              props.setIsChanged(true);
              props.setInterviewee(
                e.target.value.replace(
                  new RegExp(/[*#$%!~^&`(){}<>?/\\:;""'|]/gm),
                  ""
                )
              );
            }}
          />
          <span style={{ color: "red" }}>{props.intervieweeMessage}</span>
        </FormControl>
        <FormControl sx={{ m: 1, width: 200, mt: 3 }} className="filter-input">
          <Typography className="level">Interviewer</Typography>
          <TextField
            disabled={props.pageName === "preview" ? true : false}
            value={props.interviewer}
            id="outlined-basic"
            variant="outlined"
            placeholder=""
            inputProps={{ autoComplete: "off" }}
            size="small"
            onChange={(e) => {
              props.setIsChanged(true);
              props.setInterviewer(
                e.target.value.replace(
                  new RegExp(/[*#$%!~^&`(){}<>?/\\:;""'|]/gm),
                  ""
                )
              );
            }}
          />
          <span style={{ color: "red" }}>{props.interviewerMessage}</span>
        </FormControl>
        <FormControl sx={{ m: 1, width: 200, mt: 3 }} className="filter-input">
          <Typography className="level">Job Title</Typography>
          <TextField
            value={props.jobTitle}
            id="outlined-basic"
            disabled={props.pageName === "preview" ? true : false}
            variant="outlined"
            placeholder=""
            inputProps={{ autoComplete: "off" }}
            size="small"
            onChange={(e) => {
              props.setIsChanged(true);
              props.setJobTitle(
                e.target.value.replace(
                  new RegExp(/[*#$%!~^&`(){}<>?/\\:;""'|]/gm),
                  ""
                )
              );
            }}
          />
          <span style={{ color: "red" }}>{props.intervieweeMessage}</span>
        </FormControl>

        <FormControl sx={{ m: 1, width: 150, mt: 3 }} className="filter-input">
          <Typography className="level">
            <span className="required">*</span>Date
          </Typography>

          <LocalizationProvider dateAdapter={AdapterDayjs}>
            <DatePicker
              value={props.date}
              inputFormat="MM/DD/YYYY"
              // onChange={(newValue) => {
              //   // setDate(newValue);
              //   setDate(newValue.toISOString())
              //   setIsChanged(true);
              // }}
              onChange={dateChange}
              renderInput={(params) => (
                <TextField {...params} variant="outlined" size="small" />
              )}
              disabled={props.pageName === "preview" ? true : false}
            />
          </LocalizationProvider>
          <span style={{ color: "red" }}>{props.dateMessage}</span>
        </FormControl>
      </div>
    </div>
  );
};

export default AddQuestionnaireDetailsFilter;
