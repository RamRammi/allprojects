import * as React from "react";
import { useState, useEffect } from "react";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import OutlinedInput from "@mui/material/OutlinedInput";
import MenuItem from "@mui/material/MenuItem";
import { Typography } from "@mui/material";
import { useTheme } from "@mui/material/styles";
import * as Api from "../../comman/api";
import * as Constant from "../../comman/constant";
import "../ValueDriver/ValueDriver.css";
const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};

function getStyles(name, personName, theme) {
  return {
    fontWeight:
      personName.indexOf(name) === -1
        ? theme.typography.fontWeightRegular
        : theme.typography.fontWeightMedium,
  };
}

export default function ValueDriver(props) {
  const [valueDriver, setValueDriver] = useState([]);
  const [valueDriverId, setValueDriverId] = useState(0);
  const [valueDriverName, setValueDriverName] = React.useState([]);
  const theme = useTheme();

  useEffect(() => {
    getValueDriverList();
  }, []);

  //Get Value Driver list
  const getValueDriverList = () => {
    Api.getValueDriverList(Constant.GET_Value_Driver_List).then((res) => {
      console.log(res);
      setValueDriverName(res);
    });
  };

  // On change Value Driver
  const handleChange = (event) => {
    const {
      target: { value },
    } = event;
    if (value === "") {
      setValueDriver({ id: 0, name: "Select a Value Driver" });
      setValueDriverId(0);
      props.setVdId(value.id);
    } else {
      console.log(value);
      setValueDriver(typeof value === "string" ? value.split(",") : value);
      setValueDriverId(value.id);
      props.setVdId(value.id);
    }
  };
  return (
    <React.Fragment>
      <div className="value-drive-border">
        <div className="value-driver-group ">
          <hr />
          <FormControl sx={{ m: 1, width: 300, mt: 3 }}>
            <Typography className="level value-driver-level">
              Value Driver
            </Typography>

            <Select
              className="select-value-driver"
              displayEmpty
              value={valueDriver}
              onChange={handleChange}
              input={<OutlinedInput />}
              renderValue={(selected) => {
                if (selected.length === 0) {
                  return "Select a Value Driver";
                }
                return selected.name;
              }}
              MenuProps={MenuProps}
              inputProps={{ "aria-label": "Without label" }}
            >
              <MenuItem value="">Select a Value Driver </MenuItem>
              {valueDriverName.map((obj) => (
                <MenuItem
                  key={obj.id}
                  value={obj}
                  style={getStyles(obj.name, valueDriverName, theme)}
                >
                  {obj.name}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
          <hr />
        </div>
      </div>
    </React.Fragment>
  );
}
