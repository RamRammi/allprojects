import React, { lazy, Suspense, Fragment } from "react";
import { Routes, Route } from "react-router-dom";
import ShapeProgram from "./pages/ShapeProgram";
import Home from "./pages/Home";
import ProcessHierarchies from "./pages/ProcessHierarchies/ProcessHierarchies";
import Process from "./pages/Process/[id]";
import ClientProcess from "./pages/ClientProcess/[id]";
import VDTClientProcess from "./pages/ValueDriveTrees/ClientPage/[id]";
import VDTMasterProcess from "./pages/ValueDriveTrees/MasterPage/[id]";
import FinanceToManage from "./pages/FinanceToManage";
const Project = lazy(() => import("./pages/Project/Project"));
const Questionnaire = lazy(() => import("./pages/Questionnaire/Questionnaire"));
const TaskSummary = lazy(() => import("./pages/TaskSummary/TaskSummary"));
const MasterSummary = lazy(() =>
  import("./pages/Questionnaire/MasterSummary.js")
);
const ValueDriveTrees = lazy(() =>
  import("./pages/ValueDriveTrees/ValueDriveTrees")
);

const Preview = lazy(() => import("./pages/Questionnaire/Preview.js"));
const ResponsePreview = lazy(() =>
  import("./pages/Questionnaire/ResponsePreview.js")
);
const AddQuestionnaire = lazy(() =>
  import("./pages/Questionnaire/AddQuestionnaire.js")
);
const Respond = lazy(() => import("./pages/Questionnaire/Respond.js"));
const InterviewSynopsis = lazy(() =>
  import("./pages/InterviewSynopsis/InterviewSynopsis")
);
const QuestionGallery = lazy(() =>
  import("./pages/Questionnaire/QuestionGallery.js")
);
const ClientPreview = lazy(() => import("./pages/ClientProcess/ClientPreview"));
const MasterPreview = lazy(() => import("./pages/Process/MasterPreview"));
const TasksAssigned = lazy(() =>
  import("./pages/Client/TasksAssigned/TasksAssigned")
);
const ClientProject = lazy(() => import("./pages/Client/Project/Project"));
const ClientRespond = lazy(() =>
  import("./pages/Client/Questionnaire/Respond")
);
const PainPoints = lazy(() => import("./pages/PainPoints/PainPoints"));
const AddPainPoints = lazy(() => import("./pages/PainPoints/AddPainPoints"));
const EditPainPoints = lazy(() => import("./pages/PainPoints/EditPainPoints"));
function ConsultantApp() {
  return (
    <Fragment>
      <Suspense fallback={<div>Loading...</div>}>
        <div className="App"></div>
        <Routes>
          <Route exact path="/home" element={<Home />}></Route>
          <Route exact path="/shape-program" element={<ShapeProgram />}></Route>
          <Route
            exact
            path="/finance-to-manage"
            element={<FinanceToManage />}
          ></Route>
          <Route
            exact
            path="/AddQuestionnaire"
            element={<AddQuestionnaire />}
          ></Route>
          <Route exact path="/" element={<Project />}></Route>
          <Route
            exact
            path="/process-hierarchies"
            element={<ProcessHierarchies />}
          ></Route>
          <Route
            exact
            path="/process-hierarchies/process/:id"
            element={<Process />}
          ></Route>
          <Route
            exact
            path="/process-hierarchies/client-process/:id"
            element={<ClientProcess />}
          ></Route>
          <Route
            exact
            path="/valueDriveTrees"
            element={<ValueDriveTrees />}
          ></Route>

          <Route
            exact
            path="/valueDriveTrees/master-value-driver/:id"
            element={<VDTMasterProcess />}
          ></Route>

          <Route
            exact
            path="/valueDriveTrees/client-value-driver/:id"
            element={<VDTClientProcess />}
          ></Route>

          <Route exact path="/TaskSummary" element={<TaskSummary />}></Route>
          <Route
            exact
            path="/Questionnaire"
            element={<Questionnaire />}
          ></Route>
          <Route exact path="/Respond" element={<Respond />}></Route>
          <Route exact path="/Preview" element={<Preview />}></Route>
          <Route
            exact
            path="/ResponsePreview"
            element={<ResponsePreview />}
          ></Route>
          <Route
            exact
            path="/InterviewSynopsis"
            element={<InterviewSynopsis />}
          ></Route>
          <Route
            exact
            path="/MasterSummary"
            element={<MasterSummary />}
          ></Route>
          <Route
            exact
            path="/QuestionGallery"
            element={<QuestionGallery />}
          ></Route>

          <Route
            exact
            path="/process-hierarchies/client-process/:id/client-preview"
            element={<ClientPreview />}
          ></Route>
          <Route
            exact
            path="/process-hierarchies/process/:id/master-preview"
            element={<MasterPreview />}
          ></Route>
          <Route
            exact
            path="/process-hierarchies/process/:id/master-preview"
            element={<MasterPreview />}
          ></Route>
          <Route
            exact
            path="/Client/Project"
            element={<ClientProject />}
          ></Route>
          <Route
            exact
            path="/client/tasksAssigned"
            element={<TasksAssigned />}
          ></Route>
          <Route
            exact
            path="/client/respond"
            element={<ClientRespond />}
          ></Route>
          <Route exact path="/painpoints" element={<PainPoints />}></Route>
          <Route
            exact
            path="/painpoints/addpainpoints"
            element={<AddPainPoints />}
          ></Route>
          <Route
            exact
            path="/painpoints/editpainpoints/:id"
            element={<EditPainPoints />}
          ></Route>
          {/* <Route exact path="/preview-master/process-hierarchies/process/:id" element={<PreviewMasterPH />}></Route> */}
        </Routes>
      </Suspense>
    </Fragment>
  );
}
export default ConsultantApp;
