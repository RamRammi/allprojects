import { actionType } from "../actionType";
export const setConsultantProjectActiveTab = (data) => {
  return {
    type: actionType.CONSULTANT_PROJECT_ACTIVE_TAB,
    data: data,
  };
};
export const setLeadershipId = (data) => {
  return {
    type: actionType.LEADERSHIP_ID,
    data: data,
  };
};
export const setLeadershipCate = (data) => {
  return {
    type: actionType.LEADERSHIP_CATE,
    data: data,
  };
};
export const setLeadershipCateName = (data) => {
  return {
    type: actionType.LEADERSHIP_CATE_NAME,
    data: data,
  };
};
export const setSelectedRoles = (data) => {
  return {
    type: actionType.SELECTED_ROLES,
    data: data,
  };
};
export const setRoleList = (data) => {
  return {
    type: actionType.ROLE_BY_LEADERSHIP_ID,
    data: data,
  };
};
export const setMasterQuestionSearch = (data) => {
  return {
    type: actionType.MASTER_QUESTION_SEARCH,
    data: data,
  };
};
export const setMasterFilterQuestion = (data) => {
  return {
    type: actionType.MASTER_FILTER_QUESTION,
    data: data,
  };
};
export const setMasterSearchApply = (data) => {
  return {
    type: actionType.MASTER_SEARCH_APPLY,
    data: data,
  };
};
export const setSelectedMasterQuestion = (data) => {
  return {
    type: actionType.SELECTED_MASTER_QUESTION,
    data: data,
  };
};
export const setClientProjectActiveTab = (data) => {
  return {
    type: actionType.CLIENT_PROJECT_ACTIVE_TAB,
    data: data,
  };
};
export const setMasterSummarySearch = (data) => {
  return {
    type: actionType.MASTER_SUMMARY_SEARCH,
    data: data,
  };
};
export const setGeneralQuestion = (data) => {
  return {
    type: actionType.GENERAL_QUESTION,
    data: data,
  };
};
export const setLeaderShipQuestion = (data) => {
  return {
    type: actionType.LEADERSHIP_QUESTION,
    data: data,
  };
};
export const setRoleQuestion = (data) => {
  return {
    type: actionType.ROLE_QUESTION,
    data: data,
  };
};
export const setTemplateId = (data) => {
  return {
    type: actionType.TEMPLATE_ID,
    data: data,
  };
};
export const setPId = (data) => {
  return {
    type: actionType.PID,
    data: data,
  };
};
export const setSavedQuestions = (data) => {
  return {
    type: actionType.SAVED_QUESTIONS,
    data: data,
  };
};
export const setQuestionnaireState = (data) => {
  return {
    type: actionType.QUESTIONNAIRE_STATE,
    data: data,
  };
};
export const setAddNewQuestionsFlag = (data) => {
  return {
    type: actionType.ADD_NEW_QUESTIONS_FLAG,
    data: data,
  };
};
export const setProjectId = (data) => {
  return {
    type: actionType.PROJECT_ID,
    data: data,
  };
};
export const setClientId = (data) => {
  return {
    type: actionType.CLIENT_ID,
    data: data,
  };
};
export const setUserId = (data) => {
  return {
    type: actionType.USER_ID,
    data: data,
  };
};
export const setUserData = (data) => {
  return {
    type: actionType.USER_DATA,
    data: data,
  };
};
export const setJwt = (data) => {
  return {
    type: actionType.JWT,
    data: data,
  };
};
export const setTemplateStatus = (data) => {
  return {
    type: actionType.TEMPLATE_STATUS,
    data: data,
  };
};
export const setUserType = (data) => {
  return {
    type: actionType.USER_TYPE,
    data: data,
  };
};
export const setRedirectFrom = (data) => {
  return {
    type: actionType.REDIRECT_FROM,
    data: data,
  };
};
export const setQuestionnaireEvent = (data) => {
  return {
    type: actionType.QUESTIONNAIRE_EVENT,
    data: data,
  };
};
export const setTemplateName = (data) => {
  return {
    type: actionType.TEMPLATE_NAME,
    data: data,
  };
};
export const setMasterQuestionnaireEvent = (data) => {
  return {
    type: actionType.MASTER_QUESTIONNAIRE_EVENT,
    data: data,
  };
};
export const setEditQuestionList = (data) => {
  return {
    type: actionType.EDIT_QUESTION_LIST,
    data: data,
  };
};
export const setProjectName = (data) => {
  return {
    type: actionType.PROJECT_NAME,
    data: data,
  };
};
export const setUserRole = (data) => {
  return {
    type: actionType.USER_ROLE,
    data: data,
  };
};
export const setUrlProjectId = (data) => {
  return {
    type: actionType.URL_PROJECT_ID,
    data: data,
  };
};
export const setUrlClientId = (data) => {
  return {
    type: actionType.URL_CLIENT_ID,
    data: data,
  };
};
export const setUrlUserId = (data) => {
  return {
    type: actionType.URL_USER_ID,
    data: data,
  };
};
export const setProgramName = (data) => {
  return {
    type: actionType.PROGRAM_NAME,
    data: data,
  };
};
