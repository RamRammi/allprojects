import { actionType } from "../actionType";

const initialState = {
  consultantProjectActiveTab: 1,
  leadershipId: 0,
  leadershipCate: [],
  leadershipCateName: [],
  selectedRoles: [],
  roleList: [],
  masterQuestionSearch: "",
  masterFilterQuestion: {
    general: [],
    leadershipType: [],
    roleSpecific: [],
  },
  masterSearchApply: false,
  selectedMasterQuestion: [],
  clientProjectActiveTab: 0,
  masterSummarySearch: "",
  selectCateQuestion: {
    general: [],
    leadershipType: [],
    roleSpecific: [],
  },
  generalQuestion: [],
  leadershipQuestion: [],
  roleQuestion: [],
  templateId: 0,
  pId: 0,
  savedQuestions: [],
  questionnaireState: "add",
  addNewQuestionsFlag: 0,
  projectId: "",
  clientId: "",
  userId: "",
  userData: {},
  jwt: "",
  templateStatus: "",
  userType: "",
  redirectFrom: "",
  questionnaireEvent: "",
  templateName: "Untitled",
  masterQuestionnaireEvent: "add",
  editQuestionList: [],
  projectName: "",
  userRole: "",
  urlProjectId: "",
  urlClientId: "",
  urlUserId: "",
  programName: "Ambition & Levers",
};

export default function questionnaireReducer(state = initialState, action) {
  switch (action.type) {
    case actionType.CONSULTANT_PROJECT_ACTIVE_TAB:
      return {
        ...state,
        consultantProjectActiveTab: action.data,
      };

    case actionType.LEADERSHIP_ID:
      return {
        ...state,
        leadershipId: action.data,
      };

    case actionType.LEADERSHIP_CATE:
      return {
        ...state,
        leadershipCate: action.data,
      };
    case actionType.LEADERSHIP_CATE_NAME:
      return {
        ...state,
        leadershipCateName: action.data,
      };
    case actionType.SELECTED_ROLES:
      return {
        ...state,
        selectedRoles: action.data,
      };
    case actionType.ROLE_BY_LEADERSHIP_ID:
      return {
        ...state,
        roleList: action.data,
      };
    case actionType.MASTER_QUESTION_SEARCH:
      return {
        ...state,
        masterQuestionSearch: action.data,
      };
    case actionType.MASTER_FILTER_QUESTION:
      return {
        ...state,
        masterFilterQuestion: action.data,
      };
    case actionType.MASTER_SEARCH_APPLY:
      return {
        ...state,
        masterSearchApply: action.data,
      };
    case actionType.SELECTED_MASTER_QUESTION:
      return {
        ...state,
        selectedMasterQuestion: action.data,
      };
    case actionType.CLIENT_PROJECT_ACTIVE_TAB:
      return {
        ...state,
        clientProjectActiveTab: action.data,
      };
    case actionType.MASTER_SUMMARY_SEARCH:
      return {
        ...state,
        masterSummarySearch: action.data,
      };
    case actionType.GENERAL_QUESTION:
      return {
        ...state,
        generalQuestion: action.data,
      };
    case actionType.LEADERSHIP_QUESTION:
      return {
        ...state,
        leadershipQuestion: action.data,
      };
    case actionType.ROLE_QUESTION:
      return {
        ...state,
        roleQuestion: action.data,
      };
    case actionType.TEMPLATE_ID:
      return {
        ...state,
        templateId: action.data,
      };
    case actionType.PID:
      return {
        ...state,
        pId: action.data,
      };
    case actionType.SAVED_QUESTIONS:
      return {
        ...state,
        savedQuestions: action.data,
      };
    case actionType.QUESTIONNAIRE_STATE:
      return {
        ...state,
        questionnaireState: action.data,
      };
    case actionType.ADD_NEW_QUESTIONS_FLAG:
      return {
        ...state,
        addNewQuestionsFlag: action.data,
      };
    case actionType.PROJECT_ID:
      return {
        ...state,
        projectId: action.data,
      };
    case actionType.CLIENT_ID:
      return {
        ...state,
        clientId: action.data,
      };
    case actionType.USER_ID:
      return {
        ...state,
        userId: action.data,
      };
    case actionType.USER_DATA:
      return {
        ...state,
        userData: action.data,
      };
    case actionType.JWT:
      return {
        ...state,
        jwt: action.data,
      };
    case actionType.TEMPLATE_STATUS:
      return {
        ...state,
        templateStatus: action.data,
      };
    case actionType.USER_TYPE:
      return {
        ...state,
        userType: action.data,
      };
    case actionType.REDIRECT_FROM:
      return {
        ...state,
        redirectFrom: action.data,
      };
    case actionType.QUESTIONNAIRE_EVENT:
      return {
        ...state,
        questionnaireEvent: action.data,
      };
    case actionType.TEMPLATE_NAME:
      return {
        ...state,
        templateName: action.data,
      };
    case actionType.MASTER_QUESTIONNAIRE_EVENT:
      return {
        ...state,
        masterQuestionnaireEvent: action.data,
      };
    case actionType.EDIT_QUESTION_LIST:
      return {
        ...state,
        editQuestionList: action.data,
      };
    case actionType.PROJECT_NAME:
      return {
        ...state,
        projectName: action.data,
      };
    case actionType.USER_ROLE:
      return {
        ...state,
        userRole: action.data,
      };
    case actionType.URL_PROJECT_ID:
      return {
        ...state,
        urlProjectId: action.data,
      };
    case actionType.URL_CLIENT_ID:
      return {
        ...state,
        urlClientId: action.data,
      };
    case actionType.URL_USER_ID:
      return {
        ...state,
        urlUserId: action.data,
      };
    case actionType.PROGRAM_NAME:
      return {
        ...state,
        programName: action.data,
      };
    default:
      return state;
  }
}
