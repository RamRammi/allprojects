import { combineReducers } from "redux";
import questionnaireReducer from "./questionnaireReducer.js";
export default combineReducers({
  questionnaireReducer,
});
