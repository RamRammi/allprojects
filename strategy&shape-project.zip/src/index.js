import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter as Router, HashRouter } from "react-router-dom";
import App from "./App";
import { Provider } from "react-redux";
import store from "./redux/store";
import { ReactKeycloakProvider } from "@react-keycloak/web";
import keycloak from "./keycloak";
const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <Provider store={store}>
    <ReactKeycloakProvider
      authClient={keycloak}
      initOptions={{
        onLoad: "login-required",
        // onLoad: "check-sso",
      }}
    >
      <Router>
        <App />
      </Router>
    </ReactKeycloakProvider>
  </Provider>
);
