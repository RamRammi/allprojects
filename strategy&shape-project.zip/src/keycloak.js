import Keycloak from "keycloak-js";
const { NODE_ENV, REACT_APP_SHAPE_URL, REACT_APP_DAN_URL } = process.env;
const REACT_APP_DAN_URL_PROD =
  "https://dan-platformapps-prod-be01.azurewebsites.net/User/GetUserDetailById?";
const REACT_APP_SHAPE_URL_PROD =
  "https://dan-shapeapps-prod-be01.azurewebsites.net/api";

const REACT_APP_DAN_URL_UAT =
  "https://dan-platformapps-uat-be01.azurewebsites.net/User/GetUserDetailById?";
const REACT_APP_SHAPE_URL_UAT =
  "https://dan-shapeapps-uat-be01.azurewebsites.net/api";

const REACT_APP_DAN_URL_DEV =
  "https://dan-apps-dev-be01.azurewebsites.net/User/GetUserDetailById?";
const REACT_APP_SHAPE_URL_DEV =
  "https://shape-apps-dev-be01.azurewebsites.net/api";

const LOCAL_CONFIG = {
  realm: "DAN",
  url: "https://ssolab.capgsolution.com:8443/auth/",
  clientId: "DAN-local-app",
};
const UAT_CONFIG = {
  realm: "DAN_UAT",
  url: "https://ssolab.capgsolution.com:8443/auth/",
  clientId: "DAN-UAT-APP",
};

const DEV_CONFIG = {
  realm: "DAN",
  url: "https://ssolab.capgsolution.com:8443/auth/",
  clientId: "DAN-APP-DEV",
};
const PROD_CONFIG = {
  realm: "DAN_PROD",
  url: "https://ssolab.capgsolution.com:8443/auth/",
  clientId: "DAN-APP-PROD",
};

const isDev =
  REACT_APP_DAN_URL === REACT_APP_DAN_URL_DEV &&
  REACT_APP_SHAPE_URL === REACT_APP_SHAPE_URL_DEV;

const isUat =
  REACT_APP_DAN_URL === REACT_APP_DAN_URL_UAT &&
  REACT_APP_SHAPE_URL === REACT_APP_SHAPE_URL_UAT;

const isProd =
  REACT_APP_DAN_URL === REACT_APP_DAN_URL_PROD &&
  REACT_APP_SHAPE_URL === REACT_APP_SHAPE_URL_PROD;

let configOptions = LOCAL_CONFIG;

if (isDev) {
  configOptions = DEV_CONFIG;
} else if (isUat) {
  configOptions = UAT_CONFIG;
} else if (isProd) {
  configOptions = PROD_CONFIG;
}

const keycloak = new Keycloak(configOptions);
keycloak.onTokenExpired = () => keycloak.updateToken();
export default keycloak;
