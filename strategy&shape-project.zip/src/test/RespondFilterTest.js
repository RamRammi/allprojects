import React from "react";
import { useState } from "react";
import { useTheme } from '@mui/material/styles';
import "./RespondFilter.css"
import OutlinedInput from '@mui/material/OutlinedInput';
import { Button, DialogActions, TextField, Typography } from "@mui/material";
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import InputLabel from "@mui/material/InputLabel";
import maskImage from "../../Images/MaskImage.png"
import { Dialog,DialogTitle,DialogContent,DialogueContentText,DialogueActions } from "@material-ui/core";

const ITEM_HEIGHT = 38;
const ITEM_PADDING_TOP = 8; 
const MenuProps = {
    style: {
      minHeight:"40px",
      width: 200,
    },

};

function getStyles(name, personName, theme) {
  return {
    fontWeight:
      personName.indexOf(name) === -1
        ? theme.typography.fontWeightRegular
        : theme.typography.fontWeightMedium,
  };
}

export default function RespondFilterData(props) {
  const theme = useTheme();
  const [personName, setPersonName] = React.useState([]);
  const [open,setOpen]=useState(false);

  const handleChange = (event) => {
    const {
      target: { value },
    } = event;
    setPersonName(
      // On autofill we get a stringified value.
      typeof value === 'string' ? value.split(',') : value,
    );
  };
  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  return (
    //main div
    <div>
        {/*div for header */}
        <div style={{display:"flex",justifyContent:"space-between",margin:"10px"}}>
            <div style={{marginLeft:"40px"}} >
            <p style={{float:"left",fontFamily:"Ubuntu",fontWeight:"500",fontSize:"18px",paddingTop:"10px"}}>CXO - Questionnaire</p>
            </div>
            <div style={{display:"flex",marginRight:"40px"}} >
                <Button style={{fontFamily:"Ubuntu",fontSize:"12px",backgroundColor:"white",margin:" 10px",color:"#0070AD",borderRadius:"25px",padding:"5px 10px",border:"1px solid #0070AD",textTransform:"capitalize"}} >Notes</Button>

                <Button onClick={handleClickOpen} style={{fontFamily:"Ubuntu",fontSize:"12px",backgroundColor:"#0070AD",color:"white",margin:" 10px",borderRadius:"25px",padding:"5px 10px",border:"1px solid #0070AD",textTransform:"capitalize"}}>Export Questionnaire </Button>
                <Dialog open={open} onClose={handleClose} style={{minWidth:"800px"}}>
        <DialogTitle>Send to</DialogTitle>
        <DialogContent>
         
            
          <div>
              <FormControl sx={{ m: 1, width: '40ch' }} variant="outlined">
              <Typography style={{fontSize:"12px",fontFamily:"Ubuntu"}}>Specify a Filename</Typography>
                <OutlinedInput
                  id="outlined-adornment-weight"
                  name="firstName"
                  placeholder="Text"
                  // value={values.weight}
                  // onChange={handleChange('weight')}
                />
              </FormControl>
              <FormControl sx={{ m: 1, width: '40ch' }} variant="outlined">
              <Typography style={{fontSize:"12px",fontFamily:"Ubuntu"}}>Select a Filetype</Typography>
                <OutlinedInput
                  id="outlined-adornment-weight"
                  name="lastName"
                  placeholder="PDF(*.pdf)"
                  // value={values.weight}
                  // onChange={handleChange('weight')}
                />
              </FormControl>
              <FormControl sx={{ m: 1, width: '40ch' }} variant="outlined">
              <Typography style={{fontSize:"12px",fontFamily:"Ubuntu"}}>Choose a Location</Typography>
                <OutlinedInput
                  id="outlined-adornment-weight"
                  name="emailId"
                  placeholder="Browser"
                  // value={values.weight}
                  // onChange={handleChange('weight')}
                />
              </FormControl>
              
              </div>

        <div >
          
        </div>

          {/* <MultipleInputSelect getProjectName={getProjectName} /> */}
          <div>
          <DialogActions>
            <Button
              style={{ padding: "0px 12px", textTransform: "capitalize" }}
              variant="outlined"
              onClick={handleClose}
            >
              Cancel
            </Button>
            <Button
              onClick={handleClose}
              style={{
                textTransform: "capitalize",
                padding: "0px 12px",
                backgroundColor: "#0070AD",
                color: "#fff",
                textTransform: "capitalize",
              }}
              variant="outlined"
            >
              Done
            </Button>
          </DialogActions>
          </div>
        </DialogContent>
      </Dialog>

            </div>
        </div>
        {/* div for header end */}
        <div style={{paddingLeft:"40px",backgroundColor:"#F8F8F8",height:"102px",paddingTop:"20px"}}>
        <FormControl sx={{ m: 1, width: 300, mt: 3 }}>
        <Typography className="Rightbar_input_drop_typ">
              <span className="required">*</span>Interviewee
            </Typography>
            <TextField id="outlined-basic" />
          <span style={{ color: "red" }}>{props.designationMessage}</span>
        </FormControl>
        <FormControl sx={{ m: 1, width: 300, mt: 3 }}>
        <Typography className="Rightbar_input_drop_typ">
              <span className="required">*</span>Interviewer
            </Typography>
            <TextField id="outlined-basic" />
          <span style={{ color: "red" }}>{props.designationMessage}</span>
        </FormControl>

        
        <FormControl sx={{ m: 1, width: 300, mt: 3 }}>
        <Typography className="Rightbar_input_drop_typ">
              <span className="required">*</span>Function
            </Typography>
          <Select
          outlined-basic
            displayEmpty
            // value={designations}
            // onChange={handleChangeDesignation}
            // input={<OutlinedInput />}
            // renderValue={(selected) => {
            //   if (selected.length === 0) {
            //     return <em> Select a Designation </em>;
            //   }
            //   return selected.designationName;
            // }}
            MenuProps={MenuProps}
            inputProps={{ "aria-label": "Without label" }}
          >
              <MenuItem style={{fontSize:"15px"}}>Placeholder</MenuItem>
            <MenuItem style={{fontSize:"15px"}}>Industry</MenuItem>
            <MenuItem style={{fontSize:"10px"}}>Banking</MenuItem>
            {/* {designationName.map((obj) => (
              <MenuItem
                key={obj.designationId}
                value={obj}
                style={getStyles(obj.designationName, designationName, theme)}
              >
                {obj.designationName}
              </MenuItem>
            ))} */}
          </Select>
          <span style={{ color: "red" }}>{props.designationMessage}</span>
        </FormControl>

        
        <FormControl sx={{ m: 1, width: 300, mt: 3 }}>
        <Typography className="Rightbar_input_drop_typ">
              <span className="required">*</span>Desigination
            </Typography>
          <Select
            displayEmpty
            // value={designations}
            // onChange={handleChangeDesignation}
            input={<OutlinedInput />}
            // renderValue={(selected) => {
            //   if (selected.length === 0) {
            //     return <em> Select a Designation </em>;
            //   }
            //   return selected.designationName;
            // }}
            MenuProps={MenuProps}
            inputProps={{ "aria-label": "Without label" }}
          >
            <MenuItem disabled value="">
              <em>Placeholder</em>
            </MenuItem>
            {/* {designationName.map((obj) => (
              <MenuItem
                key={obj.designationId}
                value={obj}
                style={getStyles(obj.designationName, designationName, theme)}
              >
                {obj.designationName}
              </MenuItem>
            ))} */}
          </Select>
          <span style={{ color: "red" }}>{props.designationMessage}</span>
        </FormControl>

        
        <FormControl sx={{ m: 1, width: 300, mt: 3 }}>
        <Typography className="Rightbar_input_drop_typ">
              <span className="required">*</span>Category
            </Typography>
         
          <Select
            displayEmpty
            // value={designations}
            // onChange={handleChangeDesignation}
            input={<OutlinedInput />}
            // renderValue={(selected) => {
            //   if (selected.length === 0) {
            //     return <em> Select a Designation </em>;
            //   }
            //   return selected.designationName;
            // }}
            MenuProps={MenuProps}
            inputProps={{ "aria-label": "Without label" }}
          >
            <MenuItem disabled value="">
              <em>Placeholder</em>
            </MenuItem>
            {/* {designationName.map((obj) => (
              <MenuItem
                key={obj.designationId}
                value={obj}
                style={getStyles(obj.designationName, designationName, theme)}
              >
                {obj.designationName}
              </MenuItem>
            ))} */}
          </Select>
          <span style={{ color: "red" }}>{props.designationMessage}</span>
        </FormControl>

        </div>
        {/* //input boxes end */}


        <div style={{display:"flex",justifyContent:"space-between",borderBottom:"1px solid #E0E0E0"}}>
          <div>
            <label style={{fontFamily:"Ubuntu",paddingLeft:"15px",margin:"25px 10px 20px 20px",fontSize:"14px",display:"block",float:"left"}}>al</label>
            <FormControl sx={{ m: 1, width: 150, mt: 3,height:"30px",marginLeft:"10px",marginBottom:"10px" }}>
                            
                            <Select
                                displayEmpty
                                // value={designations}
                                // onChange={handleChangeDesignation}
                                input={<OutlinedInput />}
                                // renderValue={(selected) => {
                                //   if (selected.length === 0) {
                                //     return <em> Select a Designation </em>;
                                //   }
                                //   return selected.designationName;
                                // }}
                                MenuProps={MenuProps}
                                inputProps={{ "aria-label": "Without label" }}
                            >
                                <MenuItem disabled value="">
                                <em>Placeholder</em>
                                </MenuItem>
                                {/* {designationName.map((obj) => (
                                <MenuItem
                                    key={obj.designationId}
                                    value={obj}
                                    style={getStyles(obj.designationName, designationName, theme)}
                                >
                                    {obj.designationName}
                                </MenuItem>
                                ))} */}
                            </Select>
                        </FormControl>

            
          </div>
          <div style={{marginRight:"40px"}}>
          <Button style={{border:"1px solid #0070AD",backgroundColor:"#0070AD",color:"white",padding:"5px 10px",margin:"20px",fontSize:"13px",borderRadius:"25px",fontSize:"12px",textTransform:"capitalize"}} >Interview Synopsis</Button>

          </div>
        </div>
         
    </div>
  );
}
