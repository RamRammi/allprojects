import { createContext } from "react";
export const ResponseContext = createContext();
