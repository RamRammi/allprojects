export const ERROR_MESSAGE = "SOMETHING WRONG";
export const ERROR_MSG = "SOMETHING WRONG";
export const BASE_URL = process.env.REACT_APP_SHAPE_URL;
export const LOGIN_URL = process.env.REACT_APP_DAN_URL;
export const BASE_DAN_BE_URL = process.env.REACT_APP_DAN_BE_URL;
export const GET_FUNCTION_LIST = "/common/getfunctionlist";
export const GET_DESIGNATION_LIST = "/common/getdesignationlist";
export const GET_CATEGORY_LIST = "/common/GetCategoryList";
//export const GET_QUESTION_LIST = "/MasterQuestions/GetMasterQuestions";
export const GET_Value_Driver_List = "/common/getvaluedriverlist";
export const GET_QUESTION_LIST_SEARCH =
  "/MasterQuestions/GetMasterQuestionsFilterSearch";
export const ADD_QUESTIONNIRE_TEMPLATE = "/Project/SaveClientQuestion";
export const GET_PROJECT_DOCUMENT_LIST = "/Project/GetProjectTemplate";
//export const SEND_DATA_LIST = "/Questionnaire/sendQuestionnaireTemplateClient";
export const SEND_DATA_LIST =
  "/Questionnaire/sendQuestionnaireTemplateConsultant";
export const GET_QUESTIONNAIRE_DATA_BY_TEMPLATEID =
  "/Project/GetProjectQuestionnaireDetailsById";
export const GET_LEADERSHIP_CATEGORY_LIST = "/Common/GetLeaderShipCategories";
export const GET_ROLE = "/Common/GetRolesByLeaderShipId";

export const SAVE_RESPONSE_BY_CONSULTANT =
  "/Project/SaveClientQuestionResponseByConsultant";
export const SAVE_RESPONSE_BY_CLIENT =
  "/Project/SaveClientQuestionResponseByClient";
export const SUBMIT_RESPONSE_BY_CONSULTANT =
  "/Project/SubmitClientQuestionResponseByConsultant";
export const SUBMIT_RESPONSE_BY_CLIENT =
  "/Project/SubmitQuestionResponseByClient";
export const GET_QUESTIONNAIRE_DATA_WITH_RESPONSE =
  "/Project/GetClientQuestionListWithResponseTemplete";

export const GET_QUESTION_LIST = "/MasterQuestions/GetMasterQuestionsList";
export const GET_Client_GetTasksAssigned = "/Client/GetTasksAssigned";
export const GET_MASTER_SUMMARY_QUESTIONNAIRE =
  "/Questionnaire/GetSynopsisList";
export const GET_Consultant_GetTaskSummary =
  "/Questionnaire/ConsultantTasksummary";

// export const GET_Consultant_DownloadQuestionList = "/Questionnaire/downloadConsultantTaskSummary?templateId=33&fileName=ds&fileType=excel&filePath=";
export const DOWNLOAD_TASK_SUMMARY_DOCUMENT =
  "/Questionnaire/downloadConsultantTaskSummary";
export const GET_CONSULTANT_NOTIFICATION =
  "/Project/GetConsultantNotifications";
//Client DownloadQuestionList
export const GET_Client_DownloadQuestionList = "/Client/DownloadQuestionList";
//taskassigned Serach
// export const GET_CLIENT_TASKASSIGNED_SEARCH ="/Client/SearchClientTaskAssigned";
export const GET_SEARCH_LIST = "/Client/SearchClientTaskAssigned";
//Client_ExportQuestionnaire
export const GET_Client_ExportQuestionnaire = "/Client/ExportQuestionnaire";
//Client_QuestionnaireTemplatebyId
export const GET_Client_QuestionnaireTemplatebyId =
  "/Client/QuestionnaireTemplatebyId";
export const GET_CLIENT_NOTIFICATION = "/Project/GetClientNotifications";
export const GET_CLIENT_EXPORTQUESTIONNARIE = "/Client/ExportQuestionnaire";
export const GET_CLIENT_RESPONSE = "/Client/QuestionnaireTemplatebyId";
export const GET_CLIENT_RESPONSE_BY_TASKSUMMARY =
  "/Questionnaire/GetConsultantQuestionResponseByTemplateId";
export const SAVE_COMPLETED_QUESTIONNAIRE =
  "/Questionnaire/SaveCompltedQuestionnaire";
export const GET_QUESTION_GALLERY = "/Questionnaire/GetQuesGalaryList";
export const EXPORT_MASTER_SUMMARY = "/Questionnaire/ExportAllSynopsis";
export const VIEW_QUESTIONNAIRE = "/Questionnaire/GetViewQuestionnaireList";
export const DOWNLOAD_LIST = "/Questionnaire/DownloadSingleSynopsis";
export const MASTER_SEARCH = "/Questionnaire/GetSynopsisList";
export const QUESTION_GALLERY_SEARCH = "/Questionnaire/GetQuesGalaryList";
export const EXPORT_QUSETIONNAIRE_SET = "/Questionnaire/GetExportQuestionsSet";
export const EXPORT_PROJECT_SET = "/Questionnaire/GetExportProjectDoc";
export const GET_CONSULTANT_EXPORTQUESTIONNAIRE =
  "/Questionnaire/ExportConsultantQuestionResponseByTempId";

//Constant Data
export const QUESTION_CATEGORY = [
  { id: 2, name: "Leadership Type General" },
  { id: 3, name: "Role Specific" },
  { id: 4, name: "General" },
];

// Industry Id for VDT only
export const IndustryId="5f41d090-881a-11ed-b645-856466d0e2fb";

//Project API
export const PROJECT_RENAME = "/Project/RenameProjectTemplate";
//Project Delete API
export const PROJECT_DELETE = "/Project/DeleteProjectTemplate";

//Client Assigned Questionnaires
export const CLIENT_TASK_ASSIGNED_QUESTIONNAIRES =
  "/Client/SearchClientTaskAssigned";
//client completed Questionnaires

export const CLIENT_COMPLETED_QUESTIONNAIRES =
  "/Client/SearchClientTaskAssigned";

export const GET_LEADERSHIP_CATEGORY_BY_ROLE_ID =
  "/Common/GetLeadershipCategoryByRoleId";

export const SAVE_TEMPLATE_CLONE = "/Project/SaveAsCloneProject";

export const PAIN_POINT = "/PainPoint/GetMasterPainPoints";
export const IMPROVEMENT_OPPURTUNITY =
  "/PainPoint/GetMasterImprovementOpportunities";
export const SAVE_PAINPOINT = "/PainPoint/SaveWorkShop";
export const WORKSHOP_LIST = "/PainPoint/GetPHWorkShopName";
export const L1_PPROCESS_LIST = "/PainPoint/GetPHMastertL1List";
export const L2_PPROCESS_LIST = "/PainPoint/GetPHMastertL2List";
export const L3_PPROCESS_LIST = "/PainPoint/GetPHMastertL3List";
export const PROCESS_SOURCE_LIST =
  "/ProcessHierarchy/GetAllSourcesByClientId?clientId=";
export const PROCESS_HIERARCHY_SAVE = "/ProcessHierarchy/SaveUpdateClientPH";
export const PROCESS_HIERARCHY_TREE =
  "/ProcessHierarchy/ExportFullClientPHTreeJsonNExcel?ProcessId=";
export const PROCESS_HIERARCHY_TREE_MASTER =
  "/ProcessHierarchy/ExportFullMasterPHTreeJsonNExcel?ProcessId=";
export const PROCESS_HIERARCHY_INDUSTRY =
  "/ProcessHierarchy/GetMasterProcessByProjectNSource?";
export const DELETE_WORKSHOPBYID = "/PainPoint/DeleteWorkshopById";
export const PROCESS_HIERARCHY_IMPORT_SAVE_PROCESS =
  "/ProcessHierarchy/ImportPHMasterToClientMapping";
export const PROCESS_HIERARCHY_PROCESS_FIRSTLEVEL =
  "/ProcessHierarchy/Export2LevelClientPHTreeJsonNExcel?ProjectId=";
export const PH_CLIENT_EXPORT =
  "/ProcessHierarchy/ExportFullClientPHTreeJsonNExcel?ProcessId=";
export const HOME_PH_CLIENT_EXPORT =
  "/ProcessHierarchy/Export2LevelClientPHTreeJsonNExcel?ProjectId=";
export const PROCESS_DELETE = "/ProcessHierarchy/DeleteSelectedPHClient";

export const VDT_IMPACT_AREA = "/ValueDriver/GetImpactAreasList";
export const VDT_CLIENT_IMPACT_AREAS =
  "/ValueDriver/ClientImpactAreasListByProject";
export const VDT_CLIENT_IMPORTED_LISTING =
  "/ValueDriver/GetClientImpactAreasList";
export const VDT_TREE_DATA = "/ValueDriver/GetAllLevelsList";
export const VDT_CLIENT_TREE_DATA = "/ValueDriver/GetClientLevelsList";
export const VDT_TREE_SAVE_DATA = "/ValueDriver/savevaluedrivers";
export const VDT_CLIENT_IMPORT_SAVE = "/ValueDriver/saveImportedValueDrivers";
export const VDT_EXPORT_EXCEL = "/ValueDriver/ExportMasterValueDrivers";
export const VDT_CLIENT_EXPORT_EXCEL="/ValueDriver/ExportClientValueDrivers"

export const PAIN_POINT_FILTER_DATA = "/PainPoint/GetClientWorkshopSummary";
export const DOWNLOAD_WORKSHOP_BY_ID =
  "/PainPoint/ExportClientWorkShopDetailById";
export const VIEW_PAINPOINT = "/PainPoint/GetWorkShopDetailById?workshopId=";
export const UPDATE_PAINPOINT = "/PainPoint/UpdateWorkShop";
export const EXPORT_ALL_WORKSHOP="/PainPoint/ExportAllWorkShopDetailsForProject"
