export const dateFormat = (d) => {
  let date = new Date(d);
  return (
    date.getDate() + "/" + (date.getMonth() + 1) + "/" + date.getFullYear()
  );
};
export const dateFormatchange = (d) => {
  let date = new Date(d);
  return date.getMonth() + 1 + "/" + date.getDate() + "/" + date.getFullYear();
};
export const getPersonNamesFromArr = (str) => {
  if (typeof str === "string") {
    const stringCheck = str.includes(",");
    if (stringCheck) {
      let arr = str.split(",");
      let name = [];
      arr.map((value, index) => {
        let firstname = value.split("@");
        name.push(firstname[0].replace(".", " "));
      });

      if (name.length > 1) {
        return name[0] + ", " + "+" + (name.length - 1);
      } else {
        return name;
      }
    } else {
      if (typeof str === "string") {
        if (str !== "" && str !== undefined && str !== null) {
          let name = "";
          let firstname = str.split("@");
          name = firstname[0].replace(".", " ");
          return name;
        } else {
          return "";
        }
      }
    }
  }
};

export const getPersonNameByEmail = (id) => {
  if (id !== "" && id !== undefined && id !== null) {
    let name = "";
    let firstname = id.split("@");
    name = firstname[0].replace(".", " ");
    return name;
  } else {
    return "";
  }
};
