import axios from "axios";
import { BASE_URL } from "./constant.js";

const fetchToken = () => {
  const jwt = localStorage.getItem("jwt");
  return jwt;
};

export function loginHeaders() {
  const myHeads = new Headers();
  myHeads.append("Authorization", `Bearer ${fetchToken()}`);
  myHeads.append("Content-Type", `application/json`);
  return myHeads;
}

export async function fetchLoginDetails(endPointUrl, payload) {
  try {
    const resp = await fetch(endPointUrl, {
      method: "GET",
      headers: loginHeaders(),
      body: payload ? JSON.stringify(payload) : undefined,
    });
    if (resp.status === 200) {
      const data = await resp.json();
      return data;
    } else {
      return {
        statusCode: resp.status,
        errorMsg:
          resp.status === 451 ? "Access not allowed" : "Something went wrong",
      };
    }
  } catch (error) {
    console.log(error);
    // throw error;
  }
}

// call function list api
export const getFunctionList = (URL) => {
  return axios(BASE_URL + URL, {
    method: "GET",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    //   data: payload,
  })
    .then((response) => response.data)

    .catch((error) => {
      throw error;
    });
};

// call project document list api
export const getProjectDocumentList = (URL, payload) => {
  return axios(BASE_URL + URL, {
    method: "POST",
    headers: {
      "content-Type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    data: payload,
  })
    .then((response) => response.data)

    .catch((error) => {
      throw error;
    });
};

// call question list api
export const getQuestionList = (URL) => {
  return axios(BASE_URL + URL, {
    method: "GET",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    //  data: payload,
  })
    .then((response) => response.data)

    .catch((error) => {
      throw error;
    });
};
// call save Questionnaire template
export const saveQuestionnaireTemplate = (URL, payload) => {
  return axios(BASE_URL + URL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    data: payload,
  })
    .then((response) => response.data)

    .catch((error) => {
      return error.response.data;
      //throw error;
    });
};
export const DeleteWorkshopById = (URL, payload) => {
  return axios(BASE_URL + URL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    data: payload,
  })
    .then((response) => response.data)

    .catch((error) => {
      return error.response.data;
      //throw error;
    });
};
export const sendQuestionnaireTemplate = (URL, payload) => {
  return axios(BASE_URL + URL, {
    method: "POST",

    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },

    data: payload,
  })
    .then((response) => response.data)

    .catch((error) => {
      throw error;
    });
};
export const getQuestionnaireData = (URL) => {
  return axios(BASE_URL + URL, {
    method: "GET",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
  })
    .then((response) => {
      let data = {
        templateName:
          response.data.questionnaireTemplateDateials[0].templatename,
        templateId: response.data.questionnaireTemplateDateials[0].templateId,
        projectId: response.data.questionnaireTemplateDateials[0].projectId,
        //new
        interviewee:
          response.data.questionnaireTemplateDateials[0].projectInterviewee,
        interviewer:
          response.data.questionnaireTemplateDateials[0].projectInterviewer,
        jobTitle: response.data.questionnaireTemplateDateials[0].jobTitle,
        projectCreateDate:
          response.data.questionnaireTemplateDateials[0].projectCreateDate,
        isOwner: response.data.isOwner,
        leaderShipCategoryId:
          response.data.questionnaireTemplateDateials[0].leaderShipCategoryId,
        selectedQuestions: [],
      };
      response.data.questionnaireTemplateDateials.map((value) => {
        data.selectedQuestions.push({
          questionDesc: value.cQuestionDesc,
          type: value.cQuestionType,
          categoryId: value.categoryId,
          roleId: value.roleId,
          leaderShipCategoryId: value.leadershipCategoryId,
          cQuestionId: value.cQuestionId,
          multipleChoiceQuestionOptionList:
            value.multipleChoiceQuestionOptionList !== null
              ? value.multipleChoiceQuestionOptionList
              : [],
        });
      });
      return data;
    })
    .catch((error) => {
      throw error;
    });
};
// call Leadership category list api
export const getLeadershipCategoryList = (URL) => {
  return axios(BASE_URL + URL, {
    method: "GET",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    //   data: payload,
  })
    .then((response) => response.data)
    .catch((error) => {
      throw error;
    });
};
// call role list api
export const getRoleList = (URL) => {
  return axios(BASE_URL + URL, {
    method: "GET",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    //   data: payload,
  })
    .then((response) => response.data)
    .catch((error) => {
      throw error;
    });
};
// call download Api
export const getClientDownloadQuestionList = (URL) => {
  return axios(BASE_URL + URL, {
    method: "GET",
    responseType: "blob",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    //  data:
    // payload,
  })
    .then((response) => response.data)

    .catch((error) => {
      throw error;
    });
};
export const getTasksAssigned = (URL) => {
  return axios(BASE_URL + URL, {
    method: "GET",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    //  data:
    // payload,
  })
    .then((response) => response.data)

    .catch((error) => {
      throw error;
    });
};
//Master Summary Accordion API
export const getMasterSummaryQuestionnaire = (URL, payload) => {
  return axios(BASE_URL + URL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    data: payload,
  })
    .then((response) => response.data)

    .catch((error) => {
      throw error;
    });
};

//get questions for Respond page
export const getRespondQuestionList = (URL) => {
  return axios(BASE_URL + URL, {
    method: "GET",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    //   data: payload,
  })
    .then((response) => response.data)

    .catch((error) => {
      throw error;
    });
};
// call save response from consultant
export const saveResponseData = (URL, payload) => {
  return axios(BASE_URL + URL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    data: payload,
  })
    .then((response) => response.data)

    .catch((error) => {
      return error.response.data;
      //throw error;
    });
};
// call submit response from consultant
export const submitResponseData = (URL, payload) => {
  return axios(BASE_URL + URL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    data: payload,
  })
    .then((response) => response.data)

    .catch((error) => {
      return error.response.data;
      //throw error;
    });
};
// call download Api
// export const getClientDownloadQuestionList = (URL) => {
//   return axios(BASE_URL + URL, {
//     method: "GET",
//     responseType: "blob",
//     headers: {
//       "content-type": "application/json",
//     },
//     //  data:
//     // payload,
//   })
//     .then((response) => response.data)

//     .catch((error) => {
//       throw error;
//     });
// };

// TaskAssigned Table Data
// export const getTasksAssigned = (URL) => {
//   return axios(BASE_URL + URL, {
//     method: "GET",
//     headers: {
//       "content-type": "application/json",
//     },
//     //  data:
//     // payload,
//   })
//     .then((response) => response.data)

//     .catch((error) => {
//       throw error;
//     });
// };

//Master Summary Accordion API
export const getTaskSummaryDownload = (URL) => {
  return axios(BASE_URL + URL, {
    method: "GET",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    //  data:
    // payload,
  })
    .then((response) => response.data)

    .catch((error) => {
      throw error;
    });
};

export const getTasksSummary = (URL) => {
  return axios(BASE_URL + URL, {
    method: "GET",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    //  data:
    // payload,
  })
    .then((response) => response.data)

    .catch((error) => {
      throw error;
    });
};
//Master Summary Accordion API

// export const getMasterSummaryQuestionnaire = (URL) => {
//   return axios(BASE_URL + URL, {
//     method: "GET",
//     headers: {
//       "content-type": "application/json",
//     },
//     //   data: payload,
//   })
//     .then((response) => response.data)

//     .catch((error) => {
//       throw error;
//     });
// };

// GetConsultantNotificationsy api
export const GetConsultantNotification = (URL) => {
  return axios(BASE_URL + URL, {
    method: "GET",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    //   data: payload,
  })
    .then((response) => response.data)

    .catch((error) => {
      throw error;
    });
};

export const getSearchList = (URL, payload) => {
  return axios(BASE_URL + URL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    data: payload,
  })
    .then((response) => response.data)

    .catch((error) => {
      // throw error;
      return error.response.data;
    });
};
//Question Gallery API

export const getQuestionGallery = (URL) => {
  return axios(BASE_URL + URL, {
    method: "GET",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    //   data: payload,
  })
    .then((response) => response.data)

    .catch((error) => {
      throw error;
    });
};

//EXPORT ALL MASTER SUMMARY

export const exportMasterSummary = (URL) => {
  return axios(BASE_URL + URL, {
    method: "GET",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    //   data: payload,
  })
    .then((response) => response.data)

    .catch((error) => {
      throw error;
    });
};

//VIEW QUESTIONNAIRE
export const getQuestionnaireList = (URL) => {
  return axios(BASE_URL + URL, {
    method: "GET",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    //   data: payload,
  })
    .then((response) => response.data)

    .catch((error) => {
      throw error;
    });
};

//Download

export const downloadAllSynopsis = (URL, payload) => {
  return axios(BASE_URL + URL, {
    method: "POST",
    // responseType: "blob",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    data: payload,
  })
    .then((response) => response.data)

    .catch((error) => {
      throw error;
    });
};

//SaveCompltedQuestionnaire

export const SaveCompltedQuestionnaire = (URL, payload) => {
  return axios(URL, {
    method: "POST",
    // responseType: "blob",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    data: payload,
  })
    .then((response) => response.data)

    .catch((error) => {
      return error.response.data;
    });
};

//Gallery Search
export const GallerySearch = (URL) => {
  return axios(BASE_URL + URL, {
    method: "GET",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    //   data: payload,
  })
    .then((response) => response.data)

    .catch((error) => {
      throw error;
    });
};

//Master summary Search
export const master_Summary_search = (URL, payload) => {
  return axios(BASE_URL + URL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    data: payload,
  })
    .then((response) => response.data)

    .catch((error) => {
      throw error;
    });
};

//Project Rename API
export const ProjectRename = (URL, payload) => {
  return axios(BASE_URL + URL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    data: payload,
  })
    .then((response) => response.data)

    .catch((error) => {
      return error.response.data;
      //throw error;
    });
};

//Project Delete API

export const ProjectDelete = (URL) => {
  return axios(BASE_URL + URL, {
    method: "GET",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    //   data: payload,
  })
    .then((response) => response.data)

    .catch((error) => {
      throw error;
    });
};

export const SearchClientTaskAssigned = (URL) => {
  return axios(BASE_URL + URL, {
    method: "GET",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    //   data: payload,
  })
    .then((response) => response.data)

    .catch((error) => {
      return error.response.data;
      //throw error;
    });
};

export const SearchCompletedQuestionnaires = (URL) => {
  return axios(BASE_URL + URL, {
    method: "GET",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    //   data: payload,
  })
    .then((response) => response.data)

    .catch((error) => {
      return error.response.data;
      //throw error;
    });
};

export const getLeaderShipIdByRoleId = (URL) => {
  return axios(BASE_URL + URL, {
    method: "GET",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    //   data: payload,
  })
    .then((response) => response.data)

    .catch((error) => {
      throw error;
    });
};
export const previewMasterPH = (URL) => {
  return axios(BASE_URL + URL, {
    method: "GET",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
  })
    .then((response) => response.data)
    .catch((error) => {
      throw error;
    });
};

//Project Clone API
export const projectClone = (URL, payload) => {
  return axios(BASE_URL + URL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    data: payload,
  })
    .then((response) => response.data)

    .catch((error) => {
      return error.response.data;
      //throw error;
    });
};

//VDT Get Impact Areas record api
export const getImpactAreasList = (URL) => {
  return axios(BASE_URL + URL, {
    method: "GET",
    headers: {
      "content-Type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
  })
    .then((response) => response.data)
    .catch((error) => {
      throw error;
    });
};

//Master VDT Get Tree data for selected imapct areas
export const getVDTTreeDataList = (URL) => {
  return axios(BASE_URL + URL, {
    method: "GET",
    headers: {
      "content-Type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
  })
    .then((response) => response.data)
    .catch((error) => {
      throw error;
    });
};

//Client VDT Get Tree data for selected imapct areas
export const getClientVDTTreeDataList = (URL) => {
  return axios(BASE_URL + URL, {
    method: "GET",
    headers: {
      "content-Type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
  })
    .then((response) => response.data)
    .catch((error) => {
      throw error;
    });
};

//PH Source API
export const loadSourceCheckList = async (URL) => {
  return await axios(URL, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
  })
    .then((response) => response.data)
    .catch((error) => {
      throw error;
    });
};

//PH List by Industry
export const loadChecList = async (URL) => {
  return await axios(URL, {
    method: "GET",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
  })
    .then((response) => response.data)
    .catch((error) => {
      throw error;
    });
};

// PH Save imported process
export const loadSaveProcessList = async (URL, payload) => {
  return await axios(URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    data: payload,
  })
    .then((response) => response.data)
    .catch((error) => {
      return error;
    });
};

//PH Process list till Level 2
export const loadProcessList = async (URL) => {
  return await axios(URL, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
  })
    .then((res) => res.data)
    .catch((error) => {
      return error;
    });
};

//PH Client Export excel till level 2
export const exportExcelHome = async (URL) => {
  return await axios(URL, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    responseType: "arraybuffer",
  })
    .then((res) => res.data)
    .catch((error) => {
      return error;
    });
};

//PH full Tree view
export const loadPhLevels = async (URL) => {
  return await axios(URL, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
  })
    .then((res) => res.data)
    .catch((error) => {
      return error;
    });
};

//PH Client full Tree view Export excel
export const exportExcelTree = async (URL) => {
  return await axios(URL, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    responseType: "arraybuffer",
  })
    .then((res) => res.data)
    .catch((error) => {
      return error;
    });
};

//PH preview Master page
export const PHPreviewMaster = (URL) => {
  return axios(URL, {
    method: "GET",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
  })
    .then((response) => response.data)
    .catch((error) => {
      throw error;
    });
};
// PH Delete process
export const deleteProcess = async (URL, payload) => {
  return await axios(URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    data: payload,
  })
    .then((response) => response.data)
    .catch((error) => {
      return error;
    });
};

//PH Client full Tree view Export excel
export const exportExcelTreeMaster = async (URL) => {
  return await axios(URL, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    responseType: "arraybuffer",
  })
    .then((res) => res.data)
    .catch((error) => {
      return error;
    });
};

// PH save process on client
export const saveClientPH = async (URL, payload) => {
  return await axios(URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    data: payload,
  })
    .then((response) => response.data)
    .catch((error) => {
      return error;
    });
};

// Fetching Workname for Pain points
export const getWorkshops = (URL) => {
  return axios(BASE_URL + URL, {
    method: "GET",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    //   data: payload,
  })
    .then((response) => response.data)

    .catch((error) => {
      throw error;
    });
};

// Fetching L1 Process for Pain points
export const getL1Process = (URL) => {
  return axios(BASE_URL + URL, {
    method: "GET",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    //   data: payload,
  })
    .then((response) => response.data)

    .catch((error) => {
      throw error;
    });
};
// Fetching L2 Process for Pain points
export const getL2Process = (URL) => {
  return axios(BASE_URL + URL, {
    method: "GET",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    //   data: payload,
  })
    .then((response) => response.data)

    .catch((error) => {
      throw error;
    });
};
// Fetching L3 Process for Pain points
export const getL3Process = (URL) => {
  return axios(BASE_URL + URL, {
    method: "GET",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    //   data: payload,
  })
    .then((response) => response.data)

    .catch((error) => {
      throw error;
    });
};
// Fetching Pain Point Filter data
export const getPainPointFilterData = (URL, payload) => {
  return axios(BASE_URL + URL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    data: payload,
  })
    .then((response) => response.data)

    .catch((error) => {
      throw error;
    });
};

export const Save_API_PainPoint = (URL, payload) => {
  return axios(BASE_URL + URL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    data: payload,
  })
    .then((response) => response.data)

    .catch((error) => {
      // throw error;
      return error.response.data;
    });
};
export const Update_API_PainPoint = (URL, payload) => {
  return axios(BASE_URL + URL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    data: payload,
  })
    .then((response) => response.data)

    .catch((error) => {
      // throw error;
      return error.response.data;
    });
};
// //pain point
export const getPainPoint = (URL) => {
  return axios(BASE_URL + URL, {
    method: "GET",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    //   data: payload,
  })
    .then((response) => response.data)

    .catch((error) => {
      throw error;
    });
};
//master improvement

export const GetMasterImprovementOpportunity = (URL) => {
  return axios(BASE_URL + URL, {
    method: "GET",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    //   data: payload,
  })
    .then((response) => response.data)

    .catch((error) => {
      throw error;
    });
};
//Export Workshop data by Id
export const downloadWorkshopById = async (URL) => {
  return await axios(URL, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
    responseType: "arraybuffer",
  })
    .then((res) => res.data)
    .catch((error) => {
      return error;
    });
};
export const viewpainpoint = async (URL) => {
  return await axios(BASE_URL + URL, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${fetchToken()}`,
    },
  })
    .then((res) => res.data)
    .catch((error) => {
      return error;
    });
};

//EXPORT ALL PAIN POINTS


export const Export_All_PainPoints = async (URL, payload) => {
   return await axios(BASE_URL + URL, 
    {
      method: "POST",
    headers: {
       "content-type": "application/json",
       Authorization: `Bearer ${fetchToken()}`, 
      },
        responseType: "arraybuffer",
       data: payload, 
      })
        .then((response) => response.data) .catch((error) => {
          return error.response.data;
        });
      };

