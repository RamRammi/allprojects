import React, { useState, useEffect, Suspense, useCallback } from "react"
import { useParams } from "react-router-dom"
import { useLocation } from "react-router-dom"
import "./ProcessCss.css"
import { CircularProgress, Grid, InputLabel } from "@mui/material"
import Navbar from "../../components/Navbar/Navbar"
import { Tree, getBackendOptions, MultiBackend, getDescendants } from "@minoru/react-dnd-treeview"
import { DndProvider } from "react-dnd"
import { ThemeProvider } from "@mui/material"
import { useTheme } from "@mui/material/styles"
import { CustomNode } from "../../components/ProcessHierarchyCustomNode/CustomNode"
import { CustomDragPreview } from "../../components/ProcessHierarchyCustomNode/CustomDragPreview"
import { AddDialog } from "../../components/ProcessHierarchyCustomNode/AddDialog"
import { ProcessSave } from "../../components/ProcessHierarchyCustomNode/ProcessSave"
import MenuItem from "@mui/material/MenuItem"
import FormControl from "@mui/material/FormControl"
import Select from "@mui/material/Select"
import { toPng } from "html-to-image"
import jsPDF from "jspdf"

import * as Constant from "../../comman/constant"
import * as Api from "../../comman/api"
import { BASE_DAN_BE_URL } from "../../comman/constant"
import ExportPH from "./ExportPH"
import { useSelector } from "react-redux"

const ITEM_HEIGHT = 48
const ITEM_PADDING_TOP = 8

const getLastId = (treeData) => {
  const reversedArray = [...treeData].sort((a, b) => {
    if (a.id < b.id) {
      return 1
    } else if (a.id > b.id) {
      return -1
    }
    return 0
  })
  if (reversedArray.length > 0) {
    return reversedArray[0].id
  }
  return 0
}
const ClientProcess = (props) => {
  const { id } = useParams()
  const [loading, setLoading] = useState(false)
  const [showBtn, setShowBtn] = useState(false)
  const [nodeData, setNodeData] = useState([])
  const [arrWith, setArrWith] = useState([])
  const [nodeDepth, setNodeDepth] = useState()
  const [open, setOpen] = useState(false)
  const [selectedNodes, setSelectedNodes] = useState([])
  const [openDialog, setOpenDialog] = useState(false)
  const theme = useTheme()
  const [personName, setPersonName] = useState([])
  const [textValue, setTextValue] = useState("")
  const location = useLocation()
  const [initialLevel, setInitialLevel] = useState()
  const [fileNamePDF, setFileNamePDF] = useState("")
  const [defaultOpen, setDefaultOpen] = useState()
  const [defaultTitle, setDefaultTitle] = useState()
  const [isDisplayed, setIsDisplayed] = useState(false)
  const [downloadCompleted, setdownloadCompleted] = useState(false)
  const [downloadFunction, setDownloadFunction] = useState(false)
  const [addNewNode, setAddNewNode] = useState(false)
  const [updatedNode, setUpdatedNode] = useState()
  const [saveModal, setSaveModal] = useState(false)
  const [enableDnd, setEnableDnd] = useState(false)
  const [spin, setSpin] = useState(false)

  const ref = React.createRef()
  // const ref=useRef(null)
  const pageName = "client view export"

  const handleClickOpen = () => {
    setOpenDialog(true)
  }

  //Edit text Change
  // const onTextValueChange = (event) => {
  //   const {
  //     target: { value },
  //   } = event
  //   setTextValue(
  //     On autofill we get a stringified value.
  //     typeof value === "string" ? value.split(",") : value
  //   )
  // }

  useEffect(() => {
    setSpin(true)
    let URL = BASE_DAN_BE_URL + Constant.PROCESS_HIERARCHY_TREE + id
    Api.loadPhLevels(URL)
      .then((data) => {
        setNodeData(data)
        setInterval(() => {
          setIsDisplayed(true)
        }, 100)
        setSpin(false)
      })
      .catch((err) => {
        console.log(err.message)
      })
    setLoading(false)
    Api.loadPhLevels()
  }, [])

  const newArr = useCallback((arrData) => {
    let arr0 = [delete arrData.industryId]
    const arr1 = [arrData].flatMap((elem) => elem.clientL2BPHs)

    const arr2 = arr1
      .map((elem) => {
        if (elem) {
          return elem.clientL3BPHs
        }
      })
      .filter((el) => {
        if (el) {
          return el != 0
        }
      })
      .map((e) => {
        if (e) {
          return e
        }
      })
      .flat(1)

    const arr2_4bph = arr2
      .map((elem) => {
        if (elem) {
          return elem.clientL4BPHs
        }
      })
      .flat(2)

    const arr2_5bph = arr2_4bph
      .map((elem) => {
        if (elem) {
          return elem.clientL5BPHs
        }
      })
      .flat(1)

    const simpleObj = {}
    const destructure = (obj) => {
      for (let key in obj) {
        const value = obj[key]
        const type = typeof value
        if (["string", "boolean"].includes(type) || (type === "number" && !isNaN(value))) {
          simpleObj[key] = value
        }
      }
      Object.assign(simpleObj, { parent: "0" })
      return simpleObj
    }

    arr1.push(destructure(arrData))
    arr2.push(arr1)
    arr2.push(arr2_4bph)
    arr2.push(arr2_5bph)

    const multiDimArray = arr2
      .map((items) => {
        if (items) {
          return items
        }
      })
      .flat(1)
    setInitialLevel(multiDimArray)
    const renameDescription = JSON.parse(JSON.stringify(multiDimArray).split('"description":').join('"text":'))
    const renameParent1 = JSON.parse(JSON.stringify(renameDescription).split('"clientL1BPHId":').join('"parent":'))
    const renameParent2 = JSON.parse(JSON.stringify(renameParent1).split('"clientL2BPHId":').join('"parent":'))
    const renameParent2_1 = JSON.parse(JSON.stringify(renameParent2).split('"clientL3BPHId":').join('"parent":'))
    const renameParent2_2 = JSON.parse(JSON.stringify(renameParent2_1).split('"clientL4BPHId":').join('"parent":'))

    const arrWithDroppable = renameParent2_2.map((object) => {
      return { ...object, droppable: true }
    })
    const renameParent3 = arrWithDroppable.map((object) => {
      return { ...object, isUpdated: false }
    })
    const renameParent4 = renameParent3.map((object) => {
      return { ...object, isNew: false }
    })
    setArrWith(renameParent4)
  }, [])

  useEffect(() => {
    newArr(nodeData)
  }, [nodeData])

  const handleCallback = (childData) => {
    setNodeDepth(childData)
  }

  const [treeData, setTreeData] = useState([])
  useEffect(() => {
    setTreeData(arrWith)
  }, [arrWith])

  const [addDrop, setAddDrop] = useState(false)
  const handleDrop = (newTreeData) => {
    setAddDrop(true)
    setTreeData(newTreeData)
    setSaveModal(true)
  }

  const handleSelect = (node) => {
    const item = selectedNodes.find((n) => n.id === node.id)

    if (!item) {
      setSelectedNodes([...selectedNodes, node])
    } else {
      setSelectedNodes(selectedNodes.filter((n) => n.id !== node.id))
    }
    setSaveModal(true)
  }

  const unselectDiffNode = treeData
    .filter((val) => {
      return selectedNodes.some((val2) => {
        return val.parent === val2.id
      })
    })
    .map((node) => {
      return node.isChecked === true ? Object.assign({}, node, { isChecked: false }) : node
    })

  const idSet = new Set(unselectDiffNode.map((o) => o.id))
  const resCheck = treeData.map((o) => ({ ...o, isChecked: idSet.has(o.id) ? true : o.isChecked }))
  const addSingleCheck = resCheck.concat(selectedNodes)
  const newSelectedResultId = addSingleCheck.map((o) => o.id)
  const newSelectedFilter = addSingleCheck.filter(({ id }, index) => !newSelectedResultId.includes(id, index + 1))
  const newSelectedResult = [...new Set(newSelectedFilter)]

  const handleDelete = (id) => {
    const deleteIds = [id, ...getDescendants(treeData, id).map((node) => node.id)]
    const newTree = treeData.filter((node) => !deleteIds.includes(node.id))
    setTreeData(newTree)
    setSaveModal(true)
  }

  const handleCopy = (id) => {
    const lastId = getLastId(treeData)
    const targetNode = treeData.find((n) => n.id === id)
    const descendants = getDescendants(treeData, id)
    const partialTree = descendants.map((node) => ({
      ...node,
      id: node.id + lastId,
      parent: node.parent + lastId,
    }))

    setTreeData([
      ...treeData,
      {
        ...targetNode,
        id: targetNode.id + lastId,
      },
      ...partialTree,
    ])
    setSaveModal(true)
  }

  const handleOpenDialog = () => {
    setOpen(true)
  }

  const handleCloseDialog = () => {
    setOpen(false)
  }

  const handleSubmit = (newNode) => {
    let UUID = crypto.randomUUID()
    setAddNewNode(true)
    setUpdatedNode(false)
    const lastId = UUID

    setTreeData([
      ...treeData,
      {
        ...newNode,
        id: lastId,
      },
    ])
    setSaveModal(true)
    setOpen(false)
  }

  const handleTextChange = (id, value) => {
    const newTree = treeData.map((node) => {
      if (node.id === id) {
        return {
          ...node,
          text: value,
        }
      }
      return node
    })

    setTreeData(newTree)
    setSaveModal(true)
  }

  const handleEdit = () => {
    setEnableDnd(true)
    setShowBtn(true)
    //setSaveModal(true)
  }

  const callDndFunc = (node) => {
    if (enableDnd) {
      if (node.isChecked !== false) {
        return node.id
      }
    }
  }

  const variable = location.pathname.substring(location.pathname.lastIndexOf("/") + 1)
  const previewVariable = location.pathname.split("/")[3]

  const initialOpenTreeLevel = (event) => {
    const getAllclientL1BPHId = initialLevel.map((node) => {
      return node.clientL1BPHId
    })
    const getAllclientL2BPHId = initialLevel.map((node) => {
      return node.clientL2BPHId
    })
    const getAllclientL3BPHId = initialLevel.map((node) => {
      return node.clientL3BPHId
    })
    const getAllclientL4BPHId = initialLevel.map((node) => {
      return node.clientL4BPHId
    })
    const getAllclient4All = getAllclientL1BPHId.concat(getAllclientL2BPHId)
    const getAllclient5 = getAllclient4All.concat(getAllclientL3BPHId)
    const getAllclient5All = getAllclient5.concat(getAllclientL4BPHId)

    switch (event.target.value) {
      case 10:
        setDefaultOpen(getAllclientL1BPHId)
        break
      case 20:
        setDefaultOpen(getAllclient4All)
        break
      case 30:
        setDefaultOpen(getAllclient5)
        break
      case 40:
        setDefaultOpen(getAllclient5All)
        break
      default:
        setDefaultOpen(event.target.value)
    }
  }

  useEffect(() => {
    const initialLoadTree = newSelectedResult.map((id) => {
      return id.id
    })
    setDefaultOpen(initialLoadTree)
    const initialLoadTitle = newSelectedResult.map((id) => {
      if (id.parent === "0") return id.text
    })
    setDefaultTitle(initialLoadTitle)
  }, [treeData])

  const textValues = (value) => {
    setFileNamePDF(value)
  }

  const downloadPng = useCallback(() => {
    setDownloadFunction(true)
    if (ref.current === null) {
      return
    }
    toPng(ref.current)
      .then((dataUrl) => {
        // dataURL = dataUrl[dataURL.length - 1]
        const link = document.createElement("a")
        link.download = "download file"
        link.href = dataUrl
        // console.log(dataUrl, "image")
        // console.log(dataUrl)
        window.location.href = dataUrl
        const imgData = dataUrl
        //console.log(imgData);
        const pdf = new jsPDF("p", "mm", "a4")
        const imgProps = pdf.getImageProperties(imgData)
        //console.log(imgProps.height,"img props");
        var pdfWidth = pdf.internal.pageSize.getWidth()
        var height = pdf.internal.pageSize.getHeight()
        var ratio = pdfWidth / pdfWidth
        height = ratio * pdfWidth
        const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width
        //console.log(height, "height pdf")
        const pageHeight = pdf.internal.pageSize.height
        //console.log(pageHeight, "pageHeight")
        pdf.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight)
        pdf.save(fileNamePDF)
        setdownloadCompleted(true)
        setDownloadFunction(false)
      })
      .catch((err) => {
        console.log(err.message)
      })
  }, [ref])

  return (
    <div className="process-hierarchy">
      <Suspense fallback="loading...">
        <ThemeProvider theme={theme}>
          <Navbar />

          <Grid container style={{ marginTop: "10px" }}>
            <Grid item xs={12}>
              <div className="title">
                <h1>
                  {defaultTitle}
                  <ExportPH style={{ float: "right", marginTop: "0" }} variant="contained" onClick={handleClickOpen} variable={variable} pageName={pageName} textValues={textValues} previewVariable={previewVariable} downloadPng={downloadPng} downloadCompleted={downloadCompleted} setdownloadCompleted={setdownloadCompleted} />
                </h1>
              </div>

              <div className="rightCol-inner level-container" ref={ref}>
                <div style={{ float: "right" }}>
                  <FormControl sx={{ m: 1, minWidth: 120 }}>
                    {
                      <>
                        {downloadFunction === true ? (
                          ""
                        ) : (
                          <div>
                            <InputLabel id="demo-simple-select-label">Level Preference</InputLabel>
                            {/* <p className="select-label">Level Preference</p> */}
                            <Select
                              labelId="demo-simple-select-label"
                              sx={{
                                boxShadow: "none",
                                ".MuiOutlinedInput-notchedOutline": {
                                  border: 0,
                                },
                              }}
                              value={defaultOpen}
                              onChange={initialOpenTreeLevel}
                            >
                              <MenuItem value={0}>Level 1</MenuItem>
                              <MenuItem value={10}>Level 2</MenuItem>
                              <MenuItem value={20}>Level 3</MenuItem>
                              <MenuItem value={30}>Level 4</MenuItem>
                              <MenuItem value={40}>Level 5</MenuItem>
                            </Select>
                          </div>
                        )}
                      </>
                    }
                  </FormControl>
                </div>
                <div className="legend-blocks">
                  Legend |<span className="level-ones"> Level 1 |</span>
                  <span className="level-two"> Level 2 |</span>
                  <span className="level-three"> Level 3 |</span>
                  <span className="level-four"> Level 4 |</span>
                  <span className="level-five"> Level 5</span>
                </div>
                {spin === false ? (
                  isDisplayed && (
                    <DndProvider backend={MultiBackend} options={getBackendOptions()}>
                      <div>{open && <AddDialog tree={treeData} nodeDepth={nodeDepth} newSelectedResult={newSelectedResult} onClose={handleCloseDialog} onSubmit={handleSubmit} />}</div>

                      <Tree
                        tree={treeData}
                        rootId={"0"}
                        onDrop={handleDrop}
                        initialOpen={defaultOpen}
                        classes={{
                          container: "wtree",
                          listItem: "parent-listitem",
                        }}
                        sort={false}
                        canDrag={(node) => callDndFunc(node)}
                        render={(node, { depth, isOpen, hasChild, onToggle }) => <CustomNode addDrop={addDrop} addNewNode={addNewNode} updatedNode={updatedNode} handleEdit={handleDrop} parentCallback={handleCallback} isSelected={!!selectedNodes.find((n) => n.id === node.id)} onSelect={handleSelect} handleCloseDialog={handleCloseDialog} showBtn={showBtn} handleSubmit={handleSubmit} handleOpenDialog={handleOpenDialog} node={node} depth={depth} hasChild={hasChild} isOpen={isOpen} onToggle={onToggle} onTextChange={handleTextChange} onDelete={handleDelete} onCopy={handleCopy} dragPreviewRender={(monitorProps) => <CustomDragPreview monitorProps={monitorProps} />} />}
                      />
                    </DndProvider>
                  )
                ) : (
                  <div className="loader">
                    <CircularProgress />
                  </div>
                )}
              </div>

              <ProcessSave saveModal={saveModal} variable={variable} clientValue={props.clientValue} showBtn={showBtn} handleEdit={handleEdit} newSelectedResult={newSelectedResult} />
            </Grid>
          </Grid>
        </ThemeProvider>
      </Suspense>
    </div>
  )
}

export default ClientProcess
