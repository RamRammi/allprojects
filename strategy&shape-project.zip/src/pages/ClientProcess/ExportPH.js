import React from "react"
import { useState, useCallback, useEffect } from "react"
import { Button } from "@mui/material"
import Dialog from "@mui/material/Dialog"
import DialogActions from "@mui/material/DialogActions"
import DialogContent from "@mui/material/DialogContent"
import DialogContentText from "@mui/material/DialogContentText"
import DialogTitle from "@mui/material/DialogTitle"
import MenuItem from "@mui/material/MenuItem"
import OutlinedInput from "@mui/material/OutlinedInput"
import FormControl from "@mui/material/FormControl"
import Select from "@mui/material/Select"
import { Grid, Typography } from "@mui/material"
import { theme } from "../../theme"
import { useTheme } from "@mui/material/styles"
import * as Constant from "../../comman/constant"
import { toPng, toJpeg } from "html-to-image"
import jsPDF from "jspdf"

import * as Api from "../../comman/api"
import { BASE_URL, BASE_DAN_BE_URL } from "../../comman/constant"
import { useSelector } from "react-redux"
import fileDownload from "js-file-download"
import { useLocation } from "react-router-dom"

const ITEM_HEIGHT = 48
const ITEM_PADDING_TOP = 8
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
}

function ExportPH(props) {
  let location = useLocation()
  const [openDialog, setOpenDialog] = useState(false)
  const [personName, setPersonName] = useState([])
  const [textValue, setTextValue] = useState("")
  const theme = useTheme()
  const names = location.pathname.includes("/client-process") ? ["PDF", "Excel"] : location.pathname.includes("/process-hierarchies/process") ? ["PDF", "Excel"] : ["Excel"]
  //const [fileDownload, setFileDownload] = useState()

  useEffect(() => {
    props.textValues(textValue)
  }, [textValue])

  useEffect(() => {
    if (props.downloadCompleted === true) {
      handleClose()
    }
  }, [props.downloadCompleted])

  const handleClickOpen = () => {
    setOpenDialog(true)
  }

  const handleClose = () => {
    setOpenDialog(false)
    setTextValue("")
    setPersonName("")
  }

  const handleChange = (event) => {
    const {
      target: { value },
    } = event
    setPersonName(
      // On autofill we get a stringified value.
      typeof value === "string" ? value.split(",") : value
    )
  }
  function getStyles(name, personName, theme) {
    return {
      fontWeight: personName.indexOf(name) === -1 ? theme.typography.fontWeightRegular : theme.typography.fontWeightMedium,
    }
  }

  const onTextValueChange = (event) => {
    setTextValue(event.target.value.replace(new RegExp(/[*#$%!~^&`(){}<>?/\\:;""'|]/gm), ""))
  }

  const exportPHExcel = async () => {
    if (props.pageName === "client view export") {
      let URL = BASE_DAN_BE_URL + Constant.PH_CLIENT_EXPORT + props.previewVariable + `&FileType=` + personName[0] + `&FileName=` + textValue
      Api.exportExcelTree(URL)
        .then((blob) => fileDownload(blob, textValue + ".xlsx", "text/xlsx;charset=utf-8"), handleClose())
        .catch((err) => {
          console.log(err.message)
        })
    }
  }
  const exportPHExcelMaster = async () => {
    let URL = BASE_DAN_BE_URL + Constant.PROCESS_HIERARCHY_TREE_MASTER + props.previewVariable + `&FileType=` + personName[0] + `&FileName=` + textValue
    Api.exportExcelTree(URL)
      .then((blob) => fileDownload(blob, textValue + ".xlsx", "text/xlsx;charset=utf-8"), handleClose())
      .catch((err) => {
        console.log(err.message)
      })
  }
  return (
    <div>
      <Button style={{ float: "right", marginTop: "-23px" }} variant="contained" onClick={handleClickOpen}>
        Export File
      </Button>
      <Dialog open={openDialog} onClose={handleClose} aria-labelledby="alert-dialog-title" aria-describedby="alert-dialog-description">
        <DialogTitle id="alert-dialog-title" style={{ fontFamily: "Ubuntu" }}>
          Export As
        </DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            <Typography
              style={{
                color: "black",
                fontFamily: "Ubuntu",
                marginBottom: "10px",
              }}
            >
              Specify a File Name
            </Typography>
            <FormControl sx={{ m: 1, width: 451, mt: 3 }}>
              <OutlinedInput placeholder="Text" value={textValue} onChange={onTextValueChange} />
            </FormControl>

            <Typography style={{ color: "black", fontFamily: "Ubuntu" }}>Filetype</Typography>
            <FormControl sx={{ m: 1, width: 500, mt: 3 }}>
              <Select
                displayEmpty
                value={personName}
                onChange={handleChange}
                input={<OutlinedInput />}
                renderValue={(selected) => {
                  if (selected.length === 0) {
                    return <em>Placeholder</em>
                  }

                  return selected.join(", ")
                }}
                MenuProps={MenuProps}
                inputProps={{ "aria-label": "Without label" }}
              >
                <MenuItem disabled value="">
                  <em>Placeholder</em>
                </MenuItem>
                {names.map((name) => (
                  <MenuItem key={name} value={name} style={getStyles(name, personName, theme)}>
                    {name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>cancel</Button>
          {personName != "" ? (
            personName != "PDF" ? (
              location.pathname.includes("/client-process") ? (
                <Button onClick={exportPHExcel} autoFocus>
                  Export
                </Button>
              ) : location.pathname.includes("/process-hierarchies/process") ? (
                <Button onClick={exportPHExcelMaster} autoFocus>
                  Export
                </Button>
              ) : (
                <Button onClick={props.clientexportPHExcel} autoFocus>
                  Export
                </Button>
              )
            ) : (
              <Button
                onClick={() => {
                  props.downloadPng()
                  props.setdownloadCompleted(false)
                }}
                autoFocus
              >
                Export
              </Button>
            )
          ) : (
            ""
          )}
          {/* {personName[0]==="PPT"?(
            <Button
            onClick={() => {
              props.downloadPPT()
              props.setdownloadCompleted(false)
            }}
            autoFocus
          >
            Export
          </Button>

          ):("")} */}
        </DialogActions>
      </Dialog>
    </div>
  )
}

export default ExportPH
