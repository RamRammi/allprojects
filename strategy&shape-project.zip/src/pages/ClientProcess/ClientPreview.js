import React from "react"
import ClientProcess from "./[id]"

// import ClientProcess from "./ClientProcess/[id]"

function CilentPreview() {
  const clientValue = "Client preview"
  return (
    <div>
      <ClientProcess clientValue={clientValue} />
    </div>
  )
}

export default CilentPreview
