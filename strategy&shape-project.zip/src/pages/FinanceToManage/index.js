import React from "react"
import "./finance.css"
import { Grid } from "@mui/material"
import Navbar from "../../components/Navbar/Navbar"
import { Tree, TreeNode } from "react-organizational-chart"

const FinanceToManage = () => (
  <>
    <Navbar />
    <Grid container style={{ marginTop: "20px" }}>
      <Grid item xs={12}>
        <Tree lineColor={"#707070"} lineHeight={"40px"} label={<div>Level 1</div>}>
          <TreeNode>
            <TreeNode label={<div className="level-one">Level 2</div>}>
              <TreeNode label={<div>Level 3</div>} />
              <TreeNode label={<div>Level 3</div>} />
              <TreeNode label={<div>Level 3</div>} />
              <TreeNode label={<div>Level 3</div>} />
              <TreeNode label={<div>Level 3</div>} />
            </TreeNode>
            <TreeNode label={<div>Level 2</div>}>
              <TreeNode label={<div>Level 3</div>} />
              <TreeNode label={<div>Level 3</div>} />
              <TreeNode label={<div>Level 3</div>} />
              <TreeNode label={<div>Level 3</div>} />
              <TreeNode label={<div>Level 3</div>} />
            </TreeNode>
            <TreeNode label={<div>Level 2</div>}>
              <TreeNode label={<div>Level 3</div>} />
              <TreeNode label={<div>Level 3</div>} />
              <TreeNode label={<div>Level 3</div>} />
              <TreeNode label={<div>Level 3</div>} />
              <TreeNode label={<div>Level 3</div>} />
            </TreeNode>
            <TreeNode label={<div>Level 2</div>}>
              <TreeNode label={<div>Level 3</div>} />
              <TreeNode label={<div>Level 3</div>} />
              <TreeNode label={<div>Level 3</div>} />
              <TreeNode label={<div>Level 3</div>} />
              <TreeNode label={<div>Level 3</div>} />
            </TreeNode>
            <TreeNode label={<div>Level 2</div>}>
              <TreeNode label={<div>Level 3</div>} />
              <TreeNode label={<div>Level 3</div>} />
              <TreeNode label={<div>Level 3</div>} />
              <TreeNode label={<div>Level 3</div>} />
              <TreeNode label={<div>Level 3</div>} />
            </TreeNode>
          </TreeNode>
        </Tree>
      </Grid>
    </Grid>
  </>
)

export default FinanceToManage
