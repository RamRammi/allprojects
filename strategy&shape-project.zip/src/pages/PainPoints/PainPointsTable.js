import React, { useEffect } from "react";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import { styled, alpha } from "@mui/material/styles";
import AppBar from "@mui/material/AppBar";
import InputBase from "@mui/material/InputBase";
import { Link, useNavigate } from "react-router-dom";
import SearchIcon from "@mui/icons-material/Search";
import "./PainPoints.css";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell, { tableCellClasses } from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import PropTypes from "prop-types";
import Typography from "@mui/material/Typography";
import Paper from "@mui/material/Paper";
import { visuallyHidden } from "@mui/utils";
import { Pagination } from "@mui/material";
import EditOutlinedIcon from "@mui/icons-material/EditOutlined";
import FileDownloadOutlinedIcon from "@mui/icons-material/FileDownloadOutlined";
import DeleteOutlineOutlinedIcon from "@mui/icons-material/DeleteOutlineOutlined";
import SaveAltIcon from "@mui/icons-material/SaveAlt";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import MenuItem from "@mui/material/MenuItem";
import OutlinedInput from "@mui/material/OutlinedInput";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import DeletePopup from "./DeletePopup";
import { useTheme } from "@mui/material/styles";
import { useSelector } from "react-redux";
import * as Api from "../../comman/api";
import * as Constant from "../../comman/constant";
import ExportPainPoint from "../../pages/PainPoints/ExportPainPoint";
import fileDownload from "js-file-download";
import SuccssMsg from "../../components/AlertBox/SuccessMsg";

const Search = styled("div")(({ theme }) => ({
  position: "relative",
  borderRadius: theme.shape.borderRadius,
  backgroundColor: alpha(theme.palette.common.white, 0.15),
  "&:hover": {
    backgroundColor: alpha(theme.palette.common.white, 0.25),
  },
  marginRight: theme.spacing(2),
  marginLeft: 0,

  [theme.breakpoints.up("sm")]: {
    marginLeft: theme.spacing(3),
    width: "auto",
  },
}));

const SearchIconWrapper = styled("div")(({ theme }) => ({
  padding: theme.spacing(0, 2),
  height: "100%",
  position: "absolute",
  pointerEvents: "none",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
}));

const StyledInputBase = styled(InputBase)(({ theme }) => ({
  color: "inherit",
  "& .MuiInputBase-input": {
    padding: theme.spacing(1, 1, 1, 0),
    // vertical padding + font size from searchIcon
    paddingLeft: `calc(1em + ${theme.spacing(4)})`,
    transition: theme.transitions.create("width"),

    [theme.breakpoints.up("md")]: {},
  },
}));

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};

function descendingComparator(a, b, orderBy) {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
}
function getComparator(order, orderBy) {
  return order === "desc"
    ? (a, b) => descendingComparator(a, b, orderBy)
    : (a, b) => -descendingComparator(a, b, orderBy);
}

// This method is created for cross-browser compatibility, if you don't
// need to support IE11, you can use Array.prototype.sort() directly
function stableSort(array, comparator) {
  const stabilizedThis = array.map((el, index) => [el, index]);
  stabilizedThis.sort((a, b) => {
    const order = comparator(a[0], b[0]);
    if (order !== 0) {
      return order;
    }
    return a[1] - b[1];
  });
  return stabilizedThis.map((el) => el[0]);
}
const StyledTableCell = styled(TableCell)(({ theme }) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: "#F3F3F3",
    color: theme.palette.common.black,
    fontWeight: 500,
    fontSize: 14,
    // width: "50px",
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 14,
  },
}));
const headCells = [
  {
    id: "name",
    numeric: false,
    disablePadding: false,
    label: "Workshop Name",
    width: "150px",
  },
  {
    id: "calories",
    numeric: true,
    disablePadding: false,
    label: "Status",
    width: "150px",
  },
  {
    id: "fat",
    numeric: true,
    disablePadding: false,
    label: "Processes",
    width: "200px",
  },
  {
    id: "action",
    numeric: true,
    disablePadding: false,
    label: "As-Is",
    width: "300px",
  },
  {
    id: "action",
    numeric: true,
    disablePadding: false,
    label: "To-Be",
    width: "300px",
  },
  {
    id: "action",
    numeric: true,
    disablePadding: false,
    label: "Pain Points",
    width: "400px",
  },
  {
    id: "action",
    numeric: true,
    disablePadding: false,
    label: "Improvement Opportunities",
    width: "400px",
  },
  {
    id: "action",
    numeric: true,
    disablePadding: false,
    label: "Action",
    width: "0px",
  },
];

function EnhancedTableHead(props) {
  const {
    onSelectAllClick,
    order,
    orderBy,
    numSelected,
    rowCount,
    onRequestSort,
  } = props;

  return (
    <TableHead>
      <TableRow>
        {headCells.map((headCell) => (
          <StyledTableCell
            className="Table_row-Bg"
            key={headCell.id}
            align={headCell.numeric ? "left" : "left"}
            padding={headCell.disablePadding ? "none" : "normal"}
            sortDirection={orderBy === headCell.id ? order : false}
            width={headCell.width}
          >
            {/* <TableSortLabel
              active={orderBy === headCell.id}
              direction={orderBy === headCell.id ? order : "asc"}
              onClick={createSortHandler(headCell.id)}
            > */}
            {headCell.label}
            {orderBy === headCell.id ? (
              <Box component3="span" sx={visuallyHidden}>
                {order === "desc" ? "sorted descending" : "sorted ascending"}
              </Box>
            ) : null}
            {/* </TableSortLabel> */}
          </StyledTableCell>
        ))}
      </TableRow>
    </TableHead>
  );
}

EnhancedTableHead.propTypes = {
  numSelected: PropTypes.number.isRequired,
  onRequestSort: PropTypes.func.isRequired,
  onSelectAllClick: PropTypes.func.isRequired,
  order: PropTypes.oneOf(["asc", "desc"]).isRequired,
  orderBy: PropTypes.string.isRequired,
  rowCount: PropTypes.number.isRequired,
};

export const PainPointsTable = (props) => {
  const [order, setOrder] = React.useState("asc");
  const [orderBy, setOrderBy] = React.useState("calories");
  const [selected, setSelected] = React.useState([]);
  const [page, setPage] = React.useState(0);
  const [dense, setDense] = React.useState(false);
  const [rowsPerPage, setRowsPerPage] = React.useState(5);
  const [pageCount, setPagepageCount] = React.useState(0);
  const [tableData, setTableData] = React.useState([]);
  const [rows, setRows] = React.useState([]);
  const [searchStr, setSearchStr] = React.useState("");
  const [showAlertBox, setShowAlertBox] = React.useState("");
  const [successMessage, setSuccessMessage] = React.useState("");
  const [openDialog, setOpenDialog] = React.useState(false);
  const [originalData, setOriginalData] = React.useState([]);
  const documentType = ["pdf", "excel"];
  const [documentName, setDocumentName] = React.useState(["pdf"]);
  const [fileName, setFileName] = React.useState("");
  const [workshopId, setWorkshopId] = React.useState("");
  const [fileNameError, setFileNameError] = React.useState("");
  const theme = useTheme();
  const navigate = useNavigate();
  const projectId = useSelector(
    (state) => state.questionnaireReducer.projectId
  );
  const textValues = (value) => {
    setFileNameExcel(value);
  };

  const [fileNameExcel, setFileNameExcel] = React.useState("");
  useEffect(() => {
    console.log(props.filterTableData);
    setTableData(props.filterTableData);
    setOriginalData(props.filterTableData);
  }, [props.filterTableData]);

  useEffect(() => {
    if (searchStr !== "") getSearchData();
    else setTableData(originalData);
  }, [searchStr]);
  React.useEffect(() => {
    setPage(0);
    if (tableData.length > 0) {
      let pageCounts = Math.ceil(tableData.length / rowsPerPage);
      setPagepageCount(pageCounts);
    }
  }, [rowsPerPage, tableData]);

  const handleRequestSort = (event, property) => {
    const isAsc = orderBy === property && order === "asc";
    setOrder(isAsc ? "desc" : "asc");
    setOrderBy(property);
  };
  const handleClickOpen = (id) => {
    setOpenDialog(true);
    setWorkshopId(id);
  };
  const handleClose = () => {
    setOpenDialog(false);
    setFileName("");
    setDocumentName(["pdf"]);
    setWorkshopId("");
    setFileNameError("");
  };

  const handleSelectAllClick = (event) => {
    if (event.target.checked) {
      const newSelected = rows.map((n) => n.name);
      setSelected(newSelected);
      return;
    }
    setSelected([]);
  };

  const handleClick = (event, name) => {
    const selectedIndex = selected.indexOf(name);
    let newSelected = [];

    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selected, name);
    } else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selected.slice(1));
    } else if (selectedIndex === selected.length - 1) {
      newSelected = newSelected.concat(selected.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        selected.slice(0, selectedIndex),
        selected.slice(selectedIndex + 1)
      );
    }

    setSelected(newSelected);
  };

  // const handleChangePage = (event, newPage) => {
  //   setPage(newPage);
  // };
  const handleChangePage = (event, newPage) => {
    setPage(newPage - 1);
  };

  const handleChangeRowsPerPage = (newValue) => {
    setRowsPerPage(newValue);
    setPage(0);
  };
  //Get Data after the search using serch box
  const getSearchData = () => {
    let searchData = [];
    //  let str = searchStr;
    searchData = originalData.filter((value) => {
      console.log(searchStr);
      return (
        value.workshopName.toLowerCase().includes(searchStr.toLowerCase()) ||
        value.status.toLowerCase().includes(searchStr.toLowerCase()) ||
        value.asIs.toLowerCase().includes(searchStr.toLowerCase()) ||
        value.toBe.toLowerCase().includes(searchStr.toLowerCase()) ||
        value.painPoints.some((value1) => {
          return value1.painPointDesc
            .toLowerCase()
            .includes(searchStr.toLowerCase());
        }) ||
        value.improvementOpportunity.some((value1) => {
          return value1.improvOppDesc
            .toLowerCase()
            .includes(searchStr.toLowerCase());
        })
      );
    });
    setTableData(searchData);
  };
  const downloadWorkshopById = () => {
    console.log(fileName);
    if (fileName === "") {
      setFileNameError("Please Enter the the File Name");
    } else {
      setFileNameError("");
      let URL =
        Constant.BASE_URL +
        Constant.DOWNLOAD_WORKSHOP_BY_ID +
        "?workshopId=" +
        workshopId +
        "&projectId=" +
        projectId +
        "&fileName=" +
        fileName +
        "&fileType=" +
        documentName[0];
      Api.downloadWorkshopById(URL)
        .then(
          (blob) =>
            documentName[0] === "pdf"
              ? fileDownload(blob, fileName + ".pdf", "text/pdf;charset=utf-8")
              : fileDownload(
                  blob,
                  fileName + ".xlsx",
                  "text/xlsx;charset=utf-8"
                ),
          handleClose()
        )
        .catch((err) => {
          console.log(err.message);
        });
    }
  };

  const getHighlightedText = (text, higlight) => {
    // Split text on higlight term, include term itself into parts, ignore case
    if (higlight !== "") {
      var parts = text.split(new RegExp(`(${higlight})`, "gi"));
      return (
        <div style={{ display: "block" }}>
          {parts.map((part, index) => (
            <span
              style={{
                backgroundColor:
                  part.toLowerCase() === higlight.toLowerCase()
                    ? "#e8bb49"
                    : "white",
              }}
            >
              {part}
            </span>
          ))}
        </div>
      );
    } else {
      return text;
    }
  };
  function getStyles(name, personName, theme) {
    return {
      fontWeight:
        personName.indexOf(name) === -1
          ? theme.typography.fontWeightRegular
          : theme.typography.fontWeightMedium,
    };
  }
  const handleChange = (event) => {
    const {
      target: { value },
    } = event;
    setDocumentName(
      // On autofill we get a stringified value.
      typeof value === "string" ? value.split(",") : value
    );
  };
  const handleChangeFileName = (event) => {
    setFileNameError("");
    setFileName(
      event.target.value.replace(
        new RegExp(/[*#$%!~^&`(){}<>?/\\:;""'|]/gm),
        ""
      )
    );
  };
  const showDeleteSuccessMsg = (msg) => {
    setShowAlertBox(true);
    setSuccessMessage(msg);
  };
  const editWorkshop = (id) => {
    navigate(`/painpoints/editpainpoints/${id}`);
  };
  // Avoid a layout jump when reaching the last page with empty rows.
  const emptyRows =
    page > 0 ? Math.max(0, (1 + page) * rowsPerPage - rows.length) : 0;
  return (
    <React.Fragment>
      <div className="search-bar-section">
        <Box className="search_button_M" sx={{ flexGrow: 1 }}>
          <AppBar className="search_button_s" position="static">
            <Search className="search_button">
              <SearchIconWrapper className="searchIconWrapper_css">
                <SearchIcon className="searchicon_css" />
              </SearchIconWrapper>
              <StyledInputBase
                className="search_inputbase"
                placeholder="Search…"
                inputProps={{ "aria-label": "search" }}
                defaultValue={searchStr}
                onChange={(event) => setSearchStr(event.target.value)}
              />
            </Search>
            <Box sx={{ flexGrow: 1 }} />
          </AppBar>
        </Box>

        <span className="create-new-button">
          {/* API integration pending on export all button */}
          {tableData.length===0?"":(
          <ExportPainPoint
          status={props.status}
          workshopId={props.workshopId}
          L1Process={props.L1Process}
          L2Process={props.L2Process}
          L3Process={props.L3Process}/>)}
          <Link to="/painpoints/addpainpoints">
            <Button variant="contained">Create New</Button>
          </Link>
        </span>

        <Box sx={{ width: "100%" }}>
          <Paper sx={{ width: "95%", margin: "0 auto", boxShadow: "none" }}>
            <TableContainer>
              <div className="table-heading">Maturity Summary</div>
              <div
                className={
                  tableData.length
                    ? "painpoints-table "
                    : "painpoints-table-no-record"
                }
              >
                <Table
                  sx={{ minWidth: 850 }}
                  aria-labelledby="tableTitle"
                  borderAxis={"both"}
                  className="painpoints-table-outer"
                >
                  <EnhancedTableHead
                    numSelected={selected.length}
                    order={order}
                    orderBy={orderBy}
                    onSelectAllClick={handleSelectAllClick}
                    onRequestSort={handleRequestSort}
                    rowCount={tableData.length}
                  />
                  <TableBody>
                    {/* if you don't need to support IE11, you can replace the `stableSort` call with:
                 rows.slice().sort(getComparator(order, orderBy)) */}
                    {stableSort(tableData, getComparator(order, orderBy))
                      .slice(
                        page * rowsPerPage,
                        page * rowsPerPage + rowsPerPage
                      )
                      .map((row, index) => {
                        // const isItemSelected = isSelected(row.name);
                        const labelId = `enhanced-table-checkbox-${index}`;

                        return (
                          <TableRow
                            hover
                            onClick={(event) => handleClick(event, row.name)}
                            role="checkbox"
                            //   aria-checked={isItemSelected}
                            tabIndex={-1}
                            key={index}
                            //  selected={isItemSelected}
                          >
                            <TableCell
                              style={{ color: "#0070AD" }}
                              onClick={() => editWorkshop(row.workShopId)}
                            >
                              {getHighlightedText(row.workshopName, searchStr)}
                            </TableCell>
                            <TableCell>
                              {getHighlightedText(row.status, searchStr)}
                            </TableCell>
                            <TableCell>
                              {row.processes !== null
                                ? row.processes.map((value, i) => {
                                    return (
                                      <p>
                                        {value.split("=")[1].split("/")[0] !==
                                        ""
                                          ? getHighlightedText(value, searchStr)
                                          : ""}
                                      </p>
                                    );
                                  })
                                : ""}
                            </TableCell>
                            <TableCell>
                              {getHighlightedText(row.asIs, searchStr)}
                            </TableCell>
                            <TableCell>
                              {getHighlightedText(row.toBe, searchStr)}
                            </TableCell>
                            <TableCell>
                              <ul id="point">
                                {row.painPoints.map((value) => {
                                  return (
                                    <li>
                                      {getHighlightedText(
                                        value.painPointDesc,
                                        searchStr
                                      )}
                                      {/* {value.painPointDesc} */}
                                    </li>
                                  );
                                })}
                              </ul>
                            </TableCell>
                            <TableCell>
                              {/* {row.ImprovementOpportunities} */}
                              <ul id="point">
                                {row.improvementOpportunity.map((value) => {
                                  return (
                                    <li>
                                      {getHighlightedText(
                                        value.improvOppDesc,
                                        searchStr
                                      )}
                                      {/* {value.improvOppDesc} */}
                                    </li>
                                  );
                                })}
                              </ul>
                            </TableCell>
                            <TableCell>
                              <Button
                                onClick={() => editWorkshop(row.workShopId)}
                                style={{
                                  border: "none",
                                  color: "#0070AD",
                                }}
                              >
                                <EditOutlinedIcon />
                              </Button>
                              <Button
                                style={{
                                  // float: "right",
                                  textTransform: "capitalize",
                                }}
                                onClick={() => {
                                  handleClickOpen(row.workShopId);
                                }}
                              >
                                <FileDownloadOutlinedIcon
                                // style={{ float: "right" }}
                                />
                              </Button>
                              <DeletePopup
                                data={row}
                                index={index}
                                getRefreshedData={props.getFilterData}
                                showDeleteSuccessMsg={showDeleteSuccessMsg}
                              />
                              {/* </Button> */}
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    {emptyRows > 0 && (
                      <TableRow
                        style={{
                          height: (dense ? 33 : 53) * emptyRows,
                        }}
                      >
                        <TableCell colSpan={6} />
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
                {tableData.length ? (
                  ""
                ) : (
                  <div
                    style={{
                      marginTop: "20px",
                      display: "flex",
                      justifyContent: "center",
                    }}
                  >
                    <div
                      style={{
                        color: "#707070DE",
                        textAlign: "center",
                        alignItems: "center",
                        marginLeft: "20px",
                        textAlign: "center",
                        width: "520px",
                        padding: "64px 20px",
                        fontSize: "16px",
                      }}
                    >
                      <em>No Record Found</em>
                    </div>
                  </div>
                )}
              </div>
            </TableContainer>

            {tableData.length ? (
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  margin: "20px",
                  paddingBottom: "20px",
                }}
              >
                <Typography
                  style={{
                    display: "inline-block",
                    font: "ubuntu",
                    color: "#707070DE",
                  }}
                >
                  Page {page + 1} of {pageCount}
                </Typography>
                <div
                  className="Pagination"
                  //nikhitha
                  // style={{ marginLeft: "39%", display: "inline-block" }}
                >
                  <Pagination
                    count={pageCount}
                    defaultPage={1}
                    boundaryCount={2}
                    onChange={handleChangePage}
                  />
                </div>
                <Typography
                  style={{
                    //nikhitha
                    // marginLeft: "35%",
                    // display: "inline-block",
                    color: "#707070DE",
                  }}
                >
                  Show{" "}
                  <button
                    style={{
                      border: "none",
                      font: "ubuntu",
                      backgroundColor: "white",
                      marginRight: "5px",
                      fontSize: "16px",
                      color: "#0070AD",
                    }}
                    onClick={() => handleChangeRowsPerPage(5)}
                  >
                    5
                  </button>
                  <button
                    style={{
                      border: "none",
                      font: "ubuntu",
                      backgroundColor: "white",
                      marginRight: "5px",
                      fontSize: "16px",
                      color: "#0070AD",
                    }}
                    onClick={() => handleChangeRowsPerPage(10)}
                  >
                    10
                  </button>
                  <button
                    style={{
                      border: "none",
                      font: "ubuntu",
                      backgroundColor: "white",
                      fontSize: "16px",
                      color: "#0070AD",
                    }}
                    onClick={() => handleChangeRowsPerPage(tableData.length)}
                  >
                    All
                  </button>
                </Typography>
              </div>
            ) : (
              ""
            )}
          </Paper>
        </Box>

        <Dialog
          open={openDialog}
          onClose={handleClose}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <DialogTitle id="alert-dialog-title" style={{ fontFamily: "Ubuntu" }}>
            Download
          </DialogTitle>
          <DialogContent>
            <DialogContentText id="alert-dialog-description">
              <Typography
                style={{
                  color: "black",
                  fontFamily: "Ubuntu",
                  marginBottom: "10px",
                }}
              >
                Specify a File Name
              </Typography>
              <FormControl sx={{ m: 1, width: 451, mt: 3 }}>
                <OutlinedInput
                  placeholder=""
                  value={fileName}
                  onChange={handleChangeFileName}
                />
                <span style={{ color: "red", fontSize: "10px" }}>
                  {fileNameError}
                </span>
              </FormControl>

              <Typography style={{ color: "black", fontFamily: "Ubuntu" }}>
                Filetype
              </Typography>
              <FormControl sx={{ m: 1, width: 500, mt: 3, height: 100 }}>
                <Select
                  displayEmpty
                  value={documentName}
                  onChange={handleChange}
                  input={<OutlinedInput />}
                  renderValue={(selected) => {
                    if (selected.length === 0) {
                      return <em></em>;
                    }

                    return selected.join(", ");
                  }}
                  MenuProps={MenuProps}
                  inputProps={{ "aria-label": "Without label" }}
                >
                  {/* <MenuItem disabled value="">
                    <em>Placeholder</em>
                  </MenuItem> */}
                  {documentType.map((name) => (
                    <MenuItem
                      key={name}
                      value={name}
                      style={getStyles(name, documentName, theme)}
                    >
                      {name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleClose}>cancel</Button>

            <Button onClick={downloadWorkshopById}>Download</Button>
          </DialogActions>
        </Dialog>
        <SuccssMsg
          showAlertBox={showAlertBox}
          setShowAlertBox={setShowAlertBox}
          message={successMessage}
        />
      </div>
    </React.Fragment>
  );
};
