import * as React from "react";
import DeleteIcon from "@mui/icons-material/Delete";
import IconButton from "@mui/material/IconButton";
import Stack from "@mui/material/Stack";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import { useSelector, useDispatch } from "react-redux";
import * as Api from "../../comman/api";
import * as Constant from "../../comman/constant";

export default function DeleteiconButtons(props) {
  const [open, setOpen] = React.useState(false);

  const clientId = useSelector((state) => state.questionnaireReducer.clientId);
  const userId = useSelector((state) => state.questionnaireReducer.userId);
  const projectId = useSelector(
    (state) => state.questionnaireReducer.projectId
  );
  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };
  const deleteapi = () => {
    console.log(clientId, userId, "props.data");
    const obj = {
      workshopId: props.data.workShopId,
      projectId: projectId,
      clientId: clientId,
      userId: userId,
      message: "string",
      statusCode: 0,
      isDeleted: true,
    };
    console.log(obj, "obj");
    Api.DeleteWorkshopById(Constant.DELETE_WORKSHOPBYID, obj).then((res) => {
      setOpen(false);
      props.getRefreshedData();
      props.showDeleteSuccessMsg(res.message);
    });
  };
  return (
    <div>
      <Button onClick={handleClickOpen}>
        <Stack direction="row" spacing={1}>
          <IconButton aria-label="delete">
            <DeleteIcon />
          </IconButton>
        </Stack>
      </Button>
      <Dialog open={open} onClose={handleClose}>
        <DialogTitle>Delete</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Do you really want to delete {props.data.workshopName}
          </DialogContentText>
        </DialogContent>

        <DialogActions>
          <DialogActions>
            <Button
              variant="outlined"
              style={{
                borderRadius: "25px",
                padding: "5px 10px",
                margin: "10px 10px 20px 0px",
                fontSize: "12px",
              }}
              onClick={handleClose}
            >
              Cancel
            </Button>
            <Button
              variant="outlined"
              style={{
                borderRadius: "25px",
                padding: "5px 10px",
                margin: "10px 10px 20px 0px",
                fontSize: "12px",
              }}
              onClick={() => deleteapi()}
            >
              Yes
            </Button>
          </DialogActions>
        </DialogActions>
      </Dialog>
    </div>
  );
}
