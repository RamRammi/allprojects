import React, { useState } from "react";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import MenuItem from "@mui/material/MenuItem";
import OutlinedInput from "@mui/material/OutlinedInput";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import { Typography } from "@mui/material";
import { useTheme } from "@mui/material/styles";
import "./PainPoints.css";
import { useSelector } from "react-redux";
import * as Api from "../../comman/api"
import * as Constant from "../../comman/constant";
import fileDownload from "js-file-download";



const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 200,
    },
  },
};

function ExportPainPoint(props) {
  const [openDialog1, setOpenDialog1] = useState(false);
  // const documentType = ["pdf", "excel", "csv"];j
  const documentType = [ "EXCEL"];

  const [fileNameError, setFileNameError] = React.useState("");
  const [documentName, setDocumentName] = React.useState(["EXCEL"]);
  // const[documentError,setDocumentError]=useState("")
  const [fileName, setFileName] = React.useState("");
  const theme = useTheme();
  const projectId = useSelector(
    (state) => state.questionnaireReducer.projectId
  );
  const clientId = useSelector((state) => state.questionnaireReducer.clientId);

  // useEffect(() => {
  //   props.textValues(textValue);
  // }, [textValue]);

  // useEffect(() => {
  //   if (props.downloadCompleted === true) {
  //     handleClose1();
  //   }
  // }, [props.downloadCompleted]);

  const handleClickOpen1 = () => {
    setOpenDialog1(true);
    setDocumentName(["EXCEL"]);
  };

  const handleClose1 = () => {
    setOpenDialog1(false);
    setDocumentName("");
    setFileName("");
    setFileNameError("");
  };
  const handleChangeFileName = (event) => {
    setFileNameError("");
    setFileName(
      event.target.value.replace(
        new RegExp(/[*#$%!~^&`(){}<>?/\\:;""'|]/gm),
        ""
      )
    );
  };
  const exportAllWorkshop = () => {
    // setDocumentName(["EXCEL"])
    if (fileName === "") {
      setFileNameError("Please Enter the the File Name");
    } 

    // if(documentName.length===0){
    //   setDocumentError("select the file type");
    // }
    else {
      setFileNameError("");
      // setDocumentError("");
      // let URL =
      //   Constant.BASE_URL +
      //   Constant.DOWNLOAD_WORKSHOP_BY_ID +
      //   "?workshopId=" +
      //   workshopId +
      //   "&projectId=" +
      //   projectId +
      //   "&fileName=" +
      //   fileName +
      //   "&fileType=" +
      //   documentName[0];
      // Api.downloadWorkshopById(URL)
      //   .then(
      //     (blob) =>
      //       fileDownload(
      //         blob,
      //         fileName + ".xlsx",
      //         "text/xlsx;charset=utf-8"
      //       ),
      //     handleClose()
      //   )
      //   .catch((err) => {
      //     console.log(err.message);
      //   });
      const data={
        projectId: projectId,
        clientId: clientId,
        workshopId: props.workshopId,
        status: props.status,
        l1ProcessId: props.L1Process,
        l2ProcessId: props.L2Process,
        l3ProcessId: props.L3Process,
        fileType: documentName[0],
        fileName: fileName
      }
      console.log(data);
      Api.Export_All_PainPoints(Constant.EXPORT_ALL_WORKSHOP,data).then(
        (blob) =>
            documentName[0] === "pdf"
              ? fileDownload(blob, fileName + ".pdf", "text/pdf;charset=utf-8")
              : fileDownload(
                  blob,
                  fileName + ".xlsx",
                  "text/xlsx;charset=utf-8"
                ),
                handleClose1()
      )
      .catch((err) => {
        console.log(err.message);
      });
      
    }
   
  
  };



  const handleChange = (event) => {
    const {
      target: { value },
    } = event;
    setDocumentName(
      // On autofill we get a stringified value.
      typeof value === "string" ? value.split(",") : value
    );
  };
  function getStyles(name, personName, theme) {
    return {
      fontWeight:
        personName.indexOf(name) === -1
          ? theme.typography.fontWeightRegular
          : theme.typography.fontWeightMedium,
    };
  }

  return (
    <>
      <Button
        className="exportbtn"
        variant="contained"
        onClick={handleClickOpen1}
      >
        Export Data
      </Button>

      <Dialog
        open={openDialog1}
        onClose={handleClose1}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title" style={{ fontFamily: "Ubuntu" }}>
          Export As
        </DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            <Typography
              style={{
                color: "black",
                fontFamily: "Ubuntu",
                marginBottom: "10px",
              }}
            >
              Specify a File Name
            </Typography>
            <FormControl sx={{ mb:3, width: 500}}>
              <OutlinedInput
                placeholder=""
                value={fileName}
                onChange={handleChangeFileName}
              />
              <span style={{ color: "red", fontSize: "10px" }}>
                {fileNameError}
              </span>
            </FormControl>

            <Typography style={{ color: "black", fontFamily: "Ubuntu" }}>
              Filetype
            </Typography>
            <FormControl sx={{  width: 500}}>
              <Select
                displayEmpty
                value={documentName}
                onChange={handleChange}
                input={<OutlinedInput />}
                renderValue={(selected) => {
                  if (selected.length === 0) {
                    return <em></em>;
                  }

                  return selected.join(", ");
                }}
                MenuProps={MenuProps}
                inputProps={{ "aria-label": "Without label" }}
              >
                {/* <MenuItem disabled value="">
                    <em>Placeholder</em>
                  </MenuItem> */}
                {documentType.map((name) => (
                  <MenuItem 
                    key={name}
                    value={name}
                    style={getStyles(name, documentName, theme)}
                  >
                    {name}
                  </MenuItem>
                ))}
              </Select>
              {/* <span style={{ color: "red", fontSize: "10px" }}>
                {documentError}
              </span> */}
            </FormControl>
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose1}>cancel</Button>

          <Button onClick={exportAllWorkshop}>Export</Button>
        </DialogActions>
        {/* export_all_painPoints */}
      </Dialog>
    </>
  );
}
export default ExportPainPoint;
