import React, { useState, useEffect } from "react";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import { Typography } from "@mui/material";
import Button from "@mui/material/Button";
import "./PainPoints.css";
import * as Api from "../../comman/api";
import * as Constant from "../../comman/constant";
import TextField from "@mui/material/TextField";
import Autocomplete from "@mui/material/Autocomplete";
import { useSelector } from "react-redux";
const ITEM_HEIGHT = 50;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 200,
    },
  },
};
export const PainPointFilter = (props) => {
  const [workshopList, setWorkshopList] = useState([]);
  const [L1ProcessList, setL1ProcessList] = useState([]);
  const [L2ProcessList, setL2ProcessList] = useState([]);
  const [L3ProcessList, setL3ProcessList] = useState([]);
  const [workshopName, setWorkshopName] = useState("");
  const [L1ProcessError, setL1ProcessError] = useState("");
  const projectId = useSelector(
    (state) => state.questionnaireReducer.projectId
  );

  useEffect(() => {
    getL1ProcesList();
    getWorkshopList("");
  }, []);

  useEffect(() => {
    if (props.L1Process !== "") {
      getL2ProcesList();
      setL1ProcessError("");
    }
  }, [props.L1Process]);

  useEffect(() => {
    if (props.L2Process !== "") getL3ProcesList();
  }, [props.L2Process]);

  const resetFilter = () => {
    setWorkshopName("");
    props.setL1Process("");
    props.setL2Process("");
    props.setL3Process("");
    props.setStatus("");
    props.setWorkshopId("");
    props.setWorkshopName("");
    props.resetTable();
  };

  const getWorkshopList = (value) => {
    let URL =
      Constant.WORKSHOP_LIST +
      "?workShopName=" +
      value +
      "&projectId=" +
      projectId;
    Api.getWorkshops(URL).then((res) => {
      setWorkshopList(res);
    });
  };
  const getL1ProcesList = () => {
    Api.getL1Process(
      Constant.L1_PPROCESS_LIST + "?projectId=" + projectId
    ).then((res) => {
      setL1ProcessList(res);
    });
  };
  const getL2ProcesList = () => {
    let URL =
      Constant.L2_PPROCESS_LIST +
      "?id=" +
      props.L1Process +
      "&projectId=" +
      projectId;
    Api.getL2Process(URL).then((res) => {
      setL2ProcessList(res);
    });
  };
  const getL3ProcesList = () => {
    let URL =
      Constant.L3_PPROCESS_LIST +
      "?id=" +
      props.L2Process +
      "&projectId=" +
      projectId;
    Api.getL3Process(URL).then((res) => {
      setL3ProcessList(res);
    });
  };

  const handleChangeL1Process = (event) => {
    props.setL1Process(event.target.value);
    props.setL2Process("");
    props.setL3Process("");
  };
  const handleChangeL2Process = (event) => {
    props.setL2Process(event.target.value);
    props.setL3Process("");
  };
  const handleChangeL3Process = (event) => {
    props.setL3Process(event.target.value);
  };
  const handleChangeWorkshopName = (value, id) => {
    let abc = value.replace(new RegExp(/[*#$%!~^&`(){}<>?/\\:;""'|]/gm), "");

    setWorkshopName(abc);
    // props.setWorkshopId(value.workShopId);
    props.setWorkshopId(id);
    props.setWorkshopName(abc);
    // console.log(value + id);
  };

  return (
    <React.Fragment>
      <div className="painpoint-drop-input-div">
        <FormControl sx={{ m: 1, maxWidth: 200, width: 200, mt: 3 }}>
          <Typography className="painpoint-input-div-type">
            Workshop Name
          </Typography>
          <Autocomplete
            id="size-small-standard"
            // size="small"
            freeSolo
            variant="outlined"
            value={workshopName}
            inputValue={workshopName}
            placeholder=""
            inputProps={{ autoComplete: "off" }}
            onChange={(e, newValue) => {
              handleChangeWorkshopName(
                newValue.workshopName,
                newValue.workShopId
              );
            }}
            options={workshopList}
            getOptionLabel={(option) => option.workshopName || ""}
            renderInput={(params) => (
              <TextField
                {...params}
                variant="outlined"
                value={workshopName}
                onChange={(e) => {
                  handleChangeWorkshopName(e.target.value, "");
                }}
              />
            )}
            disableClearable
          />
        </FormControl>
        <FormControl
          sx={{ m: 1, marginTop: "20px", maxWidth: 200, width: 200, mt: 3 }}
        >
          <Typography className="painpoint-input-div-type">
            L1 Process
          </Typography>
          <Select
            className="dropdown-font"
            labelId="demo-simple-select-label"
            id="demo-simple-select"
            MenuProps={MenuProps}
            value={props.L1Process}
            onChange={handleChangeL1Process}
            placeholder="Select"
          >
            <MenuItem className="menu-List-li" value="">
              Select L1 Process
            </MenuItem>
            {L1ProcessList.map((obj) => (
              <MenuItem className="menu-List-li" key={obj.id} value={obj.id}>
                {obj.description}
              </MenuItem>
            ))}
          </Select>
          <span style={{ color: "red", fontSize: "10px" }}>
            {L1ProcessError}
          </span>
        </FormControl>
        <FormControl sx={{ m: 1, maxWidth: 200, width: 200, mt: 3 }}>
          <Typography className="painpoint-input-div-type">
            L2 Process
          </Typography>
          <Select
            labelId="demo-simple-select-label"
            id="demo-simple-select"
            value={props.L2Process}
            MenuProps={MenuProps}
            onChange={handleChangeL2Process}
          >
            <MenuItem className="menu-List-li" value="">
              Select L2 Process
            </MenuItem>

            {L2ProcessList.map((obj) => (
              <MenuItem className="menu-List-li" key={obj.id} value={obj.id}>
                {obj.description}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
        <FormControl sx={{ m: 1, maxWidth: 200, width: 200, mt: 3 }}>
          <Typography className="painpoint-input-div-type">
            L3 Process
          </Typography>
          <Select
            labelId="demo-simple-select-label"
            id="demo-simple-select"
            value={props.L3Process}
            MenuProps={MenuProps}
            onChange={handleChangeL3Process}
          >
            <MenuItem className="menu-List-li" value="">
              Select L3 Process
            </MenuItem>
            {L3ProcessList.map((obj) => (
              <MenuItem className="menu-List-li" key={obj.id} value={obj.id}>
                {obj.description}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
        <FormControl sx={{ m: 1, maxWidth: 200, width: 200, mt: 3 }}>
          <Typography className="painpoint-input-div-type">Status</Typography>
          <Select
            labelId="demo-simple-select-label"
            id="demo-simple-select"
            value={props.status}
            onChange={(e) => props.setStatus(e.target.value)}
          >
            <MenuItem className="menu-List-li" value="In Progress">
              In Progress
            </MenuItem>
            <MenuItem className="menu-List-li" value="Draft Complete">
              Draft Complete
            </MenuItem>
            <MenuItem className="menu-List-li" value="Complete">
              Complete
            </MenuItem>
          </Select>
        </FormControl>
        <FormControl
          className="clear-apply"
          sx={{ m: 1, maxWidth: 200, width: 200, mt: 3, marginTop: 5 }}
        >
          <span className="filter-data-button">
            <Button variant="outlined" onClick={resetFilter}>
              Clear
            </Button>
            <Button
              variant="contained"
              onClick={() => {
                props.getFilterData("apply");
              }}
            >
              Apply
            </Button>
          </span>
        </FormControl>
      </div>
    </React.Fragment>
  );
};
