import React, { useState, Suspense } from "react";
import Navbar from "../../components/Navbar/Navbar";
import Leftbar from "../../components/Leftbar/Leftbar";
import { Grid } from "@mui/material";
import { ThemeProvider } from "@mui/material";
import { theme } from "../../theme";
import { PainPointFilter } from "./PainPointFilter";
import { PainPointsTable } from "./PainPointsTable";
import "./PainPoints.css";
import { useSelector } from "react-redux";
import * as Api from "../../comman/api";
import * as Constant from "../../comman/constant";
const PainPoints = (props) => {
  const [filterTableData, setFilterTableData] = useState([]);
  const [pointList, setPointList] = useState([]);
  const [workshopId, setWorkshopId] = useState("");
  const [workshopName, setWorkshopName] = useState("");
  const [L1Process, setL1Process] = useState("");
  const [L2Process, setL2Process] = useState("");
  const [L3Process, setL3Process] = useState("");
  const [status, setStatus] = useState("");
  const projectId = useSelector(
    (state) => state.questionnaireReducer.projectId
  );
  const clientId = useSelector((state) => state.questionnaireReducer.clientId);

  const getFilterData = (eventName) => {
    console.log(workshopId);
    setFilterTableData([]);
    setPointList([]);
    let data = {
      projectId: projectId,
      clientId: clientId,
      workshopId: eventName !== "Clear" ? workshopId : "",
      workshopName: eventName !== "Clear" ? workshopName : "",
      status: eventName !== "Clear" ? status : "",
      l1ProcessId: eventName !== "Clear" ? L1Process : "",
      l2ProcessId: eventName !== "Clear" ? L2Process : "",
      l3ProcessId: eventName !== "Clear" ? L3Process : "",
    };
    let list = [];
    let workshopObj = [];
    Api.getPainPointFilterData(Constant.PAIN_POINT_FILTER_DATA, data).then(
      (res) => {
        res.map((value, index) => {
          if (Array.isArray(value)) {
            if (value.length) {
              list = [...list, ...value];
            }
          } else {
            workshopObj.push(value);
          }
        });
        workshopObj.map((value, index) => {
          value.painPoints = [];
          value.improvementOpportunity = [];
          list.map((value1, index1) => {
            if (
              value.workShopId === value1.workShopId &&
              value1.type === "PainPoint"
            ) {
              value.painPoints.push(value1);
            }
            if (
              value.workShopId === value1.workShopId &&
              value1.type === "ImprovementOpportunity"
            ) {
              value.improvementOpportunity.push(value1);
            }
          });
        });
        console.log(workshopObj);
        setPointList(list);
        setFilterTableData(workshopObj);
      }
    );
  };
  const resetTable = () => {
    setPointList([]);
    setFilterTableData([]);
  };

  return (
    <div className="painpoint-load">
      <Navbar />
      <Grid container>
        <Grid item sm={0.8}>
          <Leftbar />
        </Grid>
        <Grid item sm={11.2}>
          <div className="pain-point">
            <Suspense fallback="loading...">
              <ThemeProvider theme={theme}>
                <Grid container style={{ marginTop: "10px" }}>
                  <Grid item xs={12}>
                    <div className="title">
                      <h1>{"Pain Points & Improvement Opportunities"}</h1>
                    </div>
                    <PainPointFilter
                      getFilterData={getFilterData}
                      setWorkshopId={setWorkshopId}
                      setWorkshopName={setWorkshopName}
                      setL1Process={setL1Process}
                      setL2Process={setL2Process}
                      setL3Process={setL3Process}
                      setStatus={setStatus}
                      status={status}
                      workshopId={workshopId}
                      L1Process={L1Process}
                      L2Process={L2Process}
                      L3Process={L3Process}
                      resetTable={resetTable}
                    />
                    <PainPointsTable
                      filterTableData={filterTableData}
                      pointList={pointList}
                      getFilterData={getFilterData}
                      status={status}
                      workshopId={workshopId}
                      L1Process={L1Process}
                      L2Process={L2Process}
                      L3Process={L3Process}
                    />
                  </Grid>
                </Grid>
              </ThemeProvider>
            </Suspense>
          </div>
        </Grid>
      </Grid>
    </div>
  );
};
export default PainPoints;
