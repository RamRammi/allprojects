import React from "react";
import { useState, useEffect } from "react";
import "./AccordionPainPoints.css";
import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import Typography from "@mui/material/Typography";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import { TextField } from "@mui/material";
import Button from "@mui/material/Button";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import OutlinedInput from "@mui/material/OutlinedInput";
import MenuItem from "@mui/material/MenuItem";
import { useTheme } from "@mui/material/styles";
import TextareaAutosize from "@mui/base/TextareaAutosize";
import Switch from "@mui/material/Switch";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import Box from "@mui/material/Box";
import Dialog from "@mui/material/Dialog";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import EditOutlinedIcon from "@mui/icons-material/EditOutlined";
import * as Api from "../../comman/api";
import * as Constant from "../../comman/constant";
import { useSelector, useDispatch } from "react-redux";
import { useNavigate, useParams } from "react-router-dom";
import SuccssMsg from "../../components/AlertBox/SuccessMsg";
import WarningMsg from "../../components/AlertBox/WarningMsg";
import ClearIcon from "@mui/icons-material/Clear";
const ITEM_HEIGHT = 58;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};

function getStyles(name, personName, theme) {
  return {
    fontWeight:
      personName.indexOf(name) === -1
        ? theme.typography.fontWeightRegular
        : theme.typography.fontWeightMedium,
    fontSize: "12px",
  };
}

const label = { inputProps: { "aria-label": "Switch demo" } };

const EditAccordionPainPoints = () => {
  const projectId = useSelector(
    (state) => state.questionnaireReducer.projectId
  );
  const projectName = useSelector(
    (state) => state.questionnaireReducer.projectName
  );
  const clientId = useSelector((state) => state.questionnaireReducer.clientId);
  const userId = useSelector((state) => state.questionnaireReducer.userId);
  const theme = useTheme();
  const dispatch = useDispatch();
  const [workshopName, setWorkshopName] = useState("");
  const [open, setOpen] = useState(false);
  const [openDialog1, setOpenDialog1] = useState(false);
  const [openDialog2, setOpenDialog2] = useState(false);
  const [painPointValue, setPainPointValue] = useState([]);
  const [editMode, setEditMode] = useState(false);
  const [EditId, setEditId] = useState();
  const [description, setDescription] = useState("");
  const [improvementValue, setImprovementValue] = useState([]);
  const [editModeImprovement, setEditModeImprovement] = useState(false);
  const [EditIdImprovement, setEditIdImprovement] = useState();
  const [descriptionImprovement, setDescriptionImprovement] = useState("");
  const [successMessage, setSuccessMessage] = React.useState("File Saved");
  const [showWarningBox, setShowWarningBox] = React.useState(false);
  const [showAlertBox, setShowAlertBox] = React.useState(false);
  const [warningMessage, setWarningMessage] = React.useState("");
  const [documentName1, setDocumentName1] = React.useState([]);
  const [openDelete, setOpenDelete] = useState("");
  const [cancelButton, setCancelButton] = useState(false);

  const [textFieldPainPoint, setTextFieldPainPoint] = useState("");
  const [textFieldImprovement, settextFieldImprovement] = useState("");
  const [error, setError] = useState("");
  const [errorL1, setErrorL1] = useState("");
  const [L1ProcessList, setL1ProcessList] = useState([]);
  const [L2ProcessList, setL2ProcessList] = useState([]);
  const [L3ProcessList, setL3ProcessList] = useState([]);
  const [L1Process, setL1Process] = useState("");
  const [L2Process, setL2Process] = useState("");
  const [L3Process, setL3Process] = useState("");
  const [statusChange, setStatusChange] = useState([]);
  const [AsValue, setAsIsValue] = useState("");
  const [toBe, setToBeValue] = useState("");
  const [notes, setNotes] = useState("");

  const [L1ProcessName, setL1ProcessName] = useState("");
  const [L2ProcessName, setL2ProcessName] = useState("");
  const [L3ProcessName, setL3ProcessName] = useState("");

  const [L1SequenceNumber, setL1SequenceNumber] = useState("");
  const [L2SequenceNumber, setL2SequenceNumber] = useState("");
  const [L3SequenceNumber, setL3SequenceNumber] = useState("");

  const [painPointObj, setPainPointObj] = useState({});
  const [improvementObj, setImprovementObj] = useState({});
  const [L1ProcessListPopup, setL1ProcessListPopup] = useState([]);
  const [L2ProcessListPopup, setL2ProcessListPopup] = useState([]);
  const [L3ProcessListPopup, setL3ProcessListPopup] = useState([]);

  const [processChange, setProcessChange] = useState(false);

  const [openSave, setOpenSave] = useState(false);
  const [isChanged, setIsChanged] = useState(false);
  const [disableYesButton, setDisableYesButton] = useState(false);

  const { id } = useParams();
  const navigate = useNavigate();

  useEffect(() => {
    getL1ProcesList();
    viewpainpoint();
  }, []);
  useEffect(() => {
    getL3ProcesListPopUp(painPointObj.l2ProcessId);
  }, [painPointObj.l2ProcessId]);
  useEffect(() => {
    getL3ProcesListPopUp(improvementObj.l2ProcessId);
  }, [improvementObj.l2ProcessId]);

  useEffect(() => {
    if (L1Process !== "") {
      getL2ProcesList(L1Process);
      getL2ProcesListPopUp(L1Process);
      if (processChange) {
        getPainPointList();
        getImprovementList();
      }
    }
  }, [L1Process]);

  useEffect(() => {
    if (L2Process !== "") {
      getL3ProcesList(L2Process);
      if (processChange) {
        getPainPointList();
        getImprovementList();
      }
    }
  }, [L2Process]);

  const handleChangeL1Popup = (event) => {
    let obj = {
      l1ProcessId: event.target.value,
      l2ProcessId: painPointObj.l2ProcessId,
      l3ProcessId: painPointObj.l3ProcessId,
    };
    setPainPointObj(obj);
  };

  const handleChangeL2Popup = (event) => {
    let obj = {
      l1ProcessId: painPointObj.l1ProcessId,
      l2ProcessId: event.target.value,
      l3ProcessId: painPointObj.l3ProcessId,
    };
    setPainPointObj(obj);
  };
  const handleChangeL3Popup = (event) => {
    let obj = {
      l1ProcessId: painPointObj.l1ProcessId,
      l2ProcessId: painPointObj.l2ProcessId,
      l3ProcessId: event.target.value,
    };
    setPainPointObj(obj);
  };

  const handleChangeL1PopupImprove = (event) => {
    let obj = {
      l1ProcessId: event.target.value,
      l2ProcessId: improvementObj.l2ProcessId,
      l3ProcessId: improvementObj.l3ProcessId,
    };
    setImprovementObj(obj);
  };

  const handleChangeL2PopupImprove = (event) => {
    let obj = {
      l1ProcessId: improvementObj.l1ProcessId,
      l2ProcessId: event.target.value,
      l3ProcessId: improvementObj.l3ProcessId,
    };
    setImprovementObj(obj);
  };

  const handleChangeL3PopupImprove = (event) => {
    let obj = {
      l1ProcessId: improvementObj.l1ProcessId,
      l2ProcessId: improvementObj.l2ProcessId,
      l3ProcessId: event.target.value,
    };
    setImprovementObj(obj);
  };

  const handleDeleteClose = async () => {
    await setOpenDelete(false);
  };

  const openAlertBox = () => {
    setShowAlertBox(true);
  };
  const openWarningBox = () => {
    setShowWarningBox(true);
  };

  const handleClickOpen1 = () => {
    setOpenDialog1(true);
    let addNewPainPointObj = {
      l1ProcessId: L1Process,
      l2ProcessId: L2Process,
      l3ProcessId: L3Process,
    };
    setPainPointObj(addNewPainPointObj);
  };

  const handleClickOpen2 = () => {
    setOpenDialog2(true);
    let addNewImprovementObj = {
      l1ProcessId: L1Process,
      l2ProcessId: L2Process,
      l3ProcessId: L3Process,
    };
    setImprovementObj(addNewImprovementObj);
  };

  const statusValues = ["In Progress", "Draft complete", "Complete"];

  const getL1ProcesList = () => {
    Api.getL1Process(
      Constant.L1_PPROCESS_LIST + "?projectId=" + projectId
    ).then((res) => {
      setL1ProcessList(res);
    });
  };
  const getL2ProcesList = (id) => {
    Api.getL1Process(
      Constant.L2_PPROCESS_LIST + "?id=" + id + "&projectId=" + projectId
    ).then((res) => {
      setL2ProcessList(res);
    });
  };
  const getL3ProcesList = (id) => {
    Api.getL3Process(
      Constant.L3_PPROCESS_LIST + "?id=" + id + "&projectId=" + projectId
    ).then((res) => {
      setL3ProcessList(res);
    });
  };

  const handleChangeL1Process = (event) => {
    setL1Process(event.target.value);
    setProcessChange(true);
    setL2Process("");
    setL3Process("");
    setPainPointValue([]);
    setImprovementValue([]);
    const getL1ProcesList = () => {
      Api.getL1Process(
        Constant.L1_PPROCESS_LIST + "?projectId=" + projectId
      ).then((res) => {
        setL1ProcessList(res);
        // if(res===event.target.value){
        // }
        res.map((value, key) => {
          // console.log(res, "L1 process")
          if (value.id === event.target.value) {
            console.log(value.sequenceNumber);
            console.log(value.description);
            setL1SequenceNumber(value.sequenceNumber);
            setL1ProcessName(value.description);
          }
        });
      });
    };

    const getL2ProcesList = () => {
      let URL =
        Constant.L2_PPROCESS_LIST +
        "?id=" +
        event.target.value +
        "&projectId=" +
        projectId;
      //console.log(URL);
      Api.getL2Process(URL).then((res) => {
        setL2ProcessList(res);
      });
    };
    getL2ProcesList();

    getL1ProcesList();
  };

  const handleChangeL2Process = (event) => {
    console.log(L1Process);
    setProcessChange(true);
    setL3Process("");
    setPainPointValue([]);
    setImprovementValue([]);
    const getL3ProcesList = () => {
      let URL =
        Constant.L3_PPROCESS_LIST +
        "?id=" +
        event.target.value +
        "&projectId=" +
        projectId;
      Api.getL3Process(URL).then((res) => {
        setL3ProcessList(res);
        res.map((value, key) => {
          L2ProcessList.map((l2) => {
            if (l2.id === event.target.value) {
              setL2ProcessName(l2.description);
              setL2SequenceNumber(l2.sequenceNumber);
              console.log(l2.description);
              console.log(l2.sequenceNumber);
            }
          });
        });
      });
    };

    getL3ProcesList();
    setL2Process(event.target.value);
    setL3Process("");
  };
  const handleChangeL3Process = (event) => {
    setL3Process(event.target.value);
    setProcessChange(true);
    setPainPointValue([]);
    setImprovementValue([]);
    L3ProcessList.map((l3) => {
      if (l3.id === event.target.value) {
        console.log(l3.description);
        console.log(l3.sequenceNumber);
        setL3SequenceNumber(l3.sequenceNumber);
        setL3ProcessName(l3.description);
      }
    });
  };

  const handleChangeStatus = (event) => {
    setStatusChange(event.target.value);
    setIsChanged(true);
  };

  const handleAsIs = (e) => {
    if (e.target.value.length >= 1200) {
      window.alert("content should not exceed more than 1200 letters ");
    } else {
      setAsIsValue(e.target.value);
      setIsChanged(true);
    }
  };

  const handleToBe = (e) => {
    if (e.target.value.length >= 1200) {
      window.alert("content should not exceed more than 1200 letters ");
    } else {
      setToBeValue(e.target.value);
      setIsChanged(true);
    }
  };

  const handleNotes = (e) => {
    if (e.target.value.length >= 1200) {
      window.alert("content should not exceed more than 1200 letters ");
    } else {
      setNotes(e.target.value);
      setIsChanged(true);
    }
  };

  function handleEditPainPoint(id, value) {
    setEditMode(true);
    setEditId(id);
    setCancelButton(true);
    setDescription(value);
  }

  function DoneClick() {
    let newArr = [...painPointValue];
    console.log(painPointValue);
    console.log(description);
    newArr.map((value, index) => {
      if (value.ppId === EditId || value.id === EditId) {
        newArr[index].painPointDesc = description;
        console.log(newArr[index]);
      }
    });
    setIsChanged(true);
    setEditId(0);
    setPainPointValue(newArr);
    setEditMode(false);
  }

  function cancelUpdatePainPoint() {
    setEditId(0);
    setEditMode(false);
  }

  //improvement oppurtunities

  function handleImprovementChange(id, value) {
    setCancelButton(true);
    setEditModeImprovement(true);
    setEditIdImprovement(id);
    setDescriptionImprovement(value);
  }

  function updateImprovement() {
    let newArr = [...improvementValue];
    newArr.map((value, index) => {
      if (value.ioId === EditIdImprovement || value.id === EditIdImprovement) {
        newArr[index].improvOppDesc = descriptionImprovement;
      }
    });
    setIsChanged(true);
    setEditIdImprovement(0);
    // setTextFieldPainPoint(newArr.improvOppDesc);
    setImprovementValue(newArr);
    setEditModeImprovement(false);
  }

  function cancelUpdateImprovement() {
    setEditIdImprovement(0);
    setEditModeImprovement(false);
  }

  function handleTogglePainPoint(id, event) {
    console.log(id);
    console.log(painPointValue);
    let newArr = [...painPointValue];
    newArr.map((value, index) => {
      if (value.ppId === id || value.id === id) {
        newArr[index].isApplicable = !newArr[index].isApplicable;
      }
    });
    console.log(newArr);
    setPainPointValue(newArr);
    setIsChanged(true);
  }

  function handleToggleImprovement(id, event) {
    console.log(id);
    let newArr = [...improvementValue];
    newArr.map((value, index) => {
      if (value.ioId === id || value.id === id) {
        newArr[index].isApplicable = !newArr[index].isApplicable;
      }
    });
    setImprovementValue(newArr);
    setIsChanged(true);
  }

  const handleClose1 = () => {
    setOpenDialog1(false);
    setTextFieldPainPoint("");
    setDocumentName1([]);
    setErrorL1("");
    setError("");
    let addNewPainPointObj = {
      l1ProcessId: L1Process,
      l2ProcessId: L2Process,
      l3ProcessId: L3Process,
    };
    setPainPointObj(addNewPainPointObj);
  };

  function handlePainPointText(e) {
    setTextFieldPainPoint(e.target.value);
  }

  function handleImprovementText(e) {
    settextFieldImprovement(e.target.value);
  }

  const handleClose2 = () => {
    setOpenDialog2(false);
    settextFieldImprovement("");
    setDocumentName1([]);
    setErrorL1("");
    setError("");
    let addNewImprovementObj = {
      l1ProcessId: L1Process,
      l2ProcessId: L2Process,
      l3ProcessId: L3Process,
    };
    setImprovementObj(addNewImprovementObj);
  };

  //API call for pain point
  const getPainPointList = () => {
    let URL =
      Constant.PAIN_POINT +
      "?L1ProcessId=" +
      L1Process +
      "&L2ProcessId=" +
      L2Process +
      "&L3ProcessId=" +
      L3Process;
    Api.getPainPoint(URL).then((res) => {
      setPainPointValue(res);
    });
  };

  //API for improvement oppurtunity
  const getImprovementList = () => {
    let URL =
      Constant.IMPROVEMENT_OPPURTUNITY +
      "?L1ProcessId=" +
      L1Process +
      "&L2ProcessId=" +
      L2Process +
      "&L3ProcessId=" +
      L3Process;
    Api.GetMasterImprovementOpportunity(URL).then((res) => {
      setImprovementValue(res);
    });
  };

  const viewpainpoint = () => {
    console.log(id);
    let URL = Constant.VIEW_PAINPOINT + id + `&projectId=` + projectId;

    Api.viewpainpoint(URL).then((res) => {
      setWorkshopName(res.clientworkshops.workshopName);
      setL1Process(res.clientworkshops.l1ProcessId);
      setL2Process(res.clientworkshops.l2ProcessId);
      setL3Process(res.clientworkshops.l3ProcessId);
      setStatusChange(res.clientworkshops.status);
      setAsIsValue(res.clientworkshops.asIs);
      setToBeValue(res.clientworkshops.toBe);
      setNotes(res.clientworkshops.notes);
      setPainPointValue(res.clientpainpoints);
      setImprovementValue(res.clientimprovementopportunities);
      setL1ProcessName(res.clientworkshops.l1ProcessName);
      setL2ProcessName(res.clientworkshops.l2ProcessName);
      setL3ProcessName(res.clientworkshops.l3ProcessName);
      setL1SequenceNumber(res.clientworkshops.l1SequenceNumber);
      setL2SequenceNumber(res.clientworkshops.l2SequenceNumber);
      setL3SequenceNumber(res.clientworkshops.l3SequenceNumber);
      console.log(res);
    });
  };

  //update API

  const updateAPI = (callFrom = "") => {
    let arrPainPoint = [];
    painPointValue.map((value, index) => {
      arrPainPoint.push({
        ppId: value.ppId ? value.ppId : "",
        l1ProcessId: value.l1ProcessId,
        l2ProcessId: value.l2ProcessId,
        l3ProcessId: value.l3ProcessId,
        painPointDesc: value.painPointDesc,
        isApplicable: value.isApplicable,
        createdBy: userId,
        createdDate: "2023-02-28T12:40:24.311Z",
        workShopId: id,
        type: "",
      });
    });

    let arrImprovement = [];
    improvementValue.map((value, index) => {
      arrImprovement.push({
        ioId: value.ioId ? value.ioId : "",
        l1ProcessId: value.l1ProcessId,
        l2ProcessId: value.l2ProcessId,
        l3ProcessId: value.l3ProcessId,
        improvOppDesc: value.improvOppDesc,
        isApplicable: value.isApplicable,
        createdBy: userId,
        createdDate: "2023-02-28T12:40:24.311Z",
        workShopId: id,
        type: "",
      });
    });
    let data = {
      clientworkshops: {
        workShopId: id,
        projectId: projectId,
        clientId: clientId,
        projectName: projectName,
        workshopName: workshopName,
        l1ProcessId: L1Process,
        l2ProcessId: L2Process,
        l3ProcessId: L3Process,
        L1ProcessName: L1ProcessName,
        L2ProcessName: L2ProcessName,
        L3ProcessName: L3ProcessName,
        L1SequenceNumber: L1SequenceNumber,
        L2SequenceNumber: L2SequenceNumber,
        L3SequenceNumber: L3SequenceNumber,
        status: statusChange,
        asIs: AsValue,
        tobe: toBe,
        notes: notes,
        createdBy: userId,
        createdDate: "2023-02-28T12:40:24.311Z",
        type: "",
      },
      clientpainpoints: arrPainPoint,
      clientimprovementopportunities: arrImprovement,
    };

    console.log(data);
    setDisableYesButton(true);
    Api.Update_API_PainPoint(Constant.UPDATE_PAINPOINT, data).then((res) => {
      if (res.code === 1) {
        setSuccessMessage(res.message);
        openAlertBox();
        if (callFrom === "cancel") {
          setTimeout(() => {
            navigate("/painpoints");
          }, 500);
        }
        setDisableYesButton(false);
      } else {
        console.log(res.message);
        setWarningMessage(res.message);
        openWarningBox();
        handleDeleteClose();
        setOpenSave(false);
        setDisableYesButton(false);
      }
      setIsChanged(false);
    });
  };

  const addNewPainPoint = () => {
    // if(textFieldPainPoint===""){
    //    setError("Enter the pain point to submit");
    //    }
    let value = document.getElementById("painpointtext").value;
    if (value !== "") {
      console.log(value);
      let obj = {
        painPointDesc: value,
        id: painPointValue.length + 1,
        l1ProcessId: painPointObj.l1ProcessId,
        l2ProcessId: painPointObj.l2ProcessId,
        l3ProcessId: painPointObj.l3ProcessId,
        isApplicable: true,
      };
      setPainPointValue([...painPointValue, obj]);
      console.log(obj);
      let addNewPainPointObj = {
        l1ProcessId: L1Process,
        l2ProcessId: L2Process,
        l3ProcessId: L3Process,
      };
      setPainPointObj(addNewPainPointObj);
      setIsChanged(true);
    }
    if (textFieldPainPoint === "") {
      console.log("painpointtexterror");
      setError("Enter the pain point to submit");
    }
    if (textFieldPainPoint != "") {
      handleClose1();
    }
    // props.setPainPointValue(newArr);
  };

  const addImrovementOpportunities = () => {
    let value = document.getElementById("improvementOpportunity").value;
    if (value != "") {
      let obj = {
        improvOppDesc: value,
        id: improvementValue.length + 1,
        l1ProcessId: improvementObj.l1ProcessId,
        l2ProcessId: improvementObj.l2ProcessId,
        l3ProcessId: improvementObj.l3ProcessId,
        isApplicable: true,
      };
      console.log(obj);
      setImprovementValue([...improvementValue, obj]);
      let addNewImprovementbj = {
        l1ProcessId: L1Process,
        l2ProcessId: L2Process,
        l3ProcessId: L3Process,
      };
      setImprovementObj(addNewImprovementbj);
      setIsChanged(true);
    }
    if (textFieldImprovement === "") {
      console.log("painpointtexterror");
      setError("Enter the pain point to submit");
    }
    if (textFieldImprovement != "") {
      handleClose2();
    }
  };

  const getL2ProcesListPopUp = (l1ProcessId) => {
    let URL =
      Constant.L2_PPROCESS_LIST +
      "?id=" +
      l1ProcessId +
      "&projectId=" +
      projectId;
    //console.log(URL);
    Api.getL2Process(URL).then((res) => {
      setL2ProcessListPopup(res);
    });
  };
  const getL3ProcesListPopUp = (l2ProcessId) => {
    let URL =
      Constant.L3_PPROCESS_LIST +
      "?id=" +
      l2ProcessId +
      "&projectId=" +
      projectId;
    Api.getL3Process(URL).then((res) => {
      setL3ProcessListPopup(res);
    });
  };

  return (
    <div>
      {/* <span className="header">Workshop</span> */}
      <div className="text-boxes">
        {/* first Accordion */}
        <Accordion>
          <AccordionSummary
            className="Accordion_expend"
            expandIcon={<ExpandMoreIcon className="icon" />}
            aria-controls="panel1a-content"
            id="panel1a-header"
          >
            {" "}
            General
            <Typography className="questionnaire-heading"> </Typography>
          </AccordionSummary>

          <div>
            <FormControl
              sx={{ m: 2, width: 200, mt: 3 }}
              className="filter-input"
            >
              <Typography className="level">
                {" "}
                <span className="required" style={{ color: "red" }}>
                  *
                </span>
                Workshop Name
              </Typography>
              <TextField
                id="outlined-basic"
                // label="Outlined"
                variant="outlined"
                value={workshopName}
                placeholder=""
                MenuProps={MenuProps}
                inputProps={{ autoComplete: "off" }}
                size="small"
                onChange={(e) => {
                  setWorkshopName(
                    e.target.value.replace(
                      new RegExp(/[*#$%!~^&`(){}<>?/\\:;""'|]/gm),
                      ""
                    )
                  );
                  setIsChanged(true);
                }}
              />
            </FormControl>
            <FormControl sx={{ m: 2, maxWidth: 250, width: 250, mt: 3 }}>
              <Typography className="Rightbar_input_drop_typ">
                <span className="required" style={{ color: "red" }}>
                  *
                </span>
                L1 Process
              </Typography>
              <Select
                disabled
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                value={L1Process}
                MenuProps={MenuProps}
                onChange={handleChangeL1Process}
                placeholder="Select"
              >
                <MenuItem value="">Select L1 Process</MenuItem>
                {L1ProcessList.map((obj) => (
                  <MenuItem key={obj.id} value={obj.id}>
                    {obj.description}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            <FormControl sx={{ m: 2, maxWidth: 250, width: 250, mt: 3 }}>
              <Typography className="Rightbar_input_drop_typ">
                L2 Process
              </Typography>
              <Select
                disabled
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                value={L2Process}
                MenuProps={MenuProps}
                onChange={handleChangeL2Process}
              >
                <MenuItem value="">Select L2 Process</MenuItem>

                {L2ProcessList.map((obj) => (
                  <MenuItem key={obj.id} value={obj.id}>
                    {obj.description}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            <FormControl sx={{ m: 2, maxWidth: 250, width: 250, mt: 3 }}>
              <Typography className="Rightbar_input_drop_typ">
                L3 Process
              </Typography>
              <Select
                disabled
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                value={L3Process}
                MenuProps={MenuProps}
                onChange={handleChangeL3Process}
              >
                <MenuItem value="">Select L3 Process</MenuItem>
                {L3ProcessList.map((obj) => (
                  <MenuItem key={obj.id} value={obj.id}>
                    {obj.description}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            <FormControl sx={{ m: 2, maxWidth: 250, width: 250, mt: 3 }}>
              <Typography className="Rightbar_input_drop_typ">
                Status
              </Typography>
              <Select
                displayEmpty
                input={<OutlinedInput />}
                value={statusChange}
                onChange={handleChangeStatus}
                MenuProps={MenuProps}
                inputProps={{ "aria-label": "Without label" }}
              >
                <MenuItem className="menu-List" value=""></MenuItem>
                {statusValues.map((name) => (
                  <MenuItem key={name} value={name} setStatusChange={name}>
                    {name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </div>
        </Accordion>
        {/* second Accordion */}
        <Accordion>
          <AccordionSummary
            className="Accordion_expend"
            expandIcon={<ExpandMoreIcon className="icon" />}
            aria-controls="panel1a-content"
            id="panel1a-header"
          >
            {" "}
            Discovery Findings
            <Typography className="questionnaire-heading"> </Typography>
          </AccordionSummary>
          <div>
            <AccordionDetails className="questionGallary_accordionDetails">
              <div class="textField-accordion">
                <Typography className="synopis-textField_typography">
                  <p className="synopis-textField-span">
                    {/* {obj1.name} */} As-Is
                  </p>
                  <div>
                    <TextareaAutosize
                      maxLength={1200}
                      style={{
                        marginRight: "10px",
                        marginTop: "10px",
                        minWidth: "1350px",
                        padding: "5px 0px 0px 8px",
                        maxWidth: "1350px",
                        minHeight: "50px",
                        border: "1px solid #828282",
                      }}
                      onChange={handleAsIs}
                      value={AsValue}
                      className="synopis-textField-master"
                      id="outlined-basic"
                      variant="outlined"
                      placeholder=""
                      inputProps={{ autoComplete: "off" }}
                    />
                    <span className="text-count">{AsValue.length}/1200</span>
                  </div>
                </Typography>
              </div>
              <div class="textField-accordion">
                <Typography className="synopis-textField_typography">
                  <p className="synopis-textField-span">
                    {/* {obj1.name} */} To-Be
                  </p>
                  <div>
                    <TextareaAutosize
                      style={{
                        marginRight: "10px",
                        marginTop: "10px",
                        minWidth: "1350px",
                        padding: "5px 0px 0px 8px",
                        maxWidth: "1350px",
                        minHeight: "50px",
                        border: "1px solid #828282",
                      }}
                      onChange={handleToBe}
                      value={toBe}
                      className="synopis-textField-master"
                      id="outlined-basic"
                      variant="outlined"
                      placeholder=""
                      inputProps={{ autoComplete: "off" }}
                    />
                    <span className="text-count">{toBe.length}/1200</span>
                  </div>
                </Typography>
              </div>
              <div class="textField-accordion">
                <Typography className="synopis-textField_typography">
                  <p className="synopis-textField-span">
                    {/* {obj1.name} */} Notes
                  </p>
                  <div>
                    <TextareaAutosize
                      style={{
                        marginRight: "10px",
                        marginTop: "10px",
                        minWidth: "1350px",
                        padding: "5px 0px 0px 8px",
                        maxWidth: "1350px",
                        minHeight: "50px",
                        border: "1px solid #828282",
                      }}
                      onChange={handleNotes}
                      value={notes}
                      className="synopis-textField-master"
                      id="outlined-basic"
                      variant="outlined"
                      placeholder=""
                      inputProps={{ autoComplete: "off" }}
                    />
                    <span className="text-count">{notes.length}/1200</span>
                  </div>
                </Typography>
              </div>

              <div></div>
            </AccordionDetails>
          </div>
        </Accordion>
        {/* Third accodion */}
        <Accordion>
          <AccordionSummary
            className="Accordion_expend"
            expandIcon={<ExpandMoreIcon className="icon" />}
            aria-controls="panel1a-content"
            id="panel1a-header"
          >
            {" "}
            Pain points
            <Typography className="questionnaire-heading"> </Typography>
          </AccordionSummary>
          <div>
            <AccordionDetails className="questionGallary_accordionDetails">
              <TableContainer className="scroll-bar-table" component={Paper}>
                <Table sx={{ minWidth: 650 }} aria-label="simple table">
                  <TableHead>
                    <TableRow>
                      <TableCell></TableCell>
                      <TableCell>Pain points</TableCell>
                      <TableCell>Actions</TableCell>
                    </TableRow>
                  </TableHead>

                  <TableBody>
                    {painPointValue.map((row, key) => (
                      <TableRow
                        disable={row.isApplicable ? row.isApplicable : false}
                        key={key}
                        sx={{
                          "&:last-child td, &:last-child th": { border: 0 },
                        }}
                      >
                        <TableBody>
                          <Switch
                            onChange={(e) => {
                              handleTogglePainPoint(
                                row.ppId ? row.ppId : row.id,
                                e.target.value
                              );
                            }}
                            {...label}
                            defaultChecked={
                              row.isApplicable ? row.isApplicable : false
                            }
                          />
                        </TableBody>
                        <TableCell
                          align="left"
                          component="th"
                          scope="row"
                          className={
                            row.isApplicable ? "enable-row" : "disable-row"
                          }
                        >
                          {(editMode && EditId == row.ppId) ||
                          (editMode && EditId == row.id) ? (
                            <>
                              <TextField
                                multiline
                                rows={2}
                                maxRows={3}
                                className="pain-point-textField"
                                fullWidth
                                id="standard-basic"
                                variant="outlined"
                                onChange={(e) => setDescription(e.target.value)}
                                defaultValue={row.painPointDesc}
                                // setDescriptionPainPoint={row.painPointDesc}
                                // value={descriptionPainPoint}
                              ></TextField>
                              <div style={{ display: "flex" }}></div>
                            </>
                          ) : (
                            row.painPointDesc
                          )}
                        </TableCell>
                        <TableCell align="left" component="th" scope="row">
                          {cancelButton === true &&
                          ((editMode && EditId == row.ppId) ||
                            (editMode && EditId == row.id)) ? (
                            <div style={{ display: "flex" }}>
                              <ClearIcon
                                className="clear-button"
                                onClick={cancelUpdatePainPoint}
                              />
                              <Button
                                className="done-button"
                                onClick={DoneClick}
                              >
                                Done
                              </Button>
                            </div>
                          ) : (
                            <EditOutlinedIcon
                              className={
                                row.isApplicable ? "enable-row" : "disable-row"
                              }
                              onClick={() => {
                                handleEditPainPoint(
                                  row.ppId ? row.ppId : row.id,
                                  row.painPointDesc
                                );
                              }}
                            />
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
              <div style={{ margin: "30px 1px 12px 20px" }}>
                <Button
                  variant="outlined"
                  className="pain-point-button"
                  onClick={handleClickOpen1}
                >
                  Add Pain Points
                </Button>
                <Dialog
                  open={openDialog1}
                  onClose={handleClose1}
                  aria-labelledby="alert-dialog-title"
                  aria-describedby="alert-dialog-description"
                >
                  <DialogTitle className="DialogTitle-PP">
                    Add Pain Points
                  </DialogTitle>
                  <DialogContent>
                    <h5 className="DialogContent-h5"> Pain Point</h5>
                    <DialogContentText className="DialogText-PP">
                      <TextField
                        className="textfiled-PP"
                        placeholder="Text Here"
                        id="painpointtext"
                        value={textFieldPainPoint}
                        onChange={handlePainPointText}
                        multiline
                        rows={2}
                        maxRows={3}
                        style={{
                          width: "525px",
                        }}
                      />
                      <p className="error-message">{error}</p>
                      <Box component="form" noValidate autoComplete="off">
                        <FormControl
                          className="PP-FormControl"
                          sx={{ width: 250, float: "left" }}
                        >
                          <Typography className="L1-process">
                            L1 Process{" "}
                          </Typography>

                          <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            value={painPointObj.l1ProcessId}
                            onChange={handleChangeL1Popup}
                            disabled={L1Process ? true : false}
                            MenuProps={MenuProps}
                            placeholder="Select"
                          >
                            <MenuItem value="">Select L1 Process</MenuItem>
                            {L1ProcessList.map((obj) => (
                              <MenuItem
                                //  className="menu-List-li"
                                key={obj.id}
                                value={obj.id}
                              >
                                {obj.description}
                              </MenuItem>
                            ))}
                          </Select>
                        </FormControl>
                        <FormControl
                          className="PP-FormControl"
                          sx={{ width: 250, paddingLeft: "10px" }}
                        >
                          <Typography className="L2-process">
                            L2 Process
                          </Typography>

                          <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select-addpainpoint"
                            value={painPointObj.l2ProcessId}
                            onChange={handleChangeL2Popup}
                            MenuProps={MenuProps}
                            disabled={L2Process ? true : false}
                          >
                            <MenuItem value="">Select L2 Process</MenuItem>

                            {L2ProcessListPopup.map((obj) => (
                              <MenuItem
                                //  className="menu-List-li"
                                key={obj.id}
                                value={obj.id}
                              >
                                {obj.description}
                              </MenuItem>
                            ))}
                          </Select>
                        </FormControl>
                        <FormControl
                          className="PP-FormControl"
                          sx={{ width: 250 }}
                        >
                          <Typography className="L3-process">
                            L3 Process
                          </Typography>

                          <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select-addpainpoint"
                            value={painPointObj.l3ProcessId}
                            onChange={handleChangeL3Popup}
                            MenuProps={MenuProps}
                            disabled={L3Process ? true : false}
                          >
                            <MenuItem value="">Select L3 Process</MenuItem>

                            {L3ProcessListPopup.map((obj) => (
                              <MenuItem
                                //  className="menu-List-li"
                                key={obj.id}
                                value={obj.id}
                              >
                                {obj.description}
                              </MenuItem>
                            ))}
                          </Select>
                        </FormControl>
                      </Box>
                    </DialogContentText>
                  </DialogContent>
                  <DialogActions>
                    <Button
                      variant="outlined"
                      style={{
                        borderRadius: "25px",
                        padding: "5px 10px",
                        margin: "10px 46px 20px 0px",
                        fontSize: "12px",
                      }}
                      onClick={handleClose1}
                    >
                      Cancel
                    </Button>
                    <Button
                      variant="outlined"
                      style={{
                        borderRadius: "25px",
                        padding: "5px 10px",
                        margin: "10px 46px 20px 0px",
                        fontSize: "12px",
                      }}
                      onClick={() => addNewPainPoint()}
                    >
                      OK
                    </Button>
                  </DialogActions>
                </Dialog>
              </div>
            </AccordionDetails>
          </div>
        </Accordion>
        {/* Fourth accodion */}
        <Accordion>
          <AccordionSummary
            className="Accordion_expend"
            expandIcon={<ExpandMoreIcon className="icon" />}
            aria-controls="panel1a-content"
            id="panel1a-header"
          >
            {" "}
            Improvement Opportunities
            <Typography className="questionnaire-heading"> </Typography>
          </AccordionSummary>
          <div>
            <AccordionDetails className="questionGallary_accordionDetails">
              <TableContainer className="scroll-bar-table" component={Paper}>
                <Table sx={{ minWidth: 650 }} aria-label="simple table">
                  <TableHead>
                    <TableRow>
                      <TableCell></TableCell>
                      <TableCell>Improvement oppurtunities</TableCell>
                      <TableCell>Actions</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {improvementValue.map((row, key) => (
                      <TableRow
                        disable={row.isApplicable ? row.isApplicable : false}
                        key={key}
                        sx={{
                          "&:last-child td, &:last-child th": { border: 0 },
                        }}
                      >
                        <TableBody>
                          <Switch
                            {...label}
                            onChange={(e) => {
                              handleToggleImprovement(
                                row.ioId ? row.ioId : row.id,
                                e.target.value
                              );
                            }}
                            {...label}
                            defaultChecked={
                              row.isApplicable ? row.isApplicable : false
                            }
                          />
                        </TableBody>
                        <TableCell
                          align="left"
                          component="th"
                          scope="row"
                          className={
                            row.isApplicable ? "enable-row" : "disable-row"
                          }
                        >
                          {(editModeImprovement &&
                            EditIdImprovement == row.ioId) ||
                          (editModeImprovement &&
                            EditIdImprovement == row.id) ? (
                            <>
                              <TextField
                                className="improvement-textField"
                                multiline
                                rows={2}
                                maxRows={3}
                                fullWidth
                                id="standard-basic"
                                variant="outlined"
                                onChange={(e) =>
                                  setDescriptionImprovement(e.target.value)
                                }
                                defaultValue={row.improvOppDesc}
                              ></TextField>
                              <div style={{ display: "flex" }}></div>
                            </>
                          ) : (
                            row.improvOppDesc
                          )}
                        </TableCell>
                        <TableBody>
                          {cancelButton === true &&
                          ((editModeImprovement &&
                            EditIdImprovement == row.ioId) ||
                            (editModeImprovement &&
                              EditIdImprovement == row.id)) ? (
                            <div style={{ display: "flex" }}>
                              <ClearIcon
                                className="clear-button-imp"
                                onClick={cancelUpdateImprovement}
                              />
                              <Button
                                className="done-button-imp"
                                onClick={updateImprovement}
                              >
                                Done
                              </Button>
                            </div>
                          ) : (
                            <EditOutlinedIcon
                              className={
                                row.isApplicable ? "enable-row" : "disable-row"
                              }
                              onClick={() => {
                                handleImprovementChange(
                                  row.ioId ? row.ioId : row.id,
                                  row.improvOppDesc
                                );
                              }}
                            />
                          )}
                        </TableBody>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
              <div style={{ margin: "30px 1px 12px 20px" }}>
                <Button
                  variant="outlined"
                  className="pain-point-button"
                  onClick={handleClickOpen2}
                >
                  Add Improvement Opportunities
                </Button>
                <Dialog
                  open={openDialog2}
                  onClose={handleClose2}
                  aria-labelledby="alert-dialog-title"
                  aria-describedby="alert-dialog-description"
                >
                  <DialogTitle> Add Improvement Opportunities</DialogTitle>
                  <DialogContent>
                    Improvement Opportunities
                    <DialogContentText>
                      <TextField
                        // disabled={documentName1.length == 0 ? true : false}
                        value={textFieldImprovement}
                        placeholder="Text here"
                        id="improvementOpportunity"
                        onChange={handleImprovementText}
                        multiline
                        rows={2}
                        maxRows={3}
                        style={{
                          width: "540px",
                        }}
                      />
                      <p className="error-message">{error}</p>

                      <Box component="form" noValidate autoComplete="off">
                        <FormControl
                          className="PP-FormControl"
                          sx={{ width: 250, float: "left" }}
                        >
                          <Typography className="L1-process">
                            L1 Process
                          </Typography>
                          <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            value={improvementObj.l1ProcessId}
                            onChange={handleChangeL1PopupImprove}
                            MenuProps={MenuProps}
                            disabled={L1Process ? true : false}
                            placeholder="Select"
                          >
                            <MenuItem value="">Select L1 Process</MenuItem>
                            {L1ProcessList.map((obj) => (
                              <MenuItem
                                //  className="menu-List-li"
                                key={obj.id}
                                value={obj.id}
                              >
                                {obj.description}
                              </MenuItem>
                            ))}
                          </Select>
                        </FormControl>

                        <FormControl
                          className="PP-FormControl"
                          sx={{ width: 250, paddingLeft: "10px" }}
                        >
                          <Typography className="L2-process">
                            L2 Process
                          </Typography>
                          <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select-addpainpoint"
                            value={improvementObj.l2ProcessId}
                            MenuProps={MenuProps}
                            onChange={handleChangeL2PopupImprove}
                            disabled={L2Process ? true : false}
                          >
                            <MenuItem value="">Select L2 Process</MenuItem>

                            {L2ProcessListPopup.map((obj) => (
                              <MenuItem
                                //  className="menu-List-li"
                                key={obj.id}
                                value={obj.id}
                              >
                                {obj.description}
                              </MenuItem>
                            ))}
                          </Select>
                        </FormControl>

                        <FormControl
                          className="PP-FormControl"
                          sx={{ width: 250 }}
                        >
                          <Typography className="L3-process">
                            L3 Process
                          </Typography>

                          <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select-addpainpoint"
                            value={improvementObj.l3ProcessId}
                            MenuProps={MenuProps}
                            onChange={handleChangeL3PopupImprove}
                            disabled={L3Process ? true : false}
                          >
                            <MenuItem value="">Select L3 Process</MenuItem>

                            {L3ProcessListPopup.map((obj) => (
                              <MenuItem
                                //  className="menu-List-li"
                                key={obj.id}
                                value={obj.id}
                              >
                                {obj.description}
                              </MenuItem>
                            ))}
                          </Select>
                        </FormControl>
                      </Box>
                    </DialogContentText>
                  </DialogContent>
                  <DialogActions>
                    <DialogActions>
                      <Button
                        variant="outlined"
                        style={{
                          borderRadius: "25px",
                          padding: "5px 10px",
                          margin: "10px 46px 20px 0px",
                          fontSize: "12px",
                        }}
                        onClick={handleClose2}
                      >
                        Cancel
                      </Button>
                      <Button
                        variant="outlined"
                        style={{
                          borderRadius: "25px",
                          padding: "5px 10px",
                          margin: "10px 46px 20px 0px",
                          fontSize: "12px",
                        }}
                        onClick={() => addImrovementOpportunities()}
                      >
                        OK
                      </Button>
                    </DialogActions>
                  </DialogActions>
                </Dialog>
              </div>
            </AccordionDetails>
          </div>
        </Accordion>
        {/* Fifth Accordion */}

        {/* Footer  */}
        <div className="div-footer">
          <Button className="footer-button" onClick={updateAPI}>
            Save
          </Button>
          <Button
            onClick={() => {
              isChanged ? setOpenSave(true) : navigate("/painpoints");
            }}
            className="footer-button-cancel"
          >
            Cancel
          </Button>
        </div>
      </div>
      <Dialog className="dialog-submit" open={openSave}>
        <DialogTitle
          style={{
            fontFamily: "Ubuntu",
            padding: "10px",
            marginLeft: "10px",
          }}
        >
          Save
        </DialogTitle>
        <DialogContent style={{ fontSize: "14px", fontFamily: "Ubuntu" }}>
          Do you want to save the changes?
        </DialogContent>
        <DialogActions style={{ padding: "30px" }}>
          <Button
            style={{
              borderRadius: "25px",
              textTransform: "capitalize",
              marginRight: "10px",
            }}
            variant="outlined"
            onClick={() => {
              setOpenSave(false);
              navigate("/painpoints");
            }}
          >
            No
          </Button>

          <Button
            style={{
              textTransform: "capitalize",
              borderRadius: "25px",
              backgroundColor: disableYesButton ? "#BFBFBF" : "#0070AD",
              color: "#fff",
              textTransform: "capitalize",
            }}
            onClick={() => {
              updateAPI("cancel");
            }}
            variant="outlined"
            disabled={disableYesButton}
          >
            Yes
          </Button>
        </DialogActions>
      </Dialog>
      <SuccssMsg
        showAlertBox={showAlertBox}
        setShowAlertBox={setShowAlertBox}
        message={successMessage}
      />
      <WarningMsg
        showWarningBox={showWarningBox}
        setShowWarningBox={setShowWarningBox}
        message={warningMessage}
      />
    </div>
  );
};

export default EditAccordionPainPoints;
