import React, { useState, Suspense } from "react";
import Navbar from "../../components/Navbar/Navbar";
import Leftbar from "../../components/Leftbar/Leftbar";
import { Accordion, Grid } from "@mui/material";
import { ThemeProvider } from "@mui/material";
import { theme } from "../../theme";

import EditAccordionPainPoints from "./EditAccordionPainPoints";
// import DeleteiconButtons from "./DeletePopup";

const PainPoints = (props) => {
  return (
    <div className="VDT-Tree_load">
      <Navbar />
      <Grid container>
        <Grid item sm={0.8}>
          <Leftbar />
        </Grid>
        <Grid item sm={11.2}>
          <div className="vdt-hierarchy">
            <Suspense fallback="loading...">
              <ThemeProvider theme={theme}>
                <Grid container style={{ marginTop: "10px" }}>
                  <Grid item xs={12}>
                    <div className="title">
                      <h1>{"Workshop"}</h1>
                    </div>

                    <EditAccordionPainPoints />
                  </Grid>
                </Grid>
              </ThemeProvider>
            </Suspense>
          </div>
        </Grid>
      </Grid>
    </div>
  );
};
export default PainPoints;
