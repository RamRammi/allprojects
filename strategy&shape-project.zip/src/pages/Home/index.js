import React from "react"
import Container from "@mui/material/Container"
import { Link, useNavigate } from "react-router-dom"
import { Redirect } from "react-router"
import styles from "./Home.module.css"
import Grid from "@mui/material/Grid"
import Paper from "@mui/material/Paper"
import Navbar from "../../components/Navbar/Navbar"

const Home = () => {
  const navigate = useNavigate()
  const questionnairePage = () => {
    navigate({
      pathname: "/shape-program",
    })
  }
  return (
    <Grid className={styles.shape_css} sx={{ flexGrow: 0 }}>
      <Navbar />
      <Paper variant="outlined" square className={styles.paperContainer}>
        <Grid container spacing={2}>
          <Grid className={styles.bannerText} item xs={8}>
            <h1>LOREM IPSUM DOLOR SIT AMET, CONSECTETUR.</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Curabitur tempus urna at turpis condimentum lobortis. Lorem ipsum dolor sit amet, consectetur adipiscing elit...</p>
          </Grid>
          <Grid item xs={4}></Grid>
        </Grid>
      </Paper>

      <Container maxWidth="md">
        <Grid container sx={{ marginTop: "20px" }} spacing={2}>
          <Grid item xs={6}>
            <div className={styles.imgWrapper}>
              <h2 className={styles.homeHeadings}>Strategy Navigator</h2>
              <img src="img/chess.jpg" className={styles.imgCircle} onClick={() => questionnairePage()} />
            </div>
            <div className={styles.containerSideLeftBorder}></div>
            <div className={styles.conatinerWrapperLeft}></div>
          </Grid>
          <Grid item xs={6}>
            <div className={styles.description} style={{ marginLeft: "30px" }}>
              <small>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Curabitur tempus urna at turpis condimentum lobortis. Lorem ipsum dolor sit amet, consectetur adipiscing elit...</small>
              {/* <Link to="/shape-program"> */}
              <button className={styles.buttonMore} onClick={() => questionnairePage()}>
                Know More
              </button>
              {/* </Link> */}
            </div>
          </Grid>
        </Grid>

        <Grid container sx={{ marginTop: "20px" }} spacing={0}>
          <Grid item xs={6}>
            <div className={styles.description} style={{ marginRight: "80px" }}>
              <small>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. <br />
                <br />
                Curabitur tempus urna at turpis condimentum lobortis. Lorem ipsum dolor sit amet, consectetur adipiscing elit...
              </small>
              <button className={styles.buttonMore}>Know More</button>
            </div>
          </Grid>
          <Grid item xs={6}>
            <div className={styles.imgWrapper}>
              <h2 className={styles.homeHeadings} style={{ left: "80px" }}>
                CHANGE MANAGEMENT
              </h2>
              <img src="img/chess.jpg" className={styles.imgCircle} style={{ float: "left " }} />
            </div>
            <div className={styles.containerSideRightBorder}></div>
            <div className={styles.conatinerWrapperRight}></div>
          </Grid>
        </Grid>

        <Grid container sx={{ marginTop: "20px" }} spacing={2}>
          <Grid item xs={6}>
            <div className={styles.imgWrapper}>
              <h2 className={styles.homeHeadings}>DESIGN BUILD TEST</h2>
              <img src="img/chess.jpg" className={styles.imgCircle} />
            </div>
            <div className={styles.containerSideLeftBottomBorder}></div>
            <div className={styles.conatinerWrapperLeft}></div>
          </Grid>
          <Grid item xs={6}>
            <div className={styles.description} style={{ marginLeft: "30px" }}>
              <small>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Curabitur tempus urna at turpis condimentum lobortis. Lorem ipsum dolor sit amet, consectetur adipiscing elit...</small>
              <button className={styles.buttonMore}>Know More</button>
            </div>
          </Grid>
        </Grid>

        <Grid container sx={{ marginTop: "20px", marginBottom: "50px" }} spacing={0}>
          <Grid item xs={6}>
            <div className={styles.description} style={{ marginRight: "80px" }}>
              <small>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. <br />
                <br />
                Curabitur tempus urna at turpis condimentum lobortis. Lorem ipsum dolor sit amet, consectetur adipiscing elit...
              </small>
              <button className={styles.buttonMore}>Know More</button>
            </div>
          </Grid>
          <Grid item xs={6}>
            <div className={styles.imgWrapper}>
              <h2 className={styles.homeHeadings} style={{ left: "80px" }}>
                VALUE MANAGEMENT
              </h2>
              <img src="img/chess.jpg" className={styles.imgCircle} style={{ float: "left " }} />
            </div>
          </Grid>
        </Grid>
      </Container>
    </Grid>
  )
}

export default Home
