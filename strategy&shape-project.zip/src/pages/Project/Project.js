import React from "react";
import { Grid } from "@mui/material";
import "./Project.css";
import Navbar from "../../components/Navbar/Navbar";
import Leftbar from "../../components/Leftbar/Leftbar";
import { useLocation } from "react-router-dom";
import Button from "@mui/material/Button";
import * as Api from "../../comman/api";
import * as Constant from "../../comman/constant";
import TabsList from "../../components/Tabs/Tabs";
import { useSelector, useDispatch } from "react-redux";
const Project = () => {
  const location = useLocation();
  const pageName = "project";
  const [filterField, setFilterField] = React.useState([]);
  const projectName = useSelector(
    (state) => state.questionnaireReducer.projectName
  );
  // React.useEffect(() => {
  //   getSelectedFilters();
  // }, []);

  // const getSelectedFilters = () => {
  //   let URL = Constant.GET_PROJECT_DOCUMENT_LIST;
  //   Api.getProjectDocumentList(URL).then((res) => {
  //     setFilterField(res);
  //   });
  // };
  return (
    <React.Fragment>
      <Navbar pageName="project" />

      <Grid container>
        <Grid item sm={0.8}>
          <Leftbar />
        </Grid>
        <Grid item sm={11.2}>
          {/* <div> */}
          <div className="Project_css">
            <h2 className="Project_css_h2">
              Questionnaire{" "}
              <span
                style={{
                  color: "#2B0A3D",
                  fontSize: "20px",
                  paddingLeft: "19px",
                  marginLeft: "20px",
                  color: "#2B0A3D",
                  fontSize: "16px",
                  borderLeft: "1px solid #828282",
                }}
              >
                {" "}
                {projectName}
              </span>
            </h2>
          </div>
          <TabsList filterField={filterField} />
          {/* </div> */}
        </Grid>
      </Grid>
    </React.Fragment>
  );
};

export default Project;
