import React, { useState } from "react";
import PlatformNav from "../../components/PlatformNav/PlatformNav";
import StrategyNav from "../../components/StrategyNav/StrategyNav";
import Navbar from "../../components/Navbar/Navbar";
import Filters from "../../components/Filters/FilterData";
import CenterRepositoryTable from "../../components/Table/CenterRepositoryTable";
import SearchBar from "../../components/SearchBar/SearchBar";
import "./CenterRepository.css";
import { Grid } from "@mui/material";
import Leftbar from "../../components/Leftbar/Leftbar";
const CenterRepository = () => {
  const [searchStr, setSearchStr] = React.useState("");
  const [filterField, setFilterField] = React.useState([]);

  const searchText = (event) => {
    setSearchStr(event.target.value);
  };
  const [projectsMessage, setProjectsMessage] = useState("");
  const [functionsMessage, setfunctionsMessage] = useState("");
  const [industryMessage, setIndustryMessage] = useState("");
  const [designationMessage, setDesignationMessage] = useState("");

  const getSelectedFilters = (
    projects,
    functions,
    industry,
    designation,
    eventName
  ) => {
    console.log(
      "Project:",
      projects,
      "Function:",
      functions,
      "Industry:",
      industry,
      "Designation:",
      designation
    );
    let filterVal = [];
    filterVal.push(projects, functions, industry, designation);
    if (eventName === "onclick") {
      if (industry === 0) {
        // if (projects === 0) {
        //   setProjectsMessage("Please select the Project");
        // }
        setIndustryMessage("Please select the Industry");
      }
      if (functions === 0) {
        setfunctionsMessage("Please select the Function");
      }
      // if (designation === 0) {
      //   setDesignationMessage("Please select the Designation");
      // }
      if (industry !== 0 && functions !== 0) {
        getFilterTableData(industry, functions, designation);
      }
    }
    // } else if (eventName === "industry") {
    //   getFilterTableByIndustry(industry);
    // } else if (eventName === "function") {
    //   getFilterTableByFunction(industry, functions);
    // } else if (eventName === "designation") {
    //   getFilterTableByDesignation(industry, functions, designation);
    // }
  };

  const getFilterTableData = async (industryId, functionId, designationId) => {
    const result = await fetch(
      "http://inmumvm25745601:90/api/Project/GetProjectListById?industryId=" +
        industryId +
        "&functionId=" +
        functionId +
        "&designationId=" +
        designationId
    );
    const data = await result.json();
    console.log(data);
    setFilterField(await data);
  };
  const getFilterTableByIndustry = async (industryId) => {
    const result = await fetch(
      "http://INMUMVM25745601:90/api/Project/GetProjectListByIndustryId?industryId=" +
        industryId
    );
    const data = await result.json();
    console.log(data);
    setFilterField(await data);
  };
  const getFilterTableByFunction = async (industryId, functionId) => {
    const result = await fetch(
      "http://INMUMVM25745601:90/api/Project/GetProjectListByFunctionId?industryId=" +
        industryId +
        "&functionId=" +
        functionId
    );
    const data = await result.json();
    console.log(data);
    setFilterField(await data);
  };
  const getFilterTableByDesignation = async (
    industryId,
    functionId,
    designationId
  ) => {
    const result = await fetch(
      "http://INMUMVM25745601:90/api/Project/GetProjectListByDesignationId?industryId=" +
        industryId +
        "&functionId=" +
        functionId +
        "&designationId=" +
        designationId
    );
    const data = await result.json();
    console.log(data);
    setFilterField(await data);
  };
  const resetTable = () => {
    setFilterField([]);
  };
  return (
    <React.Fragment>
      <Navbar />
      <Grid container>
        <Grid item sm={0.6}>
          <Leftbar />
        </Grid>
        <Grid item sm={11.4} style={{ display: "inline-block" }}>
          {/* <div> */}
            <div className="Rightbar_css">
              <h2 className="Rightbar_h2">Central Repository</h2>
            </div>
            {/* <PlatformNav /> */}
            {/* <StrategyNav /> */}
            {/* <Filters
              getSelectedFilters={getSelectedFilters}
              getFilterTableByIndustry={getFilterTableByIndustry}
              getFilterTableByFunction={getFilterTableByFunction}
              getFilterTableByDesignation={getFilterTableByDesignation}
              resetTable={resetTable}
              projectsMessage={projectsMessage}
              functionsMessage={functionsMessage}
              designationMessage={designationMessage}
              industryMessage={industryMessage}
              setIndustryMessage={setIndustryMessage}
              setProjectsMessage={setProjectsMessage}
              setfunctionsMessage={setfunctionsMessage}
              setDesignationMessage={setDesignationMessage}
              pageName="centerRepo"
            /> */}
            <SearchBar searchText={searchText} />
            <CenterRepositoryTable
              searchStr={searchStr}
              filterField={filterField}
            />
          {/* </div> */}
        </Grid>
      </Grid>
    </React.Fragment>
  );
};

export default CenterRepository;
