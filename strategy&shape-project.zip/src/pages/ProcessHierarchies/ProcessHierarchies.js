import React, { useState, useEffect } from "react"
import { Grid } from "@mui/material"
import "./process.css"
import FormGroup from "@mui/material/FormGroup"
import FormControlLabel from "@mui/material/FormControlLabel"
import MenuItem from "@mui/material/MenuItem"
import FormControl from "@mui/material/FormControl"
import Select from "@mui/material/Select"
import Button from "@mui/material/Button"
import Modal from "@mui/material/Modal"
import Box from "@mui/material/Box"
import Table from "@mui/material/Table"
import TableBody from "@mui/material/TableBody"
import TableCell from "@mui/material/TableCell"
import TableContainer from "@mui/material/TableContainer"
import TableHead from "@mui/material/TableHead"
import TableRow from "@mui/material/TableRow"
import Checkbox from "@mui/material/Checkbox"
import Navbar from "../../components/Navbar/Navbar"
import Leftbar from "../../components/Leftbar/Leftbar"
import SearchBar from "../../components/SearchBar/SearchBar"
import ProcessSteps from "../../components/ProcessSteps"
import ProcessStepsClient from "../../components/ProcessSteps/ProcessStepsClient"
import SuccssMsg from "../../components/AlertBox/SuccessMsg"
import WarningMsg from "../../components/AlertBox/WarningMsg"
import CircularProgress from "@mui/material/CircularProgress"
import * as Constant from "../../comman/constant"
import * as Api from "../../comman/api"
import { BASE_URL, BASE_DAN_BE_URL } from "../../comman/constant"
import { Link } from "react-router-dom"
import { useNavigate } from "react-router-dom"
import { useLocation } from "react-router-dom"
import { PropaneSharp } from "@mui/icons-material"
import CheckIcon from "@mui/icons-material/Check"
import Tooltip from "@mui/material/Tooltip"
import { useSelector } from "react-redux"
import ExportPH from "../ClientProcess/ExportPH"
import fileDownload from "js-file-download"

const boxStyle = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: "40%",
  bgcolor: "background.paper",
  boxShadow: 24,
  p: 2,
  "@media(max-height: 890px)": {
    top: "0",
    transform: "translate(-50%, 0%)",
  },
}

function createData(sno, process) {
  return { sno, process }
}
// d

const ProcessHierachies = () => {
  const navigate = useNavigate()
  const location = useLocation()

  const [open, setOpen] = useState(false)
  const handleOpen = () => {
    setOpen(true)
  }
  const handleClose = () => {
    setOpen(false)
    setErr("")
    setCheckedId([])
  }
  const [process, setProcess] = useState("")
  const [expandAll, setExpandAll] = useState(false)
  const [isCheckedId, setIsCheckedId] = useState([])
  const [checkSourceList, setCheckSourceList] = useState([])
  const [checkList, setCheckList] = useState([])
  //const [checked, setChecked] = useState(false)
  const [checkedId, setCheckedId] = useState([])
  //const [filteredCheckedId, setFilteredCheckedId] = useState("")
  const [processData, setProcessData] = useState([])
  const [processDataClient, setProcessDataClient] = useState([])
  const [processDataClientSaved, setProcessDataClientSaved] = useState([])
  const [checkProcessData, setCheckProcessData] = useState(false)
  const [selectionProcess, setSelectionProcess] = useState([])
  const [showResults, setShowResults] = useState(false)
  const [searchStr, setSearchStr] = useState("")
  const [sourceDataClient, setSourceDataClient] = useState([])
  const [sourceProcessData, setSourceProcessData] = useState([])
  const [dprocessData, setDProcessData] = useState([])
  const [err, setErr] = useState("")
  const [DProcessClientData, setDProcessClientData] = useState([])
  const [rowId, setRowId] = useState("")
  const [sourceName, setSourceName] = useState([])
  const [showAlertBox, setShowAlertBox] = useState(false)
  const [successMessage, setSuccessMessage] = useState("")
  const [showWarningBox, setShowWarningBox] = useState(false)
  const [warningMessage, setWarningMessage] = useState("")
  const [spin, setSpin] = useState(false)
  const [spinSource, setSpinSource] = useState(false)
  const [fileNameExcel, setFileNameExcel] = useState("")

  const projectName = useSelector((state) => state.questionnaireReducer.projectName)
  const projectId = useSelector((state) => state.questionnaireReducer.projectId)
  const clientId = useSelector((state) => state.questionnaireReducer.clientId)
  const userId = useSelector((state) => state.questionnaireReducer.userId)
  const email = useSelector((state) => state.questionnaireReducer.userData.email)

  useEffect(() => {
    let URL = BASE_DAN_BE_URL + Constant.PROCESS_SOURCE_LIST + clientId
    Api.loadSourceCheckList(URL).then((response) => {
      setCheckSourceList(response)
    })
    Api.loadSourceCheckList()
  }, [])

  const handleImportMaster = () => {
    setCheckList([])
    setSourceName([])
    setSelectionProcess([])
    setSpin(true)
    checkedId.map((index) => {
      let data = JSON.stringify({ loggedInUserEmail: email, userId: userId, projectId: projectId, processId: index })
      let URL = BASE_DAN_BE_URL + Constant.PROCESS_HIERARCHY_IMPORT_SAVE_PROCESS
      Api.loadSaveProcessList(URL, data).then((response) => {
        if (response.statusCode === 200) {
          setProcessDataClientSaved(response)
          setDProcessData(response)
          setSourceProcessData(response)
          setShowAlertBox(true)
          setSpin(false)
          setTimeout(() => {
            setShowAlertBox(false)
          }, 3000)
          setSuccessMessage("Successfully Imported")
        } else {
          setProcessDataClientSaved(response)
          setShowWarningBox(true)
          setWarningMessage(response.message)
          setTimeout(() => {
            setShowWarningBox(false)
          }, 3000)
          setSpin(false)
          handleClose()
        }
      })
      Api.loadSaveProcessList()
      setCheckProcessData(true)
    })
  }

  useEffect(() => {
    setSpin(true)
    let URL = BASE_DAN_BE_URL + Constant.PROCESS_HIERARCHY_PROCESS_FIRSTLEVEL + projectId
    Api.loadProcessList(URL)
      .then((data) => {
        setProcessDataClient(data)
        setDProcessClientData(data)
        setSourceDataClient(data)
        setCheckProcessData(false)
        setSpin(false)
      })
      .catch((err) => {
        console.log(err.message)
      })
    Api.loadProcessList()
    handleClose()
  }, [processDataClientSaved])

  const searchText = (event) => {
    setSearchStr(event.target.value)
    let res = []
    if (checkProcessData) {
      res = processData.reduce((acc, a) => {
        const ch = a.masterl2List && a.masterl2List.filter((b) => b.description.toLowerCase().includes(event.target.value.toLowerCase()))
        if (ch && ch.length) acc.push(a)
        else if (a.description.toLowerCase().includes(event.target.value.toLowerCase())) acc.push(a)
        return acc
      }, [])
      if (event.target.value !== "") {
        setProcessData(res)
        setExpandAll(true)
      } else {
        setProcessData(dprocessData)
        setExpandAll(false)
      }
    } else {
      res = processDataClient.reduce((acc, a) => {
        const ch = a.clientL2BPHs && a.clientL2BPHs.filter((b) => b.description.toLowerCase().includes(event.target.value.toLowerCase()))
        if (ch && ch.length) acc.push(a)
        else if (a.description.toLowerCase().includes(event.target.value.toLowerCase())) acc.push(a)
        return acc
      }, [])

      if (event.target.value !== "") {
        setProcessDataClient(res)
        setExpandAll(true)
        // handleChange(true)
      } else {
        setProcessDataClient(DProcessClientData)
        setExpandAll(false)
        // handleChange(false)
      }
    }
    handleClose()
  }

  const handleChangeSource = (event) => {
    setSpinSource(true)
    let URL = `UserId=${userId}&ProjectId=${projectId}&SourceId=${event.target.value}`
    Api.loadChecList(BASE_DAN_BE_URL + Constant.PROCESS_HIERARCHY_INDUSTRY + URL).then((response) => {
      setCheckList(response)
      setSpinSource(false)
    })

    Api.loadChecList()

    const {
      target: { value },
    } = event
    //console.log(event.target.text)
    setSourceName(
      // On autofill we get a stringified value.
      typeof value === "string" ? value.split(",") : value
    )
  }

  const handleChange = (event) => {
    switch (event.target.value) {
      case 10:
        setExpandAll(true)
        break
      case 20:
        setExpandAll(false)
        break
      default:
        setProcess(event.target.value)
    }
  }

  const handleCheck = (e) => {
    if (e.target.checked) {
      setIsCheckedId([...isCheckedId, e.target.value])
      //setIsCheckedId(e.target.value)
    } else {
      setIsCheckedId([...isCheckedId].filter((id) => id !== e.target.value))
    }
    // setIsCheckedId((current) => !current)
  }
  const handleImportChange = (e, value) => {
    if (e.target.checked) {
      setCheckedId([...checkedId, e.target.value])
      setSelectionProcess(e.target.value)
    } else {
      setCheckedId(checkedId.filter((id) => id !== e.target.value))
    }
  }

  function previewMaster(id) {
    let URL = ""
    URL = BASE_DAN_BE_URL + Constant.PROCESS_HIERARCHY_TREE_MASTER + id
    Api.PHPreviewMaster(URL).then((res) => {
      if (location.pathname.includes("/process-hierarchies")) navigate(`/process-hierarchies/process/${id}/master-preview`)
    })
  }

  const textValues = (value) => {
    setFileNameExcel(value)
  }

  const clientexportPHExcel = async () => {
    // if (props.pageName === "client view export") {
    let URL = BASE_DAN_BE_URL + Constant.HOME_PH_CLIENT_EXPORT + projectId + `&FileType=Excel&FileName=` + fileNameExcel
    Api.exportExcelHome(URL).then((blob) => fileDownload(blob, fileNameExcel + ".xlsx", "text/xlsx;charset=utf-8"))
  }

  const handleDelete = async (clickedID) => {
    let data = JSON.stringify({ loggedInUserEmail: email, userId: userId, projectId: projectId, processId: clickedID })
    let URL = BASE_DAN_BE_URL + Constant.PROCESS_DELETE
    Api.deleteProcess(URL, data)
      .then((result) => {
        if (result.statusCode === 200) {
          setShowAlertBox(true)
          setSpin(false)
          setTimeout(() => {
            setShowAlertBox(false)
            window.location.reload(true)
          }, 1000)
          setSuccessMessage(result.message)
        } else {
          setShowWarningBox(true)
          setWarningMessage("Something went wrong")
          setTimeout(() => {
            setShowWarningBox(false)
          }, 1000)
          setSpin(false)
        }
      })
      .catch((err) => console.log(err))
  }

  return (
    <div className="process-hierarchy">
      <Navbar />
      <Grid container>
        <Grid item xs={0.8}>
          <Leftbar />
        </Grid>
        <Grid item xs={11.2}>
          <div className="title">
            <h1>
              Process Hierarchies<span className="divider"> {projectName}</span>
              {/* <Button style={{ float: "right", marginBottom: "10px" }} variant="contained">
                  Export
                 
                </Button> */}
              <ExportPH textValues={textValues} clientexportPHExcel={clientexportPHExcel} />
            </h1>
            <Grid container>
              <Grid item xs={8}>
                <SearchBar searchText={searchText} />
              </Grid>
              <Grid item xs={4}>
                <div className="formControl">
                  <FormControl sx={{ m: 1, minWidth: 120 }}>
                    {
                      <Select
                        className="tree-select"
                        sx={{
                          boxShadow: "none",
                          ".MuiOutlinedInput-notchedOutline": { border: 0 },
                        }}
                        value={process}
                        onChange={handleChange}
                        displayEmpty
                      >
                        <MenuItem value="">Select Action</MenuItem>
                        <MenuItem value={10}>Expand All</MenuItem>
                        <MenuItem value={20}>Collapse All</MenuItem>
                        <MenuItem value onMouseOver={() => setShowResults(!showResults)}>
                          View Hierarchy
                        </MenuItem>
                        {showResults ? (
                          <div className="options-action">
                            {checkProcessData === true &&
                              processData.map((el) => {
                                return <FormGroup>{el.link ? "" : <FormControlLabel control={<Checkbox defaultChecked={isCheckedId.includes(el.id) ? true : false} onChange={handleCheck} value={el.id} />} label={el.description} />}</FormGroup>
                              })}
                            {checkProcessData != true &&
                              processDataClient.map((el) => {
                                return <FormGroup>{el.link ? "" : <FormControlLabel control={<Checkbox defaultChecked={isCheckedId.includes(el.id) ? true : false} onChange={handleCheck} value={el.id} />} label={el.description} />}</FormGroup>
                              })}
                          </div>
                        ) : (
                          ""
                        )}
                      </Select>
                    }
                  </FormControl>

                  <Button className="configure-btn" onClick={handleOpen} variant="contained">
                    Configure Hierarchy
                  </Button>
                  <Modal className="hierarchy-modal" open={open} onClose={handleClose} sx={{ overflowY: "scroll", top: "35px" }} disableScrollLock={false} aria-labelledby="modal-modal-title" aria-describedby="modal-modal-description">
                    <Box sx={boxStyle}>
                      <div className="process-modal">
                        <h4 style={{ marginTop: "5px" }}>Process Hierarchies</h4>
                      </div>
                      {/* <p className="err-content">{err}</p> */}
                      <div className="source-container">
                        <p className="source-title">Source</p>
                        <FormControl sx={{ m: 1, minWidth: 120 }}>
                          {
                            <Select
                              sx={{
                                boxShadow: "none",
                                ".MuiOutlinedInput-notchedOutline": {
                                  border: 0,
                                },
                              }}
                              value={sourceName ? sourceName : ""}
                              onChange={handleChangeSource}
                              displayEmpty
                              // renderValue={(selected) => {
                              //   if (selected.length === 0) {
                              //     return <em>Select Source</em>
                              //   }

                              //   return selected.join(", ")
                              // }}
                            >
                              <MenuItem disabled value="">
                                <em>Select Source</em>
                              </MenuItem>
                              {/* <MenuItem value="">Select Source</MenuItem> */}
                              {checkSourceList.map((source) => {
                                return (
                                  <MenuItem key={source.sourceId} value={source.sourceId}>
                                    {source.sourceType}
                                  </MenuItem>
                                )
                              })}
                            </Select>
                          }
                        </FormControl>
                      </div>

                      <TableContainer className="source-modal" style={{ maxHeight: 380 }}>
                        <Table stickyHeader sx={{ minWidth: 100 }} aria-label="simple table">
                          <TableHead>
                            <TableRow>
                              <TableCell></TableCell>
                              <TableCell align="left">S.no</TableCell>
                              <TableCell align="left">End to End Processes</TableCell>
                              <TableCell></TableCell>
                            </TableRow>
                          </TableHead>
                          <TableBody>
                            {spinSource === false ? (
                              checkList.map((row, index) => (
                                <TableRow
                                  key={row.id}
                                  sx={{
                                    "&:last-child td, &:last-child th": {
                                      border: 0,
                                    },
                                  }}
                                >
                                  <TableCell width="10%" size="small" padding="checkbox" component="th" scope="row">
                                    {row.isImported === true ? (
                                      <Tooltip title="This process is already imported in the Project." arrow placement="top">
                                        <CheckIcon
                                          sx={{
                                            color: "#0070ad",
                                            marginTop: "5px",
                                          }}
                                        />
                                      </Tooltip>
                                    ) : (
                                      <Checkbox value={row.id} onChange={handleImportChange} />
                                    )}
                                  </TableCell>
                                  <TableCell width="20%" align="left">
                                    {index + 1}
                                  </TableCell>
                                  <TableCell width="70%" style={{ color: "#0070AD" }} align="left">
                                    {row.description}
                                  </TableCell>
                                  <TableCell className="processBtn">
                                    {row.link ? (
                                      <Button
                                        variant="contained"
                                        style={{ marginBottom: "10px" }}
                                        onClick={() => {
                                          window.open(row.link, "_blank")
                                        }}
                                      >
                                        Download
                                      </Button>
                                    ) : (
                                      <Button
                                        variant="contained"
                                        style={{ marginBottom: "10px" }}
                                        onClick={() => {
                                          previewMaster(row.id)
                                        }}
                                      >
                                        Preview
                                      </Button>
                                    )}
                                  </TableCell>
                                </TableRow>
                              ))
                            ) : (
                              <div className="loader">
                                <CircularProgress />
                              </div>
                            )}
                          </TableBody>
                        </Table>
                      </TableContainer>

                      <div className="processBtn">
                        <Button onClick={() => handleClose()} variant="outlined">
                          Cancel
                        </Button>
                        <Button onClick={handleImportMaster} disabled={!selectionProcess.length} variant="contained">
                          Import
                        </Button>
                      </div>
                    </Box>
                  </Modal>
                </div>
              </Grid>
            </Grid>
          </div>
          <div className="rightCol b-0">
            {spin && <div className="loader">{<CircularProgress />}</div>}
            <div className="processBox">
              <small>End to End Process</small> |
              <div className="levelshowone">
                <span></span>L1
              </div>
              <div className="levelshowtwo">
                <span></span>L2
              </div>
            </div>
            {spin === false ? (
              <div className="contentBox">{checkProcessData ? <ProcessSteps processData={processData} expandAll={expandAll} isCheckedId={isCheckedId} searchStr={searchStr} setProcessDataClient={setProcessData} sourceDataClient={sourceProcessData} /> : <ProcessStepsClient spin={spin} handleDelete={handleDelete} processDataClient={processDataClient} expandAll={expandAll} isCheckedId={isCheckedId} searchStr={searchStr} setProcessDataClient={setProcessDataClient} sourceDataClient={sourceDataClient} />}</div>
            ) : (
              <div className="loader">
                <CircularProgress />
              </div>
            )}
          </div>
        </Grid>
      </Grid>
      <SuccssMsg showAlertBox={showAlertBox} setShowAlertBox={setShowAlertBox} message={successMessage} />
      <WarningMsg showWarningBox={showWarningBox} setShowWarningBox={setShowWarningBox} message={warningMessage} />
    </div>
  )
}

export default ProcessHierachies
