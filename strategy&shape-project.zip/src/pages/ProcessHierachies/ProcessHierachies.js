import React from "react";
import PlatformNav from "../../components/PlatformNav/PlatformNav";
import StrategyNav from "../../components/StrategyNav/StrategyNav";
import Filters from "../../components/Filters/FilterData";
import ProjectSearchBar from "../../components/ProjectSearchBar/ProjectSearchBar";
import { Grid } from "@mui/material";

// import "./TextSummary.css";
import Navbar from "../../components/Navbar/Navbar"
import Leftbar from "../../components/Leftbar/Leftbar";
import ProjectTable from "../../components/Table/ProjectTable";
const ProcessHierachies = () => {
  return (<React.Fragment>
    <Navbar/>
    <Grid container>
     <Grid item sm={0.6}>
        <Leftbar />
      </Grid>
      <Grid item sm={11.4}>
        <div>
        <div className="TextSummary_css">
          <h2>Process Hierachies</h2>
          </div>
          <PlatformNav />
          <StrategyNav />
          <Filters />
          <ProjectSearchBar />
          {/* <ProjectTable/> */}
        </div>
      </Grid>
    </Grid></React.Fragment>

  );

};



export default ProcessHierachies;