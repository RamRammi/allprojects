import React from "react";

import Navbar from "../../../components/Navbar/Navbar";
import SearchBar from "../../../components/SearchBar/SearchBar";
import { Grid } from "@mui/material";
import ClientLeftbar from "../../../components/ClientLeftbar/ClientLeftbar";
import * as Api from "../../../comman/api";
import * as Constant from "../../../comman/constant";
import TasksAssignedTable from "../../../components/Table/TasksAssignedTable";
const TasksAssigned = () => {
  const [tasksAssigned, setTaskAssigned] = React.useState([]);
  const [templateId, setTemplateId] = React.useState([]);
  const [usertype, setUsertype] = React.useState("client");
  const [documentType, setdocumentType] = React.useState(0);
  const [searchStr, setSearchStr] = React.useState("");

  return (
    <React.Fragment>
      <Navbar usertype={usertype} />

      <Grid container>
        {/* <Grid item sm={0.6}>
          <ClientLeftbar />
        </Grid> */}
        <Grid item sm={12}>
          <div>
            <div className="page-title">
              <h2>Tasks Assigned</h2>
            </div>

            {/* <SearchBar searchText={searchText} /> */}
            <TasksAssignedTable
              searchStr={searchStr}
              documentType={documentType}
            />
          </div>
        </Grid>
      </Grid>
    </React.Fragment>
  );
};

export default TasksAssigned;
