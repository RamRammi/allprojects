import React from "react";
import Navbar from "../../../components/Navbar/Navbar";
import SearchBar from "../../../components/SearchBar/SearchBar";
import ClientProjectTable from "../../../components/Table/ClientProjectTable";
import { Grid } from "@mui/material";
import ClientLeftbar from "../../../components/ClientLeftbar/ClientLeftbar";
import TabsList from "../Tabs/Tabs";

// import * as Api from "../../comman/api";
import "../Project/Project.css";
import * as Constant from "../../../comman/constant";
import { useSelector } from "react-redux";
const Project = () => {
  const [download, setDownload] = React.useState([]);
  const [searchStr, setSearchStr] = React.useState("");
  const [usertype, setUsertype] = React.useState("client");
  const projectName = useSelector(
    (state) => state.questionnaireReducer.projectName
  );
  return (
    <React.Fragment>
      <Navbar usertype={usertype} />

      <Grid container>
        <Grid item sm={0.8}>
          <ClientLeftbar />
        </Grid>
        <Grid item sm={11.2}>
          <div>
            <div className="Project_css">
              <h2 className="Project_css_h2">
                {"Project"}
                <span
                  style={{
                    //nikhitha
                    // marginLeft: "20px",
                    color: "#2B0A3D",
                    fontSize: "20px",
                    paddingLeft: "19px",
                    marginLeft: "20px",
                    color: "#2B0A3D",
                    fontSize: "16px",
                    borderLeft: "1px solid #828282",
                  }}
                >
                  {projectName}
                </span>
                {/* <button
                  onClick={TasksAssigned}
                  className="Projectt_css"
                  variant="contained"
                  style={{ backgroundColor: "#0070AD", color: "#fff" }}
                >
                  TasksAssigned
                </button> */}
              </h2>
            </div>
            <div>
              <TabsList />
            </div>
            {/* <SearchBar />
            <ClientProjectTable /> */}
          </div>
        </Grid>
      </Grid>
    </React.Fragment>
  );
};

export default Project;
