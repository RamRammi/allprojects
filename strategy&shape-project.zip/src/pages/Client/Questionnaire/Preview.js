import React from "react";
import Respond from "./Respond";
import Navbar from "../../components/Navbar/Navbar";
import Filters from "../../components/Filters/FilterData";
import RespondFilterData from "../Questionnaire/RespondFilterData";
import RespondContent from "../Questionnaire/RespondContent";
import FooterButtons from "./FooterButtons";
import RespondComments from "./RespondComments";
import { useLocation } from "react-router-dom";
import { useState, useEffect, createContext } from "react";
import { ResponseContext } from "../../comman/context.js";
import * as Api from "../../comman/api";
import * as Constant from "../../comman/constant";
function Preview(props) {
  const pages = "preview";
  const location = useLocation();
  const [templateId, setTemplateId] = useState(0);
  const [templateName, setTemplateName] = useState("");
  const [respondQuestionList, setRespondQuestionList] = useState([]);
  const [responseList, setResponseList] = useState([]);
  const [successMessage, setSuccessMessage] = React.useState("");
  const [showAlertBox, setShowAlertBox] = React.useState(false);
  const [showWarningBox, setShowWarningBox] = React.useState(false);
  const [userType, setUserType] = React.useState("");
  const [interviewee, setInterviewee] = useState("");
  const [interviewer, setInterviewer] = useState("");
  const [jobTitle, setJobTitle] = useState("");
  const [date, setDate] = useState(new Date());
  const [readOnlyView, setReadOnlyView] = React.useState(false);
  const [pId, setPId] = React.useState("");
  const [warningMessage, setWarningMessage] = React.useState("");
  const [interviewSynopsis, setInterviewSynopsis] = React.useState("");
  const [notes, setNotes] = React.useState("");
  useEffect(() => {
    if (location.state === null) {
    } else {
      console.log(location.state);
      setTemplateId(location.state.templateId);
      setUserType(location.state.userType);
      setPId(location.state.pId);

      if (location.state.pageName === "AddQuestionnaire") {
        getRespondQuestionList(
          location.state.templateId,
          location.state.userType
        );
      } else {
        getQuestionnaireDetailsByMasterSummay(location.state.templateId);
      }
    }
  }, [location.state]);

  // When click on view questionnaire on master summary page
  const getQuestionnaireDetailsByMasterSummay = (templateId) => {
    let URL = Constant.VIEW_QUESTIONNAIRE + "?templateid=" + templateId;
    console.log(URL, "url");
    Api.getQuestionnaireList(URL).then((res) => {
      console.log(res);
      setRespondQuestionList(res);
      setInterviewee(res[0].interviewee);
      setInterviewer(res[0].interviewer);
      setJobTitle(res[0].jobTitle);
      setDate(res[0].date);
      setInterviewSynopsis(res[0].synopsis);
      setNotes(res[0].notes);
    });
  };

  const openAlertBox = () => {
    setShowAlertBox(true);
  };
  const openWarningBox = () => {
    setShowWarningBox(true);
  };

  const getRespondQuestionList = (tempId, userType) => {
    console.log(location.state.status);
    let URL = "";
    if (userType === "consultant" && location.state.status === "Completed") {
      //Consultant flow
      URL =
        Constant.GET_QUESTIONNAIRE_DATA_WITH_RESPONSE +
        "?pId=" +
        location.state.pId +
        "&templateId=" +
        tempId +
        "&status=" +
        location.state.status;
      Api.getRespondQuestionList(URL).then((res) => {
        setReadOnlyView(true);
        setRespondQuestionList(res.templateQuestionResponseList);
        setTemplateName(
          res.templateQuestionResponseList.length
            ? res.templateQuestionResponseList[0].templateName
            : ""
        );
        setInterviewee(res.project.projectInterviewee);
        setInterviewer(res.project.projectInterviewer);
        setJobTitle(res.project.jobTitle);
        //setDate("");
      });
    } else if (userType === "consultant" && location.state.status === "Saved") {
      URL =
        Constant.GET_QUESTIONNAIRE_DATA_BY_TEMPLATEID + "?templateId=" + tempId;
      Api.getRespondQuestionList(URL).then((res) => {
        setRespondQuestionList(res.questionnaireTemplateDateials);
        setTemplateName(
          res.questionnaireTemplateDateials.length
            ? res.questionnaireTemplateDateials[0].templateName
            : ""
        );
        //  setInterviewee(res.project.projectInterviewee);
        //  setInterviewer(res.project.projectInterviewer);
        //  setJobTitle(res.project.jobTitle);
        //setDate("");
      });
    } else if (
      userType === "consultant" &&
      (location.state.status === "New" || location.state.status === "Pending")
    ) {
      URL =
        Constant.GET_CLIENT_RESPONSE_BY_TASKSUMMARY +
        "?templateId=" +
        tempId +
        "&status=" +
        location.state.status;
      Api.getRespondQuestionList(URL).then((res) => {
        setRespondQuestionList(res.consQuestResByTemplateId);

        setTemplateName(
          res.consQuestResByTemplateId.length
            ? res.consQuestResByTemplateId[0].templateName
            : ""
        );

        setInterviewee(res.consQuestResByTemplateId[0].projectInterviewee);

        setInterviewer(res.consQuestResByTemplateId[0].projectInterviewer);

        setJobTitle(res.consQuestResByTemplateId[0].jobTitle);

        setNotes(res.consQuestResByTemplateId[0].notes);

        setNotes(res.consQuestResByTemplateId[0].synopsis);

        res.consQuestResByTemplateId.map((value, index) => {
          responseList[index] = value.response;
        });
        console.log(responseList);
      });
    } else if (userType === "client") {
      //Client flow
      URL =
        Constant.GET_CLIENT_RESPONSE +
        "?templateId=" +
        tempId +
        "&status=" +
        location.state.status;
      Api.getRespondQuestionList(URL).then((res) => {
        setRespondQuestionList(res);
        setPId(res.length ? res[0].pId : 0);
        setTemplateName(res.length ? res[0].templateName : "");
        res.map((value, index) => {
          responseList[index] = value.response;
        });
        console.log(responseList);
      });
    }
  };
  return (
    <div>
      <Navbar />
      <ResponseContext.Provider
        value={{
          interviewee,
          interviewer,
          jobTitle,
          date,
          setInterviewee,
          setInterviewer,
          setJobTitle,
          setDate,
        }}
      >
        <RespondFilterData
          pages={pages}
          templateId={templateId}
          status={location.state.status ? location.state.status : ""}
          interviewSynopsis={interviewSynopsis}
          notes={notes}
        />
      </ResponseContext.Provider>
      <RespondContent
        pages={pages}
        respondQuestionList={respondQuestionList}
        setResponseList={setResponseList}
        responseList={responseList}
      />
      {/* <RespondComments pages={pages} /> */}
      <FooterButtons
        pageName={pages}
        questionnaireName={templateName}
        templateId={templateId}
        readOnlyView={readOnlyView}
      />
    </div>
  );
}

export default Preview;
