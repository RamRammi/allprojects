import React from "react";
import Navbar from "../../../components/Navbar/Navbar";
import RespondFilterData from "../Questionnaire/RespondFilterData";
import RespondContent from "../Questionnaire/RespondContent";
import FooterButtons from "../Questionnaire/FooterButtons";
import RespondComments from "../Questionnaire/RespondComments";
import { useLocation } from "react-router-dom";
import { useState, useEffect, createContext } from "react";
import * as Api from "../../../comman/api";
import * as Constant from "../../../comman/constant";
import SuccssMsg from "../../../components/AlertBox/SuccessMsg";
import WarningMsg from "../../../components/AlertBox/WarningMsg";
import { ResponseContext } from "../../../comman/context.js";
import { set } from "react-hook-form";
import { dateFormatchange } from "../../../comman/utils";
import { useSelector, useDispatch } from "react-redux";
import { setPId } from "../../../redux/actions/questionnaireAction";
import { useNavigate } from "react-router-dom";
import { parseISO } from 'date-fns';

function Respond(props) {
  const location = useLocation();
  const navigate = useNavigate();
  const [templateName, setTemplateName] = useState("");
  const [respondQuestionList, setRespondQuestionList] = useState([]);
  const [responseList, setResponseList] = useState([]);
  const [successMessage, setSuccessMessage] = React.useState("");
  const [showAlertBox, setShowAlertBox] = React.useState(false);
  const [showWarningBox, setShowWarningBox] = React.useState(false);

  const [interviewee, setInterviewee] = useState("");
  const [interviewer, setInterviewer] = useState("");
  const [jobTitle, setJobTitle] = useState("");
  const [date, setDate] = useState(new Date());
  const [readOnlyView, setReadOnlyView] = React.useState(false);
  const [disabledSubmit, setDisabledSubmit] = React.useState(true);
  const [comment, setComment] = useState("");
  const [commentsList, setCommentsList] = useState([]);
  const [commentTrackingClientId, setcommentTrackingClientId] = useState();
  const [commentTrackingId, setcommentTrackingId] = useState(0);
  const [addbtn, setAddbtn] = React.useState(false);
  const [textboxdis, setTextboxdis] = React.useState(false);
  const [addbtnhide, setAddbtnhide] = useState(true);
  //  const [status, setStatus] = React.useState("");
  //const [pId, setPId] = React.useState("");
  const currentDate = new Date();
  const userId = useSelector((state) => state.questionnaireReducer.userId);
  const clientId = useSelector((state) => state.questionnaireReducer.clientId);
  const projectId = useSelector(
    (state) => state.questionnaireReducer.projectId
  );
  const projectName = useSelector(
    (state) => state.questionnaireReducer.projectName
  );
  const clientName = useSelector(
    (state) => state.questionnaireReducer.userData.clientName
  );
  const email = useSelector(
    (state) => state.questionnaireReducer.userData.email
  );
  const firstName = useSelector(
    (state) => state.questionnaireReducer.userData.firstName
  );
  const lastName = useSelector(
    (state) => state.questionnaireReducer.userData.lastName
  );
  // const [pId, setPId] = React.useState("");
  // const [templateId, setTemplateId] = useState(0);
  const pId = useSelector((state) => state.questionnaireReducer.pId);
  const templateId = useSelector(
    (state) => state.questionnaireReducer.templateId
  );
  // const userType = useSelector((state) => state.questionnaireReducer.userType);
  const templateStatus = useSelector(
    (state) => state.questionnaireReducer.templateStatus
  );
  const [openSave, setOpenSave] = useState(false);
  const [disabledYesButton, setDisabledYesButton] = React.useState(false);
  const [isChanged, setIsChanged] = React.useState(false);
  const [warningMessage, setWarningMessage] = React.useState("");
  const pages = "response";
  const dispatch = useDispatch();
  // const ResponseContext = createContext();
  useEffect(() => {
    if (respondQuestionList) {
      respondQuestionList.map((value, index) => {
        if (
          (value.cQuestionType === "textbox" || value.type === "textbox") &&
          value.response === null
        ) {
          value.response = "";
        }
        if (
          (value.cQuestionType === "Date" || value.type === "Date") &&
          value.response === null
        ) {
          let currentDate = new Date();
          responseList[index] = currentDate.toISOString();
          value.response = dateFormatchange(currentDate);
        }
        if (
          (value.cQuestionType === "Logical" || value.type === "Logical") &&
          value.response === null
        ) {
          value.response = "";
        }
        if (value.response !== null && value.type === "Range of Values") {
          value.response = value.response.split(",");
        }
        if (
          (value.cQuestionType === "Range of Values" ||
            value.type === "Range of Values") &&
          value.response === null
        ) {
          value.response = [0, 0];
        }

        if (
          (value.cQuestionType === "Multiple Choice Questions" ||
            value.type === "Multiple Choice Questions") &&
          value.response === null
        ) {
          value.response = "";
        }
      });
    }
  }, [respondQuestionList]);
  useEffect(() => {
    if (templateStatus === "Completed") {
      setReadOnlyView(true);
    }
    getRespondQuestionList(templateId, "first");
  }, []);

  const openAlertBox = () => {
    setShowAlertBox(true);
  };
  const openWarningBox = () => {
    setShowWarningBox(true);
  };

  const getRespondQuestionList = (tempId, type) => {
    let URL = "";
    //Client flow
    URL =
      Constant.GET_CLIENT_RESPONSE +
      "?templateId=" +
      tempId +
      "&status=" +
      templateStatus;
    Api.getRespondQuestionList(URL).then((res) => {
      if (type === "return") {
        setAddbtn(false);
      }
      setTemplateName(res.objTemplate[0].templatename);
      setTextboxdis(true);
      setRespondQuestionList(res.objTemplate);
      setCommentsList(res.templateCommentList);
      setcommentTrackingClientId(
        res.templateCommentList[res.templateCommentList.length - 1]
          .commentTrackingClientId
      );
      setcommentTrackingId(
        res.templateCommentList[res.templateCommentList.length - 1]
          .commentTrackingId
      );
      dispatch(setPId(res.objTemplate.length ? res.objTemplate[0].pId : 0));

      setInterviewee(res.objTemplate[0].projectInterviewee);
      setInterviewer(res.objTemplate[0].projectInterviewer);
      setJobTitle(res.objTemplate[0].jobTitle);
      //setDate(res[0].date);
      res.objTemplate.map((value, index) => {
        responseList[index] = value.response;
      });
    });
  };

  const saveResponse = (callFrom = "") => {
    console.log(date);
    setDisabledYesButton(true);
    let project = {
      id: pId,
      projectId: projectId,
      clientId: clientId,
      clientName: clientName,
      projectName: projectName,
      projectInterviewer: interviewer,
      projectInterviewee: interviewee,
      projectCreateDate:parseISO(props.date),
      createdDate: parseISO(props.date),
      createdBy: userId,
      modifiedDate:currentDate,
      modifiedBy: userId,
      jobTitle: jobTitle,
    };

    let templatecomments = {
      commentId: 0,
      templateId: templateId,
      projectId: projectId,
      clientId: clientId,
      cDescription: comment,
      createdBy: userId,
      createdDate: "2022-11-08T09:32:09.059Z",
      modifiedDate: "2022-11-08T09:32:09.059Z",
      modifiedBy: userId,
      commentBy: "Client",
      commentTrackingId: commentTrackingId,
      commentTrackingClientId: commentTrackingClientId,
      freezStatus: false,
      createdByEmail: email,
      fullName:
        firstName.charAt(0).toLocaleUpperCase() +
        lastName.charAt(0).toLocaleUpperCase(),
    };
    let clientresponseaudit = [];
    let objSend = {
      project,
      clientresponseaudit,
      templatecomments,
    };
    respondQuestionList.map((value, index) => {
      let obj = {
        // id: pId,
        templateID: value.templateId,
        cQuestionId: value.questionId,
        response: responseList[index],
        responseBy: "",
        createdDate: "2022-11-08T09:32:09.059Z",
        createdBy: userId,
        modifiedDate: "2022-11-08T09:32:09.059Z",
        modifiedBy: userId,
        responseSubmittedBy: "string",
      };
      clientresponseaudit.push(obj);
    });
    Api.saveResponseData(Constant.SAVE_RESPONSE_BY_CLIENT, objSend).then(
      (res) => {
        if (res.code === 1) {
          setAddbtn(true);
          setDisabledSubmit(false);
          setSuccessMessage(res.message);
          openAlertBox();
          setDisabledYesButton(false);
          setOpenSave(false);
          if (callFrom === "back") {
            setTimeout(() => {
              navigate(-1);
            }, 500);
          }
        }
      }
    );
  };

  const submitResponse = () => {
    console.log(date,"date");
    let project = {
      id: pId,
      projectId: projectId,
      clientId: clientId,
      clientName: clientName,
      projectName: projectName,
      projectInterviewer: interviewer,
      projectInterviewee: interviewee,
      createdDate: parseISO(date),
      createdBy: userId,
      modifiedDate: currentDate,
      projectCreateDate:parseISO(date),
      modifiedBy: userId,
      jobTitle: jobTitle, 
    };
    let clientresponse = [];
    let objSend = {
      project,
      clientresponse,
    };
    respondQuestionList.map((value, index) => {
      let obj = {
        // id: 0,
        templateID: value.templateId,
        cQuestionId: value.questionId,
        response: responseList[index],
        responseBy: "",
        createdDate: "2022-11-08T09:32:09.059Z",
        createdBy: userId,
        modifiedDate: "2022-11-08T09:32:09.059Z",
        modifiedBy: userId,
        responseSubmittedBy: "string",
      };
      clientresponse.push(obj);
    });
    Api.submitResponseData(Constant.SUBMIT_RESPONSE_BY_CLIENT, objSend).then(
      (res) => {
        // if (res.code === 1) {
        //   setSuccessMessage(res.message);
        //   openAlertBox();
        // }
        //     setWarningMessage(res.message);
        //     openWarningBox();
      }
    );
  };
  const setcomm = (value) => {
    setComment(value);
  };
  return (
    <div>
      <Navbar />

      <ResponseContext.Provider
        value={{
          interviewee,
          interviewer,
          jobTitle,
          // parseISO({date}),
          date,
          isChanged,
          setInterviewee,
          setInterviewer,
          setJobTitle,
          setDate,
          setIsChanged,
        }}
      >
        <RespondFilterData
          pages={pages}
          templateId={templateId}
          status={templateStatus}
          templateName={templateName}
        />
      </ResponseContext.Provider>
      <RespondContent
        pages={pages}
        respondQuestionList={respondQuestionList}
        setResponseList={setResponseList}
        responseList={responseList}
        setIsChanged={setIsChanged}
      />
      <RespondComments
        pages={pages}
        comm={setcomm}
        comments={commentsList}
        addbtn={addbtn}
        textboxdis={textboxdis}
        addbtnhide={addbtnhide}
        tmpId={templateId}
        getrespondquestionlist={getRespondQuestionList}
        status={templateStatus}
        setIsChanged={setIsChanged}
        initials={
          firstName.charAt(0).toLocaleUpperCase() +
          lastName.charAt(0).toLocaleUpperCase()
        }
      />
      <FooterButtons
        pageName={pages}
        saveResponse={saveResponse}
        submitResponse={submitResponse}
        questionnaireName={templateName}
        templateId={templateId}
        readOnlyView={readOnlyView}
        disabledSubmit={disabledSubmit}
        disabledYesButton={disabledYesButton}
        templateStatus={templateStatus}
        isChanged={isChanged}
        openSave={openSave}
        setOpenSave={setOpenSave}
      />
      <SuccssMsg
        showAlertBox={showAlertBox}
        setShowAlertBox={setShowAlertBox}
        message={successMessage}
      />
      <WarningMsg
        showWarningBox={showWarningBox}
        setShowWarningBox={setShowWarningBox}
        message={warningMessage}
      />
    </div>
  );
}

export default Respond;
