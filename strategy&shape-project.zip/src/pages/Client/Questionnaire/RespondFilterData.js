import React from "react";
import { useState, useEffect, useRef } from "react";
import { useTheme } from "@mui/material/styles";
import "./RespondFilter.css";
import "../../../components/Filters/QuestionnaireFilters.css";
//import "./AddQuestionnaire.css";
import { Button } from "@mui/material";
import ResponseDetails from "../Questionnaire/ResponseDetails";
import CommonModal from "../../../components/PopUp/ExpendPopup/modal";

export default function RespondFilterData(props) {
  const [open, setOpen] = useState(false);
  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  return (
    //main div
    <div>
      {/*div for header */}
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          margin: "10px",
        }}
      >
        <div style={{ marginLeft: "40px" }}>
          <p
            style={{
              float: "left",
              fontFamily: "Ubuntu",
              fontWeight: "500",
              fontSize: "18px",
              paddingTop: "10px",
            }}
          >
            {props.templateName}
          </p>
        </div>
        <div style={{ display: "flex", marginRight: "40px" }}>
          <Button
            onClick={handleClickOpen}
            style={{
              fontFamily: "Ubuntu",
              fontSize: "12px",
              backgroundColor: "#0070AD",
              color: "white",
              margin: " 10px",
              borderRadius: "25px",
              padding: "5px 10px",
              border: "1px solid #0070AD",
              textTransform: "capitalize",
            }}
          >
            Export Questionnaire{" "}
          </Button>
          <CommonModal
            pageName={"ClientRespond"}
            open={open}
            onClose={() => handleClose()}
            type="export"
            templateId={props.templateId}
            status={props.status}
          />
        </div>
      </div>
      {/* div for header end */}
      {/* //input boxes end */}
      <ResponseDetails
        pageName={props.pages}
        questionnaireDetails={props.questionnaireDetails}
      />

      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          borderBottom: "1px solid #E0E0E0",
        }}
      ></div>
    </div>
  );
}
