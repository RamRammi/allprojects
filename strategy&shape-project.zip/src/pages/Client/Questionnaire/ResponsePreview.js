import React from "react";
import Respond from "./Respond";
import Navbar from "../../components/Navbar/Navbar";
import Filters from "../../components/Filters/FilterData";
import RespondFilterData from "../Questionnaire/RespondFilterData";
import RespondContent from "../Questionnaire/RespondContent";
import FooterButtons from "./FooterButtons";
import RespondComments from "./RespondComments";

const ResponsePreview = (props) => {
  const pageName = "responsePreview";
  return (
    <div>
      <Navbar />
      <RespondFilterData />
      <RespondContent />
      <RespondComments pageName={pageName} />
      <FooterButtons pageName={pageName} />
    </div>
  );
};

export default ResponsePreview;
