import React from "react";
import FormControl from "@mui/material/FormControl";
import dayjs from 'dayjs';
import { Typography } from "@mui/material";
import TextField from "@material-ui/core/TextField";
import { useContext } from "react";
import { ResponseContext } from "../../../comman/context";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import moment from 'moment';
import { useState } from "react";
import { parseISO } from 'date-fns';



const AddQuestionnaireDetails = (props) => {
  const currentDate = new Date();
  const { interviewee, setInterviewee } = useContext(ResponseContext);
  const { interviewer, setInterviewer } = useContext(ResponseContext);
  const { jobTitle, setJobTitle } = useContext(ResponseContext);
  const { date, setDate } = useContext(ResponseContext);
  // const[calenderValue,setCalenderValue]=useContext(ResponseContext);
  // const[calenderValue,setcalenderValue]=useState(dayjs(ResponseContext()))
  const { isChanged, setIsChanged } = useContext(ResponseContext);
  console.log(currentDate,"current");
  
  
  const dateChange=(currentDate)=>{
    setIsChanged(true);
    setDate(currentDate);
  }

  console.log(parseISO(date));


  return (
    <div>
      <div className="filter-fields">
        <FormControl sx={{ m: 1, width: 200, mt: 3 }} className="filter-input">
          <Typography className="level">Interviewee</Typography>
          <TextField
            id="outlined-basic"
            value={interviewee}
            disabled={props.pageName === "preview" ? true : false}
            variant="outlined"
            placeholder="Text"
            inputProps={{ autoComplete: "off" }}
            size="small"
            onChange={(e) => {
              setIsChanged(true);
              setInterviewee(e.target.value.replace(
                new RegExp(/[*#$%!~^&`(){}<>?/\\:;""'|]/gm),
                ""
              ));
            }}
          />
          <span style={{ color: "red" }}>{props.intervieweeMessage}</span>
        </FormControl>
        {/* <FormControl sx={{ m: 1, width: 200, mt: 3 }} className="filter-input">
          <Typography className="level">
            <span className="required">*</span>Interviewer
          </Typography>
          <TextField
            disabled={props.pageName === "preview" ? true : false}
            value={interviewer}
            id="outlined-basic"
            variant="outlined"
            placeholder="Text"
            inputProps={{ autoComplete: "off" }}
            size="small"
            onChange={(e) => setInterviewer(e.target.value)}
          />
          <span style={{ color: "red" }}>{props.interviewerMessage}</span>
        </FormControl> */}
        <FormControl sx={{ m: 1, width: 200, mt: 3 }} className="filter-input">
          <Typography className="level">Job Title</Typography>
          <TextField
            value={jobTitle}
            id="outlined-basic"
            disabled={props.pageName === "preview" ? true : false}
            variant="outlined"
            placeholder="Text"
            inputProps={{ autoComplete: "off" }}
            size="small"
            onChange={(e) => {
              setIsChanged(true);
              setJobTitle(e.target.value.replace(
                new RegExp(/[*#$%!~^&`(){}<>?/\\:;""'|]/gm),
                ""
              ));
            }}
          />
          <span style={{ color: "red" }}>{props.intervieweeMessage}</span>
        </FormControl>

        <FormControl sx={{ m: 1, width: 150, mt: 3 }} className="filter-input">
          <Typography className="level">
            <span className="required">*</span>Date
          </Typography>
          {/* <TextField
            value={date}
            disabled={props.pageName === "preview" ? true : false}
            // disabled={props.pageNames === "preview" ? true : false}
            // readOnly={props.pageNames==="preview" ? true:false}
            id="outlined-basic"
            variant="outlined"
            type="date"
            size="small"
            onChange={(e) => setDate(e.target.value, "date")}
          /> */}

          <LocalizationProvider dateAdapter={AdapterDayjs}>
            <DatePicker
            inputFormat="MM/DD/YYYY"
              value={parseISO(date)}
              // onChange={(newValue) => {
              //   setIsChanged(true);
              //   setDate(newValue.toISOString());
              // }}
              onChange={dateChange}
              renderInput={(params) => (
                <TextField {...params} variant="outlined" size="small" />
              )}
            />
          </LocalizationProvider>
          <span style={{ color: "red" }}>{props.dateMessage}</span>
        </FormControl>
      </div>
    </div>
  );
};

export default AddQuestionnaireDetails;
