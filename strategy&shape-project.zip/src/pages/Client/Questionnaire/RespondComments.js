import React, { useState } from "react";
import TextField from "@mui/material/TextField";
import Typography from "@mui/material/Typography";
import maskImage from "../../../Images/MaskImage.png";
import Button from "@mui/material/Button";
import Pdf from "../../../Images/pdf.png";

const MenuProps = {
  style: {
    minHeight: "40px",
    width: 200,
  },
};
function RespondComments(props) {
  const [comment, setComment] = useState("");
  const [commbox, setCommbox] = useState(true);
  const [addbtnhide, setAddbtnhide] = useState(true);
  const propcomm = (value) => {
    if (props.pages === "response") props.setIsChanged(true);
    setComment(value);
    props.comm(value);
  };
  const addcomm = () => {
    setCommbox(false);
    setAddbtnhide(false);
    setComment("");
    // if(comment)
    props.getrespondquestionlist(props.tmpId, "return");

    setCommbox(true);
  };
  return (
    <>
      {props.pages == "response" || props.pageName == "responsePreview" ? (
        <div style={{ marginLeft: "30px" }}>
          <div style={{ minHeight: "100px", borderTop: "1px solid #E0E0E0" }}>
            <div style={{ marginLeft: "30px", marginTop: "10px" }}>
              <Typography
                style={{
                  fontFamily: "Ubuntu",
                  fontWeight: "600",
                  fontSize: "18px",
                }}
              >
                Comments
              </Typography>
            </div>
            <div>
              {props.comments && props.comments.length > 0
                ? props.comments.map((k, index) => {
                    return k.cDescription !== "" ? (
                      <>
                        <div
                          style={{
                            marginLeft:
                              k.commentBy === "Client" ? "80px" : "30px",
                            display: "flex",
                            marginTop: "10px",
                          }}
                        >
                          <span>
                            <div
                              className="circle"
                              style={{
                                backgroundColor:
                                  props.initials === k.fullName
                                    ? "#00d53b"
                                    : "#512DA8",
                              }}
                            >
                              <p className="circle-inner">{k.fullName}</p>
                            </div>
                          </span>
                          <TextField
                            id="outlined-basic"
                            disabled
                            //  disabled={index === props.comments.length -1   ?  props.comments[props.comments.length -1].commentBy === 'Client' ? false : true :   true}
                            defaultValue={k.cDescription}
                            fullWidth
                            sx={{
                              width: "100%",
                              marginLeft: "20px",
                              marginBottom: "30px",
                              marginRight: "10px",
                              height: "32px",
                              marginTop: "5px",
                              border: "1px #828282",
                            }}
                          ></TextField>

                          {/* <Button readOnly={props.pageNames==="preview" ? true:false} onClick={respondPreviewPage}
                          style={{display:"inline-block",marginBottom:"15px"}}><img src={Pdf}></img></Button> */}
                        </div>
                        <span className="comment-by">
                          Commented by : {k.createdByEmail}
                        </span>
                      </>
                    ) : null;
                  })
                : null}
            </div>
            {/* {props.comments && props.comments.length > 0 ? 
            props.comments[props.comments.length -1].commentBy === 'Client' && props.comments[props.comments.length -1].cDescription !== ''  ? 
              null
             : 
             <div style={{marginLeft:"30px",display:"flex",marginTop:"10px"}}>
             <span ><img style={{marginTop:"10px",width:'20px',height:'20px',borderRadius:'100px'}} src="../img/chess.jpg"></img></span>
              <TextField id="outlined-basic"  
             //  disabled 
          

             placeholder="Add Comment..."
             onChange={(e) => propcomm(e.target.value)}
              //  readOnly={props.pages==="preview" ? true:false}
              fullWidth sx={{width:"100%",marginLeft:"20px",marginBottom:"30px",marginRight:"10px",height:"32px",marginTop:"5px",border:"1px #828282"}}></TextField>
           
           </div>: 
          <div style={{marginLeft:"30px",display:"flex",marginTop:"10px"}}>
          <span ><img style={{marginTop:"10px",width:'20px',height:'20px',borderRadius:'100px'}} src="../img/chess.jpg"></img></span>
           <TextField id="outlined-basic"  
          //  disabled 
          placeholder="Add Comment..."
          onChange={(e) => propcomm(e.target.value)}
            // readOnly={props.pages==="preview" ? true:false}
           fullWidth sx={{width:"100%",marginLeft:"20px",marginBottom:"30px",marginRight:"10px",height:"32px",marginTop:"5px",border:"1px #828282"}}></TextField>
        

            

        </div>
          } */}
            {commbox ? (
              <div
                style={{
                  marginLeft: "30px",
                  display: "flex",
                  marginTop: "10px",
                }}
              >
                {props.status !== "Completed" ? (
                  <>
                    <span>
                      <div
                        className="circle"
                        style={{ backgroundColor: "#00d53b" }}
                      >
                        <p className="circle-inner">{props.initials}</p>
                      </div>
                    </span>

                    <TextField
                      id="outlined-basic"
                      placeholder=""
                      disabled={props.addbtn}
                      onChange={(e) => propcomm(e.target.value.replace(
                        new RegExp(/[*^~]/gm),
                        ""
                      ))
                    }
                      value={comment}
                      fullWidth
                      sx={{
                        width: "100%",
                        marginLeft: "20px",
                        marginBottom: "30px",
                        marginRight: "10px",
                        height: "32px",
                        marginTop: "5px",
                        border: "1px #828282",
                      }}
                    ></TextField>
                  </>
                ) : (
                  ""
                )}
              </div>
            ) : null}

            {props.addbtn ? (
              <button className="add-comment-button" onClick={() => addcomm()}>
                {" "}
                add comment <span> + </span>
              </button>
            ) : null}
            {/* <div
              style={{ marginLeft: "30px", display: "flex", marginTop: "10px" }}
            >
              <span>
                <img style={{ marginTop: "10px" }} src={maskImage}></img>
              </span>
              <TextField
                id="outlined-basic"
                //  disabled
                // readOnly={props.pages==="preview" ? true:false}
                fullWidth
                sx={{
                  width: "80%",
                  marginLeft: "20px",
                  marginBottom: "30px",
                  marginRight: "10px",
                  height: "32px",
                  marginTop: "5px",
                  border: "1px #828282",
                }}
              ></TextField>
              <Button
                readOnly={props.pageNames === "preview" ? true : false}
                onClick={respondPreviewPage}
                style={{ display: "inline-block", marginBottom: "15px" }}
              >
                <img src={Pdf}></img>
              </Button>
            </div> */}
          </div>
        </div>
      ) : (
        " "
      )}
    </>
  );
}

export default RespondComments;
