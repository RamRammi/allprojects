import React from "react";
import { useState, useEffect } from "react";
import { Button } from "@mui/material";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import MenuItem from "@mui/material/MenuItem";
import OutlinedInput from "@mui/material/OutlinedInput";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import { Typography } from "@mui/material";
import { useTheme } from "@mui/material/styles";
import * as Constant from "../../comman/constant";

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};

function ExportVDTClient(props) {
  const [openDialog, setOpenDialog] = useState(false);
  const [personName, setPersonName] = useState([]);
  const [textValue, setTextValue] = useState("");
  const [error, setError] = useState("");

  const theme = useTheme();
  const names = ["PDF", "Excel"];

  useEffect(() => {
    props.textValues(textValue);
  }, [textValue]);

  useEffect(() => {
    if (props.downloadCompleted === true) {
      handleClose();
    }
  }, [props.downloadCompleted]);

  const handleClickOpen = () => {
    setOpenDialog(true);
  };

  const handleClose = () => {
    setOpenDialog(false);
    setTextValue("");
    setPersonName("");
    setError("");
  };

  const handleChange = (event) => {
    const {
      target: { value },
    } = event;
    setPersonName(
      typeof value === "string"
        ? value
            .replace(new RegExp(/[*#$%!~^&`(){}<>?/\\:;""'|]/gm), "")
            .split(",")
        : value.replace(new RegExp(/[*#$%!~^&`(){}<>?/\\:;""'|]/gm), "")
    );
  };

  function getStyles(name, personName, theme) {
    return {
      fontWeight:
        personName.indexOf(name) === -1
          ? theme.typography.fontWeightRegular
          : theme.typography.fontWeightMedium,
    };
  }

  const onTextValueChange = (event) => {
    const {
      target: { value },
    } = event;
    setTextValue(
      typeof value === "string"
        ? value
            .replace(new RegExp(/[*#$%!~^&`(){}<>?/\\:;""'|]/gm), "")
            .split(",")
        : value.replace(new RegExp(/[*#$%!~^&`(){}<>?/\\:;""'|]/gm), "")
    );
  };

  function exportExcel() {
    if (
      textValue[0] === "" ||
      textValue[0] === undefined ||
      textValue[0] === null
    ) {
      setError("Please enter the file name. ");
      return;
    }

    let URL = "";
    URL =
      Constant.BASE_URL +
      Constant.VDT_CLIENT_EXPORT_EXCEL +
      "?id=" +
      props.selectedImpact +
      "&projectId=" +
      props.projectId +
      "&industryId=" +
      props.industryId +
      "&fileType=" +
      personName[0] +
      "&fileName=" +
      textValue[0];
    window.location.href = URL;
    handleClose();
  }

  return (
    <div>
      <Button
        style={{ float: "right", marginTop: "-35px" }}
        variant="contained"
        onClick={handleClickOpen}
      >
        Export File
      </Button>
      <Dialog
        open={openDialog}
        onClose={handleClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title" style={{ fontFamily: "Ubuntu" }}>
          Export As
        </DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            <Typography
              style={{
                color: "black",
                fontFamily: "Ubuntu",
                marginBottom: "10px",
              }}
            >
              Specify a File Name
            </Typography>
            <FormControl sx={{ m: 1, width: 451, mt: 3 }}>
              <OutlinedInput
                placeholder="Text"
                value={textValue}
                onChange={onTextValueChange}
              />
                <p className="error-message">{error}</p>
            </FormControl>

            <Typography style={{ color: "black", fontFamily: "Ubuntu" }}>
              Filetype
            </Typography>
            <FormControl sx={{ m: 1, width: 451, mt: 3 }}>
              <Select
                displayEmpty
                value={personName}
                onChange={handleChange}
                input={<OutlinedInput />}
                renderValue={(selected) => {
                  if (selected.length === 0) {
                    return <em>Select</em>;
                  }

                  return selected.join(", ");
                }}
                MenuProps={MenuProps}
                inputProps={{ "aria-label": "Without label" }}
              >
                <MenuItem disabled value="">
                  <em>Select</em>
                </MenuItem>
                {names.map((name) => (
                  <MenuItem
                    key={name}
                    value={name}
                    style={getStyles(name, personName, theme)}
                  >
                    {name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>cancel</Button>
          {personName[0] === "Excel" ? (
            <Button onClick={exportExcel} autoFocus>
              Export
            </Button>
          ) : (
            <Button
              onClick={() => {
                props.downloadPng();
                props.setdownloadCompleted(false);
              }}
              autoFocus
            >
              Export
            </Button>
          )}
        </DialogActions>
      </Dialog>
    </div>
  );
}

export default ExportVDTClient;
