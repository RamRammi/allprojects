import React, { useState, useEffect } from "react";
import { Grid } from "@mui/material";
import Navbar from "../../components/Navbar/Navbar";
import Leftbar from "../../components/Leftbar/Leftbar";
import Button from "@mui/material/Button";
import Box from "@mui/material/Box";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableRow from "@mui/material/TableRow";
import Checkbox from "@mui/material/Checkbox";
import Modal from "@mui/material/Modal";
import TableContainer from "@mui/material/TableContainer";
import Tooltip from "@mui/material/Tooltip";
import CheckIcon from "@mui/icons-material/Check";
import { useLocation } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import SuccssMsg from "../../components/AlertBox/SuccessMsg";
import WarningMsg from "../../components/AlertBox/WarningMsg";
import TableHead from "@mui/material/TableHead";
import * as Constant from "../../comman/constant";
import { BASE_URL } from "../../comman/constant";
import CircularProgress from "@mui/material/CircularProgress";
import ClientImport from "./ClientImport";

const ValueTree = (props) => {
  const [open, setOpen] = useState(false);
  const [err, setErr] = useState("");
  const [checkedId, setCheckedId] = useState([]);
  const [impactData, setImpactData] = React.useState([]);
  const [selectedImpact, setselectedImpact] = useState(0);
  const [spin, setSpin] = useState(false);
  const [checkProcessData, setCheckProcessData] = useState(false);
  const [updatedModelData, setUpdatedModelData] = useState();
  const [VDTDataClientSaved, setVDTDataClientSaved] = useState();
  const [showAlertBox, setShowAlertBox] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");
  const [showWarningBox, setShowWarningBox] = useState(false);
  const [warningMessage, setWarningMessage] = useState("");


  const projectId = useSelector(
    (state) => state.questionnaireReducer.projectId
  );
  const clientId = useSelector((state) => state.questionnaireReducer.clientId);
  const userId = useSelector((state) => state.questionnaireReducer.userId);
  const email = useSelector(
    (state) => state.questionnaireReducer.userData.email
  );

  const navigate = useNavigate();

  useEffect(() => {
    getClientImpactAreaData();
  }, [updatedModelData]);

  const getClientImpactAreaData = () => {
    setSpin(true);
    const loadChecList = async () => {
      await fetch(BASE_URL + Constant.VDT_CLIENT_IMPACT_AREAS, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${localStorage.getItem("jwt")}`,
        },
        body: JSON.stringify({
          projectId: projectId,
          clientId: clientId,
          userId: userId,
          email: email,
        }),
      })
        .then((response) => response.json())
        .then((data) => {
          setImpactData(data);
          setSpin(false);
        })
        .catch((err) => {
          console.log(err.message);
          setSpin(false);
        });
    };
    loadChecList();
  };

  const handleOpen = () => setOpen(true);
  const [selectionProcess, setSelectionProcess] = useState([]);

  const handleClose = () => {
    setOpen(false);
    setErr("");
    setCheckedId([]);
  };

  const previewMaster = (id) => {
    let path = `/valueDriveTrees/master-value-driver/${id}`;
    navigate(path);
  };

  const handleImportChange = (e, value) => {
    if (e.target.checked) {
      setCheckedId([...checkedId, e.target.value]);
      setSelectionProcess(e.target.value);
    } else {
      if (checkedId.length <= 1) {
        setSelectionProcess("");
      }
      setCheckedId(checkedId.filter((id) => id !== e.target.value));
    }
  };

  const handleImportMaster = () => {
    setSpin(true);
    checkedId.map((index) => {
      const loadProcessList = async () => {
        await fetch(BASE_URL + Constant.VDT_CLIENT_IMPORT_SAVE, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${localStorage.getItem("jwt")}`,
          },
          body: JSON.stringify({
            platformUserDetails: {
              projectId: projectId,
              clientId: clientId,
              userId: userId,
              email: email,
            },
            processId: index,
          }),
        })
          .then((res) => res.json())
          .then((result) => {
            if (result.status === 1) {
              setShowAlertBox(true);
              setSpin(false);
              handleClose();
              setTimeout(() => {
                setVDTDataClientSaved(result.newProcessId);
                setUpdatedModelData(result.newProcessId);
                setShowAlertBox(false);
              }, 3000);
              setSuccessMessage("Successfully Imported");
            } else {
              setShowWarningBox(true);
              setWarningMessage(result.msg + "for" + result.processName);
              setTimeout(() => {
                setShowWarningBox(false);
              }, 3000);
              setSpin(false);
              handleClose();
            }
          })
          .catch((err) => console.log(err));
        setCheckProcessData(true);
      };
      loadProcessList();
    });
  };

  const boxStyle = {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    width: "40%",
    bgcolor: "background.paper",
    boxShadow: 24,
    p: 2,
    "@media(max-height: 890px)": {
      top: "0",
      transform: "translate(-50%, 0%)",
    },
  };
  return (
    <div className="process-hierarchy">
      <Navbar />
      <Grid container>
        <Grid item sm={0.8}>
          <Leftbar />
        </Grid>
        <Grid item sm={11.2}>
          <div className="title">
            <Grid container>
              <Grid item xs={8}>
                <h1>{"Value Driver Tree"}</h1>
              </Grid>
              <Grid item xs={4}>
                <div className="formControl">
                  <Button
                    style={{ marginTop: 17 }}
                    className="configure-btn1"
                    onClick={handleOpen}
                    variant="contained"
                  >
                    Configure Impact Areas
                  </Button>
                  <Modal
                    className="hierarchy-modal"
                    open={open}
                    onClose={handleClose}
                    sx={{ overflowY: "scroll", top: "35px" }}
                    disableScrollLock={false}
                    aria-labelledby="modal-modal-title"
                    aria-describedby="modal-modal-description"
                  >
                    <Box sx={boxStyle}>
                      <div className="process-modal">
                        <h4 style={{ marginTop: "5px" }}>Value Drive Tree</h4>
                      </div>
                      {/* <p className="err-content">{err}</p> */}

                      <TableContainer
                        className="source-modal"
                        style={{ maxHeight: 380 }}
                      >
                        <Table
                          stickyHeader
                          sx={{ minWidth: 100 }}
                          aria-label="simple table"
                        >
                          <TableHead>
                            <TableRow>
                              <TableCell></TableCell>
                              <TableCell align="left">S.no</TableCell>
                              <TableCell align="left">Impact Areas</TableCell>
                              <TableCell></TableCell>
                            </TableRow>
                          </TableHead>

                          <TableBody>
                            {impactData.map((row, index) => (
                              <TableRow
                                key={row.id}
                                sx={{
                                  "&:last-child td, &:last-child th": {
                                    border: 0,
                                  },
                                }}
                              >
                                <TableCell
                                  width="10%"
                                  size="small"
                                  padding="checkbox"
                                  component="th"
                                  scope="row"
                                >
                                  {row.isImported === true ? (
                                    <Tooltip
                                      title="This VDT Tree is already imported in the Project."
                                      arrow
                                      placement="top"
                                    >
                                      <CheckIcon
                                        sx={{
                                          color: "#0070ad",
                                          marginTop: "5px",
                                        }}
                                      />
                                    </Tooltip>
                                  ) : (
                                    <Checkbox
                                      value={row.id}
                                      onChange={handleImportChange}
                                    />
                                  )}
                                </TableCell>
                                <TableCell width="20%" align="left">
                                  {index + 1}
                                </TableCell>
                                <TableCell
                                  width="70%"
                                  style={{ color: "#0070AD" }}
                                  align="left"
                                >
                                  {row.name}
                                </TableCell>
                                <TableCell className="processBtn">
                                  <Button
                                    variant="contained"
                                    style={{ marginBottom: "10px" }}
                                    onClick={() => {
                                      previewMaster(row.id);
                                    }}
                                  >
                                    Preview
                                  </Button>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </TableContainer>
                      <div className="processBtn">
                        <Button
                          onClick={() => handleClose()}
                          variant="outlined"
                        >
                          Cancel
                        </Button>
                        <Button
                          onClick={handleImportMaster}
                          disabled={!selectionProcess.length}
                          variant="contained"
                        >
                          Import
                        </Button>
                      </div>
                    </Box>
                  </Modal>
                </div>
              </Grid>
            </Grid>
          </div>

          <div className="rightCol b-0 impactArea">
            {spin && <div className="loader">{<CircularProgress />}</div>}
            <div className="contentBox">
              <ClientImport VDTDataClientSaved={VDTDataClientSaved} />
            </div>
          </div>
        </Grid>
      </Grid>
      <SuccssMsg
        showAlertBox={showAlertBox}
        setShowAlertBox={setShowAlertBox}
        message={successMessage}
      />
      <WarningMsg
        showWarningBox={showWarningBox}
        setShowWarningBox={setShowWarningBox}
        message={warningMessage}
      />
    </div>
  );
};
export default ValueTree;
