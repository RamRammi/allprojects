import React, { useState, useEffect } from "react";
import {
  Button,
  Select,
  TextField,
  MenuItem,
  FormControl,
  FormControlLabel,
  InputLabel,
  Checkbox,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from "@mui/material";
import styles from "./customnode.css";

export const AddNodes = (props) => {
  const [text, setText] = useState("");
  const [parent, setParent] = useState("0");
  const [object, setObject] = useState([]);

  useEffect(() => {
    const newObject = JSON.parse(localStorage.getItem("single-node"));
    if (newObject) {
      setObject(newObject);
    }
  }, []);

  const handleChangeText = (e) => {
    setText(e.target.value);
  };

  return (
    <Dialog open={true} onClose={props.onClose}>
      <DialogTitle>Add New Node</DialogTitle>
      <DialogContent className={styles.content}>
        <div style={{ marginTop: "10px" }}>
          <TextField label="Text" onChange={handleChangeText} value={text} />
        </div>
      </DialogContent>
      <DialogActions>
        <Button onClick={props.onClose}>Cancel</Button>
        <Button
          disabled={text === ""}
          onClick={() =>
            props.onSubmit({
              text,
              parent: object.id,
              droppable: false,
              isRoot: false,
              sequenceNumber:
                object.sequenceNumber +
                Math.floor(Math.random() * (1000 - 100) + 100) / 100,
              createdBy: 0,
              isChecked: props.newSelectedResult ? true : false,
              isNew: true,
              isUpdated: false,
              keyLevel: true,
              keyVDT: false,
              keyKPI: false,
              lblVDT: false,
              vdtText: false,
              kpiText: false,
              impText: false,
              depth: 0,
              createdAt: new Date(),
              modifiedAt: new Date(),
            })
          }
        >
          Add
        </Button>
      </DialogActions>
    </Dialog>
  );
};
