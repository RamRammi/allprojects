import React, { useState } from "react";
import Button from "@mui/material/Button";
import { useNavigate } from "react-router-dom";
import CircularProgress from "@mui/material/CircularProgress";
import * as Constant from "../../comman/constant";
import { BASE_URL } from "../../comman/constant";
import SuccssMsg from "../../components/AlertBox/SuccessMsg";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Modal from "@mui/material/Modal";

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 250,
  textAlign: "center",
  bgcolor: "background.paper",
  border: "2px solid #000",
  boxShadow: 24,
  p: 4,
};
export const VDTSave = (props) => {
  const [saveTree, setSaveTree] = useState();
  const [open, setOpen] = React.useState(false);
  let navigate = useNavigate();
  const [successMessage, setSuccessMessage] = useState("");
  const [showAlertBox, setShowAlertBox] = useState(false);

  const handleBack = () => {
    if (props.saveModal) {
      setOpen(true);
    } else {
      navigate(-1);
    }
  };

  const saveSelectedNode = async () => {
   // console.log('--------',props.newSelectedResult);
    //return;
    await fetch(BASE_URL + Constant.VDT_TREE_SAVE_DATA, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${localStorage.getItem("jwt")}`,
      },
      body: JSON.stringify(props.newSelectedResult),
    })
      .then((res) => res.json())
      .then((result) => {
        setSaveTree(result);
        setShowAlertBox(true);
        if (result.status === 1) {
          setSuccessMessage("Saved Successfully");
        } else {
          setSuccessMessage(result.message);
        }
        setTimeout(() => {
          window.location.href = `/valueDriveTrees/client-value-driver/${props.selectedImpact}`;
        }, 500);
      })
      .catch((err) => console.log(err));
  };

  const [spin, setSpin] = useState(false);
  const handleSubmit = (event) => {
    event.preventDefault();
    saveSelectedNode();
    setSpin(true);
  };

  const handleBackClose = () => setOpen(false);
  return (
    <div className="rightCol footerbtn">
      {spin && (
        <div className="loader">{!saveTree && <CircularProgress />}</div>
      )}
      {props.showBtn ? (
        <>
          {!spin ? (
            <Button
              onClick={handleSubmit}
              style={{ float: "right", marginTop: "0" }}
              variant="contained"
            >
              {saveTree ? "Saved" : "save"}
            </Button>
          ) : (
            <CircularProgress
              size="22px"
              style={{ float: "right", marginTop: "4px", marginLeft: "4px" }}
            />
          )}
        </>
      ) : (
        props.clientValue === "Client preview" && (
          <Button
            onClick={props.handleEdit}
            style={{ float: "right", marginTop: "0" }}
            variant="outlined"
          >
            Edit
          </Button>
        )
      )}

      <Button
        onClick={handleBack}
        style={{ float: "right", marginTop: "0" }}
        variant="outlined"
      >
        Back
      </Button>

      <Modal
        open={open}
        onClose={handleBackClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <Typography id="modal-modal-title" variant="h6" component="h2">
            Save Changes?
          </Typography>
          {!spin ? (
            <>
              <Button
                onClick={handleSubmit}
                style={{ borderRadius: "30px", marginTop: "10px" }}
                variant="contained"
              >
                {saveTree ? "Saved" : "save"}
              </Button>
              <Button
                onClick={() => navigate(-1)}
                style={{
                  borderRadius: "30px",
                  marginLeft: "10px",
                  marginTop: "10px",
                }}
                variant="outlined"
              >
                No
              </Button>
            </>
          ) : (
            <CircularProgress style={{ marginTop: "10px" }} size="22px" />
          )}
        </Box>
      </Modal>
      <SuccssMsg
        showAlertBox={showAlertBox}
        setShowAlertBox={setShowAlertBox}
        message={successMessage}
      />
    </div>
  );
};
