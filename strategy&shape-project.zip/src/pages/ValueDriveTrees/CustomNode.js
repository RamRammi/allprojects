import React, { useState, useEffect } from "react";
import IconButton from "@mui/material/IconButton";
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import TextField from "@mui/material/TextField";
import CheckIcon from "@mui/icons-material/Check";
import CloseIcon from "@mui/icons-material/Close";
import AddCircleOutlineIcon from "@mui/icons-material/AddCircleOutline";
import Checkbox from "@mui/material/Checkbox";
import { useDragOver } from "@minoru/react-dnd-treeview"
import styles from "./customnode.css"

export const CustomNode = (props) => {
  const { id } = props.node;
  const [visibleInput, setVisibleInput] = useState(false);
  const [labelText, setLabelText] = useState(props.node.text);
  const [object, setObject] = useState([]);
  useEffect(() => {
    setObject(props.node);
  }, [object]);

  const storeObj = () => {
    localStorage.setItem("single-node", JSON.stringify(object));
  };

  const handleSelect = (e) => {
    //debugger
    //console.log('props.node---------',props.node);
    props.onSelect(props.node);
    //props.node.isNew = props.addNewNode;
    if (e.target.checked) {
      props.node.isChecked = true;
      if (props.addNewNode) {
        props.node.isNew = props.addNewNode;
      } else {
        props.node.isNew = false;
      }
    } else {
      props.node.isChecked = false;
     // if (props.addNewNode) {
        if(props.addNewNode && props.node.isNew){
          props.node.isNew = true;
          props.node.isUpdated = false;
        } 
        if(!props.addNewNode ){
          props.node.isNew = false;
          props.node.isUpdated = true;
        }

        if(props.addNewNode && !props.node.isNew){
          props.node.isUpdated = true;
        }

        // else{
        //   props.node.isNew = true;
        // }
      // } else {
      //   props.node.isNew = false;
      // }
    }
   // console.log('final-props',props.node);
  };

  props.node.Layer = props.depth + 1;
  props.node.depth = props.depth + 1;
  const handleToggle = (e) => {
    e.stopPropagation();
    props.onToggle(props.node.id);
  };
  const handleShowInput = () => {
    setVisibleInput(true);
  };

  const handleCancel = () => {
    setLabelText(props.node.text);
    setVisibleInput(false);
  };

  const handleChangeText = (e) => {
    setLabelText(e.target.value);
    props.node.isUpdated = true;
  };

  const handleSubmit = () => {
    setVisibleInput(false);
    props.onTextChange(id, labelText);
  };

  const dragOverProps = useDragOver(id, props.isOpen, props.onToggle);
  let styletopHeight =
    props.depth !== 2 &&
    props.depth !== 3 &&
    props.depth !== 4 &&
    props.depth !== 5 &&
    props.depth !== 6
      ? { marginTop: "220px" }
      : { backgroundColor: "" };

  if (props.depth !== 0) {
    styletopHeight = styletopHeight;
  } else {
    styletopHeight = { marginTop: "20px" };
  }
  var maxlength = "";
  
  if (props.node.maxlength) {
    maxlength = "maxlenght" + props.node.maxlength;
  }
  var imp_label = "";
  if (props.node.text === "Improvement Opportunity") {
    imp_label = "imp_label";
  }
  var vDriver_label = "";
  if (props.node.text === "Value Driver") {
    vDriver_label = "vDriver_label";
  }

  if (props.node.impText) {
    var imp_list = "imp_list_" + props.node.impText;
  } else {
    var imp_list = "imp_list_false";
  }

  return (
    <div
      style={styletopHeight}
      className={
        props.node.isChecked +
        " " +
        "tree-subitem-" +
        props.depth +
        " edit_mode_" +
        props.showBtn +
        " " +
        "value_driver_" +
        props.node.keyVDT +
        "_" +
        props.showBtn +
        " " +
        "vdt_label_" +
        props.node.lblVDT +
        " " +
        "vdt_list_" +
        props.node.vdtText +
        " " +
        "kpi_list_" +
        props.node.kpiText +
        " " +
        " " +
        imp_list +
        " " +
        maxlength +
        " " +
        imp_label +
        " " +
        vDriver_label
      }
      onClick={storeObj}
      {...dragOverProps}
    >
      <div className={styles.labelGridItem}>
        {visibleInput ? (
          <div className="edit-node">
            <TextField
              className="single-edit-node"
              value={labelText}
              onChange={handleChangeText}
            />
            <IconButton
              className="edit-button"
              onClick={handleSubmit}
              disabled={labelText === ""}
            >
              <CheckIcon className="edit-icon" />
            </IconButton>
            <IconButton className="edit-button" onClick={handleCancel}>
              <CloseIcon className="edit-icon" />
            </IconButton>
          </div>
        ) : (
          <div className={`normal-node ${props.node.isChecked}`}>
            <span
              style={{
                borderLeftColor: props.node.color,
                borderLeftStyle: "solid",
                borderLeftWidth: "6px",
              }}
              className={
                props.node.lblVDT ? "node-text vdtLabel" : "node-text "
              }
              onClick={handleShowInput}
            >
              {props.node.text}
            </span>
            {!props.node.keyVDT &&
            !props.node.lblVDT &&
            props.node.keyLevel &&
            !props.node.maxlength ? (
              <span className="connector"></span>
            ) : (
              ""
            )}
            {props.node.vdtText && !props.node.impText ? (
              <>
                <br />{" "}
                <label class={"vdt_label" + " " + "lvl_" + props.node.depth}>
                  <span class="kpiConnector"></span>KPI
                </label>
              </>
            ) : (
              ""
            )}
            {
              <span className="node-navIcon" onClick={handleToggle}>
                {!props.node.keyKPI &&
                !props.node.maxlength &&
                (!props.node.impText || props.node.lblVDT) &&
                !props.node.kpiText ? (
                  <>
                    {props.isOpen ? (
                      <KeyboardArrowUpIcon
                        className={
                          props.node.lblVDT || props.node.vdtText
                            ? "edit-icon"
                            : "edit-icon iconlefttoright"
                        }
                      />
                    ) : (
                      <KeyboardArrowDownIcon
                        className={
                          props.node.lblVDT || props.node.vdtText
                            ? "edit-icon"
                            : "edit-icon iconlefttoright"
                        }
                      />
                    )}
                  </>
                ) : (
                  ""
                )}
              </span>
            }
            {props.showBtn ? (
              <>
                {!props.node.maxlength &&
                (props.node.keyLevel ||
                  props.node.lblVDT ||
                  !props.node.keyKPI) ? (
                  <>
                    {(!props.node.impText || props.node.lblVDT) &&
                      !props.node.kpiText && (
                        <AddCircleOutlineIcon
                          onClick={props.handleOpenDialog}
                          className="add-node"
                          data-id={props.node.maxlength}
                        />
                      )}
                  </>
                ) : (
                  ""
                )}
                {!props.node.lblVDT && (
                  <Checkbox
                    data-id={props.node.isChecked}
                    className="check-node"
                    color="primary"
                    size="small"
                    checked={props.node.isChecked ? true : false}
                    onClick={handleSelect}
                  />
                )}
              </>
            ) : (
              ""
            )}
          </div>
        )}
      </div>
    </div>
  );
};
