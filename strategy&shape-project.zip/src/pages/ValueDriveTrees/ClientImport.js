import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import * as Constant from "../../comman/constant";
import { BASE_URL } from "../../comman/constant";
import "./clientimport.css";
import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import { useSelector } from "react-redux";

const ClientImport = (props) => {
  const [expanded, setExpanded] = useState(
    props.expandAll || props.isCheckedId === true ? true : false
  );
  const [panelids, setpanelids] = useState([]);
  const [importedListing, setimportedListing] = useState([]);
  const projectId = useSelector(
    (state) => state.questionnaireReducer.projectId
  );
  useEffect(() => {
    getClientImportedDataList();
  }, [props.VDTDataClientSaved]);

  const getClientImportedDataList = () => {
    const importedList = async () => {
      let URL = Constant.VDT_CLIENT_IMPORTED_LISTING;
      await fetch(BASE_URL + URL + "?projectId=" + projectId, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${localStorage.getItem("jwt")}`,
        },
      })
        .then((response) => response.json())
        .then((data) => {
          setimportedListing(data);
        })
        .catch((err) => {
          console.log(err.message);
        });
    };
    importedList();
  };

  useEffect(() => {
    getcs();
  }, [props.expandAll, props.searchStr, props.isCheckedId]);

  const getcs = () => {
    let ids = [];
    if (props.expandAll === true) {
      props.processData.map((k) => {
        ids.push(k.id);
      });
      setpanelids(ids);
    } else if (props.isCheckedId != "") {
      setpanelids(props.isCheckedId);
    } else {
      setpanelids([]);
    }
  };

  const handleChange = (panel) => async (event, newExpanded) => {
    setExpanded(newExpanded ? panel : false);
    if (panelids.includes(panel)) {
      let arr = panelids;
      const ryu = arr.filter((item) => item !== panel);
      await setpanelids(ryu);
    } else {
      let arr = panelids;
      arr.push(panel);
      await setpanelids(arr);
    }
  };
  return (
    <div>
      {importedListing != "" ? (
        importedListing.map((panel) => (
          <Accordion
            disableGutters={true}
            square={true}
            expanded={expanded === panel.id}
            onChange={handleChange(panel.id)}
          >
            <AccordionSummary
              className="accordion-box-display"
              expandIcon={
                <ExpandMoreIcon
                  width="medium"
                  style={{ fill: "#0070ad", transform: "scale(1.3)" }}
                />
              }
              aria-controls={panel.name}
              id={panel.id}
            >
              <Link to={`/valueDriveTrees/client-value-driver/${panel.id}`}>
                <p style={{ float: "left", marginRight: "8px" }}>
                  {panel.name}
                </p>
                <em
                  style={{
                    float: "right",
                    fontSize: "10px",
                    textDecoration: "underline",
                    marginTop: "3px",
                    marginRight: "10px",
                  }}
                >
                  {panel.emailId}{" "}
                </em>
              </Link>
            </AccordionSummary>
          </Accordion>
        ))
      ) : (
        <div style={{ marginTop: "15px" }}>
          <em>No Records Found</em>
        </div>
      )}
    </div>
  );
};
export default ClientImport;
