import React, { useState, useEffect, useCallback } from "react";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import Box from "@mui/material/Box";
import "./impactAreas.css";
import * as Api from "../../comman/api";
import * as Constant from "../../comman/constant";
import { Link } from "react-router-dom";

export const ImpactAreas = (props) => {
  console.log("props values", props.uriSelectImpactid);
  const [impactData, setImpactData] = React.useState([]);
  const [defaultSelectId, setdefaultSelectId] = React.useState(0);
  const [masterImpactSelectId, setmasterImpactSelectId] = React.useState(0);
  const [spin, setSpin] = useState(false);
  const getPropImpactId = useCallback(() => {
    if (props.impactIdfromURI) {
      setmasterImpactSelectId(props.impactIdfromURI);
    }
  }, [props.impactIdfromURI]);

  const getUriPropImpactId = useCallback(() => {
    if (props.uriSelectImpactid) {
      setmasterImpactSelectId(props.uriSelectImpactid);
    }
  }, [props.uriSelectImpactid]);

  const handleChange = (event) => {
    props.selectedImpactid(event.target.value);
    setdefaultSelectId(event.target.value);
  };

  const getImpactAreaData = () => {
    setSpin(true);
    let industryId = Constant.IndustryId;
    let URL = Constant.VDT_IMPACT_AREA + "?industryId=" + industryId;
    Api.getImpactAreasList(URL).then((res) => {
      setImpactData(res);
      setSpin(false);
    });
  };

  useEffect(() => {
    getImpactAreaData();
  }, []);

  useEffect(() => {
    getPropImpactId();
  }, [getPropImpactId]);

  useEffect(() => {
    getUriPropImpactId();
  }, [getUriPropImpactId]);

  return (
    <div className="rightCol impactArea">
      {spin && <div className="loader nit"></div>}
      <Box sx={{ m: 1, width: 300 }}>
        <FormControl fullWidth>
          <InputLabel id="demo-simple-select-label">Impact Areas </InputLabel>
          <Select
            onChange={handleChange}
            value={defaultSelectId ? defaultSelectId : masterImpactSelectId}
          >
            <MenuItem value={0}>Select Impact Areas</MenuItem>
            {impactData.map((result) => (
              <MenuItem
                className="VDT-select-change"
                key={result.id}
                value={result.id}
              >
                <Link to={`/valueDriveTrees/master-value-driver/${result.id}`}>
                  {result.name}
                </Link>
              </MenuItem>
            ))}
          </Select>
        </FormControl>
      </Box>
    </div>
  );
};
