import React, { useState, useEffect, Suspense, useCallback } from "react";
import { Grid } from "@mui/material";
import { ThemeProvider } from "@mui/material";
import { theme } from "../../../theme";
import { useLocation } from "react-router-dom";
import * as Constant from "../../../comman/constant";
import * as Api from "../../../comman/api"
import FormControl from "@mui/material/FormControl";
import MenuItem from "@mui/material/MenuItem";
import Select from "@mui/material/Select";
import Checkbox from "@mui/material/Checkbox";
import ListItemText from "@mui/material/ListItemText"
import InputLabel from "@mui/material/InputLabel";
import ListItemIcon from "@material-ui/core/ListItemIcon"
import { DndProvider } from "react-dnd";
import {
  Tree,
  MultiBackend,
  getBackendOptions,
  getDescendants,
} from "@minoru/react-dnd-treeview"
import styles from "./../nodeTree.css"
import Navbar from "../../../components/Navbar/Navbar"
import { VDTSave } from "./../VDTSave"
import { AddNodes } from "./../AddNodes";
import { CustomNode } from "./../CustomNode";
import { CustomDragPreview } from "./../CustomDragPreview"
import ExportVDTClient from "./../ExportVDTClient";
import { toPng } from "html-to-image";
import jsPDF from "jspdf";
import { useSelector } from "react-redux";
import { MenuProps, useStyles, options } from "../multiselect";
import CircularProgress from "@mui/material/CircularProgress";

const ValueTree = (props) => {
  const [nodeData, setNodeData] = useState([])
  const [showBtn, setShowBtn] = useState(false)
  const [treeData, setTreeData] = useState([])
  const handleDrop = (newTree) => setTreeData(newTree);
  const [initialLevel, setInitialLevel] = useState();
  const [defaultLevel, setdefaultLevel] = useState();
  const [arrWith, setArrWith] = useState([]);
  const [clientId, setClientId] = useState();
  const [imapctName, setimapctName] = useState("");
  const [addNewNode, setAddNewNode] = useState(false);
  const [updatedNode, setUpdatedNode] = useState();
  const [selectedNodes, setSelectedNodes] = useState([]);
  const location = useLocation();
  const [nodeDepth, setNodeDepth] = useState();
  const [topHeight, settopHeight] = useState(false);
  const [bottomHeight, setbottomHeight] = useState(false);
  const [open, setOpen] = useState(false);
  const [openVDT, setOpenVDT] = useState(false)
  const [selectedImpact, setselectedImpact] = useState(0);
  const ref = React.createRef();
  const [fileNamePDF, setFileNamePDF] = useState("");
  const [downloadCompleted, setdownloadCompleted] = useState(false);
  const [downloadFunction, setDownloadFunction] = useState(false);
  const [updateFormat, setupdateFormat] = useState(true);
  const [maxlengthlvl4, setmaxlengthlvl4] = useState(false);
  const [detailView, setdetailView] = React.useState(["Detail View"]);
  const [enableDnd, setEnableDnd] = useState(false);
  const [saveModal, setSaveModal] = useState(false);
  const [uriSelectImpactid, seturiSelectImpactid] = useState();
  const [spin, setSpin] = useState(false);

  const projectId = useSelector(
    (state) => state.questionnaireReducer.projectId
  );
  const userId = useSelector((state) => state.questionnaireReducer.userId);
  const email = useSelector(
    (state) => state.questionnaireReducer.userData.email
  );

  if (showBtn) {
    require("./../customeditmode.css");
    require("./../customtreeedit.css");
  } else {
    require("./../customviewmode.css");
    require("./../customtreeview.css");
  }

  const variable = location.pathname.substring(
    location.pathname.lastIndexOf("/") + 1
  )

  const setSelectImpactId = useCallback(() => {
    const impId = location.pathname.substring(
      location.pathname.lastIndexOf("/") + 1
    );
    if (impId) {
      setselectedImpact(impId);
      seturiSelectImpactid(impId);
    }
  }, [location.pathname]);

  let industryId = Constant.IndustryId;
  useEffect(() => {
    setSpin(true);
    setSelectImpactId();
    setdefaultLevel(0);
    if (selectedImpact) {
      let URL =
        Constant.VDT_CLIENT_TREE_DATA +
        "?industryId=" +
        industryId +
        "&id=" +
        selectedImpact +
        "&projectId=" +
        projectId;
      Api.getVDTTreeDataList(URL).then((response) => {
        setNodeData(response)
        newArr(response)
        setSpin(false);
      });
    }
  }, [selectedImpact, setSelectImpactId]);

  // Set and Update plain Json format
  const newArr = useCallback((arrData) => {
    setimapctName(arrData.name);
    const arr1 = [arrData].flatMap((elem) => elem.l2List);
    const arr2 = arr1
      .map((elem) => {
        if (elem) {
          return elem.l3List;
        }
      })
      .filter((el) => {
        if (el) {
          return el != 0
        }
      })
      .map((e) => {
        if (e) {
          return e;
        }
      })
      .flat(1)

    var maxlengthl4Exist = ""
    const arr2_4bph = arr2
      .map((elem) => {
        if (elem.maxlength) {
          setmaxlengthlvl4(1)
          maxlengthl4Exist = true;
        }
        if (elem) {
          return elem.l4List;
        }
      })
      .flat(2)

    if (maxlengthl4Exist) {
      if (arr2_4bph) {
        var arr2_l4vdt = arr2_4bph
          .map((elem) => {
            if (elem !== undefined && elem.lblVDT === true) {
              return elem.vdtlst;
            }
          })
          .flat(1)
      }

      if (arr2_4bph) {
        var arr2_l4imp = arr2_4bph
          .map((elem) => {
            if (elem !== undefined && elem.lblVDT === true) {
              return elem.implst;
            }
          })
          .flat(1)
      }

      var arr2_L4kpi = arr2_l4vdt
        .map((elem) => {
          if (elem) {
            return elem.kpIlst;
          }
        })
        .flat(1)
    }

    const arr2_5bph = arr2_4bph
      .map((elem) => {
        if (elem) {
          return elem.l5List;
        }
      })
      .flat(1)

    if (arr2_5bph) {
      var arr2_7vdt = arr2_5bph
        .map((elem) => {
          if (elem !== undefined && elem.lblVDT === true) {
            return elem.vdtlst;
          }
        })
        .flat(1)
    }

    if (arr2_5bph) {
      var arr2_7imp = arr2_5bph
        .map((elem) => {
          if (elem !== undefined && elem.lblVDT === true) {
            return elem.implst;
          }
        })
        .flat(1)
    }

    const arr2_15KPI = arr2_7vdt
      .map((elem) => {
        if (elem) {
          return elem.kpIlst;
        }
      })
      .flat(1)

    let getAllvl4VDTTextList = "";
    let getAllvlVDTTextList = "";
    if (arr2_L4kpi) {
      getAllvl4VDTTextList = arr2_L4kpi.filter(getVDIId);
    }
    if (arr2_15KPI) {
      getAllvlVDTTextList = arr2_15KPI.filter(getVDIId);
    }
    function getVDIId(data) {
      if (data) {
        return data;
      }
    }

    const simpleObj = {};
    const destructure = (obj) => {
      for (let key in obj) {
        const value = obj[key];
        const type = typeof value;
        if (
          ["string", "boolean"].includes(type) ||
          (type === "number" && !isNaN(value))
        ) {
          simpleObj[key] = value;
        }
      }
      Object.assign(simpleObj, { parent: 0 });
      return simpleObj
    };

    arr1.push(destructure(arrData));
    arr2.push(arr1)

    if (arr2_4bph) {
      var arrNotVdtStatic = arr2_4bph.filter((n) => {
        return n.lblVDT === false;
      });
    }
    const removeStaticNodeIds = arr2.concat(arrNotVdtStatic);
    arr2.push(arr2_4bph)
    const multiDimArrayInitial = removeStaticNodeIds.map((items) => {
        if (items) {
          return items
        }
      })
      .flat(1)
    arr2.push(arr2_5bph)

    const initialDescription = JSON.parse(
      JSON.stringify(multiDimArrayInitial).split('"name":').join('"text":')
    );
    const initialParent1 = JSON.parse(
      JSON.stringify(initialDescription).split('"parentId":').join('"parent":')
    );
    const initialParent2 = JSON.parse(
      JSON.stringify(initialParent1).split('"parentId":').join('"parent":')
    );
    const initialParent2_1 = JSON.parse(
      JSON.stringify(initialParent2).split('"parentId":').join('"parent":')
    );
    const initialParent2_2 = JSON.parse(
      JSON.stringify(initialParent2_1).split('"parentId":').join('"parent":')
    );
    const arrWithInitialDroppable = initialParent2_2.map((object) => {
      return { ...object, droppable: false, isChecked: true };
    });

    const initialParent3 = arrWithInitialDroppable.map((object) => {
      return { ...object, isUpdated: false };
    });
    const initialParent4 = initialParent3.map((object) => {
      return { ...object, isNew: false };
    });

    let primaryIds = initialParent4.map((node) => node.id);

    setClientId(primaryIds);
    arr2.push(arr2_l4vdt)
    arr2.push(arr2_l4imp)
    arr2.push(getAllvl4VDTTextList)

    arr2.push(arr2_7vdt)
    arr2.push(arr2_7imp)
    arr2.push(getAllvlVDTTextList)

    const multiDimArray = arr2
      .map((items) => {
        if (items) {
          return items;
        }
      })
      .flat(1);

    setInitialLevel(multiDimArray);
    const renameDescription = JSON.parse(
      JSON.stringify(multiDimArray).split('"name":').join('"text":')
    );
    const renameParent1 = JSON.parse(
      JSON.stringify(renameDescription).split('"parentId":').join('"parent":')
    );
    const renameParent2 = JSON.parse(
      JSON.stringify(renameParent1).split('"parentId":').join('"parent":')
    );
    const renameParent2_1 = JSON.parse(
      JSON.stringify(renameParent2).split('"parentId":').join('"parent":')
    );
    const renameParent2_2 = JSON.parse(
      JSON.stringify(renameParent2_1).split('"parentId":').join('"parent":')
    );
    const arrWithDroppable = renameParent2_2.map((object) => {
      return { ...object, droppable: false };
    });

    const renameParent3 = arrWithDroppable.map((object) => {
      return { ...object, isUpdated: false };
    });
    const renameParent4 = renameParent3.map((object) => {
      return { ...object, isNew: false };
    });
    setArrWith(renameParent4)
  }, [])

  /// for apply using useEffect
  useEffect(() => {
    setTreeData(arrWith);
  }, [nodeData]);

  useEffect(() => {
    setTreeData(arrWith);
  }, [arrWith])

  const handleEdit = () => {
    setShowBtn(true)
    setEnableDnd(false)
  };

  const handleBack = () => {
    setShowBtn(false)
  };

  // When select a particular node
  const handleSelect = (node) => {
    const item = selectedNodes.find((n) => n.id === node.id);
    if (!item) {
      node["isUpdated"] = true;
      setSelectedNodes([...selectedNodes, node]);
    } else {
      setSelectedNodes(selectedNodes.filter((n) => n.id !== node.id))
    }
    setSaveModal(true);
  };

  const handleCallback = (childData) => {
    setNodeDepth(childData);
  };

  const handleOpenDialog = () => {
    setOpen(true);
  };

  const handleCloseDialog = () => {
    setOpen(false);
  };

  const handleOpenDialogVDT = () => {
    setOpenVDT(true);
  };

  const handleCloseDialogVDT = () => {
    setOpenVDT(false);
  };

  const handleTextChange = (id, value) =>{
    const newTree = treeData.map((node) => {
      if (node.id === id) {
        node["isUpdated"] = true
        node["emailId"] = email
        return {
          ...node,
          text: value,
        }
      }
      return node;
    })
    setTreeData(newTree)
    setSaveModal(true)
  }

  function uuidv3() {
    return ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, (c) =>
      (
        c ^
        (crypto.getRandomValues(new Uint8Array(1))[0] & (15 >> (c / 4)))
      ).toString(16)
    );
  }

  function uuidv4() {
    return ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, (c) =>
      (
        c ^
        (crypto.getRandomValues(new Uint8Array(1))[0] & (15 >> (c / 4)))
      ).toString(16)
    );
  }

  function addStaticNodeOnMaxLength(lastId) {
    clientId.push(lastId);
    treeData.push(
      {
        id: uuidv4(),
        text: "Value Driver",
        parent: lastId,
        isRoot: false,
        depth: 5,
        keyLevel: false,
        keyVDT: false,
        sequenceNumber: null,
        lblVDT: true,
        vdtText: false,
        kpiText: false,
        maxlength: false,
        vdtlst: [],
        implst: [],
      },
      {
        id: uuidv4(),
        text: "Improvement Opportunity",
        parent: lastId,
        isRoot: false,
        depth: 5,
        keyLevel: false,
        keyVDT: false,
        sequenceNumber: null,
        lblVDT: true,
        vdtText: false,
        kpiText: false,
        maxlength: false,
        vdtlst: [],
        implst: null,
      }
    );
  }

  const handleSubmit = (newNode) => {
    setAddNewNode(true)
    treeData.map((node) => {
      if (node.id === newNode.parent){
        if (node.text === "Improvement Opportunity" && node.lblVDT) {
          clientId.pop(node.id);
          clientId.push(node.id);
          clientId.push(node.parent)
          newNode["actualId"] = node.parent;
          newNode["parent"] = node.id;
          newNode["impText"] = true;
          node["impText"] = true;
          let updateSeql4 = "";
          if (newNode["depth"] == 6) {
            updateSeql4 = "1.2.1." + newNode["sequenceNumber"];
            newNode["sequenceNumber"] = updateSeql4
          } else {
            updateSeql4 = "1.2.1" + newNode["sequenceNumber"];
            newNode["sequenceNumber"] = updateSeql4
          }
        }
        if (node.text === "Value Driver" && node.lblVDT) {
          newNode["vdtText"] = true;
          newNode["actualId"] = node.parent;
          let updateSeql4Vdt = "";
          if (newNode["depth"] == 6) {
            updateSeql4Vdt = "1.2.1." + newNode["sequenceNumber"];
            newNode["sequenceNumber"] = updateSeql4Vdt
          } else {
            updateSeql4Vdt = "1.2.1" + newNode["sequenceNumber"];
            newNode["sequenceNumber"] = updateSeql4Vdt
          }
          clientId.push(node.id);
        }
        if (node.keyLevel && !node.vdtText) {
          newNode["keyLevel"] = true;
          newNode["isNew"] = true
          clientId.push(newNode.parent);
        }

        if (node.keyLevel && node.vdtText) {
          clientId.push(node.id);
          newNode["keyKPI"] = true;
          newNode["kpiText"] = true;
        }
        return (newNode["depth"] = node.depth + 1);
      }
      return node;
    });

    var getLastNode = treeData.find((item) => item.parent === newNode.parent)
    const lastId = uuidv3()
    if (getLastNode !== undefined) {
      if (
        ((getLastNode.l4List && getLastNode.l4List.length > 0) ||
          (getLastNode.l5List && getLastNode.l5List.length > 0)) &&
        getLastNode.maxlength
      ) {
        if (
          getLastNode.l4List &&
          getLastNode.l4List.length > 0 &&
          (newNode["impText"] || newNode["vdtText"])
        ) {
          const updateSeql4 = "1.2.1" + newNode["sequenceNumber"];
          newNode["sequenceNumber"] = updateSeql4
        }
        if (
          getLastNode.l5List &&
          getLastNode.l5List.length > 0 &&
          (newNode["impText"] || newNode["vdtText"])
        ) {
          const updateSeql5 = "1.2.1.2" + newNode["sequenceNumber"];
          newNode["sequenceNumber"] = updateSeql5
        }
        newNode["maxlength"] = true;
        clientId.push(lastId)
        addStaticNodeOnMaxLength(lastId);
      }
    } else {
      if (
        !newNode.impText &&
        !newNode.kpiText &&
        !newNode.vdtText &&
        newNode.depth === 4
      ) {
        newNode["maxlength"] = true;
        addStaticNodeOnMaxLength(lastId)
      }
    }

    setTreeData([
      ...treeData,
      {
        ...newNode,
        id: lastId,
      },
    ])
    clientId.push(lastId)
    setOpen(false);
    setupdateFormat(true);
    setSaveModal(true)
  };

  let arrWithUpdatedJson = [];
  if (updateFormat){
    const renameDescription = JSON.parse(
      JSON.stringify(treeData)
        .split('"text":')
        .join('"name":')
        .split('"parent":')
        .join('"parentVDId":')
        .split('"droppable":')
        .join('"isDropped":')
    );
    arrWithUpdatedJson = renameDescription.map((object) => {
      if (object.parentVDId === 0) {
        object["parentVDId"] = "0";
      }

      if (object.impText || object.vdtText) {
        object["parentVDId"] = object.actualId;
      }

      if (object.isUpdated === true){
        object["modifiedBy"] = userId;
        console.log("INmydate");
      } else {
        object["modifiedBy"] = "";
      }
      return {
        ...object,
        industryId: industryId,
        projectId: projectId,
        createdBy: userId,
        createdAt: new Date(),
        modifiedAt: new Date(),
        keyKPI: false,
      };
    });
    arrWithUpdatedJson = arrWithUpdatedJson.map(
      ({ keyVDT, keyLevel, actualId, ...rest }) => rest
    );
    arrWithUpdatedJson = arrWithUpdatedJson.filter((obj) =>
      Object.keys(obj).includes("id")
    )
    console.log('arrWithUpdatedJson',arrWithUpdatedJson);
  }

  // Select Level Preference using dropdown list
  const initialOpenTreeLevel = (event) => {
    const initialLevel = [nodeData].flatMap((elem) => elem.l2List);
    const getAllclientL1BPHId = initialLevel.map((node) => node.parentId)
    const lvl2 = initialLevel
      .map((elem) => {
        if (elem) {
          return elem.l3List;
        }
      })
      .filter((el) => {
        if (el) {
          return el != 0;
        }
      })
      .map((e) => {
        if (e) {
          return e;
        }
      })
      .flat(1);
    let getAllclientL2BPHId = lvl2.map((node) => node.parentId);
    const lvl3 = lvl2
      .map((elem) => {
        if (elem) {
          return elem.l4List;
        }
      })
      .flat(2);

    const lvl4 = lvl3
      .map((elem) => {
        if (elem) {
          return elem.l5List;
        }
      })
      .flat(2);

    let getAllclientL3BPHId = lvl3.map((node) => node.parentId);
    let getAllclientL5Id = lvl4.map((node) => node.parentId);
    const getAllclient4All = getAllclientL1BPHId.concat(getAllclientL2BPHId);
    const getAllclient5 = getAllclient4All.concat(getAllclientL3BPHId);
    const getAllclient5All = getAllclient5.concat(getAllclient4All);
    const getAllclient6All = getAllclientL5Id.concat(getAllclient5);

    setSelected([])
    setdefaultLevel(event.target.value);
    settopHeight(false);
    setbottomHeight(false);

    switch (event.target.value){
      case 0:
        setClientId(getAllclient6All)
        break;
      case 10:
        setClientId(nodeData.id)
        break;
      case 20:
        setClientId(getAllclientL1BPHId)
        setbottomHeight(true)
        break;
      case 30:
        setClientId(getAllclient4All)
        setbottomHeight(true)
        break;
      case 40:
        setClientId(getAllclient5)
        break;
      case 50:
        setClientId(getAllclient5All)
        break;
      default:
        setdefaultLevel(event.target.value)
    }
  };

  const handleDelete = (id) => {
    const deleteIds = [
      id,
      ...getDescendants(treeData, id).map((node) => node.id),
    ];
    const newTree = treeData.filter((node) => !deleteIds.includes(node.id));
    setTreeData(newTree);
    setSaveModal(true);
  }

  const newSelectedResult = [...new Set(arrWithUpdatedJson)]
  useEffect(() => {
    const renameTitle = JSON.parse(JSON.stringify(treeData));
    const initialLoadTitle = renameTitle.map((id) => {
      if (id.parent === 0) return id.text;
    });
    setimapctName(initialLoadTitle);
  }, [treeData]);

  //export pdf
  const textValues = (value) => {
    setFileNamePDF(value);
  }
  const downloadPng = useCallback(() => {
    setDownloadFunction(true);
    if (ref.current === null) {
      return;
    }
    toPng(ref.current)
      .then((dataUrl) => {
        const link = document.createElement("a");
        link.download = "download file";
        link.href = dataUrl;
        window.location.href = dataUrl;
        const imgData = dataUrl;
        const pdf = new jsPDF("p", "mm", "a4");
        const imgProps = pdf.getImageProperties(imgData);
        var pdfWidth = pdf.internal.pageSize.getWidth();
        var height = pdf.internal.pageSize.getHeight();
        var ratio = pdfWidth / pdfWidth;
        height = ratio * pdfWidth;
        const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
        const pageHeight = pdf.internal.pageSize.height;
        pdf.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight);
        pdf.save(fileNamePDF);
        setdownloadCompleted(true);
        setDownloadFunction(false);
      })
      .catch((err) => {
        console.log(err.message);
      });
  }, [ref]);

  ////////////Detail View Multi select option ////////
  const classes = useStyles();
  const [selected, setSelected] = useState([]);
  const isAllSelected =
    options.length > 0 && selected.length === options.length;
    const handleDetailViewChange = (event) => {
    const value = event.target.value;

    /////////////////Get data from Tree Part////////
    const initialLevel = [nodeData].flatMap((elem) => elem.l2List);
    let getAllclientL2BPHId = initialLevel.map((node) => node.parentId);

    const lvl2 = initialLevel
      .map((elem) => {
        if (elem) {
          return elem.l3List;
        }
      })
      .filter((el) => {
        if (el) {
          return el != 0;
        }
      })
      .map((e) => {
        if (e) {
          return e;
        }
      })
      .flat(1);
    let getAllvl3List = lvl2.map((node) => node.parentId);
    const lvl3 = lvl2
      .map((elem) => {
        if (elem) {
          return elem.l4List;
        }
      })
      .flat(2);

    let getAllvl4List = lvl3.map((node) => node.parentId)
    const lvl4 = lvl3
      .map((elem) => {
        if (elem) {
          return elem.l5List;
        }
      })
      .flat(2);

    let getAllvl5List = lvl4.map((node) => node.parentId);
    const lvl5 = lvl4
      .map((elem) => {
        if (elem) {
          return elem.l6List;
        }
      })
      .flat(2);

    let getAllvl6VDTLabels = lvl5.filter(getVDIId);
    let getAllvl6VDTLabelsIds = getAllvl6VDTLabels.map((node) => node.parentId)
    const lvl3Vdt = lvl3
      .map((elem) => {
        if (elem) {
          return elem.vdtlst;
        }
      })
      .flat(2);

    const lvl4Vdt = lvl4
      .map((elem) => {
        if (elem) {
          return elem.vdtlst;
        }
      })
      .flat(2);

    const lvl5Vdt = lvl5
      .map((elem) => {
        if (elem) {
          return elem.vdtlst;
        }
      })
      .flat(2);

    const lvl3Imp = lvl3
      .map((elem) => {
        if (elem) {
          return elem.implst;
        }
      })
      .flat(2)
    const lvl4Imp = lvl4
      .map((elem) => {
        if (elem) {
          return elem.implst;
        }
      })
      .flat(2)
    const lvl5Imp = lvl5
      .map((elem) => {
        if (elem) {
          return elem.implst;
        }
      })
      .flat(2)
    const lvl3Kpi = lvl3Vdt
      .map((elem) => {
        if (elem) {
          return elem.kpIlst;
        }
      })
      .flat(2)
    const lvl4Kpi = lvl4Vdt
      .map((elem) => {
        if (elem) {
          return elem.kpIlst;
        }
      })
      .flat(2)
    const lvl5Kpi = lvl5Vdt
      .map((elem) => {
        if (elem) {
          return elem.kpIlst;
        }
      })
      .flat(2);

    const lvl6 = "";
    const lvl7 = "";

    let getAllvl3VDTList = lvl3Vdt.filter(getVDIId);
    let getAllvl3VDTListIds = getAllvl3VDTList.map((node) => node.parentId)
    let getAllvl4VDTList = lvl4Vdt.filter(getVDIId);
    let getAllvl4VDTListIds = getAllvl4VDTList.map((node) => node.parentId)
    let getAllvl5VDTList = lvl5Vdt.filter(getVDIId);
    let getAllvl5VDTListIds = getAllvl5VDTList.map((node) => node.parentId)
    let getAllvl3IMPList = lvl3Imp.filter(getVDIId);
    let getAllvl3IMPListIds = getAllvl3IMPList.map((node) => node.parentId)
    let getAllvl4IMPList = lvl4Imp.filter(getVDIId);
    let getAllvl4IMPListIds = getAllvl4IMPList.map((node) => node.parentId)
    let getAllvl5IMPList = lvl5Imp.filter(getVDIId);
    let getAllvl5IMPListIds = getAllvl5IMPList.map((node) => node.parentId)
    let getAllvl3KPIText = lvl3Kpi.filter(getVDIId);
    let getAllvl3KPITextIds = getAllvl3KPIText.map((node) => node.parentId)
    let getAllvl4KPIText = lvl4Kpi.filter(getVDIId);
    let getAllvl4KPITextIds = getAllvl4KPIText.map((node) => node.parentId)
    let getAllvl5KPIText = lvl5Kpi.filter(getVDIId);
    let getAllvl5KPITextIds = getAllvl5KPIText.map((node) => node.parentId)

    function getVDIId(data) {
      if (data) {
        return data;
      }
    }

    const getlavel23 = getAllvl3List.concat(getAllclientL2BPHId);
    const getlavel34 = getAllvl4List.concat(getlavel23);
    const getlavel45 = getAllvl5List.concat(getlavel34)
    const getlevel3VdtList = getAllvl3VDTListIds.concat(getlavel45);
    const getlevel4VdtList = getAllvl4VDTListIds.concat(getlavel45);
    const getlevel5VdtList = getAllvl5VDTListIds.concat(getlavel45)
    const vdtlstlevel3Ids = getlevel3VdtList.concat(getlevel4VdtList);
    const vdtlstlevel4Ids = getlevel4VdtList.concat(getlevel5VdtList);
    const vdtlstlevelIds = vdtlstlevel4Ids.concat(vdtlstlevel3Ids)
    const getlevel3ImpList = getAllvl3IMPListIds.concat(getlavel45);
    const getlevel4ImpList = getAllvl4IMPListIds.concat(getlavel45);
    const getlevel5ImpList = getAllvl5IMPListIds.concat(getlavel45)
    const vdtlstlevel3IdsImp = getlevel3ImpList.concat(getlevel4ImpList);
    const vdtlstlevel4IdsImp = getlevel4ImpList.concat(getlevel5ImpList);
    const vdtlstlevelIdsImp = vdtlstlevel4IdsImp.concat(vdtlstlevel3IdsImp)
    const getlevel3KpiList = getAllvl3KPITextIds.concat(vdtlstlevel3Ids);
    const getlevel4KpiList = getAllvl4KPITextIds.concat(vdtlstlevelIds);
    const getlevel5KpiList = getAllvl5KPITextIds.concat(vdtlstlevelIds)
    const getlevel34KPITextList = getlevel4KpiList.concat(getlevel3KpiList);
    const getlevelKPITextList = getlevel5KpiList.concat(getlevel34KPITextList);

    ////////////////////////End ////////////////////
    settopHeight(false)
    setbottomHeight(false);
    const actualValue = value.length
    if (value[value.length - 1] === "all") {
      setdefaultLevel(0);
      setSelected(selected.length === options.length ? [] : options)
      settopHeight(true);
      if (value.length === 1){
        const alldataVDTIMP = vdtlstlevelIds.concat(vdtlstlevelIdsImp);
        const allData = alldataVDTIMP.concat(getlevelKPITextList);
        setClientId(allData);
      }
      if (value.length === 4){
        settopHeight(true);
        setClientId(getlevel5VdtList);
      }
      return;
    }
    setSelected(value);
    setdetailView(
      // On autofill we get a stringified value.
      typeof value === "string" ? value.split(",") : value
    );
    if (value.length > 0){
      setdefaultLevel(0);
      const filterVal = value.map(function (node) {
        return node.toLowerCase().replace(/\s+/g, "");
      });
      settopHeight(false)
      settopHeight(true)
      var vdtTrue = filterVal.includes("valuedriver");
      var impTrue = filterVal.includes("improvementopportunities");
      var kpiTrue = filterVal.includes("kpis");
      var vdtIdsTrue = "";
      if (vdtTrue){
        vdtIdsTrue = vdtlstlevelIds;
      }
      if (impTrue) {
        vdtIdsTrue = vdtlstlevelIdsImp;
      }
      if (kpiTrue) {
        vdtIdsTrue = getlevelKPITextList;
      }
      if (vdtTrue && impTrue){
        vdtIdsTrue = vdtlstlevelIds.concat(vdtlstlevelIdsImp);
      }
      if (impTrue && kpiTrue){
        vdtIdsTrue = getlevelKPITextList.concat(vdtlstlevelIdsImp);
      }
      if (vdtTrue && kpiTrue){
        vdtIdsTrue = vdtlstlevelIds.concat(getlevelKPITextList);
      }
      if (vdtTrue && kpiTrue && impTrue){
        var vdtIdsImp = vdtlstlevelIds.concat(vdtlstlevelIdsImp);
        vdtIdsTrue = vdtIdsImp.concat(getlevelKPITextList);
      }
      return setClientId(vdtIdsTrue)
    }
    if (value.length === 0){
      return setClientId(getlevel5VdtList);
    }
  };
  var styletopSpace = { backgroundColor: "" };
  if (bottomHeight) {
    styletopSpace = bottomHeight ? { bottom: "130px" } : "";
  }
  if (topHeight) {
    styletopSpace = topHeight ? { top: "100px" } : { backgroundColor: "" };
  }
  return(
    <div className="VDT-Tree_load">
      <Navbar />
      <Grid container>
        <Grid item sm={12}>
          <div className="vdt-hierarchy">
            <Suspense fallback="loading...">
              <ThemeProvider theme={theme}>
                <Grid container style={{ marginTop: "10px" }}>
                  <Grid item xs={12}>
                    <div className="title">
                      <h1>{"Value Driver Tree"}</h1>
                      {selectedImpact !== 0 && (
                        <ExportVDTClient
                          downloadPng={downloadPng}
                          downloadCompleted={downloadCompleted}
                          setdownloadCompleted={setdownloadCompleted}
                          textValues={textValues}
                          selectedImpact={selectedImpact}
                          industryId={industryId}
                          projectId={projectId}
                        />
                      )}
                    </div>
                    {selectedImpact !== 0 && (
                      <div
                        className="rightCol level-container vdt-container"
                        ref={ref}
                      >
                        {spin && (
                          <div className="loader">{<CircularProgress />}</div>
                        )}
                        <div className="formControl level">
                          <FormControl
                            sx={{ m: 1, minWidth: 300 }}
                            style={{ flexDirection: "row", marginRight: 130 }}
                          >
                            {
                              <>
                                {downloadFunction === true ? (
                                  " "
                                ) : (
                                  <>
                                    <div>
                                      <Select
                                        labelId="level-preference-vdt"
                                        sx={{
                                          boxShadow: "none",
                                          ".MuiOutlinedInput-notchedOutline": {
                                            border: 0,
                                            fontSize: "10px",
                                          },
                                        }}
                                        value={defaultLevel}
                                        onChange={initialOpenTreeLevel}
                                      >
                                        <MenuItem value={0}>
                                          Level Preference
                                        </MenuItem>
                                        <MenuItem value={10}>Level 1</MenuItem>
                                        <MenuItem value={20}>Level 2</MenuItem>
                                        <MenuItem value={30}>Level 3</MenuItem>
                                        <MenuItem value={40}>Level 4</MenuItem>
                                      </Select>
                                    </div>
                                  </>
                                )}
                              </>
                            }
                          </FormControl>
                        </div>
                        <div className="formControl ">
                          <FormControl className={classes.formControl}>
                            {
                              <>
                                {downloadFunction === true ? (
                                  " "
                                ) : (
                                  <>
                                    <InputLabel
                                      id="mutiple-select-label"
                                      className="MuiSelect-select-value"
                                    >
                                      Detail View
                                    </InputLabel>
                                    <div>
                                      <Select
                                        style={{
                                          flex: 4,
                                          height: 25,
                                          width: 60,
                                          marginLeft: 88,
                                          top: -11,
                                        }}
                                        labelId="mutiple-select-label"
                                        multiple
                                        value={selected}
                                        onChange={handleDetailViewChange}
                                        renderValue={(selected) =>
                                          selected.join(", ")
                                        }
                                        MenuProps={MenuProps}
                                      >
                                        <MenuItem
                                          value="all"
                                          classes={{
                                            root: isAllSelected
                                              ? classes.selectedAll
                                              : "",
                                          }}
                                        >
                                          <ListItemIcon>
                                            <Checkbox
                                              classes={{
                                                indeterminate:
                                                  classes.indeterminateColor,
                                              }}
                                              checked={isAllSelected}
                                              indeterminate={
                                                selected.length > 0 &&
                                                selected.length < options.length
                                              }
                                            />
                                          </ListItemIcon>
                                          <ListItemText
                                            classes={{
                                              primary: classes.selectAllText,
                                            }}
                                            primary="All"
                                          />
                                        </MenuItem>
                                        {options.map((option) => (
                                          <MenuItem key={option} value={option}>
                                            <ListItemIcon>
                                              <Checkbox
                                                checked={
                                                  selected.indexOf(option) > -1
                                                }
                                              />
                                            </ListItemIcon>
                                            <ListItemText primary={option} />
                                          </MenuItem>
                                        ))}
                                      </Select>
                                    </div>
                                  </>
                                )}
                              </>
                            }
                          </FormControl>
                        </div>
                        {downloadFunction === true ? (
                          " "
                        ) : (
                          <div>
                            <h4>{imapctName}</h4>
                          </div>
                        )}

                        <div className="legend-blocks">
                          Legend |<span className="level-ones"> Level 1 |</span>
                          <span className="level-two"> Level 2 |</span>
                          <span className="level-three"> Level 3 |</span>
                          <span className="level-four"> Level 4 </span>
                        </div>
                        <DndProvider
                          backend={MultiBackend}
                          options={getBackendOptions()}
                        >
                          <div>
                            {open && (
                              <AddNodes
                                tree={treeData}
                                nodeDepth={nodeDepth}
                                newSelectedResult={newSelectedResult}
                                onClose={handleCloseDialog}
                                onSubmit={handleSubmit}
                              />
                            )}
                          </div>

                          <div
                            id="wrapper"
                            style={styletopSpace}
                            className={
                              "treeBody view_mode_" +
                              showBtn +
                              " topheignt_" +
                              topHeight
                            }
                          >
                            <Tree
                              tree={treeData}
                              rootId={0}
                              canDrag={() => enableDnd}
                              render={(node, { depth, isOpen, onToggle }) => (
                                <CustomNode
                                  addNewNode={addNewNode}
                                  updatedNode={updatedNode}
                                  handleEdit={handleEdit}
                                  handleBack={handleBack}
                                  node={node}
                                  depth={depth}
                                  isOpen={isOpen}
                                  onToggle={onToggle}
                                  isSelected={
                                    !!selectedNodes.find(
                                      (n) => n.id === node.id
                                    )
                                  }
                                  onSelect={handleSelect}
                                  parentCallback={handleCallback}
                                  handleCloseDialog={handleCloseDialog}
                                  handleSubmit={handleSubmit}
                                  showBtn={showBtn}
                                  onTextChange={handleTextChange}
                                  onDelete={handleDelete}
                                  handleOpenDialog={handleOpenDialog}
                                  handleOpenDialogVDT={handleOpenDialogVDT}
                                  openVDT={openVDT}
                                  topHeight={topHeight}
                                />
                              )}
                              dragPreviewRender={(monitorProps) => (
                                <CustomDragPreview
                                  monitorProps={monitorProps}
                                />
                              )}
                              onDrop={handleDrop}
                              classes={{
                                root: styles.treeRoot,
                                draggingSource: styles.draggingSource,
                                dropTarget: styles.dropTarget,
                                container: "VDTtree",
                                listItem: "parent-listitem",
                              }}
                              initialOpen={clientId}
                            />
                          </div>
                        </DndProvider>
                      </div>
                    )}
                    {!selectedImpact && (
                      <div
                        style={{
                          marginTop: "20px",
                          display: "flex",
                          justifyContent: "center",
                        }}
                      >
                        <div
                          style={{
                            color: "#707070DE",
                            textAlign: "center",
                            alignItems: "center",
                            marginLeft: "20px",
                            width: "520px",
                            padding: "64px 20px",
                            fontSize: "16px",
                          }}
                        >
                          <em>No Record Found</em>
                        </div>
                      </div>
                    )}
                    {selectedImpact !== 0 && (
                      <VDTSave
                        saveModal={saveModal}
                        variable={variable}
                        clientValue={"Client preview"}
                        showBtn={showBtn}
                        handleEdit={handleEdit}
                        handleBack={handleBack}
                        newSelectedResult={newSelectedResult}
                        selectedImpact={selectedImpact}
                      />
                    )}
                  </Grid>
                </Grid>
              </ThemeProvider>
            </Suspense>
          </div>
        </Grid>
      </Grid>
    </div>
  );
};

export default ValueTree;
