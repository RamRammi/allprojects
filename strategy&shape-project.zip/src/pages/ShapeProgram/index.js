import React from "react";
import { Link } from "react-router-dom";
import styles from "./ShapeProgram.module.css";
import { makeStyles } from "@material-ui/core/styles";
import Grid from "@mui/material/Grid";
import Navbar from "../../components/Navbar/Navbar";
import PropTypes from "prop-types";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import Box from "@mui/material/Box";
import { useSelector, useDispatch } from "react-redux";
import { setProgramName } from "../../redux/actions/questionnaireAction";

function TabPanel(props) {
  const { children, value, index, ...other } = props;
  const userType = useSelector(
    (state) => state.questionnaireReducer.userData.userRoleMappings
  );
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && <Box sx={{ p: 3 }}>{children}</Box>}
    </div>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired,
};

function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    "aria-controls": `simple-tabpanel-${index}`,
  };
}
const useStyles = makeStyles((theme) => ({
  style: {
    width: "170px",
    color: "#1976d2 !important",
    padding: "0px",
    "&.Mui-selected": {
      color: "white !important",
      backgroundColor: "#1976d2",
    },
  },
}));
const ShapeProgram = () => {
  const classes = useStyles();
  const dispatch = useDispatch();
  const [value, setValue] = React.useState(0);
  const userRole = useSelector((state) => state.questionnaireReducer.userRole);
  const { REACT_APP_CBCA_URL } = process.env;
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  return (
    <Grid className={styles.shape_css} sx={{ flexGrow: 1 }}>
      <Navbar pageName="home" />
      <Grid
        container
        direction="column"
        alignItems="center"
        justifyContent="center"
      >
        <Grid item xs={3}>
          <Box sx={{ marginTop: "20px" }}>
            <Tabs
              TabIndicatorProps={{
                style: {
                  display: "none",
                },
              }}
              value={value}
              onChange={handleChange}
              aria-label="basic tabs example"
            >
              <Tab
                sx={{
                  textTransform: "capitalize",
                  borderTopLeftRadius: "30px",
                  borderBottomLeftRadius: "30px",
                  border: "1px solid #1976d2",
                  padding: "10px",
                }}
                label="Capgemini Activity"
                {...a11yProps(0)}
                className={classes.style}
              />
              <Tab
                sx={{
                  textTransform: "capitalize",
                  borderTopRightRadius: "30px",
                  borderBottomRightRadius: "30px",
                  border: "1px solid #1976d2",
                  marginLeft: "2px",
                }}
                label="Dashboard"
                {...a11yProps(1)}
                className={classes.style}
                style={{ pointerEvents: "none" }}
              />
            </Tabs>
          </Box>
        </Grid>
      </Grid>
      <center>
        <h3 style={{ marginBottom: "0px" }}>Strategy Program</h3>
      </center>
      <TabPanel value={value} index={0}>
        <Grid container rowSpacing={1} columnSpacing={{ xs: 1, sm: 2, md: 1 }}>
          <Grid
            item
            xs={6}
            onClick={() => {
              dispatch(setProgramName("Ambition & Levers"));
            }}
          >
            <div className={styles.shapebox}>
              <h5>Ambition & Levers</h5>
              <Grid container spacing={1}>
                <Grid item xs={6} md={3}>
                  <img
                    src="../img/ambition.svg"
                    height="100"
                    width="100"
                    alt="Ambition"
                  />
                </Grid>
                <Grid item xs={6} md={9}>
                  <small className={styles.description}>
                    Set transformation ambitions & strategic direction &
                    identify levers to secure these ambitions
                  </small>
                  <ul className={styles.flexBox}>
                    <li>
                      {userRole[0].roleName === "CONSULTANT" ||
                      userRole[0].roleName === "SHAPEADMIN" ? (
                        <Link to="/">
                          <div
                            className={styles.imgBox}
                            style={{ background: "#0f999c" }}
                          >
                            <img
                              src="../img/questionaire.svg"
                              width="15"
                              height="15"
                              alt="Questionnaire"
                            />
                          </div>
                          <br />
                          <small>Questionnaire</small>
                        </Link>
                      ) : (
                        <Link to="/client/project">
                          <div
                            className={styles.imgBox}
                            style={{ background: "#0f999c" }}
                          >
                            <img
                              src="../img/questionaire.svg"
                              width="15"
                              height="15"
                              alt="Questionnaire"
                            />
                          </div>
                          <br />
                          <small>Questionnaire</small>
                        </Link>
                      )}
                    </li>
                    <li>
                      <Link to="/process-hierarchies">
                        <div
                          className={styles.imgBox}
                          style={{ background: "#0f999c" }}
                        >
                          <img
                            src="../img/process.png"
                            width="15"
                            height="15"
                            alt="Process Hierarchies"
                          />
                        </div>
                        <br />
                        <small>Process Hierarchies</small>
                      </Link>
                    </li>
                    <li>
                      <Link to="/valueDriveTrees">
                        <div
                          className={styles.imgBox}
                          style={{ background: "#0f999c" }}
                        >
                          <img
                            src="../img/value.svg"
                            width="15"
                            height="15"
                            alt="Value Driver Tree"
                          />
                        </div>
                        <br />
                        <small>Value Driver Tree</small>
                      </Link>
                    </li>
                  </ul>
                </Grid>
              </Grid>
            </div>
          </Grid>
          <Grid
            item
            xs={6}
            onClick={() => {
              dispatch(setProgramName("Maturity"));
            }}
          >
            <div className={styles.shapebox}>
              <h5>Maturity & Target model</h5>
              <Grid container spacing={1}>
                <Grid item xs={6} md={3}>
                  <img
                    src="../img/target.svg"
                    height="100"
                    width="100"
                    alt="maturity"
                  />
                </Grid>
                <Grid item xs={6} md={9}>
                  <small className={styles.description}>
                    Assess the future direction of operating, data and IT models
                    using the maturity framework
                  </small>
                  <ul className={styles.flexBox}>
                    <li>
                      <Link to="/" style={{ pointerEvents: "none" }}>
                        <div className={styles.imgBox}>
                          <img
                            src="../img/kpi-icon.svg"
                            width="15"
                            height="15"
                            alt="KPIS"
                          />
                        </div>
                        <br />
                        <small>KPIs</small>
                      </Link>
                    </li>
                    <li>
                      <Link to="/painpoints">
                        <div
                          className={styles.imgBox}
                          style={{ background: "#7E39BA" }}
                        >
                          <img
                            src="../img/pain-point-icon.svg"
                            width="15"
                            height="15"
                            alt="pain-point-icon"
                          />
                        </div>
                        <br />
                        <small>Pain Points & Improvement Opportunities</small>
                      </Link>
                    </li>
                    <li>
                      <div className={styles.imgBox}>
                        <img
                          src="../img/maturity-matrix-icon.svg"
                          width="15"
                          height="15"
                          alt="Maturity matrix"
                        />
                      </div>
                      <br />
                      <small>Maturity Matrix</small>
                    </li>
                    <li>
                      <div className={styles.imgBox}>
                        <img
                          src="../img/skills-icon.svg"
                          width="15"
                          height="15"
                          alt="skills-icon"
                        />
                      </div>
                      <br />
                      <small>Skills</small>
                    </li>
                  </ul>
                </Grid>
              </Grid>
            </div>
          </Grid>
          {/* <Grid item xs={6}>
            <div className={styles.shapebox}>
              <h5>Target Model</h5>
              <Grid container spacing={1}>
                <Grid item xs={6} md={3}>
                  <img
                    src="../img/target.svg"
                    height="100"
                    width="100"
                    alt="maturity"
                  />
                </Grid>
                <Grid item xs={6} md={9}>
                  <small className={styles.description}>
                    Explore feasible solutions & transformation opportunities
                    that enable future maturity achievement
                  </small>
                  <ul className={styles.flexBox}>
                    <li>
                      <Link to="/" style={{ pointerEvents: "none" }}>
                        <div className={styles.imgBox}>
                          <img
                            src="../img/questionaire.svg"
                            width="15"
                            height="15"
                            alt="Questionnaire"
                          />
                        </div>
                        <br />
                        <small>Improvement Opportunities</small>
                      </Link>
                    </li>
                    <li>
                      <div className={styles.imgBox}>
                        <img
                          src="../img/process.png"
                          width="15"
                          height="15"
                          alt="Process Hierarchies"
                        />
                      </div>
                      <br />
                      <small>Skills</small>
                    </li>
                  </ul>
                </Grid>
              </Grid>
            </div>
          </Grid> */}
          <Grid item xs={6}>
            <div className={styles.shapebox}>
              <h5>Roadmap And Business Case</h5>
              <Grid container spacing={1}>
                <Grid item xs={6} md={3}>
                  <img
                    src="../img/roadmap.svg"
                    height="100"
                    width="100"
                    alt="maturity"
                  />
                </Grid>
                <Grid item xs={6} md={9}>
                  <small className={styles.description}>
                    Establish the transformation roadmap and populate the
                    associated Business Case
                  </small>
                  <ul className={styles.flexBox}>
                    <li>
                      <Link
                        onClick={() =>
                          window.open(REACT_APP_CBCA_URL, "_blank")
                        }
                      >
                        <div
                          className={styles.imgBox}
                          style={{ background: "#860864" }}
                        >
                          <img
                            src="../img/questionaire.svg"
                            width="15"
                            height="15"
                            alt="Questionnaire"
                          />
                        </div>
                        <br />
                        <small>Business Case</small>
                      </Link>
                    </li>
                    {/* <li>
                      <div className={styles.imgBox}>
                        <img
                          src="../img/process.png"
                          width="15"
                          height="15"
                          alt="Process Hierarchies"
                        />
                      </div>
                      <br />
                      <small>Business Case Reports</small>
                    </li> */}
                    {/* <li>
                      <div className={styles.imgBox}>
                        <img
                          src="../img/value.svg"
                          width="15"
                          height="15"
                          alt="Value Driver Trees"
                        />
                      </div>
                      <br />
                      <small>Cost Benefit Analysis</small>
                    </li> */}
                    <li>
                      <div className={styles.imgBox}>
                        <img
                          src="../img/value.svg"
                          width="15"
                          height="15"
                          alt="Tech Deployment Roadmap"
                        />
                      </div>
                      <br />
                      <small>Tech Deployment Roadmap​</small>
                    </li>
                  </ul>
                </Grid>
              </Grid>
            </div>
          </Grid>
          <Grid item xs={6}>
            <div className={styles.shapebox}>
              <h5>Alignment And Sign Off</h5>
              <Grid container spacing={1}>
                <Grid item xs={6} md={3}>
                  <img
                    src="../img/alignment.svg"
                    height="100"
                    width="100"
                    alt="maturity"
                  />
                </Grid>
                <Grid item xs={6} md={9}>
                  <small className={styles.description}>
                    Align all executives on outcomes & next steps & achieve
                    signed off momentum towards the next phase with Business
                    stakeholders
                  </small>
                  <ul className={styles.flexBox}>
                    <li>
                      <Link to="/" style={{ pointerEvents: "none" }}>
                        <div className={styles.imgBox}>
                          <img
                            src="../img/questionaire.svg"
                            width="15"
                            height="15"
                            alt="Questionnaire"
                          />
                        </div>
                        <br />
                        <small>Dashboard</small>
                      </Link>
                    </li>
                  </ul>
                </Grid>
              </Grid>
            </div>
          </Grid>
        </Grid>
      </TabPanel>
      <TabPanel value={value} index={1}>
        Item Two
      </TabPanel>
    </Grid>
  );
};

export default ShapeProgram;
