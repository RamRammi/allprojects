import React from "react";
import Navbar from "../../components/Navbar/Navbar";
import Button from "@mui/material/Button";
import "./InterviewSynopsis.css";
import Select, { SelectChangeEvent } from "@mui/material/Select";
import Box from "@mui/material/Box";
// import DATA from "../../local-json/InterviewSynopsis.json";
import Download from "../../Images/download.jpg";
import FooterButtons from "../Questionnaire/FooterButtons.js";
import MenuItem from "@mui/material/MenuItem";
import { useState, useEffect } from "react";
import { Theme, useTheme } from "@mui/material/styles";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import OutlinedInput from "@mui/material/OutlinedInput";
import "../../components/PopUp/Export/Export.css";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import ContentCopyIcon from "@mui/icons-material/ContentCopy";
import { Typography } from "@mui/material";
import FormControl from "@mui/material/FormControl";
import * as Api from "../../comman/api";
import * as Constant from "../../comman/constant";
import Export from "../../components/PopUp/Export/Export";
import { useNavigate } from "react-router-dom";
import CommonModal from "../../components/PopUp/ExpendPopup/modal";
import FileMoreVerIcon from "../../components/Icons/FileMoreVerIcon";
import { useSelector, useDispatch } from "react-redux";
// import Export from "../../components/PopUp/Export/Export";
const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};

function getStyles(name, personName, theme) {
  return {
    fontWeight:
      personName.indexOf(name) === -1
        ? theme.typography.fontWeightRegular
        : theme.typography.fontWeightMedium,
  };
}

const names = ["PDF", "Excel"];

const InterviewSynopsis = (props) => {
  const pageName = "Interview Synopsis";
  const [data, pageData] = useState();
  const [tempIds, setTempIds] = useState([]);
  const [open, setOpen] = React.useState(false);
  const [fileNames, setFileNames] = React.useState("");
  const [openExport, setOpenExport] = React.useState(false);
  const [personName, setPersonName] = React.useState([]);
  const [templateName, setTemplateName] = useState();
  const [synopis, setSynopisis] = useState();
  const projectId = useSelector(
    (state) => state.questionnaireReducer.projectId
  );
  const clientId = useSelector((state) => state.questionnaireReducer.clientId);
  const userId = useSelector((state) => state.questionnaireReducer.userId);

  const theme = useTheme();
  const navigate = useNavigate();

  const [download, setDownload] = useState();

  const handleClickClose = () => {
    setOpen(false);
  };
  const handleClickOpen = () => {
    setOpenExport(true);
  };

  const handleClose = () => {
    setOpenExport(false);
  };

  function handleFileName(e) {
    setFileNames(e.target.value);
  }

  const handleChange = (event) => {
    const {
      target: { value },
    } = event;
    setPersonName(
      // On autofill we get a stringified value.
      typeof value === "string" ? value.split(",") : value
    );
  };

  const downloadApi = () => {
    let URL = "";
    URL =
      Constant.BASE_URL +
      Constant.DOWNLOAD_LIST +
      "?templateName=" +
      templateName +
      "&synopsis=" +
      synopis +
      "&fileType=" +
      personName +
      "&fileName=" +
      fileNames;
    window.location.href = URL;

    handleClickClose();
  };

  const SynopisisData = () => {
    // setTempIds([]);
    let data = {
      projectId: projectId,
      clientId: clientId,
      userId: userId,
      search: "",
    };
    Api.getMasterSummaryQuestionnaire(
      Constant.GET_MASTER_SUMMARY_QUESTIONNAIRE,
      data
    ).then((res) => {
      pageData(res);

      res.map((value) => {
        tempIds.push(value.templateId);
      });
    });
  };

  function onDownloadClick(templateName, synopsis) {
    setTemplateName(templateName);
    setSynopisis(synopsis);
  }

  useEffect(() => {
    SynopisisData();
  }, []);

  function removeTags(str) {
    if (str === null || str === "") return "";
    else str = str.toString();
    return str.replace(/(<([^>]+)>)/gi, "");
  }

  return (
    <React.Fragment>
      <Navbar />
      <div className="interview-synopsis-header">
        <span className="interview-synopsis-header-title">
          Interview Synopsis
        </span>
        {/* <Button variant="contained" className="interview-synopsis-button">
          Export All Synopsis
        </Button> */}
        <Export tempIds={tempIds} />
      </div>

      {data &&
        data.map((obj) => (
          <div className="interview-synopsis-section">
            <div className="interview-synopsis-title">
              <div className="interview-synopsis-border">
                <div className="span-line">{obj.templatename}</div>
              </div>
              {/* |{" "} */}
              {/* <img
                onClick={() => {
                  handleClickOpen();  
                  onDownloadClick(obj.templateName, obj.synopsis);
                }}
                className="download-image"
                src={Download}
                alt="img"
              />  
                                       */}
              <div
                className="span-file"
                onClick={() => {
                  onDownloadClick(obj.templatename, obj.synopsis);
                }}
              >
                <FileMoreVerIcon
                  pageName={pageName}
                  open={openExport}
                  onClose={() => handleClose()}
                  type="download"
                  fileNames={fileNames}
                  synopis={synopis}
                  templateName={templateName}
                  personName={personName}
                />
              </div>
            </div>
            <p className="interview-synopsis-content">
              {removeTags(obj.synopsis)}
            </p>
          </div>
        ))}
      {/* <FooterButtons pageName={pageName}/> */}
      <div
        style={{
          height: "100px",
          backgroundColor: "#F8F8F8",
          textTransform: "capitalize",
          display: "flex",
          justifyContent: "flex-end",
          paddingRight: "40px",
        }}
      >
        <Button
          style={{
            fontFamily: "Ubuntu",
            fontSize: "12px",
            textTransform: "capitalize",
            backgroundColor: "white",
            // color: "white",
            margin: "35px 10px",
            color: "0070AD",
            borderRadius: "25px",
            padding: "7px 16px",
            border: "1px solid #0070AD",
          }}
          onClick={() => navigate(-1)}
        >
          back
        </Button>
        <Button
          style={{
            fontFamily: "Ubuntu",
            textTransform: "capitalize",
            fontSize: "12px",
            backgroundColor: props.templateId === 0 ? "#BFBFBF" : "#0070AD",
            color: "white",
            margin: "35px 10px",
            color: "white",
            borderRadius: "25px",
            padding: "7px 16px",
          }}
          className="send-button"
        >
          Send
        </Button>
      </div>
    </React.Fragment>
  );
};

export default InterviewSynopsis;
