import React from "react"
import Process from "./[id]"

// import ClientProcess from "./ClientProcess/[id]"

function MasterPreview() {
  const masterValue = "Master preview"
  return (
    <div>
      <Process masterValue={masterValue} />
    </div>
  )
}

export default MasterPreview
