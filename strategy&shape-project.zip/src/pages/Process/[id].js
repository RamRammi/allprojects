import React, { useState, useEffect, Suspense, useCallback } from "react"
import { useParams } from "react-router-dom"
import { useLocation } from "react-router-dom"
import "./ProcessCss.css"
import { CircularProgress, Grid, Typography, InputLabel } from "@mui/material"
import { BASE_URL } from "../../comman/constant"
import * as Constant from "../../comman/constant"
import ExportPH from "../ClientProcess/ExportPH"
import Navbar from "../../components/Navbar/Navbar"
import Button from "@mui/material/Button"
import { Tree, getBackendOptions, MultiBackend, getDescendants } from "@minoru/react-dnd-treeview"
import { DndProvider } from "react-dnd"
import EditOutlinedIcon from "@mui/icons-material/EditOutlined"
import { ThemeProvider } from "@mui/material"
import { theme } from "../../theme"
import { useTheme } from "@mui/material/styles"
import { CustomNode } from "../../components/ProcessHierarchyCustomNode/CustomNode"
import { CustomDragPreview } from "../../components/ProcessHierarchyCustomNode/CustomDragPreview"
import { AddDialog } from "../../components/ProcessHierarchyCustomNode/AddDialog"
import { ProcessSave } from "../../components/ProcessHierarchyCustomNode/ProcessSave"
import MenuItem from "@mui/material/MenuItem"
import FormControl from "@mui/material/FormControl"
import Select from "@mui/material/Select"
import jsPDF from "jspdf"
import { toPng, toJpeg } from "html-to-image"

import * as Api from "../../comman/api"
import { BASE_DAN_BE_URL } from "../../comman/constant"

const ITEM_HEIGHT = 48
const ITEM_PADDING_TOP = 8

const getLastId = (treeData) => {
  const reversedArray = [...treeData].sort((a, b) => {
    if (a.id < b.id) {
      return 1
    } else if (a.id > b.id) {
      return -1
    }
    return 0
  })
  if (reversedArray.length > 0) {
    return reversedArray[0].id
  }
  return 0
}
const Process = (props) => {
  const pageName = "master view export"
  const { id } = useParams()
  const [loading, setLoading] = useState(false)
  const [showBtn, setShowBtn] = useState(false)
  const [nodeData, setNodeData] = useState([])
  const [arrWith, setArrWith] = useState([])
  const [nodeDepth, setNodeDepth] = useState()
  const [openDialog, setOpenDialog] = useState(false)
  const [personName, setPersonName] = useState([])
  const location = useLocation()
  const [textValue, setTextValue] = useState("")
  const [initialLevel, setInitialLevel] = useState()
  const [defaultOpen, setDefaultOpen] = useState()
  const [defaultTitle, setDefaultTitle] = useState()
  const [isDisplayed, setIsDisplayed] = useState(false)
  const ref = React.createRef()
  const [fileNamePDF, setFileNamePDF] = useState("")
  const [downloadCompleted, setdownloadCompleted] = useState(false)
  const [downloadFunction, setDownloadFunction] = useState(false)
  const [enableDnd, setEnableDnd] = useState(false)
  const [spin, setSpin] = useState(false)

  const handleClickOpen = () => {
    setOpenDialog(true)
  }

  useEffect(() => {
    setSpin(true)
    const loadPhLevels = () => {
      let URL = ""
      URL = BASE_DAN_BE_URL + Constant.PROCESS_HIERARCHY_TREE_MASTER + id
      Api.PHPreviewMaster(URL).then((data) => {
        setNodeData(data)
        setInterval(() => {
          setIsDisplayed(true)
        }, 100)
        setSpin(false)
      })
      setLoading(false)
    }
    loadPhLevels()
  }, [])

  const newArr = useCallback((arrData) => {
    let arr0 = [delete arrData.industryId]
    const arr1 = [arrData].flatMap((elem) => elem.masterL2BPHs)
    const arr2 = arr1
      .map((elem) => {
        if (elem) {
          return elem.masterL3BPHs
        }
      })
      .filter((el) => {
        if (el) {
          return el != 0
        }
      })
      .map((e) => {
        if (e) {
          return e
        }
      })

    const simpleObj = {}
    const destructure = (obj) => {
      for (let key in obj) {
        const value = obj[key]
        const type = typeof value
        if (["string", "boolean"].includes(type) || (type === "number" && !isNaN(value))) {
          simpleObj[key] = value
        }
      }
      Object.assign(simpleObj, { parent: "0" })
      return simpleObj
    }

    arr1.push(destructure(arrData))
    arr2.push(arr1)

    const multiDimArray = arr2
      .map((items) => {
        if (items) {
          return items
        }
      })
      .flat(1)

    setInitialLevel(multiDimArray)

    const renameDescription = JSON.parse(JSON.stringify(multiDimArray).split('"description":').join('"text":'))
    const renameParent1 = JSON.parse(JSON.stringify(renameDescription).split('"masterL1BPHId":').join('"parent":'))
    const renameParent2 = JSON.parse(JSON.stringify(renameParent1).split('"masterL2BPHId":').join('"parent":'))
    //console.log(depth)
    const arrWithDroppable = renameParent2.map((object) => {
      return { ...object, droppable: true }
    })
    const renameParent3 = arrWithDroppable.map((object) => {
      return { ...object, isUpdated: false }
    })
    const renameParent4 = renameParent3.map((object) => {
      return { ...object, isNew: true }
    })
    const renameParent5 = renameParent4.map((object) => {
      return { ...object, isChecked: true }
    })
    setArrWith(renameParent5)
  }, [])

  useEffect(() => {
    newArr(nodeData)
  }, [nodeData])

  const handleCallback = (childData) => {
    setNodeDepth(childData)
  }

  const [treeData, setTreeData] = useState([])
  useEffect(() => {
    setTreeData(arrWith)
  }, [arrWith])

  const handleDrop = (newTreeData) => setTreeData(newTreeData)
  const [open, setOpen] = useState(false)

  const [selectedNodes, setSelectedNodes] = useState([])
  const handleSelect = (node) => {
    const item = selectedNodes.find((n) => n.id === node.id)
    if (!item) {
      setSelectedNodes([node, ...selectedNodes])
    } else {
      setSelectedNodes(selectedNodes.filter((n) => n.id !== node.id))
    }
  }

  const selectedresult = treeData.concat(selectedNodes)
  const newSelectedResult = [...new Set(selectedresult)]

  const handleDelete = (id) => {
    const deleteIds = [id, ...getDescendants(treeData, id).map((node) => node.id)]
    const newTree = treeData.filter((node) => !deleteIds.includes(node.id))
    setTreeData(newTree)
  }

  const handleCopy = (id) => {
    const lastId = getLastId(treeData)
    const targetNode = treeData.find((n) => n.id === id)
    const descendants = getDescendants(treeData, id)
    const partialTree = descendants.map((node) => ({
      ...node,
      id: node.id + lastId,
      parent: node.parent + lastId,
    }))

    setTreeData([
      ...treeData,
      {
        ...targetNode,
        id: targetNode.id + lastId,
      },
      ...partialTree,
    ])
  }

  const handleOpenDialog = () => {
    setOpen(true)
  }

  const handleCloseDialog = () => {
    setOpen(false)
  }

  const [addNewNode, setAddNewNode] = useState(false)
  const handleSubmit = (newNode) => {
    let UUID = crypto.randomUUID()
    setAddNewNode(true)
    const lastId = UUID

    setTreeData([
      ...treeData,
      {
        ...newNode,
        id: lastId,
      },
    ])

    setOpen(false)
  }

  const handleTextChange = (id, value) => {
    const newTree = treeData.map((node) => {
      if (node.id === id) {
        return {
          ...node,
          text: value,
        }
      }
      return node
    })

    setTreeData(newTree)
  }

  const handleEdit = () => {
    setShowBtn(true)
    setEnableDnd(true)
  }
  const isNewtrue = true
  // const ref = useRef(null)
  // const handleOpenAll = () => ref.current.openAll()
  // const handleCloseAll = () => ref.current.closeAll()

  const variable = location.pathname.substring(location.pathname.lastIndexOf("/") + 1)

  const previewVariable = location.pathname.split("/")[3]

  const onTextValueChange = (event) => {
    const {
      target: { value },
    } = event
    setTextValue(
      // On autofill we get a stringified value.
      typeof value === "string" ? value.split(",") : value
    )
  }

  const initialOpenTreeLevel = (event) => {
    const getAllmasterL1BPHId = initialLevel.map((node) => {
      return node.masterL1BPHId
    })
    const getAllmasterL2BPHId = initialLevel.map((node) => {
      return node.masterL2BPHId
    })
    const getAllmasterL3BPHId = initialLevel.map((node) => {
      return node.masterL3BPHId
    })
    const getAllmasterL4BPHId = initialLevel.map((node) => {
      return node.masterL4BPHId
    })
    const getAllmasterAll = getAllmasterL1BPHId.concat(getAllmasterL2BPHId)
    const getAllmaster5 = getAllmasterAll.concat(getAllmasterL3BPHId)
    const getAllmaster5All = getAllmaster5.concat(getAllmasterL4BPHId)
    switch (event.target.value) {
      case 10:
        setDefaultOpen(getAllmasterL1BPHId)
        break
      case 20:
        setDefaultOpen(getAllmasterAll)
        break
      case 30:
        setDefaultOpen(getAllmaster5)
        break
      case 40:
        setDefaultOpen(getAllmaster5All)
        break
      default:
        setDefaultOpen(event.target.value)
    }
  }
  useEffect(() => {
    const initialLoadTree = newSelectedResult.map((id) => {
      return id.id
    })
    setDefaultOpen(initialLoadTree)
    const initialLoadTitle = newSelectedResult.map((id) => {
      if (id.parent === "0") return id.text
    })
    setDefaultTitle(initialLoadTitle)
  }, [treeData])

  const downloadPng = useCallback(() => {
    setDownloadFunction(true)
    if (ref.current === null) {
      return
    }
    toPng(ref.current, { cacheBust: true })
      .then((dataUrl) => {
        const link = document.createElement("a")
        link.download = "download file "
        link.href = dataUrl
        // console.log(dataUrl, "image")
        // console.log(dataUrl)
        window.location.href = dataUrl
        const imgData = dataUrl
        //console.log(imgData.height, "img data ")
        const pdf = new jsPDF("p", "mm", "a4")
        const imgProps = pdf.getImageProperties(imgData)
        //console.log(imgProps.height, "img props")
        var pdfWidth = pdf.internal.pageSize.getWidth()
        var height = pdf.internal.pageSize.getHeight()
        var ratio = pdfWidth / pdfWidth
        height = ratio * pdfWidth
        const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width
        //console.log(height, "height pdf")
        const pageHeight = pdf.internal.pageSize.height
        //console.log(pageHeight, "pageHeight")
        pdf.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight)
        pdf.save(fileNamePDF)
        setdownloadCompleted(true)
        setDownloadFunction(false)
      })
      .catch((err) => {
        console.log(err.message)
      })
  }, [ref])

  const textValues = (value) => {
    console.log(value[0])
    setFileNamePDF(value)
  }

  return (
    <div className="process-hierarchy">
      <Suspense fallback="loading...">
        <ThemeProvider theme={theme}>
          <Navbar />
          <Grid container style={{ marginTop: "10px" }}>
            <Grid item xs={12}>
              <div className="title">
                <h1>
                  {defaultTitle}
                  <ExportPH style={{ float: "right", marginTop: "0" }} variant="contained" onClick={handleClickOpen} variable={variable} pageName={pageName} previewVariable={previewVariable} textValues={textValues} downloadPng={downloadPng} downloadCompleted={downloadCompleted} setdownloadCompleted={setdownloadCompleted} />
                </h1>
              </div>

              <div className="rightCol-inner level-container" ref={ref}>
                <div style={{ float: "right" }}>
                  <FormControl sx={{ m: 1, minWidth: 120 }}>
                    {
                      <>
                        {downloadFunction === true ? (
                          ""
                        ) : (
                          <div>
                            <InputLabel id="demo-simple-select-label">Level Preference</InputLabel>
                            {/* <p className="select-label">Level Preference</p> */}
                            <Select
                              labelId="demo-simple-select-label"
                              sx={{
                                boxShadow: "none",
                                ".MuiOutlinedInput-notchedOutline": { border: 0 },
                              }}
                              value={defaultOpen}
                              onChange={initialOpenTreeLevel}
                            >
                              <MenuItem value={0}>Level 1</MenuItem>
                              <MenuItem value={10}>Level 2</MenuItem>
                              <MenuItem value={20}>Level 3</MenuItem>
                              <MenuItem value={30}>Level 4</MenuItem>
                              <MenuItem value={40}>Level 5</MenuItem>
                            </Select>
                          </div>
                        )}
                      </>
                    }
                  </FormControl>
                </div>
                <div className="legend-blocks">
                  Legend |<span className="level-ones"> Level 1 |</span>
                  <span className="level-two"> Level 2 |</span>
                  <span className="level-three"> Level 3 |</span>
                  <span className="level-four"> Level 4 |</span>
                  <span className="level-five"> Level 5</span>
                </div>
                {spin === false ? (
                  isDisplayed && (
                    <DndProvider backend={MultiBackend} options={getBackendOptions()}>
                      <div>{open && <AddDialog tree={treeData} nodeDepth={nodeDepth} newSelectedResult={newSelectedResult} onClose={handleCloseDialog} onSubmit={handleSubmit} />}</div>

                      <Tree
                        tree={treeData}
                        rootId={"0"}
                        onDrop={handleDrop}
                        initialOpen={defaultOpen}
                        classes={{
                          container: "wtree",
                          listItem: "parent-listitem",
                        }}
                        sort={false}
                        canDrag={() => enableDnd}
                        render={(node, { depth, isOpen, hasChild, onToggle }) => <CustomNode addNewNode={addNewNode} isNewtrue={isNewtrue} parentCallback={handleCallback} isSelected={!!selectedNodes.find((n) => n.id === node.id)} onSelect={handleSelect} handleCloseDialog={handleCloseDialog} showBtn={showBtn} handleSubmit={handleSubmit} handleOpenDialog={handleOpenDialog} node={node} depth={depth} hasChild={hasChild} isOpen={isOpen} onToggle={onToggle} onTextChange={handleTextChange} onDelete={handleDelete} onCopy={handleCopy} dragPreviewRender={(monitorProps) => <CustomDragPreview monitorProps={monitorProps} />} />}
                      />
                    </DndProvider>
                  )
                ) : (
                  <div className="loader">
                    <CircularProgress />
                  </div>
                )}
              </div>

              <ProcessSave variable={variable} masterValue={props.masterValue} showBtn={showBtn} handleEdit={handleEdit} newSelectedResult={newSelectedResult} />
            </Grid>
          </Grid>
        </ThemeProvider>
      </Suspense>
    </div>
  )
}

export default Process
