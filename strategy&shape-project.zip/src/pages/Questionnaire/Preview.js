import React from "react";
import Respond from "./Respond";
import Navbar from "../../components/Navbar/Navbar";
import Filters from "../../components/Filters/FilterData";
import RespondFilterData from "../Questionnaire/RespondFilterData";
import RespondContent from "../Questionnaire/RespondContent";
import FooterButtons from "./FooterButtons";
import RespondComments from "./RespondComments";
import { useLocation } from "react-router-dom";
import { useState, useEffect, createContext } from "react";
import { ResponseContext } from "../../comman/context.js";
import * as Api from "../../comman/api";
import * as Constant from "../../comman/constant";
import { dateFormatchange } from "../../comman/utils";
import { useSelector, useDispatch } from "react-redux";
import { parseISO } from 'date-fns';

function Preview(props) {
  const pages = "preview";
  const location = useLocation();
  //const [templateId, setTemplateId] = useState(0);
  const [templateName, setTemplateName] = useState("");
  const [respondQuestionList, setRespondQuestionList] = useState([]);
  const [responseList, setResponseList] = useState([]);
  const [successMessage, setSuccessMessage] = React.useState("");
  const [showAlertBox, setShowAlertBox] = React.useState(false);
  const [showWarningBox, setShowWarningBox] = React.useState(false);
  const [userType, setUserType] = React.useState("");
  const [interviewee, setInterviewee] = useState("");
  const [interviewer, setInterviewer] = useState("");
  const [jobTitle, setJobTitle] = useState("");
  const [date, setDate] = useState(new Date());
  const [readOnlyView, setReadOnlyView] = React.useState(false);
  // const [pId, setPId] = React.useState("");
  const [warningMessage, setWarningMessage] = React.useState("");
  const [interviewSynopsis, setInterviewSynopsis] = React.useState("");
  const [notes, setNotes] = React.useState("");
  const projectId = useSelector(
    (state) => state.questionnaireReducer.projectId
  );
  const clientId = useSelector((state) => state.questionnaireReducer.clientId);
  const userId = useSelector((state) => state.questionnaireReducer.userId);
  const pId = useSelector((state) => state.questionnaireReducer.pId);
  const templateId = useSelector(
    (state) => state.questionnaireReducer.templateId
  );
  //const userType = useSelector((state) => state.questionnaireReducer.userType);
  const templateStatus = useSelector(
    (state) => state.questionnaireReducer.templateStatus
  );

  const redirectFrom = useSelector(
    (state) => state.questionnaireReducer.redirectFrom
  );
  useEffect(() => {
    if (respondQuestionList) {
      respondQuestionList.map((value, index) => {
        if (
          (value.cQuestionType === "textbox" || value.type === "textbox") &&
          value.response === null
        ) {
          value.response = "";
        }
        if (
          (value.cQuestionType === "Date" || value.type === "Date") &&
          value.response === null
        ) {
          let currentDate = new Date();
          responseList[index] = currentDate.toISOString();
          value.response = dateFormatchange(currentDate);
        }
        if (
          (value.cQuestionType === "Logical" || value.type === "Logical") &&
          value.response === null
        ) {
          value.response = "";
        }
        if (
          value.response !== null &&
          value.cQuestionType === "Range of Values"
        ) {
          value.response = value.response.split(",");
        }
        if (
          (value.cQuestionType === "Range of Values" ||
            value.type === "Range of Values") &&
          value.response === null
        ) {
          value.response = [0, 0];
        }

        if (
          (value.cQuestionType === "Multiple Choice Questions" ||
            value.type === "Multiple Choice Questions") &&
          value.response === null
        ) {
          value.response = "";
        }
      });
    }
  }, [respondQuestionList]);
  useEffect(() => {
    if (redirectFrom === "AddQuestionnaire") {
      getRespondQuestionList(templateId);
    } else {
      getQuestionnaireDetailsByMasterSummay(templateId);
    }
  }, []);

  // When click on view questionnaire on master summary page
  const getQuestionnaireDetailsByMasterSummay = (templateId) => {
    let URL = Constant.VIEW_QUESTIONNAIRE + "?templateid=" + templateId;
    Api.getQuestionnaireList(URL).then((res) => {
      setRespondQuestionList(res);
      setInterviewee(res[0].interviewee);
      setInterviewer(res[0].interviewer);
      setJobTitle(res[0].jobTitle);
      setDate(parseISO(res[0].date));
      setTemplateName(res[0].templatename);
      setInterviewSynopsis(res[0].synopsis);
      setNotes(res[0].notes);
    });
  };

  const openAlertBox = () => {
    setShowAlertBox(true);
  };
  const openWarningBox = () => {
    setShowWarningBox(true);
  };

  const getRespondQuestionList = (tempId, userType) => {
    let URL = "";
    if (templateStatus === "Completed") {
      //Consultant flow
      URL =
        Constant.GET_QUESTIONNAIRE_DATA_WITH_RESPONSE +
        "?pId=" +
        pId +
        "&templateId=" +
        tempId +
        "&status=" +
        templateStatus +
        "&projectId=" +
        projectId +
        "&clientId=" +
        clientId;
      Api.getRespondQuestionList(URL).then((res) => {
        setReadOnlyView(true);
        setRespondQuestionList(res.templateQuestionResponseList);
        setTemplateName(
          res.templateQuestionResponseList.length
            ? res.templateQuestionResponseList[0].templatename
            : ""
        );
          setInterviewee(res.project.projectInterviewee);
          setInterviewer(res.project.projectInterviewer);
          setJobTitle(res.project.jobTitle);
          setDate(res.project.projectCreateDate);
        //date
        setNotes(
          res.templateQuestionResponseList.length
            ? res.templateQuestionResponseList[0].notes
            : ""
        );
        setInterviewSynopsis(
          res.templateQuestionResponseList.length
            ? res.templateQuestionResponseList[0].synopsis
            : ""
        );
        //setDate("");
      });
    } else if (templateStatus === "Saved") {
      let URL =
        Constant.GET_QUESTIONNAIRE_DATA_BY_TEMPLATEID +
        "?templateId=" +
        tempId +
        "&projectId=" +
        projectId +
        "&clientId=" +
        clientId;
      Api.getRespondQuestionList(URL).then((res) => {
        setRespondQuestionList(res.questionnaireTemplateDateials);
        setTemplateName(
          res.questionnaireTemplateDateials.length
            ? res.questionnaireTemplateDateials[0].templatename
            : ""
        );
        setInterviewee(res.questionnaireTemplateDateials[0].projectInterviewee);
        setInterviewer(res.questionnaireTemplateDateials[0].projectInterviewer);
          setJobTitle(res.questionnaireTemplateDateials[0].jobTitle);
          setDate(res.questionnaireTemplateDateials[0].projectCreateDate);
        //setDate("");
      });
    } else if (templateStatus === "New" || templateStatus === "Pending") {
      URL =
        Constant.GET_CLIENT_RESPONSE_BY_TASKSUMMARY +
        "?templateId=" +
        tempId +
        "&projectId=" +
        projectId +
        "&clientId=" +
        clientId +
        "&userId=" +
        userId +
        "&status=" +
        templateStatus;
      Api.getRespondQuestionList(URL).then((res) => {
        setRespondQuestionList(res.consQuestResByTemplateId);
        setTemplateName(
          res.consQuestResByTemplateId.length
            ? res.consQuestResByTemplateId[0].templateName
            : ""
        );
        setInterviewee(res.consQuestResByTemplateId[0].projectInterviewee);
        setInterviewer(res.consQuestResByTemplateId[0].projectInterviewer);
        setJobTitle(res.consQuestResByTemplateId[0].jobTitle);
        setNotes(res.consQuestResByTemplateId[0].notes);
        setNotes(res.consQuestResByTemplateId[0].synopsis);
        res.consQuestResByTemplateId.map((value, index) => {
          responseList[index] = value.response;
        });
      });
    }
  };
  return (
    <div>
      <Navbar />
      <ResponseContext.Provider
        value={{
          interviewee,
          interviewer,
          jobTitle,
          date,
          setInterviewee,
          setInterviewer,
          setJobTitle,
          setDate,
        }}
      >
        <RespondFilterData
          pages={pages}
          templateId={templateId}
          status={templateStatus}
          synopsis={interviewSynopsis}
          notes={notes}
          templateName={templateName}
          setNotes={setNotes}
          setSynopsis={setInterviewSynopsis}
        />
      </ResponseContext.Provider>
      <RespondContent
        pages={pages}
        respondQuestionList={respondQuestionList}
        setResponseList={setResponseList}
        responseList={responseList}
      />
      {/* <RespondComments pages={pages} /> */}
      <FooterButtons
        pageName={pages}
        questionnaireName={templateName}
        templateId={templateId}
        readOnlyView={readOnlyView}
      />
    </div>
  );
}

export default Preview;
