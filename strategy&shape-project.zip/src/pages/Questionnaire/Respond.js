import React from "react";
import Navbar from "../../components/Navbar/Navbar";
import RespondFilterData from "../Questionnaire/RespondFilterData";
import RespondContent from "../Questionnaire/RespondContent";
import FooterButtons from "./FooterButtons";
import RespondComments from "./RespondComments";
import { useLocation } from "react-router-dom";
import { useState, useEffect, createContext } from "react";
import * as Api from "../../comman/api";
import * as Constant from "../../comman/constant";
import SuccssMsg from "../../components/AlertBox/SuccessMsg";
import WarningMsg from "../../components/AlertBox/WarningMsg";
import { ResponseContext } from "../../comman/context.js";
import { set } from "react-hook-form";
import { dateFormatchange } from "../../comman/utils";
import { useNavigate } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
function Respond(props) {
  const location = useLocation();
  // const [templateId, setTemplateId] = useState(0);
  const [templateName, setTemplateName] = useState("");
  const [respondQuestionList, setRespondQuestionList] = useState([]);
  const [responseList, setResponseList] = useState([]);
  const [successMessage, setSuccessMessage] = React.useState("");
  const [showAlertBox, setShowAlertBox] = React.useState(false);
  const [showWarningBox, setShowWarningBox] = React.useState(false);
  // const [userType, setUserType] = React.useState("");
  const [interviewee, setInterviewee] = useState("");
  const [interviewer, setInterviewer] = useState("");
  const [jobTitle, setJobTitle] = useState("");
  const [date, setDate] = useState(new Date());
  const [readOnlyView, setReadOnlyView] = React.useState(false);
  const [disabledSubmit, setDisabledSubmit] = React.useState(true);
  const [commentsList, setCommentsList] = useState([]);
  //  const [status, setStatus] = React.useState("");
  // const [pId, setPId] = React.useState("");
  const [warningMessage, setWarningMessage] = React.useState("");
  const [notes, setNotes] = useState("");
  const [synopsis, setSynopsis] = useState("");
  const [comment, setComment] = useState("");
  const [commentTrackingClientId, setcommentTrackingClientId] = useState();
  const [commentTrackingId, setcommentTrackingId] = useState();
  // const [templateStatus, setTemplateStatus] = useState("");
  const [isChanged, setIsChanged] = React.useState(false);
  const [addbtn, setAddbtn] = React.useState(false);
  const [textboxdis, setTextboxdis] = React.useState(false);
  const [addbtnhide, setAddbtnhide] = useState(true);
  const [isOwner, setIsOwner] = useState(true);
  const projectId = useSelector(
    (state) => state.questionnaireReducer.projectId
  );
  const projectName = useSelector(
    (state) => state.questionnaireReducer.projectName
  );
  const clientName = useSelector(
    (state) => state.questionnaireReducer.userData.clientName
  );
  const clientId = useSelector((state) => state.questionnaireReducer.clientId);
  const userId = useSelector((state) => state.questionnaireReducer.userId);
  const pId = useSelector((state) => state.questionnaireReducer.pId);
  const templateId = useSelector(
    (state) => state.questionnaireReducer.templateId
  );
  //const userType = useSelector((state) => state.questionnaireReducer.userType);
  const templateStatus = useSelector(
    (state) => state.questionnaireReducer.templateStatus
  );
  const email = useSelector(
    (state) => state.questionnaireReducer.userData.email
  );
  const firstName = useSelector(
    (state) => state.questionnaireReducer.userData.firstName
  );
  const lastName = useSelector(
    (state) => state.questionnaireReducer.userData.lastName
  );
  const pages = "response";
  const [openSave, setOpenSave] = useState(false);
  const [disabledYesButton, setDisabledYesButton] = React.useState(false);
  const currentDate = new Date();
  const navigate = useNavigate();
  const dispatch = useDispatch();

  useEffect(() => {
    getRespondQuestionList(templateId, "first");
  }, []);

  useEffect(() => {
    if (respondQuestionList) {
      respondQuestionList.map((value, index) => {
        if (
          (value.cQuestionType === "textbox" || value.type === "textbox") &&
          value.response === null
        ) {
          value.response = "";
        }
        if (
          (value.cQuestionType === "Date" || value.type === "Date") &&
          value.response === null
        ) {
          let currentDate = new Date();
          responseList[index] = currentDate.toISOString();
          value.response = dateFormatchange(currentDate);
        }
        if (
          (value.cQuestionType === "Logical" || value.type === "Logical") &&
          value.response === null
        ) {
          value.response = "";
        }
        if (
          value.response !== null &&
          value.cQuestionType === "Range of Values"
        ) {
          value.response = value.response.split(",");
        }
        if (
          (value.cQuestionType === "Range of Values" ||
            value.type === "Range of Values") &&
          value.response === null
        ) {
          value.response = [0, 0];
        }

        if (
          (value.cQuestionType === "Multiple Choice Questions" ||
            value.type === "Multiple Choice Questions") &&
          value.response === null
        ) {
          value.response = "";
        }
      });
    }
  }, [respondQuestionList]);

  const openAlertBox = () => {
    setShowAlertBox(true);
  };
  const openWarningBox = () => {
    setShowWarningBox(true);
  };

  const getRespondQuestionList = (tempId, type) => {
    if (templateStatus === "Completed") {
      setReadOnlyView(true);
    }
    let URL = "";
    if (templateStatus === "Saved") {
      //Consultant flow
      URL =
        Constant.GET_QUESTIONNAIRE_DATA_WITH_RESPONSE +
        "?pId=" +
        pId +
        "&templateId=" +
        tempId +
        "&status=" +
        templateStatus +
        "&projectId=" +
        projectId +
        "&clientId=" +
        clientId;
      Api.getRespondQuestionList(URL).then((res) => {
        // setReadOnlyView(true);
        if (type === "return") {
          setAddbtn(false);
        }
        setTextboxdis(true);
        setRespondQuestionList(res.templateQuestionResponseList);
        setTemplateName(
          res.templateQuestionResponseList.length
            ? res.templateQuestionResponseList[0].templatename
            : ""
        );
        setCommentsList(res.templateCommentList);
         setInterviewee(res.project.projectInterviewee);
         setInterviewer(res.project.projectInterviewer);
         setJobTitle(res.project.jobTitle);
         setDate(res.project.projectCreateDate);
        // console.log(date,"date from api ");
        setNotes(
          res.templateQuestionResponseList.length
            ? res.templateQuestionResponseList[0].notes
            : ""
        );
        setSynopsis(
          res.templateQuestionResponseList.length
            ? res.templateQuestionResponseList[0].synopsis
            : ""
        );
        res.templateQuestionResponseList.map((value, index) => {
          responseList[index] = value.response;
        });
        //setDate("");
      });
    } else if (
      templateStatus === "New" ||
      templateStatus === "Pending" ||
      templateStatus === "Completed"
    ) {
      URL =
        Constant.GET_CLIENT_RESPONSE_BY_TASKSUMMARY +
        "?templateId=" +
        tempId +
        "&projectId=" +
        projectId +
        "&clientId=" +
        clientId +
        "&userId=" +
        userId +
        "&status=" +
        templateStatus +
        "&createdByEmail=" +
        email;
      Api.getRespondQuestionList(URL).then((res) => {
        if (type === "return") {
          setAddbtn(false);
        }
        setTextboxdis(true);
        setRespondQuestionList(res.consQuestResByTemplateId);
        setIsOwner(res.isOwner);
        setCommentsList(res.templateCommentList);
        setTemplateName(
          res.consQuestResByTemplateId.length
            ? res.consQuestResByTemplateId[0].templatename
            : ""
        );
        setcommentTrackingClientId(
          res.templateCommentList[res.templateCommentList.length - 1]
            .commentTrackingClientId
        );
        setcommentTrackingId(
          res.templateCommentList[res.templateCommentList.length - 1]
            .commentTrackingId
        );
        setInterviewee(res.consQuestResByTemplateId[0].projectInterviewee);
        setInterviewer(res.consQuestResByTemplateId[0].projectInterviewer);
        setJobTitle(res.consQuestResByTemplateId[0].jobTitle);
        setDate(res.consQuestResByTemplateId[0].projectCreateDate);
        setNotes(
          res.consQuestResByTemplateId.length
            ? res.consQuestResByTemplateId[0].notes
            : ""
        );
        setSynopsis(
          res.consQuestResByTemplateId.length
            ? res.consQuestResByTemplateId[0].synopsis
            : ""
        );
        res.consQuestResByTemplateId.map((value, index) => {
          responseList[index] = value.response;
        });
      });
    }
  };

  const saveResponse = (callFrom = "") => {
    let data = [];
    setDisabledYesButton(true);
    let project = {
      id: pId,
      projectId: projectId,
      clientId: clientId,
      clientName: clientName,
      projectName: projectName,
      projectInterviewer:  interviewer,
      projectInterviewee:  interviewee,
      createdDate:  date,
      createdBy: userId,
      modifiedDate: currentDate,
      projectCreateDate: date,
      modifiedBy: userId,
      jobTitle:  jobTitle,
    };
    let tasktemplate = {
      taskId: 0,
      templateId: templateId,
      consultantId: "",
      clientId: clientId,
      taskStatus: 0,
      comments: "string",
      notes: notes,
      taskName: "string",
      templateStatus: "string",
      createdDate: currentDate,
      createdBy: userId,
      modifiedBy: userId,
      modifiedDate: currentDate,
      clientEmailId: "string",
      taskMessage: "string",
      synopsis: synopsis,
      isResponseFinalized: true,
      isResponseSubmittedByClient: true,
    };
    let templatecomments = {
      commentId: 0,
      templateId: templateId,
      projectId: projectId,
      clientId: clientId,
      cDescription: comment,
      createdBy: userId,
      createdDate: currentDate,
      modifiedDate: currentDate,
      modifiedBy: userId,
      commentBy: "Consultant",
      commentTrackingId: commentTrackingId,
      commentTrackingClientId: commentTrackingClientId,
      freezStatus: false,
      createdByEmail: email,
      fullName:
        firstName.charAt(0).toLocaleUpperCase() +
        lastName.charAt(0).toLocaleUpperCase(),
    };
    let clientresponseaudit = [];
    let objSend = {
      project,
      clientresponseaudit,
      templatecomments,
      tasktemplate,
    };
    respondQuestionList.map((value, index) => {
      let obj = {
        // id: pId,
        templateID: value.templateId,
        cQuestionId: value.cQuestionId ? value.cQuestionId : value.questionId,
        response: responseList[index],
        responseBy: "",
        createdDate: date,
        createdBy: userId,
        modifiedDate: currentDate,
        modifiedBy: userId,
        responseSubmittedBy: "string",
      };
      clientresponseaudit.push(obj);
    });
    Api.saveResponseData(Constant.SAVE_RESPONSE_BY_CONSULTANT, objSend).then(
      (res) => {
        if (res.code === 1) {
          setAddbtn(true);
          setSuccessMessage(res.message);
          openAlertBox();
          setDisabledSubmit(false);
          setDisabledYesButton(false);
          setOpenSave(false);
          if (callFrom === "back") {
            setTimeout(() => {
              navigate(-1);
            }, 500);
          }
        }
        //     setWarningMessage(res.message);
        //     openWarningBox();

      }
    );
  };

  const submitResponse = () => {
    let project = {
      id: pId,
      projectId: projectId,
      clientId: clientId,
      clientName: clientName,
      projectName: projectName,
      projectInterviewer: interviewer,
      projectInterviewee: interviewee,
      createdDate: currentDate,
      createdBy: userId,
      modifiedDate: currentDate,
      modifiedBy: userId,
      jobTitle: jobTitle,
    };
    let clientresponse = [];
    let templatecomments = [];
    let objSend = {
      project,
      clientresponse,
      // templatecomments
    };
    respondQuestionList.map((value, index) => {
      let obj = {
        // id: 0,
        templateID: value.templateId,
        cQuestionId: value.cQuestionId ? value.cQuestionId : value.questionId,
        response: responseList[index],
        responseBy: "",
        createdDate: currentDate,
        createdBy: userId,
        modifiedDate: currentDate,
        modifiedBy: userId,
        responseSubmittedBy: "string",
      };
      clientresponse.push(obj);
    });
    Api.submitResponseData(
      Constant.SUBMIT_RESPONSE_BY_CONSULTANT,
      objSend
    ).then((res) => {
      if (res.code === 1) {
        setSuccessMessage(res.message);
        openAlertBox();
      }
      //     setWarningMessage(res.message);
      //     openWarningBox();
    });
  };
  const setcomm = (value) => {
    setComment(value);
  };

  return (
    <div>
      <Navbar />

      <ResponseContext.Provider
        value={{
          interviewee,
          interviewer,
          jobTitle,
          date,
          isChanged,
          setInterviewee,
          setInterviewer,
          setJobTitle,
          setDate,
          setIsChanged,
        }}
      >
        <RespondFilterData
          pages={pages}
          templateId={templateId}
          status={templateStatus}
          templateName={templateName}
          setNotes={setNotes}
          setSynopsis={setSynopsis}
          notes={notes}
          synopsis={synopsis}
          // isOwner={isOwner}
        />
      </ResponseContext.Provider>
      <RespondContent
        pages={pages}
        respondQuestionList={respondQuestionList}
        setResponseList={setResponseList}
        responseList={responseList}
        readOnlyView={readOnlyView}
        setIsChanged={setIsChanged}
      />
      <RespondComments
        pages={pages}
        comm={setcomm}
        comments={commentsList}
        addbtn={addbtn}
        textboxdis={textboxdis}
        addbtnhide={addbtnhide}
        tmpId={templateId}
        getrespondquestionlist={getRespondQuestionList}
        status={templateStatus}
        setIsChanged={setIsChanged}
        initials={
          firstName.charAt(0).toLocaleUpperCase() +
          lastName.charAt(0).toLocaleUpperCase()
        }
      />
      <FooterButtons
        pageName={pages}
        saveResponse={saveResponse}
        submitResponse={submitResponse}
        questionnaireName={templateName}
        templateId={templateId}
        pId={pId}
        readOnlyView={readOnlyView}
        disabledSubmit={disabledSubmit}
        disabledYesButton={disabledYesButton}
        templateStatus={templateStatus}
        isChanged={isChanged}
        openSave={openSave}
        setOpenSave={setOpenSave}
        // isOwner={isOwner}
      />
      <SuccssMsg
        showAlertBox={showAlertBox}
        setShowAlertBox={setShowAlertBox}
        message={successMessage}
      />
      <WarningMsg
        showWarningBox={showWarningBox}
        setShowWarningBox={setShowWarningBox}
        message={warningMessage}
      />
    </div>
  );
}

export default Respond;
