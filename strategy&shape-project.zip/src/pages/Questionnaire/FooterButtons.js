import React, { useEffect } from "react";
import { useState } from "react";
import OutlinedInput from "@mui/material/OutlinedInput";
import "./FooterButton.css";
import { Button, DialogActions, TextField, Typography } from "@mui/material";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import InputLabel from "@mui/material/InputLabel";
import maskImage from "../../Images/MaskImage.png";
import Delete from "../../Images/deleteImg.png";
import { useNavigate } from "react-router-dom";
import Add from "../../Images/Add.svg";
import SuccssMsg from "../../components/AlertBox/SuccessMsg";
import CloseIcon from "@mui/icons-material/Close";
import CheckIcon from "@mui/icons-material/Check";
import * as Api from "../../comman/api";
import * as Constant from "../../comman/constant";
import { useSelector, useDispatch } from "react-redux";
import {
  setSelectedMasterQuestion,
  setQuestionnaireState,
  setMasterQuestionnaireEvent,
  setEditQuestionList,
  setTemplateStatus,
} from "../../redux/actions/questionnaireAction";

import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogueContentText,
  DialogueActions,
} from "@material-ui/core";
import { Block } from "@mui/icons-material";
import WarningMsg from "../../components/AlertBox/WarningMsg";

function FooterButtons(props) {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setInputList([
      { firstName: "", lastName: "", emailId: "", emailError: "" },
    ]);
  };

  const handleSubmitopen = () => {
    setOpenSubmit(true);
    setOpenSend(false);
  };
  const handleSendOpen = () => {
    setOpenSend(true);
  };

  const handleSendClose = () => {
    // setOpenSend(false);
    setOpenSend(false);
  };

  const handleSubmitClose = () => {
    setOpenSubmit(false);
  };

  const handleSaveClose = () => {
    props.setOpenSave(false);
    navigate(-1);
  };
  const handleSave = () => {
    props.saveResponse("back");
  };

  const [open, setOpen] = useState(false);
  const [openSend, setOpenSend] = useState(false);
  const [openSubmit, setOpenSubmit] = useState(false);
  const [firstName, setFirstName] = useState([]);
  const [warningMessage, setWarningMessage] = React.useState("");
  const [lastName, setLastName] = useState([]);
  const [showWarningBox, setShowWarningBox] = React.useState(false);
  const [email, setEmail] = useState([]);
  const [showAlertBox, setShowAlertBox] = React.useState(false);
  const [emailError, setEmailError] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [error, setError] = "";
  const [sendState, setSendState] = useState(false);
  const [textField, setTextField] = useState("changed text");
  const [inputList, setInputList] = useState([
    { firstName: "", lastName: "", emailId: "", emailError: "" },
  ]);
  const userId = useSelector((state) => state.questionnaireReducer.userId);
  const clientId = useSelector((state) => state.questionnaireReducer.clientId);
  const projectId = useSelector(
    (state) => state.questionnaireReducer.projectId
  );

  function onTextFieldChange(e) {
    setTextField(e.target.value.replace(new RegExp(/[*~^`]/gm), ""));
  }

  const handleAddClick = () => {
    setInputList([
      ...inputList,
      { firstName: "", lastName: "", emailId: "", emailError: "" },
    ]);
  };

  const openWarningBox = () => {
    setShowWarningBox(true);
  };

  const closeAlertBox = () => {
    setShowAlertBox(false);
  };
  const openAlertBox = () => {
    setShowAlertBox(true);
  };

  const handleInputChange = (e, index) => {
    const { name, value } = e.target;
    const list = [...inputList];
    list[index][name] = value.replace(
      new RegExp(/[*#$%!~^&`(){}<>?/\\:;""'|]/gm),
      ""
    );
    if (name === "emailId") {
      list[index]["emailError"] = "";
    }

    setInputList(list);
  };

  const handleRemove = (index) => {
    const list = [...inputList];
    list.splice(index, 1);
    setInputList(list);
  };

  const viewRespond = (templateId) => {
    dispatch(setQuestionnaireState("add"));
    dispatch(setTemplateStatus("Saved"));
    navigate("/Respond");
  };

  const handleBackButton = () => {
    //dispatch(setSelectedMasterQuestion([]));
    if (props.pageName === "response") {
      if (props.templateStatus !== "Completed" && props.isChanged) {
        props.setOpenSave(true);
      } else {
        navigate(-1);
      }
    } else if (props.pageName === "preview") {
      dispatch(setQuestionnaireState("add"));
      navigate(-1);
    } else {
      if (props.pageName === "addQuestionnaire") {
        dispatch(setMasterQuestionnaireEvent("edit"));
        dispatch(setEditQuestionList(props.finalQuestionList));
        navigate("/Questionnaire");
      } else {
        navigate(-1);
      }
    }
  };

  function isValidEmail(email) {
    return /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email);
  }
  const currentDate = new Date();

  function sendDataApi() {
    let fName = [];
    let lName = [];
    let email = [];
    let validEmail = true;
    const errorHandling = inputList.map((value, index) => {
      if (isValidEmail(value.emailId) && validEmail) {
        fName.push(value.firstName);
        lName.push(value.lastName);
        email.push(value.emailId);
        return value;
      } else {
        validEmail = false;
        // value.emailError = "Invalid email id";
        return { ...value, emailError: "Invalid email id " };
      }
    });
    setInputList(errorHandling);

    if (validEmail) {
      setSendState(true);
      const data = {
        projectId: projectId,
        clientId: clientId,
        leaderShipCategoryId: 0,
        roleId: 0,
        createdDate: currentDate.toISOString(),
        categoryId: 0,
        firstNames: fName.join(","),
        lastName: lName.join(","),
        tasktemplate: {
          taskId: 0,
          templateId: props.templateId,
          consultantId: "",
          clientId: clientId,
          taskStatus: 0,
          comments: "",
          notes: "",
          taskName: props.questionnaireName,
          templateStatus: "1",
          createdDate: "2022-10-17T08:32:57.887Z",
          createdBy: userId,
          modifiedDate: currentDate.toISOString(),
          modifiedBy: userId,
          clientEmailId: email.join(","),
          taskMessage: textField,
          synopsis: "",
          isResponseFinalized: true,
          isResponseSubmittedByClient: true,
        },
      };
      Api.sendQuestionnaireTemplate(Constant.SEND_DATA_LIST, data).then(
        (res) => {
          if (res.status === 200) {
            setSendState(false);
            handleClose();
            setSuccessMessage("Questionnaire Sent");
            openAlertBox();
            setInputList([
              { firstName: "", lastName: "", emailId: "", emailError: "" },
            ]);
          } else {
            setWarningMessage(res.message);
            openWarningBox();
            handleClose();
            setSendState(false);
            setInputList([
              { firstName: "", lastName: "", emailId: "", emailError: "" },
            ]);
          }
        }
      );
    }
  }

  return (
    <div
      style={{
        height: "100px",
        backgroundColor: "#F8F8F8",
        textTransform: "capitalize",
        display: "flex",
        justifyContent: "flex-end",
        paddingRight: "40px",
      }}
    >
      <Button
        style={{
          fontFamily: "Ubuntu",
          fontSize: "12px",
          textTransform: "capitalize",
          backgroundColor: "white",
          margin: "35px 10px",
          color: "0070AD",
          borderRadius: "25px",
          padding: "7px 16px",
          border: "1px solid #0070AD",
        }}
        onClick={() => handleBackButton()}
      >
        back
      </Button>
      <div style={{ display: props.readOnlyView ? "none" : "block" }}>
        {props.pageName === "addQuestionnaire" ? (
          <Button
            style={{
              fontFamily: "Ubuntu",
              textTransform: "capitalize",
              fontSize: "12px",
              backgroundColor: props.templateId === 0 ? "#BFBFBF" : "#0070AD",
              // backgroundColor: props.isOwner
              //   ? props.templateId === 0
              //     ? "#BFBFBF"
              //     : "#0070AD"
              //   : "#BFBFBF",
              color: "white",
              margin: "35px 10px",
              color: "white",
              borderRadius: "25px",
              padding: "7px 16px",
            }}
            onClick={() => viewRespond(props.templateId)}
            disabled={props.templateId === 0 ? true : false}
            // disabled={
            //   props.isOwner ? (props.templateId === 0 ? true : false) : true
            // }
          >
            Respond
          </Button>
        ) : (
          ""
        )}

        {props.pageName === "addQuestionnaire" ||
        props.pageName === "response" ||
        props.pageName === "responsePreview" ? (
          <Button
            style={{
              fontFamily: "Ubuntu",
              textTransform: "capitalize",
              fontSize: "12px",
              backgroundColor: "#0070AD",
              // backgroundColor: !props.isOwner ? "#BFBFBF" : "#0070AD",
              color: "white",
              margin: "35px 10px",
              color: "white",
              borderRadius: "25px",
              padding: "7px 16px",
            }}
            onClick={() => {
              props.pageName === "addQuestionnaire"
                ? props.saveQuestionnaire()
                : props.saveResponse();
            }}
            // disabled={!props.isOwner}
          >
            Save
          </Button>
        ) : (
          ""
        )}

        {props.pageName === "addQuestionnaire" ||
        props.pageName === "response" ||
        props.pageName === "responsePreview" ? (
          <Button
            style={{
              fontFamily: "Ubuntu",
              textTransform: "capitalize",
              fontSize: "12px",
              backgroundColor: props.templateId === 0 ? "#BFBFBF" : "#0070AD",
              // backgroundColor: props.isOwner
              //   ? props.templateId === 0
              //     ? "#BFBFBF"
              //     : "#0070AD"
              //   : "#BFBFBF",
              color: "white",
              margin: "35px 10px",
              color: "white",
              borderRadius: "25px",
              padding: "7px 16px",
            }}
            onClick={handleClickOpen}
            disabled={props.templateId === 0 ? true : false}
            // disabled={
            //   props.isOwner ? (props.templateId === 0 ? true : false) : true
            // }
            className="send-button"
          >
            Send
          </Button>
        ) : (
          ""
        )}

        <Dialog open={open} onClose={handleClose} style={{ minWidth: "800px" }}>
          <DialogTitle>Send to</DialogTitle>
          <DialogContent>
            {inputList.map((x, i) => {
              return (
                <div style={{ display: "flex" }}>
                  <FormControl sx={{ m: 1, width: "40ch" }} variant="outlined">
                    <Typography
                      style={{ fontSize: "12px", fontFamily: "Ubuntu" }}
                    >
                      First Name
                    </Typography>
                    <OutlinedInput
                      className="text-box"
                      style={{ padding: "0px" }}
                      id="outlined-adornment-weight"
                      name="firstName"
                      onChange={(e) => {
                        handleInputChange(e, i);
                      }}
                      value={x.firstName}
                    />
                  </FormControl>
                  <FormControl sx={{ m: 1, width: "40ch" }} variant="outlined">
                    <Typography
                      style={{ fontSize: "12px", fontFamily: "Ubuntu" }}
                    >
                      Last Name
                    </Typography>
                    <OutlinedInput
                      className="text-box"
                      onChange={(e) => {
                        handleInputChange(e, i);
                      }}
                      id="outlined-adornment-weight"
                      name="lastName"
                      value={x.lastName}
                    />
                  </FormControl>
                  <FormControl sx={{ m: 1, width: "45ch" }} variant="outlined">
                    <Typography
                      style={{ fontSize: "12px", fontFamily: "Ubuntu" }}
                    >
                      Email id
                    </Typography>
                    <OutlinedInput
                      className="text-box"
                      required
                      type="email"
                      onChange={(e) => {
                        handleInputChange(e, i);
                      }}
                      id="outlined-adornment-weight"
                      name="emailId"
                      value={x.emailId}
                    />
                    <span className="error-message">{x.emailError}</span>
                  </FormControl>

                  <div style={{ width: "25px", display: "flex" }}>
                    {inputList.length - 1 === i && (
                      <Button
                        style={{ marginRight: "5px" }}
                        className="popup-Button"
                        onClick={handleAddClick}
                      >
                        {" "}
                        <img src={Add}></img>
                      </Button>
                    )}

                    {inputList.length !== 1 && (
                      <Button
                        className="popup-Button"
                        onClick={() => handleRemove(i)}
                      >
                        {" "}
                        <img src={Delete}></img>
                      </Button>
                    )}
                  </div>
                </div>
              );
            })}
            <div>
              <Typography
                style={{
                  fontSize: "12px",
                  fontFamily: "Ubuntu",
                  marginRight: "10px",
                  marginTop: "10px",
                  marginBottom: "5px",
                }}
              >
                Message
              </Typography>
              <textarea
                className="text-field"
                style={{
                  width: "100%",
                  minHeight: "100px",
                  padding: "5px 2px",
                  fontFamily: "Ubuntu",
                }}
                id="fullWidth"
                multiline
                maxRows={10}
                minheight="100px"
                onChange={onTextFieldChange}
                value={textField}
              />
            </div>

            {/* <MultipleInputSelect getProjectName={getProjectName} /> */}
            <div>
              <DialogActions>
                <Button
                  className="hover_white"
                  style={{
                    fontFamily: "Ubuntu",
                    textTransform: "capitalize",
                    fontSize: "10px",
                    backgroundColor: "#0070AD",
                    color: "white",
                    margin: "20px 10px",
                    color: "white",
                    borderRadius: "25px",
                    padding: "7px 16px",
                  }}
                  variant="outlined"
                  onClick={handleClose}
                >
                  Cancel
                </Button>
                <Button
                  disabled={sendState}
                  className="hover_white"
                  // onClick={handleClose}
                  // onClick={{() => props.sendQuestionnaire()}}
                  onClick={() => sendDataApi()}
                  style={{
                    backgroundColor: sendState ? "#BFBFBF" : "#0070AD",
                    fontFamily: "Ubuntu",
                    textTransform: "capitalize",
                    fontSize: "12px",
                    color: "white",
                    margin: "20px 10px",
                    color: "white",
                    borderRadius: "25px",
                    padding: "7px 16px",
                  }}
                  variant="outlined"
                >
                  Send
                </Button>
              </DialogActions>
            </div>
          </DialogContent>
        </Dialog>

        {props.pageName == "response" ||
        props.pageName === "responsePreview" ? (
          <Button
            className="button-footer"
            onClick={handleSendOpen}
            style={{
              fontSize: "12px",
              fontFamily: "Ubuntu",
              textTransform: "capitalize",
              backgroundColor: props.disabledSubmit ? "#BFBFBF" : "#0070AD",
              color: "white",
              margin: "35px 10px",
              color: "white",
              borderRadius: "25px",
              padding: "7px 16px",
            }}
            disabled={props.disabledSubmit}
          >
            Submit
          </Button>
        ) : (
          ""
        )}
        <Dialog className="dialog-submit" open={openSend}>
          <DialogTitle
            style={{
              fontFamily: "Ubuntu",
              padding: "10px",
              marginLeft: "10px",
              fontSize: "12px",
            }}
          >
            Submit
          </DialogTitle>
          <DialogContent style={{ fontSize: "12px", fontFamily: "Ubuntu" }}>
            Make sure to validate the questionnaire with the client and project
            manager before submitting.
          </DialogContent>
          <DialogActions style={{ padding: "30px" }}>
            <Button
              style={{
                padding: "7px 12px",
                borderRadius: "25px",
                textTransform: "capitalize",
                marginRight: "10px",
              }}
              variant="outlined"
              onClick={() => {
                handleSendClose();
              }}
            >
              Cancel
            </Button>

            <Button
              style={{
                textTransform: "capitalize",
                padding: "7px 12px",
                borderRadius: "25px",
                backgroundColor: "#0070AD",
                color: "#fff",
                textTransform: "capitalize",
              }}
              onClick={() => {
                handleSubmitopen();
              }}
              variant="outlined"
            >
              Ok
            </Button>
          </DialogActions>
        </Dialog>
        <Dialog open={openSubmit} style={{ minWidth: "800px" }}>
          <DialogTitle>Send</DialogTitle>
          <DialogContent>
            Changes cannot be made once submitted. Do you confirm to submit?
            {/* <MultipleInputSelect getProjectName={getProjectName} /> */}
            <div>
              <DialogActions>
                <Button
                  style={{
                    fontFamily: "Ubuntu",
                    textTransform: "capitalize",
                    fontSize: "10px",
                    backgroundColor: "#0070AD",
                    color: "white",
                    margin: "20px 10px",
                    color: "white",
                    borderRadius: "25px",
                    padding: "7px 16px",
                  }}
                  variant="outlined"
                  onClick={handleSubmitClose}
                >
                  Cancel
                </Button>
                <Button
                  // onClick={handleSubmitClose}
                  // onClick={handleClose}
                  // onClick={{() => props.sendQuestionnaire()}}
                  style={{
                    fontFamily: "Ubuntu",
                    textTransform: "capitalize",
                    fontSize: "12px",
                    backgroundColor: "#0070AD",
                    color: "white",
                    margin: "20px 10px",
                    color: "white",
                    borderRadius: "25px",
                    padding: "7px 16px",
                  }}
                  variant="outlined"
                  onClick={() => {
                    props.submitResponse();
                    handleSubmitClose();
                  }}
                >
                  confirm
                </Button>
              </DialogActions>
            </div>
          </DialogContent>
        </Dialog>
        <Dialog className="dialog-submit" open={props.openSave}>
          <DialogTitle
            style={{
              fontFamily: "Ubuntu",
              padding: "10px",
              marginLeft: "10px",
              fontSize: "12px",
            }}
          >
            Save
          </DialogTitle>
          <DialogContent style={{ fontSize: "12px", fontFamily: "Ubuntu" }}>
            Do you want to save the changes?
          </DialogContent>
          <DialogActions style={{ padding: "30px" }}>
            <Button
              style={{
                padding: "7px 12px",
                borderRadius: "25px",
                textTransform: "capitalize",
                marginRight: "10px",
              }}
              variant="outlined"
              onClick={() => {
                handleSaveClose();
              }}
            >
              No
            </Button>

            <Button
              style={{
                textTransform: "capitalize",
                padding: "7px 12px",
                borderRadius: "25px",
                backgroundColor: props.disabledYesButton
                  ? "#BFBFBF"
                  : "#0070AD",
                color: "#fff",
                textTransform: "capitalize",
              }}
              onClick={() => {
                handleSave();
              }}
              variant="outlined"
              disabled={props.disabledYesButton}
            >
              Yes
            </Button>
          </DialogActions>
        </Dialog>

        <SuccssMsg
          showAlertBox={showAlertBox}
          setShowAlertBox={setShowAlertBox}
          message={successMessage}
        />

        <WarningMsg
          showWarningBox={showWarningBox}
          setShowWarningBox={setShowWarningBox}
          message={warningMessage}
        />
      </div>
    </div>
  );
}

export default FooterButtons;
