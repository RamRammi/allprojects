import React, { useState, useEffect } from "react";
import MenuItem from "@mui/material/MenuItem";
import OutlinedInput from "@mui/material/OutlinedInput";
import Select from "@mui/material/Select";
import FormControl from "@mui/material/FormControl";
import TextField from "@mui/material/TextField";
import Typography from "@mui/material/Typography";
import maskImage from "../../Images/MaskImage.png";
import Button from "@mui/material/Button";
import Pdf from "../../Images/pdf.png";
const MenuProps = {
  style: {
    minHeight: "40px",
    width: 200,
  },
};

function RespondComments(props) {
  const [comment, setComment] = useState("");
  const [commbox, setCommbox] = useState(true);
  const [addbtnhide, setAddbtnhide] = useState(true);
  useEffect(() => {
    // let f = ''
    // props.comments.map((l,index) => {
    //   f=l.cDescription
    //     // setComment(l.cDescription)
    // })
    // setComment(f)
  }, [props.comments]);
  const handleChange = (e, index, item) => {
    setComment(e);
  };
  const propcomm = (value) => {
    if (props.pages === "response") props.setIsChanged(true);
    setComment(value);
    props.comm(value);
  };
  const propcomment = (value, index, item) => {
    if (props.pages === "response") props.setIsChanged(true);
    let comm = "";
    props.setComment.map((f, ind) => {
      if (f.commentId === item.commentId) {
        comm = value;
      } else {
        comm = f.cDescription;
      }
    });
    setComment(comm);
    props.propcomm(value);
  };
  const addcomm = () => {
    setCommbox(false);
    setAddbtnhide(false);
    setComment("");
    // if(comment)
    props.getrespondquestionlist(props.tmpId, "return");

    setCommbox(true);
  };
  return (
    <>
      {props.pages == "response" ? (
        <div style={{ marginLeft: "30px" }}>
          <div style={{ minHeight: "100px", borderTop: "1px solid #E0E0E0" }}>
            <div style={{ marginLeft: "30px", marginTop: "10px" }}>
              <Typography
                style={{
                  fontFamily: "Ubuntu",
                  fontWeight: "600",
                  fontSize: "18px",
                }}
              >
                Comments
              </Typography>
            </div>

            <div>
              {props.comments && props.comments.length > 0
                ? props.comments.map((k, index) => {
                    return k.cDescription !== "" ? (
                      <>
                        <div
                          style={{
                            marginLeft:
                              k.commentBy === "Consultant" ? "30px" : "80px",
                            display: "flex",
                            marginTop: "10px",
                          }}
                        >
                          <span>
                            <div
                              className="circle"
                              style={{
                                backgroundColor:
                                  props.initials === k.fullName
                                    ? "#00d53b"
                                    : "#512DA8",
                              }}
                            >
                              <p className="circle-inner">
                                {k.commentBy === null
                                  ? props.initials
                                  : k.fullName}
                              </p>
                            </div>
                          </span>
                          <TextField
                            id="outlined-basic"
                            defaultValue={k.cDescription}
                            disabled={true}
                            onChange={(e) =>
                              propcomment(e.target.value, index, k)
                            }
                            fullWidth
                            sx={{
                              width: "100%",
                              marginLeft: "20px",
                              marginBottom: "30px",
                              marginRight: "10px",
                              height: "32px",
                              marginTop: "5px",
                              border: "1px #828282",
                            }}
                          ></TextField>
                        </div>
                        <span
                          className="comment-by"
                          style={{
                            marginLeft:
                              k.commentBy === "Consultant" ? "65px" : "116px",
                          }}
                        >
                          Commented by : {k.createdByEmail}
                        </span>
                      </>
                    ) : null;
                  })
                : null}
            </div>
            {commbox ? (
              <div
                style={{
                  marginLeft: "30px",
                  display: "flex",
                  marginTop: "10px",
                }}
              >
                {props.status !== "Completed" ? (
                  <>
                    <span>
                      <div
                        className="circle"
                        style={{ backgroundColor: "#00d53b" }}
                      >
                        <p className="circle-inner">{props.initials}</p>
                      </div>
                    </span>

                    <TextField
                      id="outlined-basic"
                      placeholder=""
                      disabled={props.addbtn}
                      onChange={(e) => propcomm(e.target.value.replace(
                        new RegExp(/[*^~]/gm),
                        ""
                      ))
                    }
                      value={comment}
                      fullWidth
                      sx={{
                        width: "100%",
                        marginLeft: "20px",
                        marginBottom: "30px",
                        marginRight: "10px",
                        height: "32px",
                        marginTop: "5px",
                        border: "1px #828282",
                      }}
                    ></TextField>
                  </>
                ) : (
                  ""
                )}
              </div>
            ) : null}

            {props.addbtn ? (
              <button className="add-comment-button" onClick={() => addcomm()}>
                {" "}
                add comment <span> + </span>
              </button>
            ) : null}
          </div>
        </div>
      ) : (
        " "
      )}
    </>
  );
}

export default RespondComments;
