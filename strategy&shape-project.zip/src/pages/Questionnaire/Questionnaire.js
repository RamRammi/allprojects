import React from "react";
import Filters from "../../components/Filters/FilterData";
import "./Questionnaire.css";
import Navbar from "../../components/Navbar/Navbar";
import QuestionList from "../../components/QuestionList";
import SearchBar from "../../components/SearchBar/SearchBar";
import { useLocation } from "react-router-dom";
import { Grid } from "@mui/material";
import * as Api from "../../comman/api";
import * as Constant from "../../comman/constant";
import Button from "@mui/material/Button";
import RenameQuestionnaire from "../../components/PopUp/RenameQuestionnaire";
import CommonModal from "../../components/PopUp/ExpendPopup/modal";
import { useSelector, useDispatch } from "react-redux";
import {
  setMasterQuestionSearch,
  setMasterFilterQuestion,
  setLeadershipId,
} from "../../redux/actions/questionnaireAction";
const Questionnaire = () => {
  const location = useLocation();
  const dispatch = useDispatch();
  const pageName = "questionnaire";
  // const [searchStr, setSearchStr] = React.useState("");
  // const [filterField, setFilterField] = React.useState({
  //   general: [],
  //   leadershipType: [],
  //   roleSpecific: [],
  // });
  //const [selectedRoleList, setSelectedRoleList] = React.useState([]);
  // const [leaderShipCategoryId, setLeadershipCategoryId] = React.useState(0);
  const leadershipId = useSelector(
    (state) => state.questionnaireReducer.leadershipId
  );
  const role = useSelector((state) => state.questionnaireReducer.selectedRoles);
  const [projectName, setProjectName] = React.useState("");
  const [openAccordion, setOpenAccordion] = React.useState(false);
  // const [questionnaireName, setQuestionnaireName] = React.useState("Untitled");
  const [open, setOpen] = React.useState(false);
  const [openExport, setOpenExport] = React.useState(false);

  const searchStr = useSelector(
    (state) => state.questionnaireReducer.masterQuestionSearch
  );

  const filterField = useSelector(
    (state) => state.questionnaireReducer.masterFilterQuestion
  );
  const questionnaireName = useSelector(
    (state) => state.questionnaireReducer.templateName
  );
  let QUESTION_CATEGORY = Constant.QUESTION_CATEGORY;

  React.useEffect(() => {
    const keyDownHandler = (event) => {
      if (event.key === "Enter") {
        event.preventDefault();
        getSelectedFilters();
      }
    };
    if (searchStr === "") {
      getSelectedFilters();
    }
    document.addEventListener("keydown", keyDownHandler);

    return () => {
      document.removeEventListener("keydown", keyDownHandler);
    };
  }, [searchStr]);

  const searchText = (event) => {
    dispatch(setMasterQuestionSearch(event.target.value));
  };
  // const setRoleList = (value) => {
  //   setSelectedRoleList(value);
  // };

  const getSelectedFilters = () => {
    //setLeadershipCategoryId(leaderShipCategoryId);
    let roleIdSection = "";
    role.map((value) => {
      roleIdSection = roleIdSection + "&roleId=" + value.roleId;
    });
    let URL =
      Constant.GET_QUESTION_LIST +
      "?leaderShipCategoryId=" +
      leadershipId +
      roleIdSection +
      "&searchtext=" +
      searchStr;
    Api.getQuestionList(URL).then((res) => {
      let data = {
        general: [],
        leadershipType: [],
        roleSpecific: [],
      };
      let roleCategory = { roleName: "", rows: [] };
      let roleCategory1 = { roleName: "", rows: [] };
      let roleCategory2 = { roleName: "", rows: [] };
      data.leadershipType.push(roleCategory);
      data.general.push(roleCategory1);
      res.map((value) => {
        if (value.categoryId === 2) {
          data.leadershipType[0].rows.push(value);
        }
        if (value.categoryId === 3) {
          if (role.length) {
            role.map((role) => {
              const index = data.roleSpecific.findIndex((object) => {
                return object.roleName === role.roleName;
              });
              if (index > -1) {
                if (role.roleId === value.roleId) {
                  data.roleSpecific[index].rows.push(value);
                }
              } else {
                let roleCategory = { roleName: "", rows: [] };
                roleCategory.roleName = role.roleName;
                if (role.roleId === value.roleId) {
                  roleCategory.rows.push(value);
                }
                data.roleSpecific.push(roleCategory);
              }
            });
          } else {
            // let roleCategory = { roleName: "", rows: [] };
            data.roleSpecific[0] = roleCategory2;
            data.roleSpecific[0].rows.push(value);
          }
        }
        if (value.categoryId === 4) {
          data.general[0].rows.push(value);
        }
      });
      //   setFilterField(data);
      dispatch(setMasterFilterQuestion(data));
      setOpenAccordion(true);
    });
  };
  // const resetTable = () => {
  //   dispatch(setMasterFilterQuestion({ general: [], leadershipType: [], roleSpecific: [] }));
  // };
  const handleClickOpen = () => {
    setOpenExport(true);
  };
  const handleClose = () => {
    setOpenExport(false);
  };

  return (
    <React.Fragment>
      <Navbar pageName={pageName} />

      <Grid container>
        {/* <Grid item sm={0.5}>
          <Leftbar />
        </Grid> */}
        <Grid item sm={11.5}>
          <div>
            <div className="questionnaire-name-actions">
              <span className="questionnaire-name">{questionnaireName}</span>
              <RenameQuestionnaire
                //  setQuestionnaireName={setQuestionnaireName}
                questionnaireName={questionnaireName}
                open={open}
                setOpen={setOpen}
              />
              {filterField.general.length ||
              filterField.leadershipType.length ||
              filterField.roleSpecific.length ? (
                <span>
                  <Button
                    onClick={handleClickOpen}
                    style={{
                      fontFamily: "Ubuntu",
                      fontSize: "12px",
                      backgroundColor: "#0070AD",
                      color: "white",
                      margin: " 10px",
                      borderRadius: "25px",
                      padding: "5px 10px",
                      border: "1px solid #0070AD",
                      textTransform: "capitalize",
                      float: "right",
                    }}
                  >
                    Export Question Set {" "}
                  </Button>
                  <CommonModal
                    pageName={"Questionnaire"}
                    open={openExport}
                    onClose={() => handleClose()}
                    type="export"
                    leaderShipCategoryId={leadershipId}
                    selectedRoleList={role}
                    // templateId={templateId}
                    // status={status}
                  />
                </span>
              ) : (
                ""
              )}
            </div>
            <Filters
              getSelectedFilters={getSelectedFilters}
              // resetTable={resetTable}
              // pageName={pageName}
              // setRoleList={setRoleList}
              // setFilterField={setFilterField}
            />
            <SearchBar
              searchText={searchText}
              pageName={pageName}
              searchStr={searchStr}
            />
            <div className="content">
              {filterField.general.length ||
              filterField.leadershipType.length ||
              filterField.roleSpecific.length ? (
                <QuestionList
                  // general={filterField.general}
                  // leadershipType={filterField.leadershipType}
                  // roleSpecific={filterField.roleSpecific}
                  leaderShipCategoryId={leadershipId}
                  openAccordion={openAccordion}
                  questionnaireName={questionnaireName}
                />
              ) : (
                ""
              )}
            </div>
          </div>
        </Grid>
      </Grid>
    </React.Fragment>
  );
};

export default Questionnaire;
