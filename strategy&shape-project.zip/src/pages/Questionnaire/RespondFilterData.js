import React from "react";
import { useState, useEffect, useRef } from "react";
import { useTheme } from "@mui/material/styles";
import "./RespondFilter.css";
import "../../components/Filters/QuestionnaireFilters.css";
import "./AddQuestionnaire.css";
import OutlinedInput from "@mui/material/OutlinedInput";
import { Button, DialogActions, TextField, Typography } from "@mui/material";
import FormControl from "@mui/material/FormControl";
import download from "../../Images/download.jpg";
import * as Constant from "../../comman/constant";
import * as Api from "../../comman/api";
import "./ReactQuill.css";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogueContentText,
  DialogueActions,
} from "@material-ui/core";
import AddQuestionnaireDetails from "../../components/Filters/AddQuestionnaireDetails";
import { minWidth } from "@mui/system";
import { useQuill } from "react-quilljs";
import "quill/dist/quill.snow.css";
import { ContentCopyOutlined } from "@mui/icons-material";
import { type } from "@testing-library/user-event/dist/type";
import Quill from "quill";
import CommonModal from "../../components/PopUp/ExpendPopup/modal";
import SuccssMsg from "../../components/AlertBox/SuccessMsg";
import WarningMsg from "../../components/AlertBox/WarningMsg";
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css";
import { Editor } from "react-draft-wysiwyg";
import "react-draft-wysiwyg/dist/react-draft-wysiwyg.css";
import {
  EditorState,
  convertFromHTML,
  ContentState,
  convertToHTML,
} from "draft-js";
import { stateToHTML } from "draft-js-export-html";
import { useContext } from "react";
import { ResponseContext } from "../../comman/context";

const ITEM_HEIGHT = 38;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  style: {
    minHeight: "40px",
    width: 200,
  },
};

function getStyles(name, personName, theme) {
  return {
    fontWeight:
      personName.indexOf(name) === -1
        ? theme.typography.fontWeightRegular
        : theme.typography.fontWeightMedium,
  };
}

export default function RespondFilterData(props) {
  const LOCAL_STORAGE_KEY = "notes-list";
  const [personName, setPersonName] = React.useState([]);
  const [open, setOpen] = useState(false);
  const [noteOpen, setNotesOpen] = useState(false);
  const [synopsisOpen, setSynopisOpen] = useState(false);
  const [flag, setFlag] = useState(false);

  const [content, setContent] = useState("");
  const [synopisis, setSynopisis] = useState("");

  //Changes-5
  const [editorState, setEditorState] = useState(() =>
    EditorState.createEmpty()
  );
  const [editorStatesynopisis, setEditorStatesynopisis] = useState(() =>
    EditorState.createEmpty()
  );

  const [contentState, setContentState] = useState(props.notes);
  const [contentStateSynopsis, setContentStateSynopsis] = useState(
    props.synopsis
  );
  const [showAlertBox, setShowAlertBox] = React.useState(false);
  const [successMessage, setSuccessMessage] = React.useState("");
  const { isChanged, setIsChanged } = useContext(ResponseContext);
  //Changes-4
  useEffect(() => {
    if (props.notes === "" && !flag) {
      setEditorState(
        EditorState.createWithContent(
          ContentState.createFromBlockArray(
            convertFromHTML(`<p>${props.notes}</p>`)
          )
        )
      );
    }
  }, [props.notes, props.synopsis]);

  // useEffect(() => {
  //   const html = stateToHTML(editorState.getCurrentContent());
  //   setContentState(html);
  // }, [editorState]);

  //Changes-1
  useEffect(() => {
    if (props.notes !== "" && !flag) {
      setEditorState(
        EditorState.createWithContent(
          ContentState.createFromBlockArray(
            convertFromHTML(`<p>${props.notes}</p>`)
          )
        )
      );
    }
    if (props.notes === null && !flag) {
      setEditorState(
        EditorState.createWithContent(
          ContentState.createFromBlockArray(convertFromHTML(`<p></p>`))
        )
      );
    }
  }, [props.notes]);

  //Changes-1
  useEffect(() => {
    if (props.synopsis !== "" && !flag) {
      setEditorStatesynopisis(
        EditorState.createWithContent(
          ContentState.createFromBlockArray(
            convertFromHTML(`<p>${props.synopsis}</p>`)
          )
        )
      );
    }
    if (props.synopsis === null && !flag) {
      setEditorStatesynopisis(
        EditorState.createWithContent(
          ContentState.createFromBlockArray(convertFromHTML(`<p></p>`))
        )
      );
    }
  }, [props.synopsis]);

  //Changes-2
  const notess = () => {
    let htmlContentState = editorState.getCurrentContent();
    let html = stateToHTML(htmlContentState);
    if (!flag) {
      setContentState(html);
    }

    setContentStateSynopsis(
      props.synopsis ? props.synopsis : props.interviewSynopsis
    );
  };

  useEffect(() => {
    synopnot();
  }, [contentState]);

  //Changes-5
  const synopnot = () => {
    const json = JSON.stringify(contentState);
    localStorage.setItem("notes-list", json);
    if (!flag) {
      props.setNotes(contentState);
      setEditorState(
        EditorState.createWithContent(
          ContentState.createFromBlockArray(
            convertFromHTML(`<p>${contentState}</p>`)
          )
        )
      );
      setEditorState(EditorState.moveSelectionToEnd(editorState));
    }
    if (!flag) {
      setEditorState(EditorState.moveFocusToEnd(editorState));
    }
  };

  useEffect(() => {
    synop();
  }, [contentStateSynopsis]);
  const synop = () => {
    // const json = JSON.stringify(contentStateSynopsis);
    // localStorage.setItem("Synopisis", json);
    // props.setSynopsis(contentStateSynopsis);
    const json = JSON.stringify(contentStateSynopsis);
    localStorage.setItem("notes-list", json);
    if (!flag) {
      // props.setNotes(contentState);
      props.setSynopsis(contentStateSynopsis);
      setEditorStatesynopisis(
        EditorState.createWithContent(
          ContentState.createFromBlockArray(
            convertFromHTML(`<p>${contentStateSynopsis}</p>`)
          )
        )
      );
      setEditorStatesynopisis(
        EditorState.moveSelectionToEnd(editorStatesynopisis)
      );
    }
    if (!flag) {
      setEditorStatesynopisis(EditorState.moveFocusToEnd(editorStatesynopisis));
    }
  };

  //Changes-3
  const handleContentChange = (e) => {
    let htmlcontentState = editorState.getCurrentContent();
    const html = htmlcontentState.hasText()
      ? stateToHTML(htmlcontentState)
      : "";
    if (e?.blocks[0]?.text) {
      setContentState(html);
      props.setNotes(html);
    }

    if (e?.blocks[0]?.inlineStyleRanges.length !== 0) {
      setFlag(true);
    }
  };
  const handleSynopisisChange = (e) => {
    let htmlcontentState = editorStatesynopisis.getCurrentContent();
    const html = htmlcontentState.hasText()
      ? stateToHTML(htmlcontentState)
      : "";
    if (e?.blocks[0]?.text) {
      setContentStateSynopsis(html);
      props.setSynopsis(html);
    }

    if (e?.blocks[0]?.inlineStyleRanges.length !== 0) {
      setFlag(true);
    }
  };

  const handleNotesClick = () => {
    setIsChanged(true);
    if (props.status === "Completed") {
      const obj = {
        templateId: props.templateId,
        projectId: 999,
        // notes:props.notes
        notes: contentState,
      };
      Api.SaveCompltedQuestionnaire(
        Constant.BASE_URL + Constant.SAVE_COMPLETED_QUESTIONNAIRE,
        obj
      ).then((res) => {
        if (res.status === 200) {
          setShowAlertBox(true);
          setSuccessMessage("Notes saved Successfully");
          notesClose();
        } else {
          notesClose();
        }
      });
    }
    notesClose();
    // }
  };

  const handleSynopsisClick = () => {
    setIsChanged(true);
    if (props.status === "Completed") {
      const obj = {
        templateId: props.templateId,
        projectId: 999,
        synopsis: contentStateSynopsis,
      };
      Api.SaveCompltedQuestionnaire(
        Constant.BASE_URL + Constant.SAVE_COMPLETED_QUESTIONNAIRE,
        obj
      ).then((res) => {
        if (res.status === 200) {
          setShowAlertBox(true);
          setSuccessMessage(res.msg);
          IssynopsisClose();
        } else {
          IssynopsisClose();
        }
      });
    }
    IssynopsisClose();
  };

  const handleChange = (event) => {
    const {
      target: { value },
    } = event;
    setPersonName(
      // On autofill we get a stringified value.
      typeof value === "string" ? value.split(",") : value
    );
  };
  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const notesOpen = () => {
    setNotesOpen(true);
  };

  const notesClose = () => {
    setNotesOpen(false);
  };

  const IssynopsisOpen = () => {
    setSynopisOpen(true);
  };

  const IssynopsisClose = () => {
    setSynopisOpen(false);
  };

  return (
    //main div
    <div>
      {/*div for header */}
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          margin: "10px",
        }}
      >
        <div style={{ marginLeft: "40px" }}>
          <p
            style={{
              float: "left",
              fontFamily: "Ubuntu",
              fontWeight: "500",
              fontSize: "18px",
              paddingTop: "10px",
            }}
          >
            {props.templateName}
          </p>
        </div>
        <div style={{ display: "flex", marginRight: "40px" }}>
          <div className="NotesButton_margin">
            <Button
              aria-readonly={props.pages === "preview" ? true : false}
              // aria-readonly={false}
              onClick={notesOpen}
              variant="outlined"
              className="notes-button"
            >
              Notes
            </Button>
            <Dialog
              className="Dialog_Notes"
              open={noteOpen}
              onClose={notesClose}
            >
              <div className="notes-div">
                <div className="FileDownload_width">
                  Notes
                  {/* <img src={download}></img> */}
                </div>
              </div>
              <DialogContent className="FileDownload_pad">
                <p className="p-tag-header">{props.templateName}</p>

                <div className="App">
                  <Editor
                    //  value={editorState1}
                    //  defaultContentState={contentState}
                    //  defaultEditorState={editorState1}
                    onContentStateChange={handleContentChange}
                    // blockStyleFn={myBlockStyleFn}

                    //  contentState={contentState}
                    editorState={editorState}
                    //  style={{
                    //   pointerEvents:
                    //     props.pages === "preview" ? "none" : "block",
                    // }}

                    onEditorStateChange={setEditorState}
                    readOnly={props.pages === "preview" ? true : false}
                    wrapperClassName="wrapper-class"
                    editorClassName="editor-class"
                    toolbarClassName="toolbar-class"
                    toolbar={{
                      options: [
                        "inline",
                        "blockType",
                        "fontSize",
                        "list",
                        "textAlign",
                      ],
                      inline: {
                        inDropdown: false,
                        options: ["bold", "italic", "underline"],
                      },

                      blockType: {
                        inDropdown: false,
                        options: [],
                        className: undefined,
                        component: undefined,
                        dropdownClassName: undefined,
                      },
                      fontSize: {
                        options: [
                          8, 9, 10, 11, 12, 14, 16, 18, 24, 30, 36, 48, 60, 72,
                          96,
                        ],
                        className: undefined,
                        component: undefined,
                        dropdownClassName: undefined,
                      },
                      list: {
                        inDropdown: false,
                        options: ["unordered", "ordered"],
                      },
                      textAlign: {
                        inDropdown: false,
                        className: undefined,
                        component: undefined,
                        dropdownClassName: undefined,
                        options: [],
                        left: { className: undefined },
                        center: { className: undefined },
                        right: { className: undefined },
                        justify: { className: undefined },
                      },
                      link: { inDropdown: false, options: [] },
                      history: {
                        inDropdown: false,
                        className: undefined,
                        component: undefined,
                        dropdownClassName: undefined,
                        options: [],
                        undo: { className: undefined },
                        redo: { className: undefined },
                      },
                    }}
                  />
                </div>

                <DialogActions>
                  <Button
                    style={{
                      fontFamily: "Ubuntu",
                      fontSize: "12px",
                      textTransform: "capitalize",
                      backgroundColor: "white",
                      // color: "white",
                      marginTop: "10px",

                      color: "0070AD",
                      borderRadius: "25px",
                      padding: "7px 16px",
                      border: "1px solid #0070AD",
                    }}
                    variant="outlined"
                    onClick={notesClose}
                  >
                    Close
                  </Button>
                  <Button
                    onClick={handleNotesClick}
                    style={{
                      fontFamily: "Ubuntu",
                      fontSize: "12px",
                      textTransform: "capitalize",
                      backgroundColor: "#0070AD",
                      // backgroundColor: props.isOwner ? "#0070AD" : "#BFBFBF",
                      // color: "white",
                      color: "white",
                      marginTop: "10px",
                      borderRadius: "25px",
                      padding: "7px 16px",
                      border: "1px solid #0070AD",
                      pointerEvents:
                        props.pages === "preview" ? "none" : "block",
                      // pointerEvents: props.isOwner
                      //   ? props.pages === "preview"
                      //     ? "none"
                      //     : "block"
                      //   : "none",
                    }}
                    variant="outlined"
                  >
                    OK
                  </Button>
                </DialogActions>
              </DialogContent>
            </Dialog>
          </div>
          {props.pages !== "preview" ? (
            <Button
              onClick={handleClickOpen}
              style={{
                fontFamily: "Ubuntu",
                fontSize: "12px",
                backgroundColor: "#0070AD",
                color: "white",
                margin: " 10px 10px 10px 20px",
                borderRadius: "25px",
                padding: "5px 10px",
                border: "1px solid #0070AD",
                textTransform: "capitalize",
              }}
            >
              Export Questionnaire{" "}
            </Button>
          ) : (
            " "
          )}
          <CommonModal
            pageName={"Respond"}
            open={open}
            onClose={() => handleClose()}
            type="export"
            templateId={props.templateId}
            status={props.status}
          />
        </div>
      </div>
      {/* div for header end */}
      {/* //input boxes end */}
      <AddQuestionnaireDetails
        pageName={props.pages}
        questionnaireDetails={props.questionnaireDetails}
      />

      <div className="RespondFilter_button">
        <Button
          className="respond_InterviewSynopsiss hover_white_RespondFilter"
          onClick={IssynopsisOpen}
        >
          Interview Synopsis
        </Button>
        <Dialog
          className="Dialog_Notes"
          open={synopsisOpen}
          onClose={IssynopsisClose}
        >
          <div className="notes-div">
            <div className="FileDownload_width">
              Interview Synopsis
              {/* <img src={download}></img> */}
            </div>
          </div>
          <DialogContent className="FileDownload_pad">
            <p className="p-tag-header">{props.templateName}</p>

            <div>
              <Editor
                //  value={editorState1}
                //  defaultContentState={contentState}
                //  defaultEditorState={editorState1}
                onContentStateChange={handleSynopisisChange}
                // style={{
                //   pointerEvents:
                //     props.pages === "preview" ? "none" : "block",
                // }}

                //  contentState={contentState}
                editorState={editorStatesynopisis}
                readOnly={props.pages === "preview" ? true : false}
                onEditorStateChange={setEditorStatesynopisis}
                wrapperClassName="wrapper-class"
                editorClassName="editor-class"
                toolbarClassName="toolbar-class"
                toolbar={{
                  inline: {
                    inDropdown: false,
                    options: ["bold", "italic", "underline"],
                  },
                  blockType: {
                    inDropdown: false,
                    options: [],
                    className: undefined,
                    component: undefined,
                    dropdownClassName: undefined,
                  },
                  list: {
                    inDropdown: false,
                    options: ["unordered", "ordered"],
                  },
                  textAlign: {
                    inDropdown: false,
                    className: undefined,
                    component: undefined,
                    dropdownClassName: undefined,
                    options: [],
                    left: { className: undefined },
                    center: { className: undefined },
                    right: { className: undefined },
                    justify: { className: undefined },
                  },
                  fontFamily: { inDropdown: false, options: [] },
                  link: { inDropdown: false, options: [] },
                  history: {
                    inDropdown: false,
                    className: undefined,
                    component: undefined,
                    dropdownClassName: undefined,
                    options: [],
                    undo: { className: undefined },
                    redo: { className: undefined },
                  },
                }}
              />
            </div>
            <DialogActions>
              <Button
                style={{
                  fontFamily: "Ubuntu",
                  fontSize: "12px",
                  textTransform: "capitalize",
                  backgroundColor: "white",
                  // color: "white",
                  marginTop: "10px",

                  color: "0070AD",
                  borderRadius: "25px",
                  padding: "7px 16px",
                  border: "1px solid #0070AD",
                }}
                variant="outlined"
                onClick={IssynopsisClose}
              >
                Close
              </Button>
              <Button
                onClick={handleSynopsisClick}
                style={{
                  fontFamily: "Ubuntu",
                  fontSize: "12px",
                  textTransform: "capitalize",
                  backgroundColor: "#0070AD",
                  // backgroundColor: props.isOwner ? "#0070AD" : "#BFBFBF",
                  // color: "white",
                  color: "white",
                  marginTop: "10px",
                  borderRadius: "25px",
                  padding: "7px 16px",
                  border: "1px solid #0070AD",
                  pointerEvents: props.pages === "preview" ? "none" : "block",
                  // pointerEvents: props.isOwner
                  //   ? props.pages === "preview"
                  //     ? "none"
                  //     : "block"
                  //   : "none",
                }}
                variant="outlined"
              >
                OK
              </Button>
            </DialogActions>
          </DialogContent>
        </Dialog>
        {/* </div> */}
      </div>
      <SuccssMsg
        showAlertBox={showAlertBox}
        setShowAlertBox={setShowAlertBox}
        message={successMessage}
      />
    </div>
  );
}
