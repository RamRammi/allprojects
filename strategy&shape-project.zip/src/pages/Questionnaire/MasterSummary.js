import react from "react";
import "./MasterSummary.css";
import { useNavigate } from "react-router-dom";
import Navbar from "../../components/Navbar/Navbar";
import Button from "@mui/material/Button";
import SearchBar from "../../components/SearchBar/SearchBar";
import * as Api from "../../comman/api";
import * as Constant from "../../comman/constant";
import { useEffect } from "react";
import { useState } from "react";
import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import Typography from "@mui/material/Typography";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import { TextField } from "@mui/material";
import { dateFormat } from "../../comman/utils";
import { setMasterSummarySearch } from "../../redux/actions/questionnaireAction";
import { useSelector, useDispatch } from "react-redux";
import { Pagination } from "@mui/material";
import {
  setTemplateId,
  setRedirectFrom,
} from "../../redux/actions/questionnaireAction";

const MasterSummary = (props) => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [masterSummary, setMasterSummary] = useState([]);
  const [tempId, setTempId] = useState(0);

  const [search, setSearch] = useState("");
  const [pageCount, setPagepageCount] = useState(0);
  const [rows, setRows] = useState([]);
  const [rowsPerPage, setRowsPerPage] = useState(25);
  const [page, setPage] = useState(0);
  const projectId = useSelector(
    (state) => state.questionnaireReducer.projectId
  );
  const clientId = useSelector((state) => state.questionnaireReducer.clientId);
  const userId = useSelector((state) => state.questionnaireReducer.userId);

  useEffect(() => {
    setPage(0);
    if (masterSummary.length > 0) {
      let pageCounts = Math.ceil(masterSummary.length / rowsPerPage);
      setPagepageCount(pageCounts);
    }
  }, [rowsPerPage, masterSummary]);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event, 10));
    setPage(0);
  };

  const emptyRows =
    page > 0 ? Math.max(0, (1 + page) * rowsPerPage - masterSummary.length) : 0;

  const navigateAllSynopsis = () => {
    navigate("/InterviewSynopsis");
  };

  const tempIdSet = (tempId) => {
    setTempId(tempId);
  };

  function searchText(e) {
    setSearch(e.target.value);
  }

  const viewQuestionnaire = (templateId) => {
    dispatch(setTemplateId(templateId));
    dispatch(setRedirectFrom(""));
    navigate("/Preview");
  };
  function removeTags(str) {
    if (str === null || str === "") return "";
    else str = str.toString();

    // Regular expression to identify HTML tags in
    // the input string. Replacing the identified
    // HTML tag with a null string.
    return str.replace(/(<([^>]+)>)/gi, "");
  }

  useEffect(() => {
    const keyDownHandler = (event) => {
      if (event.key === "Enter") {
        event.preventDefault();
        masterSearch();
      }
    };

    if (search === "") {
      masterSearch();
    }

    document.addEventListener("keydown", keyDownHandler);
    return () => {
      document.removeEventListener("keydown", keyDownHandler);
    };
  }, [search]);
  //function to remove tags

  function removeTags(str) {
    if (str === null || str === "") return "";
    else str = str.toString();

    // Regular expression to identify HTML tags in
    // the input string. Replacing the identified
    // HTML tag with a null string.
    return str.replace(/(<([^>]+)>)/gi, "");
  }

  const masterSearch = () => {
    let data = {
      projectId: projectId,
      clientId: clientId,
      userId: userId,
      search: search,
    };
    let URL = "";
    URL = Constant.MASTER_SEARCH;

    Api.master_Summary_search(URL, data).then((res) => {
      setMasterSummary(res);
    });
  };

  const getHighlightedText = (text, higlight) => {
    // Split text on higlight term, include term itself into parts, ignore case
    if (higlight !== "") {
      var parts = text.split(new RegExp(`(${higlight})`, "gi"))
      return (
        <div style={{ display: "block" }}>
          {parts.map((part, index) => (
            <span style={{ backgroundColor: part.toLowerCase() === higlight.toLowerCase() ? "#e8bb49" : "white" }}>{part}</span>
          ))}
        </div>
      )
    } else {
      return text
    }
  }

  return (
    <div className="Master-page">
      <div>
        <Navbar />
        <div className="master-summary">
          <h2 className="Master-header">Master Summary</h2>
          <div
            className="master_header_div"
            style={{ display: "flex", justifyContent: "space-between" }}
          >
            <div>
              <SearchBar searchText={searchText} searchStr={search} />
            </div>
            <div>
              <Button className="master-button" onClick={navigateAllSynopsis}>
                View All Synopisis
              </Button>
            </div>
          </div>
        </div>

        {masterSummary
          .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
          .map((obj, index) => {
            return (
              <div>
                <Accordion>
                  <AccordionSummary
                    className="Accordion_expend"
                    onClick={() => tempIdSet(obj.templateId)}
                    expandIcon={<ExpandMoreIcon className="icon" />}
                    aria-controls="panel1a-content"
                    id="panel1a-header"
                  >
                    <p className="number-heading">{index + 1}.</p>
                    <Typography className="questionnaire-heading">
                      {" "}
                      {/* {obj.templatename}{" "} */}
                      {getHighlightedText(obj.templatename,search)}
                    </Typography>
                  </AccordionSummary>
                  <AccordionDetails className="matersummary_accordionDetails">
                    <div class="accordion-div">
                      <Typography>
                        <Typography className="level">
                          <span className="label-master">Interviewee</span>
                        </Typography>
                        <TextField
                          className="textfield-master"
                          id="outlined-basic"
                          variant="outlined"
                          placeholder=""
                          value={obj.projectInterviewee}
                          inputProps={{ autoComplete: "off" }}
                          size="small"
                        />
                      </Typography>

                      <Typography>
                        <Typography className="level">
                          <span className="label-master">Interviewer</span>
                        </Typography>
                        <TextField
                          className="textfield-master"
                          id="outlined-basic"
                          variant="outlined"
                          value={obj.projectInterviewer}
                          placeholder=""
                          inputProps={{ autoComplete: "off" }}
                          size="small"
                        />
                      </Typography>

                      <Typography>
                        <Typography className="level">
                          <span className="label-master">Job Title</span>
                        </Typography>
                        <TextField
                          className="textfield-master"
                          id="outlined-basic"
                          variant="outlined"
                          value={obj.jobTitle}
                          placeholder=""
                          inputProps={{ autoComplete: "off" }}
                          size="small"
                        />
                      </Typography>

                      <Typography>
                        <Typography className="level">
                          <span className="label-master">Date</span>
                        </Typography>
                        <TextField
                          className="datefield-master"
                          id="outlined-basic"
                          variant="outlined"
                          value={dateFormat(obj.date)}
                          placeholder=""
                          inputProps={{ autoComplete: "off" }}
                          size="small"
                        />
                      </Typography>
                    </div>

                    <div class="textField-accordion">
                      <Typography>
                        <span className="Interview_synop_span">
                          Interview Synopisis
                        </span>
                        <TextField
                          className="synopis-textField-master"
                          multiline
                          rows={4}
                          id="outlined-basic "
                          variant="outlined"
                          value={removeTags(obj.synopsis)}
                          placeholder=""
                          inputProps={{ autoComplete: "off" }}
                        />

                        <Button
                          className="master-button-footer"
                          onClick={() => {
                            viewQuestionnaire(obj.templateId);
                          }}
                        >
                          View Questionnaire
                        </Button>
                      </Typography>
                    </div>
                    <div></div>
                  </AccordionDetails>
                </Accordion>
              </div>
            );
          })}
        {/* pagination start */}
        {masterSummary.length ? (
          ""
        ) : (
          <div
            style={{
              marginTop: "20px",
              display: "flex",
              justifyContent: "center",
            }}
          >
            <div
              style={{
                color: "#707070DE",
                textAlign: "center",
                alignItems: "center",
                marginLeft: "20px",
                textAlign: "center",
                width: "520px",
                padding: "64px 20px",
                fontSize: "16px",
              }}
            >
              <em>No Record Found</em>
            </div>
          </div>
        )}
        {masterSummary.length ? (
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              margin: "20px",
              paddingBottom: "20px",
            }}
          >
            <Typography
              style={{
                display: "inline-block",
                font: "ubuntu",
                color: "#707070DE",
              }}
            >
              Page {page + 1} of {pageCount}
            </Typography>
            <div className="Pagination">
              <Pagination
                count={pageCount}
                defaultPage={1}
                boundaryCount={2}
                onChange={handleChangePage}
              />
            </div>
            <Typography
              style={{
                color: "#707070DE",
              }}
            >
              Show{" "}
              <button
                style={{
                  border: "none",
                  font: "ubuntu",
                  backgroundColor: "white",
                  marginRight: "5px",
                  fontSize: "16px",
                  color: "#0070AD",
                }}
                onClick={() => handleChangeRowsPerPage(25)}
              >
                25
              </button>
              <button
                style={{
                  border: "none",
                  font: "ubuntu",
                  backgroundColor: "white",
                  marginRight: "5px",
                  fontSize: "16px",
                  color: "#0070AD",
                }}
                onClick={() => handleChangeRowsPerPage(50)}
              >
                50
              </button>
              <button
                style={{
                  border: "none",
                  font: "ubuntu",
                  backgroundColor: "white",
                  fontSize: "16px",
                  color: "#0070AD",
                }}
                onClick={() => handleChangeRowsPerPage(masterSummary.length)}
              >
                All
              </button>
            </Typography>
          </div>
        ) : (
          ""
        )}
      </div>
    </div>
  );
};

export default MasterSummary;
