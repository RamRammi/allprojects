import React from "react";
import { Typography } from "@mui/material";
import "./RespondContent.css";

import Attach from "../../Images/attach.png";
import { useState, useEffect } from "react";
import dayjs from "dayjs";
import Remove from "../../Images/Remove.png";
import Button from "@mui/material/Button";
import OutlinedInput from "@mui/material/OutlinedInput";
import InputLabel from "@mui/material/InputLabel";
import FormControl from "@mui/material/FormControl";
import Pdf from "../../Images/pdf.png";
import TextField from "@mui/material/TextField";
import MenuItem from "@mui/material/MenuItem";
import Select from "@mui/material/Select";
import Radio from "@mui/material/Radio";
import RadioGroup from "@mui/material/RadioGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import FormLabel from "@mui/material/FormLabel";
import { fontFamily } from "@mui/system";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { useTheme } from "@mui/material/styles";
import { DesktopDatePicker } from "@mui/x-date-pickers/DesktopDatePicker";
import { isValidDateValue } from "@testing-library/user-event/dist/utils";
import { dateFormatchange } from "../../comman/utils";
import TextareaAutosize from '@mui/base/TextareaAutosize';
// import FormControl from '@mui/material/FormControl';
// import Select from '@mui/material/Select';

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 2.5 + ITEM_PADDING_TOP,
      width: 150,
      fontSize: 14,
    },
  },
};

const names = ["Yes", "No"];
function getStyles(name, personName, theme) {
  return {
    fontWeight:
      personName.indexOf(name) === -1
        ? theme.typography.fontWeightRegular
        : theme.typography.fontWeightMedium,
  };
}
// const MenuProps = {
//   style: {
//     minHeight: "40px",
//     width: 200,
//   },
// };

function RespondContent(props) {
  const [questionList, setQuestionList] = useState([]);
  const [value, setValue] = React.useState(null);
  const [datevalue, setDateValue] = useState(new Date());

  const [dateval, setDateval] = React.useState();
  const [options, setOptions] = React.useState();
  const [rangeto, setRangeTo] = React.useState("");
  const [rangefrom, setRangeform] = React.useState("");
  const [rangevalues, setRangevalues] = React.useState();
  const [logicval, setLogicval] = React.useState();
  const [finalobj, setFinalobj] = React.useState({});
  const [clientquestion, setClientQuestion] = React.useState([]);
  const [objval, setObjval] = React.useState({});

  useEffect(() => {
    setQuestionList(props.respondQuestionList);
  }, [props.respondQuestionList]);

  const handleChange = (value, index, type, secondValue) => {
    if (props.pages === "response") props.setIsChanged(true);

    props.responseList[index] = value;
    props.respondQuestionList[index].response = value;
    if (type === "date") {
      var key = `dateval${index}`;
      var val = dateFormatchange(value.toISOString());
      // let ar = []
      var obj = {};
      obj[key] = val;
      setObjval(obj);
      props.responseList[index] = value.toISOString();
      props.respondQuestionList[index].response = dateFormatchange(
        value.toISOString()
      );
    }

    if (type === "min") {
      props.responseList[index] = value + "," + secondValue;
      questionList[index].response = [value, secondValue];
    }
    if (type === "max") {
      props.responseList[index] = secondValue + "," + value;
      questionList[index].response = [secondValue, value];
    }
  };

  const theme = useTheme();

  const [personName, setPersonName] = React.useState([]);

  const YesNOhandleChange = (event, index) => {
    props.responseList[index] = event.target.value === "Yes" ? 1 : 0;
    // const verl = [event.target.value]
    // var key =  `yesno${event.target.id}`
    // var val = typeof verl === 'string' ? verl.split(',') : verl
    // var obj  = {}
    // obj[key] = val
    // setObjval(obj)
    setPersonName(
      typeof event.target.value === "string"
        ? event.target.value.split(",")
        : event.target.value
    );
    // const {
    //   target: { value },
    // } = event;
    // setPersonName(
    //   // On autofill we get a stringified value.
    //   typeof value === 'string' ? value.split(',') : value,
    // );
  };
  const handleOptions = (option, index) => {
    props.responseList[index] = option;
    setOptions(option);
  };
  const handleDatechange = async (newValue, index) => {
    // props.responseList[index] = newValue.toISOString();
    var key = `dateval${index}`;
    var val = newValue;
    var obj = {};
    obj[key] = val;
    setObjval(obj);
    // await setDateValue(newValue);
  };
  const handlerangechangemin = (e, value, index) => {
    props.responseList[index] = `${value},${rangeto}`;
    var key = `rangefrom${e.target.id}`;
    var val = value;
    var obj = {};
    obj[key] = val;
    setObjval(obj);
    // objval.push(obj)
    // this.setState(obj)
    // setRangeform(obj)
  };
  const handlerangechangemax = (e, value, index) => {
    props.responseList[index] = `${rangefrom},${value}`;
    var key = `rangeto${e.target.id}`;
    var val = value;
    var obj = {};
    obj[key] = val;
    setObjval(obj);
    setRangeTo(value);
  };
  const conarr = (value, index) => {
    let str1 = value;
    const split_string = str1.split(",");
    return split_string;
  };
  return (
    <div className="Respond_content_main">
      <div className="Respond_content_sub">
        <Typography
        // style={{
        //   fontFamily: "Ubuntu",
        //   fontSize: "15px",
        //   marginBottom: "30px",
        // }}
        >
          Hi, When you submit this form, the owner will see your name and email
          address.
        </Typography>
        <div className="box-style">
          {questionList.map((value, index) => {
            return (
              <div
                style={{
                  marginTop: "45px",
                  pointerEvents: props.pages === "preview" ? "none" : "block",
                }}
              >
                <div
                  className="respond_content_Sno"
                  style={{
                    float: "left",
                    fontFamily: "Ubuntu",
                    fontSize: "16px",
                  }}
                >
                  {index + 1}
                </div>
                <div
                  className="respond_content-css "
                  style={{
                    marginLeft: "50px",
                    fontFamily: "Ubuntu",
                    fontSize: "16px",
                  }}
                >
                  {value.cQuestionDesc ? value.cQuestionDesc : value.queDesc}
                  {/* {value.response ? value.response : value.queResponse} */}
                </div>
                {/* <div>
                  <Button style={{ marginLeft: "30px" }}>
                    <img src={Attach}></img>
                  </Button>
                  <Button
                    readOnly={props.pageNames === "preview" ? true : false}
                    className="button-respond"
                  >
                    File Name
                  </Button>
                </div> */}
                {value.cQuestionType === "Date" || value.type === "Date" ? (
                  //  <input type="date" onChange={(newValue) => {
                  //   handleDatechange(newValue)}}
                  // data-date-format="DD/MMMM/YYYY"  />
                  <>
                    <LocalizationProvider dateAdapter={AdapterDayjs}>
                      <DatePicker
                        disabled={props.pages === "preview" ? true : false}
                        className="respond-margin-date"
                        value={
                          value.taskStatus === "Completed" ||
                          value.taskStatus === "Pending"
                            ? questionList[index].response
                            : objval[`dateval${index}`]
                        }
                        // defaultValue={
                        //   value.response
                        //     ? value.response.value
                        //     : value.queResponse
                        // }
                        id={index}
                        onChange={(newValue) => {
                          handleChange(newValue, index, "date");
                        }}
                        renderInput={(params) => (
                          <TextField
                            className="respones_date_textfiled"
                            {...params}
                            variant="outlined"
                            size="small"
                          />
                        )}
                      />
                    </LocalizationProvider>
                  </>
                ) : value.cQuestionType === "textbox" ||
                  value.type === "textbox" ? (
                    <TextareaAutosize
                    aria-label="minimum height"
                    minRows={1.5}
                    placeholder="Enter Text"
                    style={{ 
                    
                      // width: "90%",
                      marginLeft: "50px",
                      // marginBottom: "30px",
                      marginRight: "10px",
                     minWidth :"1050px",
                     padding: "5px 0px 0px 8px",
                     maxWidth: "1050px",
                     minHeight : "30px",
                      border: "1px solid #828282", }}
               
                    disabled={props.pages === "preview" ? true : false}
                    defaultValue={
                      value.response ? value.response : value.queResponse
                    }
                    // readOnly={props.pageNames==="preview" ? true:false}
                    className="input-style"
                    id="outlined-basic"
                  
                    onChange={(e) => handleChange(e.target.value, index, value)}
                    />
                ) : value.cQuestionType === "Logical" ||
                  value.type === "Logical" ? (
                  <div className="respond-margin">
                    <FormControl sx={{ m: 1, width: 150, mt: 3 }}>
                      <Select
                        className="yes-no_textC"
                        // multiple
                        disabled={props.pages === "preview" ? true : false}
                        displayEmpty
                        defaultValue={
                          value.response ? value.response : value.queResponse
                        }
                        // value={objval[`yesno${value.cQuestionId}`]}
                        id={`yesno${value.cQuestionId}`}
                        onChange={(e) => handleChange(e.target.value, index)}
                        input={<OutlinedInput />}
                        // renderValue={(selected) => {
                        //   if (selected.length === 0) {
                        //     return <em>Yes / No</em>;
                        //   }

                        //   return selected.join(', ');
                        // }}
                        MenuProps={MenuProps}
                        inputProps={{ "aria-label": "Without label" }}
                      >
                        {/* <MenuItem disabled value="">
            <em>Placeholder</em>
          </MenuItem> */}
                        {names.map((name) => (
                          <MenuItem
                            className="yes-no_css"
                            key={name}
                            value={name}
                            style={getStyles(name, personName, theme)}
                          >
                            <span> {name}</span>
                          </MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </div>
                ) : value.cQuestionType === "Range of Values" ||
                  value.type === "Range of Values" ? (
                  <div className="Vertical respond-margin_range">
                    <TextField
                      defaultValue={value.response[0]}
                      onChange={(e) =>
                        handleChange(
                          e.target.value,

                          index,

                          "min",

                          value.response[1]
                        )
                      }
                      placeholder="Enter value"
                    />{" "}
                    <hr className="hor_Line"></hr>
                    <TextField
                      defaultValue={value.response[1]}
                      onChange={(e) =>
                        handleChange(
                          e.target.value,

                          index,

                          "max",

                          value.response[0]
                        )
                      }
                      placeholder="Enter value"
                    />{" "}
                  </div>
                ) : value.cQuestionType === "Multiple Choice Questions" ||
                  value.type === "Multiple Choice Questions" ? (
                  <FormControl className="respond-margin">
                    <RadioGroup
                      name="radio-buttons-group"
                      sx={{ my: 1 }}
                      defaultValue={value.response}
                    >
                      {value.taskStatus !== "Completed" ? (
                        value &&
                        value.multipleChoiceQuestionOptionList !== null ? (
                          value.multipleChoiceQuestionOptionList.length > 0 ? (
                            value.multipleChoiceQuestionOptionList.map(
                              (option, index1) => {
                                return (
                                  <span key={index1}>
                                    <Radio
                                      value={option}
                                      disabled={
                                        props.pages === "preview" ? true : false
                                      }
                                      onChange={() =>
                                        handleChange(option, index)
                                      }
                                    />
                                    <TextField
                                      style={{
                                        pointerEvents: "none",
                                      }}
                                      value={option}
                                      disabled={
                                        props.pages === "preview" ? true : false
                                      }
                                    />
                                  </span>
                                );
                              }
                            )
                          ) : null
                        ) : null
                      ) : (
                        <span>
                          {/** Add Checkbox */}
                          {/* <Radio value={value.response} checked /> */}
                          <TextField
                            style={{
                              pointerEvents: "none",
                            }}
                            value={value.response}
                            checked
                          />
                        </span>
                      )}
                    </RadioGroup>
                  </FormControl>
                ) : null}

                {/* <LocalizationProvider dateAdapter={AdapterDayjs}>
<DesktopDatePicker
          // label="For desktop"
          value={datevalue}
          minDate={dayjs('2017-01-01')}
          onChange={(newValue) => {
            handleDatechange(newValue)
            
          }}
          renderInput={(params) => <TextField {...params} />}
        />
    </LocalizationProvider> */}

                {/* <div>
      <FormControl sx={{ m: 1, width: 150, mt: 3 }}>
        <Select
          // multiple
          displayEmpty
          value={personName}
          onChange={YesNOhandleChange}
          input={<OutlinedInput />}
          renderValue={(selected) => {
            if (selected.length === 0) {
              return <span>yes / No</span>;
            }

            return selected.join(', ');
          }}
          // MenuProps={MenuProps}
          inputProps={{ 'aria-label': 'Without label' }}
        >
       
          {names.map((name) => (
            <MenuItem
              key={name}
              value={name}
             
            >
              {name}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
    </div> */}
                {/* <div className="Vertical">
    <TextField  placeholder="Enter value"/> <hr className="hor_Line"></hr>
    <TextField  placeholder="Enter value"/>
    </div> */}

                {/* <FormControl>
 
      <RadioGroup  name="radio-buttons-group" sx={{ my: 1 }}>
        <span><Radio value="option 1"  />
        <TextField  placeholder="Enter value"/>
        </span>
        <span><Radio value="option 2"  />
        <TextField  placeholder="Enter value"/>
        </span>
        <span><Radio value="option 3"  />
        <TextField  placeholder="Enter value"/>
        </span>
       
      </RadioGroup>

    </FormControl> */}
                {/* <Button style={{ display: "inline-block" }}>
                  <img src={Pdf}></img>
                </Button> */}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

export default RespondContent;
