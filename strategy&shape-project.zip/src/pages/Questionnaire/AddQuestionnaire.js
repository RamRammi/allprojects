import React from "react";
import { useState } from "react";
import AddQuestionnaireTable from "../../components/Table/AddQuestionnaireTable";
import SearchBar from "../../components/SearchBar/SearchBar";
import "../../components/Filters/FilterData.css";
import "../../pages/Questionnaire/Questionnaire.css";
import Button from "@mui/material/Button";
import { useEffect } from "react";
import { useLocation } from "react-router-dom";
import RespondFilterData from "./RespondFilterData";
import RenameQuestionnaire from "../../components/PopUp/RenameQuestionnaire";
import "./AddQuestionnaire.css";
import { useNavigate } from "react-router-dom";
import Navbar from "../../components/Navbar/Navbar";
import SuccssMsg from "../../components/AlertBox/SuccessMsg";
import WarningMsg from "../../components/AlertBox/WarningMsg";
import FooterButtons from "./FooterButtons";
import * as Api from "../../comman/api";
import * as Constant from "../../comman/constant";
import CommonModal from "../../components/PopUp/ExpendPopup/modal";
import { ResponseContext } from "../../comman/context.js";

import { useSelector, useDispatch } from "react-redux";
import {
  setTemplateId,
  setPId,
  setSavedQuestions,
  setQuestionnaireState,
  setRedirectFrom,
  setTemplateStatus,
  setTemplateName,
} from "../../redux/actions/questionnaireAction";
import AddQuestionnaireDetailsFilter from "../../components/Filters/AddQuestionnaireDetailsFilter";

const AddQuestionnaire = (props) => {
  const pageName = "addQuestionnaire";
  const location = useLocation();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  // const [questionnaireName, setQuestionnaireName] = React.useState("Untitled");
  const [parentTemplateName, setParentTemplateName] = React.useState("");
  const [searchStr, setSearchStr] = React.useState("");
  const [finalQuestionList, setFinalQuestionList] = React.useState([]);
  const [showAlertBox, setShowAlertBox] = React.useState(false);
  const [successMessage, setSuccessMessage] = React.useState("File Saved");
  const [showWarningBox, setShowWarningBox] = React.useState(false);
  const [warningMessage, setWarningMessage] = React.useState("");
  const [open, setOpen] = React.useState(false);
  const [openExport, setOpenExport] = React.useState(false);
  const [rows, setRows] = React.useState([]);
  const [interviewee, setInterviewee] = useState("");
  const [interviewer, setInterviewer] = useState("");
  const [jobTitle, setJobTitle] = useState("");
  const [date, setDate] = useState(new Date());
  const [isChanged, setIsChanged] = useState(false);
  const [isOwner, setIsOwner] = useState(true);
  // const [templateId, setTemplateId] = React.useState(0);
  // const [pId, SetPId] = React.useState(0);

  const projectId = useSelector(
    (state) => state.questionnaireReducer.projectId
  );
  const projectName = useSelector(
    (state) => state.questionnaireReducer.projectName
  );
  const clientId = useSelector((state) => state.questionnaireReducer.clientId);
  const userId = useSelector((state) => state.questionnaireReducer.userId);
  const email = useSelector(
    (state) => state.questionnaireReducer.userData.email
  );
  const clientName = useSelector(
    (state) => state.questionnaireReducer.userData.clientName
  );
  const templateId = useSelector(
    (state) => state.questionnaireReducer.templateId
  );
  const pId = useSelector((state) => state.questionnaireReducer.pId);
  const savedQuestions = useSelector(
    (state) => state.questionnaireReducer.savedQuestions
  );
  const questionnaireState = useSelector(
    (state) => state.questionnaireReducer.questionnaireState
  );
  const generalQ = useSelector(
    (state) => state.questionnaireReducer.generalQuestion
  );
  const leadershipQ = useSelector(
    (state) => state.questionnaireReducer.leadershipQuestion
  );
  const roleQ = useSelector((state) => state.questionnaireReducer.roleQuestion);
  const questionnaireEvent = useSelector(
    (state) => state.questionnaireReducer.questionnaireEvent
  );
  const questionnaireName = useSelector(
    (state) => state.questionnaireReducer.templateName
  );
  const firstName = useSelector(
    (state) => state.questionnaireReducer.userData.firstName
  );
  const lastName = useSelector(
    (state) => state.questionnaireReducer.userData.lastName
  );
  const [questionData, setQuestionData] = React.useState({
    selectedQuestions: [],
    leaderShipCategoryId: 0,
  });
  const [renameTemplate, setRenameTemplate] = React.useState(0);
  const currentDate = new Date();

  useEffect(() => {
    if (questionnaireEvent === "addQuestionnaire") {
      let newArr = [];
      let selectedQuestions = [];
      selectedQuestions = selectedQuestions.concat(
        generalQ,
        leadershipQ,
        roleQ
      );
      var uniqueResultArrayObjOne = selectedQuestions.filter(function (objOne) {
        return !savedQuestions.some(function (objTwo) {
          return objOne.questionDesc == objTwo.questionDesc;
        });
      });
      newArr = newArr.concat(savedQuestions, uniqueResultArrayObjOne);
      dispatch(setSavedQuestions(newArr));
      setRows(newArr);
    }
  }, []);

  useEffect(() => {
    if (pId !== 0 && templateId !== 0) {
      if (questionnaireState !== "edit") getQuestionnaireData(pId, templateId);
    }
  }, []);

  useEffect(() => {
    if (renameTemplate !== 0) savetemplate();
  }, [renameTemplate]);

  const getQuestionnaireData = (pId, templateId) => {
    let URL =
      Constant.GET_QUESTIONNAIRE_DATA_BY_TEMPLATEID +
      "?templateId=" +
      templateId +
      "&projectId=" +
      projectId +
      "&clientId=" +
      clientId;
    // +
    // "&createdByEmail=" +
    // email;
    //"&userId=" +userId;
    Api.getQuestionnaireData(URL).then((res) => {
      // setInterviewee(interviewee);
      // setInterviewer(interviewer);
      // setJobTitle(jobTitle);
      setInterviewee(res.interviewee);
      setInterviewer(res.interviewer);
      setJobTitle(res.jobTitle);
      setDate(res.projectCreateDate);
      setIsOwner(res.isOwner);
      // setDate(res.)
      dispatch(setTemplateName(res.templateName));
      setParentTemplateName(res.templateName);
      dispatch(setTemplateId(res.templateId));
      dispatch(setPId(pId));
      setQuestionData({
        selectedQuestions: res.selectedQuestions,
        leaderShipCategoryId: res.leaderShipCategoryId,
      });
      dispatch(setSavedQuestions(res.selectedQuestions));
      setRows(res.selectedQuestions);
      //dispatch(setQuestionnaireState("edit"));
    });
  };

  const searchText = (event) => {
    setSearchStr(event.target.value);
  };

  const openAlertBox = () => {
    setShowAlertBox(true);
  };
  const openWarningBox = () => {
    setShowWarningBox(true);
  };

  const savetemplate = () => {
    let arr = [];
    finalQuestionList.map((value, index) => {
      arr.push({
        cQuestionId: 0,
        clientId: clientId,
        projectId: 0,
        cQuestionDesc: value.questionDesc,
        industryId: 0,
        functionId: 0,
        designation: 0,
        categoryId: value.categoryId ? value.categoryId : 0,
        type: value.type,
        //  date: date,
        valueRangeUpper: 0,
        valueRangeLower: 0,
        logical: 0,
        priority: 0,
        valuedriverId: 0,
        createdBy: userId,
        createdDate: currentDate.toISOString(),
        modifiedBy: userId,
        modifiedDate: currentDate.toISOString(),
        leaderShipCategoryId: value.leaderShipCategoryId,
        roleId: value.roleId,
        multipleChoiceQuestion:
          value.type === "Multiple Choice Questions"
            ? value.multipleChoiceQuestion
              ? value.multipleChoiceQuestion
              : value.multipleChoiceQuestionOptionList.join(",")
            : null,
      });
    });
    let data = {
      project: {
        //this code is for update the exiting questionnaire
        id: pId,
        projectId: projectId,
        clientId: clientId,
        clientName: clientName,
        projectName: projectName,
        projectInterviewer: interviewer,
        projectInterviewee: interviewee,
        createdDate: date,
        projectCreateDate: date,
        createdBy: userId,
        modifiedDate: currentDate.toISOString(),
        modifiedBy: userId,
        jobTitle: jobTitle,
      },
      template: {
        //this code is for update the exiting questionnaire
        templateId: templateId,
        name: questionnaireName,
        assignTo: "0",
        createdDate: currentDate.toISOString(),
        createdBy: userId,
        modifiedBy: userId,
        modifiedDate: currentDate.toISOString(),
        createdByEmail: email,
      },
      clientquestion: arr,
      templatecomments: {
        fullName:
          firstName.charAt(0).toLocaleUpperCase() +
          lastName.charAt(0).toLocaleUpperCase(),
      },
    };

    Api.saveQuestionnaireTemplate(
      Constant.ADD_QUESTIONNIRE_TEMPLATE,
      data
    ).then((res) => {
      setRenameTemplate(0);
      if (res.code === 1) {
        setSuccessMessage(res.message);
        openAlertBox();
        dispatch(setTemplateId(res.templateId));
        dispatch(setPId(res.pId));
      } else {
        dispatch(setTemplateName("Untitled"));
        setWarningMessage(res.message);
        openWarningBox();
      }
    });
  };

  const saveQuestionnaire = () => {
    if (
      questionnaireName === "" ||
      questionnaireName === "Untitled"
      //   questionnaireName === parentTemplateName ||
      //    templateId !== 0
    ) {
      setOpen(true);
    } else {
      savetemplate();
    }
  };

  const previewPage = () => {
    dispatch(setRedirectFrom("AddQuestionnaire"));
    dispatch(setPId(pId));
    dispatch(setTemplateId(templateId));
    dispatch(setTemplateStatus("Saved"));
    navigate("/Preview");
  };
  const handleClickOpen = () => {
    setOpenExport(true);
  };
  const handleClose = () => {
    setOpenExport(false);
  };

  return (
    <>
      <Navbar />
      <div className="">
        <div className="questionnaire-name-actions">
          <span className="questionnaire-name">{questionnaireName}</span>
          <RenameQuestionnaire
            // setQuestionnaireName={setQuestionnaireName}
            parentTemplateName={parentTemplateName}
            questionnaireName={questionnaireName}
            open={open}
            setOpen={setOpen}
            renameTemplate={renameTemplate}
            setRenameTemplate={setRenameTemplate}
            saveQuestionnaire={saveQuestionnaire}
          />
          {templateId === 0 ? (
            ""
          ) : (
            <span className="questionnaire-actions">
              <Button
                variant="outlined"
                className="button-export"
                onClick={previewPage}
                disabled={templateId === 0 ? true : false}
              >
                Preview
              </Button>
              <Button
                onClick={handleClickOpen}
                style={{
                  fontFamily: "Ubuntu",
                  fontSize: "12px",
                  backgroundColor: "#0070AD",
                  color: "white",
                  margin: " 10px",
                  borderRadius: "25px",
                  padding: "5px 10px",
                  border: "1px solid #0070AD",
                  textTransform: "capitalize",
                }}
              >
                Export Questionnaire{" "}
              </Button>
              <CommonModal
                pageName={"AddQuestionnaire"}
                open={openExport}
                onClose={() => handleClose()}
                type="export"
                templateId={templateId}
                status={"Saved"}
              />
            </span>
          )}
        </div>
        <hr />

        {/* <ResponseContext.Provider
          value={{
            interviewee,
            interviewer,
            jobTitle,
            date,
            isChanged,
            setInterviewee,
            setInterviewer,
            setJobTitle,
            setDate,
            setIsChanged,
          }}
        > */}
          <AddQuestionnaireDetailsFilter 
          interviewee={interviewee}
          interviewer={interviewer}
          jobTitle={jobTitle}
          date={date}
          isChanged={isChanged}
          setInterviewee={setInterviewee}
          setInterviewer={setInterviewer}
          setJobTitle={setJobTitle}
          setDate={setDate}
          setIsChanged={setIsChanged}
          pageName={pageName} />
        {/* </ResponseContext.Provider> */}
        <SearchBar
          pageName={pageName}
          searchText={searchText}
          // isOwner={isOwner}
        />
        <AddQuestionnaireTable
          searchStr={searchStr}
          tableData={savedQuestions}
          saveQuestionnaire={saveQuestionnaire}
          setFinalQuestionList={setFinalQuestionList}
          rows={rows}
          setRows={setRows}
          // isOwner={isOwner}
        />
      </div>
      <FooterButtons
        saveQuestionnaire={saveQuestionnaire}
        pageName={pageName}
        questionnaireName={questionnaireName}
        templateId={templateId}
        finalquestionlist={finalQuestionList}
        pId={pId}
        finalQuestionList={finalQuestionList}
        // isOwner={isOwner}
      />
      <SuccssMsg
        showAlertBox={showAlertBox}
        setShowAlertBox={setShowAlertBox}
        message={successMessage}
      />
      <WarningMsg
        showWarningBox={showWarningBox}
        setShowWarningBox={setShowWarningBox}
        message={warningMessage}
      />
    </>
  );
};

export default AddQuestionnaire;
