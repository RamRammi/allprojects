import React, { useEffect, useState } from "react";
import Navbar from "../../components/Navbar/Navbar";
import SearchBar from "../../components/SearchBar/SearchBar";
import "./QuestionGallery.css";
import "./MasterSummary.css";
import { Button, TextField, Typography } from "@mui/material";
import { dateFormat } from "../../comman/utils";
import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import * as Api from "../../comman/api";
import * as Constant from "../../comman/constant";
import ProjectSearchBar from "../../components/ProjectSearchBar/ProjectSearchBar";
import { Pagination } from "@mui/material";
import { useSelector } from "react-redux";
import TextareaAutosize from '@mui/base/TextareaAutosize';

const QuestionGallery = () => {
  const [questionGallery, setQuestionGallery] = useState([]);
  const [search, setSearch] = useState("");
  const [rows, setRows] = useState([]);
  const [rowsPerPage, setRowsPerPage] = useState(25);
  const [page, setPage] = useState(0);
  const [pageCount, setPagepageCount] = useState(0);
  const [expand, setExpand] = useState(false);
  const [expandedIndex, setExpandedIndex] = useState([]);
  const projectId = useSelector(
    (state) => state.questionnaireReducer.projectId
  );
  const clientId = useSelector((state) => state.questionnaireReducer.clientId);

  useEffect(() => {
    setPage(0);
    if (questionGallery.length > 0) {
      let pageCounts = Math.ceil(questionGallery.length / rowsPerPage);
      setPagepageCount(pageCounts);
    }
  }, [rowsPerPage, questionGallery]);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event, 10));
    setPage(0);
  };

  const emptyRows =
    page > 0
      ? Math.max(0, (1 + page) * rowsPerPage - questionGallery.length)
      : 0;

  useEffect(() => {
    const keyDownHandler = (event) => {
      if (event.key === "Enter") {
        event.preventDefault();
        gallerySearchApi();
      }
    };

    if (search === "") {
      gallerySearchApi();
    }

    document.addEventListener("keydown", keyDownHandler);

    return () => {
      document.removeEventListener("keydown", keyDownHandler);
    };
  }, [search]);

  function searchText(e) {
    setSearch(e.target.value);
  }

  //fetch call for search

  const gallerySearchApi = () => {
    let URL = "";
    URL =
      Constant.QUESTION_GALLERY_SEARCH +
      "?projectId=" +
      projectId +
      "&clientId=" +
      clientId +
      "&search=" +
      search;

    Api.GallerySearch(URL).then((res) => {
      setQuestionGallery(res);
    });
  };

  //fetch call

  const questionGalleryAPIData = () => {
    Api.getQuestionGallery(Constant.GET_QUESTION_GALLERY).then((res) => {
      setQuestionGallery(res);
    });
  };

  const getHighlightedText = (text, higlight) => {
    // Split text on higlight term, include term itself into parts, ignore case
    if (higlight !== "") {
      var parts = text.split(new RegExp(`(${higlight})`, "gi"))
      return (
        <div style={{ display: "block" }}>
          {parts.map((part, index) => (
            <span style={{ backgroundColor: part.toLowerCase() === higlight.toLowerCase() ? "#e8bb49" : "white" }}>{part}</span>
          ))}
        </div>
      )
    } else {
      return text
    }
  }

  function expandOnClick(e) {
    e.preventDefault();
    setExpand(!expand);
    if (expand) {
      document.querySelector(".ExpAll").innerHTML = "Expand All";
    } else {
      document.querySelector(".ExpAll").innerHTML = "Collapse All";
    }
  }

  function handleChange(index) {
    let expanded = [...expandedIndex];
    if (expanded && expanded.includes(index)) {
      expanded.splice(expanded.indexOf(index), 1);
    } else {
      expanded.push(index);
    }

    setExpandedIndex(expanded);
  }

  return (
    <div className="Master-page">
      <div>
        <Navbar />
        <div className="master-summary">
          <h2 className="Master-header">Question Gallery</h2>

          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <div style={{ width: "350px" }}>
              <SearchBar searchText={searchText} />
            </div>
            <Button
              className="btn ExpAll"
              type="Expand"
              onClick={expandOnClick}
            >
              {" "}
              Expand All{" "}
            </Button>
          </div>
        </div>
        <div className="gallery">
          <p className="Gallery-questions-heading">Questions</p>
        </div>

        {questionGallery
          .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
          .map((obj, index) => {
            return (
              <div>
                <Accordion
                  expanded={expand || expandedIndex.includes(index)}
                  onChange={() => handleChange(index)}
                >
                  <AccordionSummary
                    className="Accordion_expend"
                    //   onClick={()=>tempIdSet(obj.templateId)}
                    expandIcon={<ExpandMoreIcon className="icon" />}
                    aria-controls="panel1a-content"
                    id="panel1a-header"
                  >
                    <p className="question-number">{index + 1}.</p>
                    <Typography className="questionnaire-heading">
                      {" "}
                      {/* {obj.cQuestionDesc}{" "} */}
                      {getHighlightedText(obj.cQuestionDesc,search)}
                    </Typography>
                  </AccordionSummary>
                  <AccordionDetails className="questionGallary_accordionDetails">
                    {obj.responseList.map((obj1, index) => {
                      return (
                        <div class="textField-accordion">
                          <Typography className="synopis-textField_typography">
                            <span className="synopis-textField-span">
                              {obj1.name}
                              
                            </span>
                            <TextareaAutosize
                              style={{ 
                    
                                // width: "90%",
                                // marginLeft: "50px",
                                // marginBottom: "30px",
                                marginRight: "10px",
                                marginTop: "10px",
                               minWidth :"1350px",
                               padding: "5px 0px 0px 8px",
                               maxWidth: "1350px",
                               minHeight : "30px",
                                border: "1px solid #828282", }}
                              className="synopis-textField-master"
                              id="outlined-basic"
                              variant="outlined"
                              value={obj1.response}
                              placeholder=""
                              inputProps={{ autoComplete: "off" }}
                           />


                            {/* <Button className="master-button-footer">View Questionnaire</Button> */}
                          </Typography>
                        </div>
                      );
                    })}
                    <div></div>
                  </AccordionDetails>
                </Accordion>
              </div>
            );
          })}

        {questionGallery.length ? (
          ""
        ) : (
          <div
            style={{
              marginTop: "20px",
              display: "flex",
              justifyContent: "center",
            }}
          >
            <div
              style={{
                color: "#707070DE",
                textAlign: "center",
                alignItems: "center",
                marginLeft: "20px",
                textAlign: "center",
                width: "520px",
                padding: "64px 20px",
                fontSize: "16px",
              }}
            >
              <em>No Record Found</em>
            </div>
          </div>
        )}
        {questionGallery.length ? (
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              margin: "20px",
              paddingBottom: "20px",
            }}
          >
            <Typography
              style={{
                display: "inline-block",
                font: "ubuntu",
                color: "#707070DE",
              }}
            >
              Page {page + 1} of {pageCount}
            </Typography>
            <div className="Pagination">
              <Pagination
                count={pageCount}
                defaultPage={1}
                boundaryCount={2}
                onChange={handleChangePage}
              />
            </div>
            <Typography
              style={{
                color: "#707070DE",
              }}
            >
              Show{" "}
              <button
                style={{
                  border: "none",
                  font: "ubuntu",
                  backgroundColor: "white",
                  marginRight: "5px",
                  fontSize: "16px",
                  color: "#0070AD",
                }}
                onClick={() => handleChangeRowsPerPage(25)}
              >
                25
              </button>
              <button
                style={{
                  border: "none",
                  font: "ubuntu",
                  backgroundColor: "white",
                  marginRight: "5px",
                  fontSize: "16px",
                  color: "#0070AD",
                }}
                onClick={() => handleChangeRowsPerPage(50)}
              >
                50
              </button>
              <button
                style={{
                  border: "none",
                  font: "ubuntu",
                  backgroundColor: "white",
                  fontSize: "16px",
                  color: "#0070AD",
                }}
                onClick={() => handleChangeRowsPerPage(questionGallery.length)}
              >
                All
              </button>
            </Typography>
          </div>
        ) : (
          ""
        )}
      </div>
    </div>
  );
};

export default QuestionGallery;
