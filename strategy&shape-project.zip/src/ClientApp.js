import React, { lazy, Suspense, Fragment } from "react";
import { Routes, Route } from "react-router-dom";
import ShapeProgram from "./pages/ShapeProgram";
const TasksAssigned = lazy(() =>
  import("./pages/Client/TasksAssigned/TasksAssigned")
);
const ClientProject = lazy(() => import("./pages/Client/Project/Project"));
const ClientRespond = lazy(() =>
  import("./pages/Client/Questionnaire/Respond")
);

function ClientApp() {
  return (
    <Fragment>
      <Suspense fallback={<div>Loading...</div>}>
        <div className="App"></div>
        <Routes>
          <Route
            exact
            path="/Client/Project"
            element={<ClientProject />}
          ></Route>
          <Route
            exact
            path="/client/tasksAssigned"
            element={<TasksAssigned />}
          ></Route>
          <Route
            exact
            path="/client/respond"
            element={<ClientRespond />}
          ></Route>
          <Route exact path="/shape-program" element={<ShapeProgram />}></Route>
        </Routes>
      </Suspense>
    </Fragment>
  );
}
export default ClientApp;
