export const project = [
  "project1",
  "project2",
  "project3",
  "project4",
  "project5",
];

export const functions = [
  "function1",
  "function2",
  "function3",
  "function4",
  "function5",
];
export const industry = [
  "industry1",
  "industry2",
  "industry3",
  "industry4",
  "industry5",
];
export const designation = [
  "designation1",
  "designation2",
  "designation3",
  "designation4",
  "designation5",
];
